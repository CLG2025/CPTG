CPTG Cluster Active-Gate Integrated Tool v0.5
================================================

Purpose
-------
This tool computes the CPTG cluster active-gate quantities for declared cluster apertures. Version 0.5 adds explicit structural-mode outputs while keeping the baryonic mass-accounting multiplier separate.

Required download
-----------------
Galaxy cluster database: https://drive.switch.ch/index.php/s/j3WUOYXWgv9Jbnz/download

Main calculation chain
----------------------
Input per aperture:
    cluster, z, Delta, R_delta_kpc, Mgas_delta_1e14Msun, Tgate_keV
Optional per aperture:
    Mstar_delta_1e14Msun, MICL_delta_1e14Msun, MHSE_delta_1e14Msun, Mlens_delta_1e14Msun

Computed quantities include:
    F                         = Mbar / Mref
    Q_C                       = theta_T / theta_crit(F)
    y                         = active-gate mass ratio
    M_CPTG_1e14Msun            = y * Mref
    N_cluster_struct           = y * N_C0 / Q_C^2
    N_cluster_closure          = 1 / N_cluster_struct
    N_bar_multiplier           = M_CPTG / Mbar

Important interpretation
------------------------
N_cluster_struct is the true cluster structural response/load mode used in the active-gate equation. It is not the same as M_CPTG/Mbar.

N_bar_multiplier is only a mass-accounting ratio. Do not call it structural mode N.

Modes
-----
Edit MODE in the script CONFIG section. No command-line variables are required.

Available modes:
    csv_single
    csv_ladder
    xcop_archive
    run_all_demo

CSV input files expected by default:
    sample_single_aperture_input.csv
    sample_aperture_ladder_input.csv

X-COP archive mode expects:
    allfiles.tar.gz

Place allfiles.tar.gz beside the script to run xcop_archive mode. The v0.5 release bundle does not include the large X-COP archive.

Output files
------------
Single-aperture outputs:
    outputs/csv_single_results.csv
    outputs/csv_single_gate_summary.csv

Aperture-ladder outputs:
    outputs/csv_ladder_results.csv
    outputs/csv_ladder_gate_summary.csv
    outputs/csv_ladder_cluster_trends.csv
    outputs/csv_ladder_median_trend.csv

X-COP outputs when allfiles.tar.gz is available:
    outputs/xcop_r500_results.csv
    outputs/xcop_r500_gate_summary.csv
    outputs/xcop_ladder_results.csv
    outputs/xcop_ladder_gate_summary.csv
    outputs/xcop_ladder_cluster_trends.csv
    outputs/xcop_ladder_median_trend.csv

Audit/self-tests
----------------
The script runs built-in self-tests by default. The v0.5 self-tests verify:
    A2319 Q_C near 0.680912
    A2319 y near 0.983998
    A2319 N_cluster_struct near 0.4171
    A2319 gate class = suppressed
    ZW1215 Q_C near 1.622944
    ZW1215 N_cluster_struct near 0.0748
    ZW1215 gate class = closure-stable
    suppressed A2319 structural load is higher than closure-stable ZW1215 structural load

Demo sample note
----------------
The included sample_single_aperture_input.csv contains the known A2319 and ZW1215 R500 rows used in the self-tests.

The included sample_aperture_ladder_input.csv is a small schema/demo ladder input. It is intended to exercise the CSV-ladder output path and structural-mode columns. Use the published paper values or an official cluster data product for scientific X-COP/ACCEPT results.
