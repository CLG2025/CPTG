#!/usr/bin/env python3
"""
CPTG Cluster Active-Gate Integrated Tool v0.5

Purpose
-------
One practical script for the CPTG cluster active-gate formula.

Modes:
    csv_single      Process one declared aperture per cluster from CSV.
    csv_ladder      Process multiple apertures per cluster from CSV.
    xcop_archive    Read an X-COP-style allfiles.tar.gz archive directly.
    run_all_demo    Run csv_single, csv_ladder, and xcop_archive if inputs exist.

No command-line arguments are required. Edit the CONFIG block below.

Design priorities:
    - internal variables instead of command-line args
    - visible formula constants
    - repeatable CSV outputs
    - explicit cluster structural-mode outputs
    - separate baryonic mass-accounting multiplier output
    - self-tests
    - audit report
    - automatic ZIP bundle
    - no Astropy dependency for X-COP FITS products
"""

from __future__ import annotations

import csv
import math
import os
import re
import statistics
import tarfile
import zipfile
from pathlib import Path
from typing import Dict, List, Optional, Tuple

try:
    import numpy as np
except Exception as exc:
    raise RuntimeError("This script requires numpy for FITS binary-table reading.") from exc


# =============================================================================
# CONFIG: edit these internal variables instead of command-line arguments
# =============================================================================

MODE = "run_all_demo"
# Options:
#   "csv_single"
#   "csv_ladder"
#   "xcop_archive"
#   "run_all_demo"

SINGLE_INPUT_CSV = "sample_single_aperture_input.csv"
LADDER_INPUT_CSV = "sample_aperture_ladder_input.csv"
XCOP_ARCHIVE = "allfiles.tar.gz"
EXTRACT_DIR = "xcop_extracted"

OUTPUT_DIR = "outputs"
OUTPUT_ZIP = "CPTG_ClusterActiveGate_IntegratedTool_v0_5_OutputBundle.zip"

USE_MSTAR_IF_PRESENT = True
DEFAULT_S_STAR = 0.20

MAKE_PLOTS = True

RUN_SELF_TESTS = True
PROGRESS_EVERY_N_ROWS = 10

# X-COP mode options
RUN_XCOP_R500 = True
RUN_XCOP_LADDER = True
XCOP_LADDER_DELTAS = [2500, 2000, 1500, 1000, 750, 500]
TEMPERATURE_GATE_MODE = "T500_header"


# =============================================================================
# X-COP redshift map
# =============================================================================

Z_MAP = {
    "A1644": 0.0473,
    "A1795": 0.0622,
    "A2029": 0.0773,
    "A2142": 0.0909,
    "A2255": 0.0809,
    "A2319": 0.0557,
    "A3158": 0.0597,
    "A3266": 0.0594,
    "A644": 0.0704,
    "A85": 0.0555,
    "RXC1825": 0.0650,
    "ZW1215": 0.0750,
}


# =============================================================================
# Physical constants
# =============================================================================

G_SI = 6.67430e-11
MPC_M = 3.085677581491367e22
KPC_M = MPC_M / 1000.0
MSUN_KG = 1.98847e30
MP_KG = 1.67262192369e-27
KEV_J = 1.602176634e-16
MU_INTRACLUSTER = 0.61


# =============================================================================
# Locked CPTG constants
# =============================================================================

PI = math.pi
F_PI = PI / 20.0
SIGMA_0 = 0.9960249674
N_C0 = 0.1965088232

H0_PI_KM_S_MPC = 69.4162507897
H0_PI_S = H0_PI_KM_S_MPC * 1000.0 / MPC_M

B_PI = 1.0 - 1.0 / PI
T_PI = 1.0 / PI


# =============================================================================
# Generic utilities
# =============================================================================

def parse_float(value: object, default: Optional[float] = None) -> Optional[float]:
    if value is None:
        return default
    text = str(value).strip()
    if text == "" or text.lower() in {"nan", "none", "null", "na", "n/a"}:
        return default
    return float(text)


def finite(value: object) -> bool:
    try:
        return math.isfinite(float(value))
    except Exception:
        return False


def safe_ratio(numerator: Optional[float], denominator: Optional[float]) -> Optional[float]:
    if numerator is None or denominator is None or denominator == 0:
        return None
    return numerator / denominator


def median(values: List[object]) -> Optional[float]:
    clean = []
    for value in values:
        if value is None or value == "":
            continue
        try:
            v = float(value)
        except Exception:
            continue
        if math.isfinite(v):
            clean.append(v)
    return statistics.median(clean) if clean else None


def aperture_label(delta: float) -> str:
    if abs(delta - round(delta)) < 1e-9:
        return f"R{int(round(delta))}"
    return f"R{delta:g}"


def write_csv(path: Path, rows: List[Dict[str, object]], columns: List[str]) -> None:
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=columns, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow({col: row.get(col, "") for col in columns})


def read_csv_rows(path: Path) -> List[Dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


# =============================================================================
# CPTG formula core
# =============================================================================

def E_C(z: float) -> float:
    return math.sqrt(B_PI + T_PI * (1.0 + z) ** PI)


def H_C_s(z: float) -> float:
    return H0_PI_S * E_C(z)


def M_ref_delta_1e14Msun(delta: float, z: float, R_delta_kpc: float) -> float:
    H = H_C_s(z)
    R_m = R_delta_kpc * KPC_M
    M_kg = (delta / 2.0) * (H * H / G_SI) * R_m ** 3
    return M_kg / MSUN_KG / 1.0e14


def g_ref_delta_m_s2(delta: float, z: float, R_delta_kpc: float) -> float:
    H = H_C_s(z)
    R_m = R_delta_kpc * KPC_M
    return (delta / 2.0) * H * H * R_m


def T_vir_delta_keV(delta: float, z: float, R_delta_kpc: float) -> float:
    H = H_C_s(z)
    R_m = R_delta_kpc * KPC_M
    energy_joule = MU_INTRACLUSTER * MP_KG * ((delta / 2.0) * H * H * R_m * R_m)
    return energy_joule / KEV_J


def theta_crit(F_delta: float) -> float:
    if F_delta <= 0:
        raise ValueError("F_delta must be positive.")
    return math.sqrt((F_delta ** 3) / (PI * F_PI * F_PI * N_C0))


def solve_y_delta(F_delta: float, Q_C_value: float, max_iter: int = 500, tol: float = 1.0e-13) -> Tuple[float, int, bool]:
    if not (0.0 < F_delta < 1.0):
        raise ValueError(f"F_delta must satisfy 0 < F_delta < 1. Got {F_delta}.")
    if Q_C_value <= 0:
        raise ValueError(f"Q_C must be positive. Got {Q_C_value}.")

    y = 1.0
    for iteration in range(1, max_iter + 1):
        response = (1.0 + ((y * N_C0) / (Q_C_value * Q_C_value)) ** (123.0 / 50.0)) ** (-11.0 / 50.0)
        y_next = F_delta + (1.0 - F_delta) * response / SIGMA_0
        if abs(y_next - y) < tol:
            return y_next, iteration, True
        y = y_next

    return y, max_iter, False


def gate_class(Q_C_value: float) -> str:
    if Q_C_value > 1.2:
        return "closure-stable"
    if Q_C_value >= 0.8:
        return "watch"
    if Q_C_value >= 0.5:
        return "suppressed"
    return "strongly suppressed"


def cluster_structural_mode(y_delta: float, Q_C_value: float) -> float:
    """True cluster structural response/load mode.

    This is the active-response variable already present in the cluster
    active-gate law. It is not the total-to-baryonic mass multiplier.
    """
    if Q_C_value <= 0:
        raise ValueError(f"Q_C must be positive. Got {Q_C_value}.")
    return (y_delta * N_C0) / (Q_C_value * Q_C_value)


def cluster_closure_index(y_delta: float, Q_C_value: float) -> float:
    """Reciprocal closure index for the active structural mode."""
    n_struct = cluster_structural_mode(y_delta, Q_C_value)
    return 1.0 / n_struct


def baryon_mass_multiplier(M_CPTG_1e14: float, Mbar_1e14: float) -> Optional[float]:
    """Mass-accounting ratio, kept separate from structural mode N."""
    return safe_ratio(M_CPTG_1e14, Mbar_1e14)


def compute_active_gate_row(
    cluster: str,
    z: float,
    delta: float,
    R_kpc: float,
    Mgas_1e14: float,
    Tgate_keV: float,
    Mstar_1e14: Optional[float] = None,
    MICL_1e14: Optional[float] = None,
    MHSE_1e14: Optional[float] = None,
    Mlens_1e14: Optional[float] = None,
    aperture_status: str = "declared",
) -> Dict[str, object]:
    if Mstar_1e14 is not None and USE_MSTAR_IF_PRESENT:
        Mstar_used = Mstar_1e14
        star_mode = "direct"
    else:
        Mstar_used = DEFAULT_S_STAR * Mgas_1e14
        star_mode = f"default_sstar_{DEFAULT_S_STAR:.2f}"

    MICL_used = MICL_1e14 if MICL_1e14 is not None else 0.0
    Mbar = Mgas_1e14 + Mstar_used + MICL_used
    Mref = M_ref_delta_1e14Msun(delta, z, R_kpc)
    gref = g_ref_delta_m_s2(delta, z, R_kpc)
    F = Mbar / Mref
    Tvir = T_vir_delta_keV(delta, z, R_kpc)
    theta_T = Tgate_keV / Tvir
    theta_crit_value = theta_crit(F)
    Q = theta_T / theta_crit_value
    y, iterations, converged = solve_y_delta(F, Q)
    Mcptg = y * Mref
    N_cluster_struct = cluster_structural_mode(y, Q)
    N_cluster_closure = cluster_closure_index(y, Q)
    N_bar_multiplier = baryon_mass_multiplier(Mcptg, Mbar)

    return {
        "cluster": cluster,
        "z": z,
        "Delta": delta,
        "aperture": aperture_label(delta),
        "aperture_status": aperture_status,
        "R_kpc": R_kpc,
        "Mgas_1e14Msun": Mgas_1e14,
        "Mstar_used_1e14Msun": Mstar_used,
        "MICL_used_1e14Msun": MICL_used,
        "star_mode": star_mode,
        "Tgate_keV": Tgate_keV,
        "Mbar_1e14Msun": Mbar,
        "Mref_1e14Msun": Mref,
        "gref_m_s2": gref,
        "F": F,
        "Tvir_keV": Tvir,
        "theta_T": theta_T,
        "theta_crit": theta_crit_value,
        "Q_C": Q,
        "y": y,
        "M_CPTG_1e14Msun": Mcptg,
        "N_cluster_struct": N_cluster_struct,
        "N_cluster_closure": N_cluster_closure,
        "N_bar_multiplier": N_bar_multiplier,
        "g_CPTG_m_s2": y * gref,
        "M_HSE_1e14Msun": MHSE_1e14,
        "M_lensing_1e14Msun": Mlens_1e14,
        "CPTG_over_HSE": safe_ratio(Mcptg, MHSE_1e14),
        "CPTG_over_lensing": safe_ratio(Mcptg, Mlens_1e14),
        "HSE_over_ref": safe_ratio(MHSE_1e14, Mref),
        "lensing_over_ref": safe_ratio(Mlens_1e14, Mref),
        "CPTG_minus_HSE_1e14Msun": (Mcptg - MHSE_1e14) if MHSE_1e14 is not None else None,
        "CPTG_minus_lensing_1e14Msun": (Mcptg - Mlens_1e14) if Mlens_1e14 is not None else None,
        "gate_class": gate_class(Q),
        "solver_iterations": iterations,
        "solver_converged": converged,
    }


def compute_from_csv_row(row: Dict[str, str], aperture_status: str = "csv_declared") -> Dict[str, object]:
    cluster = row.get("cluster", "").strip()
    if not cluster:
        raise ValueError("Missing required column: cluster")

    z = parse_float(row.get("z"))
    delta = parse_float(row.get("Delta"))
    R_kpc = parse_float(row.get("R_delta_kpc"))
    Mgas = parse_float(row.get("Mgas_delta_1e14Msun"))
    Tgate = parse_float(row.get("Tgate_keV"))

    required = {
        "z": z,
        "Delta": delta,
        "R_delta_kpc": R_kpc,
        "Mgas_delta_1e14Msun": Mgas,
        "Tgate_keV": Tgate,
    }
    missing = [key for key, value in required.items() if value is None]
    if missing:
        raise ValueError(f"{cluster}: missing required values: {', '.join(missing)}")

    return compute_active_gate_row(
        cluster=cluster,
        z=float(z),
        delta=float(delta),
        R_kpc=float(R_kpc),
        Mgas_1e14=float(Mgas),
        Tgate_keV=float(Tgate),
        Mstar_1e14=parse_float(row.get("Mstar_delta_1e14Msun"), default=None),
        MICL_1e14=parse_float(row.get("MICL_delta_1e14Msun"), default=None),
        MHSE_1e14=parse_float(row.get("MHSE_delta_1e14Msun"), default=None),
        Mlens_1e14=parse_float(row.get("Mlens_delta_1e14Msun"), default=None),
        aperture_status=aperture_status,
    )


# =============================================================================
# FITS BINTABLE reader for X-COP products
# =============================================================================

def parse_header_cards(cards: List[str]) -> Dict[str, object]:
    header: Dict[str, object] = {}
    for card in cards:
        key = card[:8].strip()
        if not key or key == "END":
            continue
        if card[8:10] == "= ":
            raw = card[10:80].split("/")[0].strip()
            if raw.startswith("'"):
                value = raw.strip().strip("'").strip()
            elif raw in ("T", "F"):
                value = raw == "T"
            else:
                try:
                    value = float(raw.replace("D", "E")) if any(c in raw for c in ".EeDd") else int(raw)
                except Exception:
                    value = raw
            header[key] = value
    return header


def read_hdu_offsets(path: Path) -> List[Dict[str, object]]:
    hdus: List[Dict[str, object]] = []
    with path.open("rb") as f:
        while True:
            cards: List[str] = []
            first = f.read(2880)
            if not first:
                break

            block = first
            while True:
                end_found = False
                for j in range(0, 2880, 80):
                    card = block[j:j + 80].decode("ascii", errors="replace")
                    cards.append(card)
                    if card.startswith("END"):
                        end_found = True
                        break
                if end_found:
                    break
                block = f.read(2880)
                if not block:
                    break

            header = parse_header_cards(cards)
            bitpix = int(header.get("BITPIX", 8))
            naxis = int(header.get("NAXIS", 0))

            if str(header.get("XTENSION", "")).strip() == "BINTABLE":
                datasize = int(header.get("NAXIS1", 0)) * int(header.get("NAXIS2", 0)) + int(header.get("PCOUNT", 0))
            elif naxis > 0:
                prod = 1
                for ax in range(1, naxis + 1):
                    prod *= int(header.get(f"NAXIS{ax}", 0))
                datasize = abs(bitpix) // 8 * prod
            else:
                datasize = 0

            data_start = f.tell()
            pad = (2880 - datasize % 2880) % 2880
            f.seek(datasize + pad, os.SEEK_CUR)

            hdus.append({"header": header, "data_start": data_start, "datasize": datasize})
    return hdus


def parse_tform(tform: object) -> Tuple[int, str]:
    match = re.match(r"(\d*)([A-Z])", str(tform).strip())
    if not match:
        raise ValueError(f"Unsupported FITS TFORM: {tform}")
    repeat = int(match.group(1)) if match.group(1) else 1
    return repeat, match.group(2)


def read_bintable(path: Path, extname: Optional[str] = None) -> Tuple[Optional[List[Dict[str, object]]], Optional[Dict[str, object]]]:
    hdus = read_hdu_offsets(path)
    target = None
    for hdu in hdus:
        header = hdu["header"]
        if str(header.get("XTENSION", "")).strip() != "BINTABLE":
            continue
        if extname is None or str(header.get("EXTNAME", "")).strip() == extname:
            target = hdu
            break
    if target is None:
        return None, None

    header = target["header"]
    nrow = int(header.get("NAXIS2", 0))
    rowlen = int(header.get("NAXIS1", 0))
    nfields = int(header.get("TFIELDS", 0))

    fields = []
    offset = 0
    for j in range(1, nfields + 1):
        name = str(header.get(f"TTYPE{j}", f"COL{j}")).strip()
        repeat, code = parse_tform(header.get(f"TFORM{j}"))
        if code == "E":
            size, dtype = 4 * repeat, (f">{repeat}f4" if repeat > 1 else ">f4")
        elif code == "D":
            size, dtype = 8 * repeat, (f">{repeat}f8" if repeat > 1 else ">f8")
        elif code == "J":
            size, dtype = 4 * repeat, (f">{repeat}i4" if repeat > 1 else ">i4")
        elif code == "K":
            size, dtype = 8 * repeat, (f">{repeat}i8" if repeat > 1 else ">i8")
        elif code == "I":
            size, dtype = 2 * repeat, (f">{repeat}i2" if repeat > 1 else ">i2")
        elif code == "A":
            size, dtype = repeat, None
        else:
            raise ValueError(f"Unsupported FITS column type {code} in {path}, column {name}.")
        fields.append((name, repeat, code, offset, size, dtype))
        offset += size

    with path.open("rb") as f:
        f.seek(int(target["data_start"]))
        raw = f.read(rowlen * nrow)

    rows: List[Dict[str, object]] = []
    for r in range(nrow):
        out: Dict[str, object] = {}
        row_offset = r * rowlen
        for name, repeat, code, offset, size, dtype in fields:
            chunk = raw[row_offset + offset:row_offset + offset + size]
            if code == "A":
                out[name] = chunk.decode("ascii", errors="replace").strip()
            else:
                arr = np.frombuffer(chunk, dtype=np.dtype(dtype))
                if repeat == 1:
                    out[name] = float(arr[0]) if code in ("E", "D") else int(arr[0])
                else:
                    out[name] = arr.astype(float if code in ("E", "D") else int)
        rows.append(out)
    return rows, header


# =============================================================================
# X-COP archive helpers
# =============================================================================

def safe_extract_tar(tar_path: Path, extract_dir: Path) -> None:
    extract_dir.mkdir(exist_ok=True)
    with tarfile.open(tar_path, "r:gz") as tar:
        members = tar.getmembers()
        root = extract_dir.resolve()
        for member in members:
            target = (extract_dir / member.name).resolve()
            if not str(target).startswith(str(root)):
                raise RuntimeError(f"Unsafe path in archive: {member.name}")
        # Python 3.14 warning may mention default filters. This call is safe due to explicit path check above.
        tar.extractall(extract_dir)


def find_one(folder: Path, pattern: str) -> Optional[Path]:
    matches = list(folder.glob(pattern))
    return matches[0] if matches else None


def convert_mass_to_1e14Msun(value: Optional[float]) -> Optional[float]:
    if value is None:
        return None
    # X-COP high-level products usually use 1e14 Msun scale even when unit labels vary.
    return value / 1.0e14 if value > 1.0e8 else value


def value_at_radius(rows: List[Dict[str, object]], radius_col: str, value_col: str, target_kpc: float, R500_kpc: float) -> Optional[float]:
    usable = []
    for row in rows:
        r = row.get(radius_col)
        v = row.get(value_col)
        if finite(r) and finite(v):
            usable.append((float(r), float(v)))
    if not usable:
        return None
    usable.sort(key=lambda x: x[0])
    xs = [x[0] for x in usable]
    ys = [x[1] for x in usable]
    target = target_kpc / R500_kpc if max(xs) < 5.0 else target_kpc
    if target <= xs[0]:
        return ys[0]
    if target >= xs[-1]:
        return ys[-1]
    for i in range(len(xs) - 1):
        if xs[i] <= target <= xs[i + 1]:
            frac = (target - xs[i]) / (xs[i + 1] - xs[i])
            return ys[i] + frac * (ys[i + 1] - ys[i])
    return ys[-1]


def find_Rdelta_from_hydro_profile(hydro_rows: List[Dict[str, object]], z: float, delta: float) -> Tuple[Optional[float], Optional[float], str]:
    usable = []
    for row in hydro_rows:
        R = row.get("RADIUS")
        M = row.get("M_NFW")
        if finite(R) and finite(M) and float(R) > 0 and float(M) > 0:
            usable.append((float(R), float(convert_mass_to_1e14Msun(float(M)))))
    if len(usable) < 2:
        return None, None, "bad_profile"
    usable.sort(key=lambda x: x[0])
    Rvals = [u[0] for u in usable]
    Mvals = [u[1] for u in usable]
    diffs = [Mvals[i] - M_ref_delta_1e14Msun(delta, z, Rvals[i]) for i in range(len(Rvals))]
    for i in range(len(Rvals) - 1):
        if diffs[i] == 0:
            return Rvals[i], Mvals[i], "crossing"
        if diffs[i] * diffs[i + 1] < 0:
            frac = -diffs[i] / (diffs[i + 1] - diffs[i])
            R_cross = Rvals[i] + frac * (Rvals[i + 1] - Rvals[i])
            M_cross = Mvals[i] + frac * (Mvals[i + 1] - Mvals[i])
            return R_cross, M_cross, "crossing"
    idx = min(range(len(diffs)), key=lambda i: abs(diffs[i]))
    return Rvals[idx], Mvals[idx], "nearest_no_crossing"


def read_cluster_products(cluster_dir: Path) -> Optional[Dict[str, object]]:
    cluster = cluster_dir.name
    hydro_file = find_one(cluster_dir, "*_hydro_mass.fits")
    fgas_file = find_one(cluster_dir, "*_fgas_profile.fits")
    temp_file = find_one(cluster_dir, "*_temperature.fits")
    mstar_file = find_one(cluster_dir, "*_mstar.fits")

    if not hydro_file or not fgas_file or not temp_file:
        return None

    hydro_rows, hydro_header = read_bintable(hydro_file, "HYDRO_MASS")
    fgas_rows, fgas_header = read_bintable(fgas_file, "FGAS")
    xray_rows, xray_header = read_bintable(temp_file, "XRAY")
    xsz_rows, xsz_header = read_bintable(temp_file, "XSZ")

    if hydro_rows is None or hydro_header is None or fgas_rows is None or fgas_header is None:
        return None

    mstar_rows = None
    if mstar_file:
        mstar_rows, _ = read_bintable(mstar_file, "MSTAR_SMOOTHED")
        if mstar_rows is None:
            mstar_rows, _ = read_bintable(mstar_file, "MSTAR_RAW")

    R500 = float(hydro_header.get("R500", fgas_header.get("R500")))
    M500 = float(hydro_header.get("M500", fgas_header.get("M500")))
    T500 = float((xray_header or {}).get("T500", (xsz_header or {}).get("T500")))

    return {
        "cluster": cluster,
        "hydro_rows": hydro_rows,
        "fgas_rows": fgas_rows,
        "mstar_rows": mstar_rows,
        "R500_kpc": R500,
        "M500_HSE_1e14Msun": M500,
        "T500_keV": T500,
        "has_mstar": mstar_rows is not None,
    }


def compute_xcop_cluster_delta(product: Dict[str, object], delta: float) -> Optional[Dict[str, object]]:
    cluster = str(product["cluster"])
    if cluster not in Z_MAP:
        return None
    z = float(Z_MAP[cluster])
    R500 = float(product["R500_kpc"])
    Tgate = float(product["T500_keV"])

    if delta == 500:
        R_delta = R500
        M_hse = float(product["M500_HSE_1e14Msun"])
        aperture_status = "header_R500"
    else:
        R_delta, M_hse, aperture_status = find_Rdelta_from_hydro_profile(product["hydro_rows"], z, delta)
        if R_delta is None or M_hse is None:
            return None

    Mgas = value_at_radius(product["fgas_rows"], "RADIUS", "MGAS", float(R_delta), R500)
    Mgas_1e14 = convert_mass_to_1e14Msun(Mgas)
    if Mgas_1e14 is None:
        return None

    Mstar_1e14 = None
    if product.get("mstar_rows") is not None:
        Mstar = value_at_radius(product["mstar_rows"], "RADIUS", "MSTAR", float(R_delta), R500)
        Mstar_1e14 = convert_mass_to_1e14Msun(Mstar)

    return compute_active_gate_row(
        cluster=cluster,
        z=z,
        delta=float(delta),
        R_kpc=float(R_delta),
        Mgas_1e14=float(Mgas_1e14),
        Mstar_1e14=Mstar_1e14,
        Tgate_keV=Tgate,
        MHSE_1e14=float(M_hse),
        aperture_status=aperture_status,
    )


# =============================================================================
# Summaries and plots
# =============================================================================

ROW_COLUMNS = [
    "cluster", "z", "Delta", "aperture", "aperture_status", "R_kpc",
    "Mgas_1e14Msun", "Mstar_used_1e14Msun", "MICL_used_1e14Msun", "star_mode", "Tgate_keV",
    "Mbar_1e14Msun", "Mref_1e14Msun", "F", "Tvir_keV",
    "theta_T", "theta_crit", "Q_C", "y", "M_CPTG_1e14Msun",
    "N_cluster_struct", "N_cluster_closure", "N_bar_multiplier",
    "M_HSE_1e14Msun", "M_lensing_1e14Msun", "CPTG_over_HSE", "CPTG_over_lensing",
    "HSE_over_ref", "lensing_over_ref", "CPTG_minus_HSE_1e14Msun",
    "CPTG_minus_lensing_1e14Msun", "gref_m_s2", "g_CPTG_m_s2",
    "gate_class", "solver_iterations", "solver_converged",
]

SUMMARY_COLUMNS = [
    "aperture", "gate_class", "rows", "median_F", "median_Q_C",
    "median_y", "median_N_cluster_struct", "median_N_cluster_closure",
    "median_N_bar_multiplier", "median_CPTG_over_HSE", "median_HSE_over_ref",
]

CLUSTER_TREND_COLUMNS = [
    "cluster", "rows", "max_Delta", "min_Delta", "Q_C_inner", "Q_C_outer",
    "delta_Q_C_inner_minus_outer", "y_inner", "y_outer", "delta_y_inner_minus_outer",
    "N_cluster_struct_inner", "N_cluster_struct_outer", "delta_N_struct_inner_minus_outer",
    "inner_gate_class", "outer_gate_class",
]

MEDIAN_TREND_COLUMNS = [
    "Delta", "aperture", "rows", "median_F", "median_Q_C",
    "median_y", "median_N_cluster_struct", "median_N_cluster_closure",
    "median_N_bar_multiplier", "median_CPTG_over_HSE", "median_HSE_over_ref",
]


def gate_summary(rows: List[Dict[str, object]]) -> List[Dict[str, object]]:
    out = []
    keys = sorted({(float(r["Delta"]), str(r["aperture"]), str(r["gate_class"])) for r in rows}, reverse=True)
    for delta, aperture, cls in keys:
        sub = [r for r in rows if float(r["Delta"]) == delta and str(r["gate_class"]) == cls]
        out.append({
            "aperture": aperture,
            "gate_class": cls,
            "rows": len(sub),
            "median_F": median([r["F"] for r in sub]),
            "median_Q_C": median([r["Q_C"] for r in sub]),
            "median_y": median([r["y"] for r in sub]),
            "median_N_cluster_struct": median([r["N_cluster_struct"] for r in sub]),
            "median_N_cluster_closure": median([r["N_cluster_closure"] for r in sub]),
            "median_N_bar_multiplier": median([r["N_bar_multiplier"] for r in sub]),
            "median_CPTG_over_HSE": median([r["CPTG_over_HSE"] for r in sub]),
            "median_HSE_over_ref": median([r["HSE_over_ref"] for r in sub]),
        })
    return out


def cluster_trends(rows: List[Dict[str, object]]) -> List[Dict[str, object]]:
    out = []
    for cluster in sorted({str(r["cluster"]) for r in rows}):
        sub = sorted([r for r in rows if str(r["cluster"]) == cluster], key=lambda r: float(r["Delta"]), reverse=True)
        if not sub:
            continue
        inner = sub[0]
        outer = sub[-1]
        out.append({
            "cluster": cluster,
            "rows": len(sub),
            "max_Delta": inner["Delta"],
            "min_Delta": outer["Delta"],
            "Q_C_inner": inner["Q_C"],
            "Q_C_outer": outer["Q_C"],
            "delta_Q_C_inner_minus_outer": inner["Q_C"] - outer["Q_C"],
            "y_inner": inner["y"],
            "y_outer": outer["y"],
            "delta_y_inner_minus_outer": inner["y"] - outer["y"],
            "N_cluster_struct_inner": inner["N_cluster_struct"],
            "N_cluster_struct_outer": outer["N_cluster_struct"],
            "delta_N_struct_inner_minus_outer": inner["N_cluster_struct"] - outer["N_cluster_struct"],
            "inner_gate_class": inner["gate_class"],
            "outer_gate_class": outer["gate_class"],
        })
    return out


def median_trend(rows: List[Dict[str, object]]) -> List[Dict[str, object]]:
    out = []
    for delta in sorted({float(r["Delta"]) for r in rows}, reverse=True):
        sub = [r for r in rows if float(r["Delta"]) == delta]
        out.append({
            "Delta": delta,
            "aperture": aperture_label(delta),
            "rows": len(sub),
            "median_F": median([r["F"] for r in sub]),
            "median_Q_C": median([r["Q_C"] for r in sub]),
            "median_y": median([r["y"] for r in sub]),
            "median_N_cluster_struct": median([r["N_cluster_struct"] for r in sub]),
            "median_N_cluster_closure": median([r["N_cluster_closure"] for r in sub]),
            "median_N_bar_multiplier": median([r["N_bar_multiplier"] for r in sub]),
            "median_CPTG_over_HSE": median([r["CPTG_over_HSE"] for r in sub]),
            "median_HSE_over_ref": median([r["HSE_over_ref"] for r in sub]),
        })
    return out


def make_zip(zip_path: Path, paths: List[Path]) -> None:
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
        for p in paths:
            if p.exists():
                z.write(p, arcname=p.name)


def make_plots_for_rows(rows: List[Dict[str, object]], prefix: str, output_dir: Path) -> List[Path]:
    paths = []
    if not MAKE_PLOTS or not rows:
        return paths
    try:
        import matplotlib.pyplot as plt
    except Exception as exc:
        print(f"[plot] matplotlib unavailable: {exc}")
        return paths

    if len({float(r["Delta"]) for r in rows}) == 1:
        # QC vs y
        plt.figure(figsize=(9.5, 6.0))
        for cls in ["closure-stable", "watch", "suppressed", "strongly suppressed"]:
            sub = [r for r in rows if r["gate_class"] == cls]
            if not sub:
                continue
            plt.scatter([r["Q_C"] for r in sub], [r["y"] for r in sub], s=70, label=f"{cls} ({len(sub)})")
            for r in sub:
                plt.annotate(r["cluster"], (r["Q_C"], r["y"]), fontsize=7, xytext=(3, 3), textcoords="offset points")
        plt.axvline(1.2, linestyle="--", linewidth=1.2, label="closure threshold")
        plt.axvline(0.8, linestyle="--", linewidth=1.2, label="suppression threshold")
        plt.axhline(1.0, linestyle="--", linewidth=1.2, label="closure y=1")
        plt.xlabel("Q_C")
        plt.ylabel("y")
        plt.title(f"{prefix}: Q_C vs y")
        plt.legend(fontsize=8)
        plt.grid(True, linewidth=0.4, alpha=0.5)
        plt.tight_layout()
        p = output_dir / f"{prefix}_QC_vs_y.png"
        plt.savefig(p, dpi=220)
        plt.close()
        paths.append(p)

        # CPTG vs HSE if available
        sub = [r for r in rows if r.get("M_HSE_1e14Msun") is not None]
        if sub:
            plt.figure(figsize=(8.0, 7.0))
            x = [r["M_HSE_1e14Msun"] for r in sub]
            y = [r["M_CPTG_1e14Msun"] for r in sub]
            plt.scatter(x, y, s=75)
            for r in sub:
                plt.annotate(r["cluster"], (r["M_HSE_1e14Msun"], r["M_CPTG_1e14Msun"]), fontsize=7, xytext=(3, 3), textcoords="offset points")
            lo = min(min(x), min(y)) * 0.95
            hi = max(max(x), max(y)) * 1.05
            plt.plot([lo, hi], [lo, hi], linestyle="--", linewidth=1.2, label="1:1")
            plt.xlim(lo, hi)
            plt.ylim(lo, hi)
            plt.xlabel("Observed/HSE mass [1e14 Msun]")
            plt.ylabel("CPTG mass [1e14 Msun]")
            plt.title(f"{prefix}: CPTG mass vs observed mass")
            plt.legend()
            plt.grid(True, linewidth=0.4, alpha=0.5)
            plt.tight_layout()
            p = output_dir / f"{prefix}_CPTG_vs_observed.png"
            plt.savefig(p, dpi=220)
            plt.close()
            paths.append(p)
    else:
        # Ladder plots
        clusters = sorted({str(r["cluster"]) for r in rows})
        plt.figure(figsize=(9.5, 6.0))
        for cluster in clusters:
            sub = sorted([r for r in rows if r["cluster"] == cluster], key=lambda r: float(r["Delta"]), reverse=True)
            plt.plot([r["Delta"] for r in sub], [r["Q_C"] for r in sub], marker="o", linewidth=1.2, alpha=0.75)
        plt.axhline(1.2, linestyle="--", linewidth=1.2, label="closure threshold")
        plt.axhline(0.8, linestyle="--", linewidth=1.2, label="suppression threshold")
        plt.gca().invert_xaxis()
        plt.xlabel("Overdensity aperture Delta")
        plt.ylabel("Q_C")
        plt.title(f"{prefix}: Q_C by cluster")
        plt.legend()
        plt.grid(True, linewidth=0.4, alpha=0.5)
        plt.tight_layout()
        p = output_dir / f"{prefix}_QC_by_cluster.png"
        plt.savefig(p, dpi=220)
        plt.close()
        paths.append(p)

        trend = median_trend(rows)
        plt.figure(figsize=(9.5, 5.8))
        trend_sorted = sorted(trend, key=lambda r: float(r["Delta"]), reverse=True)
        plt.plot([r["Delta"] for r in trend_sorted], [r["median_Q_C"] for r in trend_sorted], marker="o", linewidth=2.2, label="Median Q_C")
        plt.axhline(1.2, linestyle="--", linewidth=1.2, label="closure threshold")
        plt.axhline(0.8, linestyle="--", linewidth=1.2, label="suppression threshold")
        plt.gca().invert_xaxis()
        plt.xlabel("Overdensity aperture Delta")
        plt.ylabel("Median Q_C")
        plt.title(f"{prefix}: median Q_C")
        plt.legend()
        plt.grid(True, linewidth=0.4, alpha=0.5)
        plt.tight_layout()
        p = output_dir / f"{prefix}_median_QC.png"
        plt.savefig(p, dpi=220)
        plt.close()
        paths.append(p)

    return paths


# =============================================================================
# Mode runners
# =============================================================================

def run_csv_single(workdir: Path, output_dir: Path) -> List[Path]:
    input_path = workdir / SINGLE_INPUT_CSV
    if not input_path.exists():
        print(f"[csv_single] skipped; missing {input_path}")
        return []

    print(f"[csv_single] Reading {input_path}")
    rows = []
    for idx, raw_row in enumerate(read_csv_rows(input_path), start=1):
        rows.append(compute_from_csv_row(raw_row, aperture_status="csv_single"))
        if PROGRESS_EVERY_N_ROWS and idx % PROGRESS_EVERY_N_ROWS == 0:
            print(f"[csv_single] processed {idx} rows")
    rows.sort(key=lambda r: float(r["Q_C"]))

    out = []
    result_path = output_dir / "csv_single_results.csv"
    summary_path = output_dir / "csv_single_gate_summary.csv"
    write_csv(result_path, rows, ROW_COLUMNS)
    write_csv(summary_path, gate_summary(rows), SUMMARY_COLUMNS)
    out.extend([result_path, summary_path])
    out.extend(make_plots_for_rows(rows, "csv_single", output_dir))
    return out


def run_csv_ladder(workdir: Path, output_dir: Path) -> List[Path]:
    input_path = workdir / LADDER_INPUT_CSV
    if not input_path.exists():
        print(f"[csv_ladder] skipped; missing {input_path}")
        return []

    print(f"[csv_ladder] Reading {input_path}")
    rows = []
    for idx, raw_row in enumerate(read_csv_rows(input_path), start=1):
        rows.append(compute_from_csv_row(raw_row, aperture_status="csv_ladder"))
        if PROGRESS_EVERY_N_ROWS and idx % PROGRESS_EVERY_N_ROWS == 0:
            print(f"[csv_ladder] processed {idx} rows")
    rows.sort(key=lambda r: (str(r["cluster"]), -float(r["Delta"])))

    out = []
    result_path = output_dir / "csv_ladder_results.csv"
    gate_summary_path = output_dir / "csv_ladder_gate_summary.csv"
    cluster_trend_path = output_dir / "csv_ladder_cluster_trends.csv"
    median_trend_path = output_dir / "csv_ladder_median_trend.csv"
    write_csv(result_path, rows, ROW_COLUMNS)
    write_csv(gate_summary_path, gate_summary(rows), SUMMARY_COLUMNS)
    write_csv(cluster_trend_path, cluster_trends(rows), CLUSTER_TREND_COLUMNS)
    write_csv(median_trend_path, median_trend(rows), MEDIAN_TREND_COLUMNS)
    out.extend([result_path, gate_summary_path, cluster_trend_path, median_trend_path])
    out.extend(make_plots_for_rows(rows, "csv_ladder", output_dir))
    return out


def run_xcop_archive(workdir: Path, output_dir: Path) -> List[Path]:
    archive = workdir / XCOP_ARCHIVE
    if not archive.exists() and Path("/mnt/data/allfiles.tar.gz").exists():
        archive = Path("/mnt/data/allfiles.tar.gz")
    if not archive.exists():
        print(f"[xcop_archive] skipped; missing {XCOP_ARCHIVE}")
        return []

    extract_dir = workdir / EXTRACT_DIR
    extract_dir.mkdir(exist_ok=True)
    if not any(extract_dir.iterdir()):
        print(f"[xcop_archive] Extracting {archive}")
        safe_extract_tar(archive, extract_dir)
    else:
        print(f"[xcop_archive] Using existing extract directory {extract_dir}")

    products = []
    for folder in sorted([p for p in extract_dir.iterdir() if p.is_dir()]):
        product = read_cluster_products(folder)
        if product is not None:
            products.append(product)

    print(f"[xcop_archive] Products loaded: {len(products)}")
    out = []

    r500_rows = []
    ladder_rows = []

    if RUN_XCOP_R500:
        for idx, product in enumerate(products, start=1):
            row = compute_xcop_cluster_delta(product, 500)
            if row is not None:
                r500_rows.append(row)
            if PROGRESS_EVERY_N_ROWS and idx % PROGRESS_EVERY_N_ROWS == 0:
                print(f"[xcop_archive:R500] processed {idx} products")
        r500_rows.sort(key=lambda r: float(r["Q_C"]))
        result_path = output_dir / "xcop_r500_results.csv"
        summary_path = output_dir / "xcop_r500_gate_summary.csv"
        write_csv(result_path, r500_rows, ROW_COLUMNS)
        write_csv(summary_path, gate_summary(r500_rows), SUMMARY_COLUMNS)
        out.extend([result_path, summary_path])
        out.extend(make_plots_for_rows(r500_rows, "xcop_r500", output_dir))

    if RUN_XCOP_LADDER:
        trial_count = 0
        for product in products:
            for delta in XCOP_LADDER_DELTAS:
                trial_count += 1
                row = compute_xcop_cluster_delta(product, float(delta))
                if row is not None:
                    ladder_rows.append(row)
                if PROGRESS_EVERY_N_ROWS and trial_count % PROGRESS_EVERY_N_ROWS == 0:
                    print(f"[xcop_archive:ladder] processed {trial_count} product-aperture trials")
        ladder_rows.sort(key=lambda r: (str(r["cluster"]), -float(r["Delta"])))
        result_path = output_dir / "xcop_ladder_results.csv"
        gate_summary_path = output_dir / "xcop_ladder_gate_summary.csv"
        cluster_trend_path = output_dir / "xcop_ladder_cluster_trends.csv"
        median_trend_path = output_dir / "xcop_ladder_median_trend.csv"
        write_csv(result_path, ladder_rows, ROW_COLUMNS)
        write_csv(gate_summary_path, gate_summary(ladder_rows), SUMMARY_COLUMNS)
        write_csv(cluster_trend_path, cluster_trends(ladder_rows), CLUSTER_TREND_COLUMNS)
        write_csv(median_trend_path, median_trend(ladder_rows), MEDIAN_TREND_COLUMNS)
        out.extend([result_path, gate_summary_path, cluster_trend_path, median_trend_path])
        out.extend(make_plots_for_rows(ladder_rows, "xcop_ladder", output_dir))

    # Record mini audit for X-COP mode.
    xcop_audit = output_dir / "xcop_mode_audit.txt"
    xcop_audit.write_text(
        "\n".join([
            "X-COP mode mini-audit",
            f"Products loaded: {len(products)}",
            f"R500 rows: {len(r500_rows)}",
            f"Ladder rows: {len(ladder_rows)}",
            f"R500 converged: {sum(1 for r in r500_rows if r.get('solver_converged'))}/{len(r500_rows)}",
            f"Ladder converged: {sum(1 for r in ladder_rows if r.get('solver_converged'))}/{len(ladder_rows)}",
            f"A2319 R500 suppressed: {any(r['cluster']=='A2319' and r['gate_class']=='suppressed' for r in r500_rows)}",
            f"ZW1215 R500 closure-stable: {any(r['cluster']=='ZW1215' and r['gate_class']=='closure-stable' for r in r500_rows)}",
        ]),
        encoding="utf-8",
    )
    out.append(xcop_audit)
    return out


# =============================================================================
# Audit and tests
# =============================================================================

def assert_close(label: str, actual: float, expected: float, tolerance: float) -> None:
    if abs(actual - expected) > tolerance:
        raise AssertionError(f"{label}: got {actual}, expected {expected}, tolerance {tolerance}")


def run_self_tests() -> None:
    # Formula known-row check
    a2319 = compute_active_gate_row(
        cluster="A2319",
        z=0.0557,
        delta=500,
        R_kpc=1368.0,
        Mgas_1e14=1.4555563540821774,
        Mstar_1e14=0.069545,
        Tgate_keV=7.549503,
        MHSE_1e14=7.6781,
    )
    assert_close("A2319 Q_C", float(a2319["Q_C"]), 0.680912, 0.002)
    assert_close("A2319 y", float(a2319["y"]), 0.983998, 0.002)
    assert_close("A2319 N_cluster_struct", float(a2319["N_cluster_struct"]), 0.4171, 0.002)
    if a2319["gate_class"] != "suppressed":
        raise AssertionError("Expected A2319 to be suppressed.")

    zw1215 = compute_active_gate_row(
        cluster="ZW1215",
        z=0.0750,
        delta=500,
        R_kpc=1358.0,
        Mgas_1e14=0.810644,
        Mstar_1e14=0.042600,
        Tgate_keV=7.590557,
        MHSE_1e14=7.6634,
    )
    assert_close("ZW1215 Q_C", float(zw1215["Q_C"]), 1.622944, 0.003)
    assert_close("ZW1215 N_cluster_struct", float(zw1215["N_cluster_struct"]), 0.0748, 0.002)
    if zw1215["gate_class"] != "closure-stable":
        raise AssertionError("Expected ZW1215 to be closure-stable.")
    if not (float(a2319["N_cluster_struct"]) > float(zw1215["N_cluster_struct"])):
        raise AssertionError("Expected suppressed A2319 to have higher structural load than closure-stable ZW1215.")
    if not (float(a2319["N_bar_multiplier"]) > 1.0 and float(zw1215["N_bar_multiplier"]) > 1.0):
        raise AssertionError("Expected mass-accounting multipliers to be positive and above unity for known rows.")


def create_global_audit(path: Path, mode: str, files: List[Path]) -> None:
    lines = [
        "CPTG Cluster Active-Gate Integrated Tool v0.5 Global Audit",
        "",
        f"Mode: {mode}",
        f"Files produced: {len(files)}",
        "",
        "File check:",
    ]
    for p in files:
        lines.append(f"  {p.name}: {'present' if p.exists() else 'missing'}")
    lines.extend([
        "",
        "Locked constants:",
        f"  f_pi = {F_PI:.12f}",
        f"  Sigma0 = {SIGMA_0:.10f}",
        f"  N_C0 = {N_C0:.10f}",
        f"  H0_pi = {H0_PI_KM_S_MPC:.10f} km/s/Mpc",
        "",
        "v0.5 structural outputs:",
        "  N_cluster_struct = y * N_C0 / Q_C^2",
        "  N_cluster_closure = 1 / N_cluster_struct",
        "  N_bar_multiplier = M_CPTG / Mbar (mass accounting only)",
        "",
        "Configuration:",
        f"  USE_MSTAR_IF_PRESENT = {USE_MSTAR_IF_PRESENT}",
        f"  DEFAULT_S_STAR = {DEFAULT_S_STAR}",
        f"  MAKE_PLOTS = {MAKE_PLOTS}",
        f"  RUN_XCOP_R500 = {RUN_XCOP_R500}",
        f"  RUN_XCOP_LADDER = {RUN_XCOP_LADDER}",
        f"  XCOP_LADDER_DELTAS = {XCOP_LADDER_DELTAS}",
        "",
        "Audit status:",
        "  PASS" if files and all(p.exists() for p in files) else "  REVIEW REQUIRED",
    ])
    path.write_text("\n".join(lines), encoding="utf-8")


# =============================================================================
# Main
# =============================================================================

def main() -> None:
    workdir = Path(__file__).resolve().parent
    output_dir = workdir / OUTPUT_DIR
    output_dir.mkdir(exist_ok=True)

    if RUN_SELF_TESTS:
        print("[self-test] Running formula checks...")
        run_self_tests()
        print("[self-test] PASS")

    produced: List[Path] = []

    if MODE == "csv_single":
        produced.extend(run_csv_single(workdir, output_dir))
    elif MODE == "csv_ladder":
        produced.extend(run_csv_ladder(workdir, output_dir))
    elif MODE == "xcop_archive":
        produced.extend(run_xcop_archive(workdir, output_dir))
    elif MODE == "run_all_demo":
        produced.extend(run_csv_single(workdir, output_dir))
        produced.extend(run_csv_ladder(workdir, output_dir))
        produced.extend(run_xcop_archive(workdir, output_dir))
    else:
        raise ValueError(f"Unknown MODE: {MODE}")

    audit_path = output_dir / "integrated_tool_global_audit.txt"
    create_global_audit(audit_path, MODE, produced)
    produced.append(audit_path)

    zip_path = workdir / OUTPUT_ZIP
    make_zip(zip_path, [Path(__file__).resolve()] + produced)
    print(f"[output] Bundle: {zip_path}")
    print("[done] CPTG integrated tool run complete.")


if __name__ == "__main__":
    main()
