#!/usr/bin/env python3
"""
CPTG Bullet Cluster ensemble benchmark.

This script upgrades the prior single-realization calibrated benchmark into a
probabilistic chaotic-transport ensemble benchmark.

Scientific purpose
------------------
Cluster mergers are chaotic. If CPTG treats curvature transport as a spacetime
medium with current-like behavior, then the fair prediction is not one exact
contour map. The fair prediction is an ensemble of allowed curvature-transport
realizations with fixed priors.

This script therefore evaluates:

    1. guide-only baseline,
    2. low-order calibrated CPTG baseline,
    3. optional residual closure baseline,
    4. CPTG ensemble generated from structure-conditioned axis-guided transport-current priors.

The ensemble mode does NOT tune each sample to the observed target. It samples
transport variables from declared priors, builds a model from the BCG+ICL guide,
then scores the observed mass contours against the ensemble.

Inputs
------
    assets/observed_cha2025.png

Outputs
-------
    CPTG_Bullet_Cha2025_ENSEMBLE_BENCHMARK.png
    ensemble_metrics.json
    ensemble_samples.csv
    ensemble_probability.npz
    ensemble_packets.csv

Run
---
    pip install pillow numpy scipy
    python ensemble_CPTG_Bullet_Cha2025_benchmark.py

Larger ensemble
---------------
    python ensemble_CPTG_Bullet_Cha2025_benchmark.py --n-samples 25000 --seed 13

Interpretation
--------------
The ensemble score asks whether the observed lensing/mass contour morphology
falls inside the CPTG transport-current envelope. This is closer to a chaotic
medium benchmark than a deterministic map benchmark.

Important caveat
----------------
The benchmark still uses figure-level color-extracted contours, not raw lensing
kappa arrays. It is suitable for reduced-model development and not a final
cosmological validation.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import random
import textwrap
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Tuple

import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageOps

try:
    from scipy.ndimage import binary_dilation, distance_transform_edt, label, shift as ndi_shift
except ImportError as exc:
    raise SystemExit("Install dependencies with: pip install pillow numpy scipy") from exc


# ---------------------------------------------------------------------------
# Default paths
# ---------------------------------------------------------------------------

SCRIPT_DIR = Path(__file__).resolve().parent
ASSET_DIR = SCRIPT_DIR / "assets"

DEFAULT_OBSERVED = ASSET_DIR / "observed_cha2025.png"
DEFAULT_OUTPUT = SCRIPT_DIR / "CPTG_Bullet_Cha2025_ENSEMBLE_BENCHMARK.png"
DEFAULT_JSON = SCRIPT_DIR / "ensemble_metrics.json"
DEFAULT_SAMPLES_CSV = SCRIPT_DIR / "ensemble_samples.csv"
DEFAULT_PACKETS_CSV = SCRIPT_DIR / "ensemble_packets.csv"
DEFAULT_NPZ = SCRIPT_DIR / "ensemble_probability.npz"


# ---------------------------------------------------------------------------
# Fixed benchmark constants
# ---------------------------------------------------------------------------

# Physical scale inherited from the figure-extraction workflow.
KPC_PER_PIXEL = 2.857

# Tolerant contour matching radius.
TOLERANCE_KPC = 20.0
TOLERANCE_PX = int(round(TOLERANCE_KPC / KPC_PER_PIXEL))

# Small epsilon for log-probability calculations.
EPS = 1e-6

# Font candidates used for platform-independent figure rendering.
FONT_CANDIDATES = {
    "bold": [
        "C:/Windows/Fonts/arialbd.ttf",
        "C:/Windows/Fonts/segoeuib.ttf",
        "/System/Library/Fonts/Supplemental/Arial Bold.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
    ],
    "regular": [
        "C:/Windows/Fonts/arial.ttf",
        "C:/Windows/Fonts/segoeui.ttf",
        "/System/Library/Fonts/Supplemental/Arial.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
    ],
}


def format_duration(seconds: float) -> str:
    """Format elapsed or remaining runtime for progress logs."""
    seconds = max(0.0, float(seconds))
    days = int(seconds // 86400)
    seconds -= days * 86400
    hours = int(seconds // 3600)
    seconds -= hours * 3600
    minutes = int(seconds // 60)
    seconds -= minutes * 60
    if days:
        return f"{days}d {hours}h {minutes}m"
    if hours:
        return f"{hours}h {minutes}m"
    if minutes:
        return f"{minutes}m {int(seconds)}s"
    return f"{seconds:.1f}s"


def maybe_print_progress(
    *,
    stage: str,
    completed: int,
    total: int,
    start_time: float,
    last_report_time: float,
    progress_interval_seconds: float,
    best_score: float | None = None,
) -> float:
    """Print progress at fixed time intervals and return updated report time."""
    now = time.time()
    if completed >= total or (now - last_report_time) >= progress_interval_seconds:
        elapsed = now - start_time
        fraction = completed / max(1, total)
        if completed > 0 and fraction > 0:
            eta = elapsed * (1.0 - fraction) / fraction
            eta_text = format_duration(eta)
        else:
            eta_text = "unknown"

        best_text = "" if best_score is None else f", best_score={best_score:.4f}"
        print(
            f"[progress] {stage}: {completed:,}/{total:,} "
            f"({100.0 * fraction:.2f}%), elapsed={format_duration(elapsed)}, "
            f"ETA={eta_text}{best_text}",
            flush=True,
        )
        return now
    return last_report_time


def print_runtime_warning(args: argparse.Namespace, low_order_evals: int) -> None:
    """Print a plain-language runtime warning before expensive work starts."""
    print("\n" + "=" * 78, flush=True)
    print("RUNTIME WARNING", flush=True)
    print("=" * 78, flush=True)
    print(
        "This benchmark can be computationally heavy. Depending on computer speed, "
        "chosen grid width, and ensemble size, calculations may take minutes, hours, "
        "or several days.",
        flush=True,
    )
    print(
        f"Planned deterministic low-order evaluations: {low_order_evals:,}",
        flush=True,
    )
    print(
        f"Planned ensemble realizations: {args.n_samples:,}",
        flush=True,
    )
    print(
        f"Progress reports will print about every {args.progress_interval_minutes:g} minute(s).",
        flush=True,
    )
    print(
        "This version uses sharpened axis-guided priors to reduce false envelope spread.\nFor a quicker run, reduce --n-samples, reduce --max-shift, or increase "
        "--low-order-step. For a deeper research run, increase --n-samples.",
        flush=True,
    )
    print("=" * 78 + "\n", flush=True)


def count_low_order_evals(max_shift: int, shift_step: int) -> int:
    """Count deterministic low-order grid evaluations without running them."""
    n_shift = len(range(-max_shift, max_shift + 1, shift_step))
    # Four shift dimensions and three choices each for left/right thickness and bridge.
    return (n_shift ** 4) * 3 * 3 * 3


@dataclass(frozen=True)
class LobeParams:
    """Low-order curvature-transport parameters for one realization."""

    left_dx: int
    left_dy: int
    left_thick: int
    right_dx: int
    right_dy: int
    right_thick: int
    bridge_width: int


# ---------------------------------------------------------------------------
# Image, mask, and geometry utilities
# ---------------------------------------------------------------------------

def load_font(size: int, bold: bool = False):
    """Load a readable font; fall back to PIL default if no system font exists."""
    for path in FONT_CANDIDATES["bold" if bold else "regular"]:
        if Path(path).exists():
            return ImageFont.truetype(path, size)
    return ImageFont.load_default()


def roi_mask(shape: Tuple[int, int]) -> np.ndarray:
    """Return the benchmark region of interest.

    The ROI removes the figure border and legend so colored annotation pixels
    are not treated as physical contours.
    """
    height, width = shape
    y, x = np.mgrid[:height, :width]
    plot_region = (x > 45) & (y > 20) & (x < width - 5) & (y < height - 5)
    legend_region = (x < 205) & (y < 112)
    return plot_region & (~legend_region)


def extract_observed_and_guide(rgb: np.ndarray) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Extract observed mass contours and BCG+ICL guide contours.

    observed_mass:
        Pink/magenta Cha et al. mass-contour target.

    guide_icl:
        Cyan BCG+ICL guide used as non-lensing curvature-transport input.
    """
    red = rgb[..., 0].astype(np.int16)
    green = rgb[..., 1].astype(np.int16)
    blue = rgb[..., 2].astype(np.int16)
    roi = roi_mask(red.shape)

    observed_mass = (
        (red > 150)
        & (blue > 120)
        & (green < 170)
        & ((red - green) > 30)
        & ((blue - green) > 0)
        & roi
    )

    guide_icl = (
        (green > 150)
        & (blue > 150)
        & (red < 160)
        & ((green - red) > 20)
        & ((blue - red) > 20)
        & roi
    )

    return observed_mass, guide_icl, roi


def split_by_median_x(mask: np.ndarray) -> Tuple[np.ndarray, np.ndarray, float]:
    """Split a mask into left/right lobes using its median x coordinate."""
    _, xs = np.nonzero(mask)
    split = float(np.median(xs)) if len(xs) else mask.shape[1] / 2
    xx = np.mgrid[: mask.shape[0], : mask.shape[1]][1]
    return mask & (xx <= split), mask & (xx > split), split


def split_fixed_x(mask: np.ndarray, split: float) -> Tuple[np.ndarray, np.ndarray]:
    """Split a mask into left/right lobes at a fixed x coordinate."""
    xx = np.mgrid[: mask.shape[0], : mask.shape[1]][1]
    return mask & (xx <= split), mask & (xx > split)


def shift_mask(mask: np.ndarray, dx: int, dy: int) -> np.ndarray:
    """Shift a binary mask by dx/dy pixels.

    This represents one discrete curvature-transport displacement.
    """
    return ndi_shift(mask.astype(float), shift=(dy, dx), order=0, mode="constant", cval=0.0) > 0.5


def dilate(mask: np.ndarray, iterations: int) -> np.ndarray:
    """Dilate a binary contour mask.

    This represents reduced curvature-polarization width.
    """
    return binary_dilation(mask, iterations=iterations) if iterations > 0 else mask.copy()


def centroid(mask: np.ndarray) -> Tuple[float, float]:
    """Return x/y centroid of a mask."""
    ys, xs = np.nonzero(mask)
    if len(xs) == 0:
        return float("nan"), float("nan")
    return float(xs.mean()), float(ys.mean())


def distance_kpc(a: Tuple[float, float], b: Tuple[float, float]) -> float:
    """Distance between two image points in kpc."""
    if any(math.isnan(v) for v in (a[0], a[1], b[0], b[1])):
        return float("nan")
    return math.dist(a, b) * KPC_PER_PIXEL


def bridge_mask(
    shape: Tuple[int, int],
    c1: Tuple[float, float],
    c2: Tuple[float, float],
    width_px: int,
    roi: np.ndarray,
) -> np.ndarray:
    """Build an optional narrow bridge/trail between lobe centroids."""
    if width_px <= 0 or any(math.isnan(v) for v in (c1[0], c1[1], c2[0], c2[1])):
        return np.zeros(shape, dtype=bool)

    height, width = shape
    y, x = np.mgrid[:height, :width]
    x1, y1 = c1
    x2, y2 = c2
    vx = x2 - x1
    vy = y2 - y1
    denom = vx * vx + vy * vy
    if denom <= 1e-9:
        return np.zeros(shape, dtype=bool)

    t = np.clip(((x - x1) * vx + (y - y1) * vy) / denom, 0.0, 1.0)
    px = x1 + t * vx
    py = y1 + t * vy
    dist = np.sqrt((x - px) ** 2 + (y - py) ** 2)

    # Central segment only; this avoids swallowing lobe cores into one blob.
    return (dist <= width_px) & (t > 0.25) & (t < 0.75) & roi



def guide_skeleton_support(
    guide: np.ndarray,
    roi: np.ndarray,
    support_radius_px: float,
    core_dilation_px: int,
) -> Tuple[np.ndarray, np.ndarray]:
    """Build a BCG+ICL skeleton support tube using guide geometry only.

    This is the main structure-conditioned prior upgrade. The ensemble is still
    allowed to transport curvature, but model pixels too far from the BCG+ICL
    guide skeleton are removed in hard-conditioning mode.

    Inputs used:
        guide: cyan BCG+ICL contour mask.
        roi: benchmark region of interest.

    Inputs not used:
        observed mass target. This keeps the prior non-lensing conditioned.
    """
    guide_core = binary_dilation(guide & roi, iterations=max(0, int(core_dilation_px)))
    distance_to_guide = distance_transform_edt(~guide_core)
    support = (distance_to_guide <= float(support_radius_px)) & roi
    return support, distance_to_guide


def apply_structure_conditioning(
    model: np.ndarray,
    support: np.ndarray,
    roi: np.ndarray,
    mode: str,
) -> np.ndarray:
    """Apply structure-conditioned support to one ensemble realization.

    mode == "none":
        Preserve the old axis-guided model.

    mode == "hard":
        Keep only model pixels inside the BCG+ICL support tube.

    This intentionally uses no observed mass/lensing target information.
    """
    if mode == "none":
        return model & roi
    if mode == "hard":
        return model & support & roi
    raise ValueError(f"Unknown structure-conditioning mode: {mode}")



# ---------------------------------------------------------------------------
# Model and metrics
# ---------------------------------------------------------------------------

def build_lobe_model(params: LobeParams, guide_left: np.ndarray, guide_right: np.ndarray, roi: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    """Build one two-lobe CPTG realization from transport parameters."""
    left = dilate(shift_mask(guide_left, params.left_dx, params.left_dy), params.left_thick) & roi
    right = dilate(shift_mask(guide_right, params.right_dx, params.right_dy), params.right_thick) & roi
    bridge = bridge_mask(roi.shape, centroid(left), centroid(right), params.bridge_width, roi)
    return (left | right | bridge) & roi, bridge


def lobe_metrics(target: np.ndarray, model: np.ndarray, split: float) -> Dict[str, float]:
    """Compute lobe centroid and lobe-separation diagnostics."""
    target_left, target_right = split_fixed_x(target, split)
    model_left, model_right = split_fixed_x(model, split)

    target_left_centroid = centroid(target_left)
    target_right_centroid = centroid(target_right)
    model_left_centroid = centroid(model_left)
    model_right_centroid = centroid(model_right)

    left_error = distance_kpc(target_left_centroid, model_left_centroid)
    right_error = distance_kpc(target_right_centroid, model_right_centroid)
    mean_error = float("nan") if math.isnan(left_error) or math.isnan(right_error) else 0.5 * (left_error + right_error)

    if any(
        math.isnan(v)
        for v in (
            target_left_centroid[0],
            target_left_centroid[1],
            target_right_centroid[0],
            target_right_centroid[1],
            model_left_centroid[0],
            model_left_centroid[1],
            model_right_centroid[0],
            model_right_centroid[1],
        )
    ):
        target_separation = model_separation = separation_residual = float("nan")
    else:
        target_separation = math.dist(target_left_centroid, target_right_centroid) * KPC_PER_PIXEL
        model_separation = math.dist(model_left_centroid, model_right_centroid) * KPC_PER_PIXEL
        separation_residual = model_separation - target_separation

    return {
        "left_lobe_centroid_error_kpc": left_error,
        "right_lobe_centroid_error_kpc": right_error,
        "mean_lobe_centroid_error_kpc": mean_error,
        "observed_lobe_separation_kpc": target_separation,
        "model_lobe_separation_kpc": model_separation,
        "lobe_separation_residual_kpc": separation_residual,
    }


def metrics(target: np.ndarray, model: np.ndarray, roi: np.ndarray, split: float) -> Dict[str, float]:
    """Compute strict and tolerance-aware metrics with normalized 0-100 score."""
    target = target & roi
    model = model & roi

    if target.sum() == 0:
        raise ValueError("Target mask has zero pixels inside ROI.")

    dist_to_target = distance_transform_edt(~target)
    dist_to_model = distance_transform_edt(~model)

    near_target = dist_to_target <= TOLERANCE_PX
    near_model = dist_to_model <= TOLERANCE_PX

    raw_iou = float((model & target).sum() / max(1, (model | target).sum()))

    precision = float((model & near_target).sum() / max(1, model.sum()))
    recall = float((target & near_model).sum() / max(1, target.sum()))
    f1 = float(2 * precision * recall / max(1e-12, precision + recall))

    missed = target & (~near_model)
    excess = model & (~near_target)
    tolerant_union = model | target
    tolerant_errors = missed | excess
    iou_20kpc = float(1.0 - tolerant_errors.sum() / max(1, tolerant_union.sum()))
    iou_20kpc = float(max(0.0, min(1.0, iou_20kpc)))

    if model.sum() == 0:
        distances = dist_to_model[target] * KPC_PER_PIXEL
    else:
        distances = np.concatenate([dist_to_target[model], dist_to_model[target]]) * KPC_PER_PIXEL

    mhd = float(distances.mean()) if distances.size else float("inf")
    rmse = float(np.sqrt((distances * distances).mean())) if distances.size else float("inf")
    mae = float(np.abs(distances).mean()) if distances.size else float("inf")

    area_ratio = float(model.sum() / max(1, target.sum()))
    lobes = lobe_metrics(target, model, split)
    mean_lobe_error = lobes["mean_lobe_centroid_error_kpc"]
    separation_residual = lobes["lobe_separation_residual_kpc"]

    lobe_factor = 0.0 if math.isnan(mean_lobe_error) else math.exp(-mean_lobe_error / 80.0)
    separation_factor = 0.0 if math.isnan(separation_residual) else math.exp(-abs(separation_residual) / 150.0)
    distance_factor = 0.5 * math.exp(-mhd / 30.0) + 0.5 * math.exp(-rmse / 45.0)
    area_penalty = min(0.25, 0.08 * abs(math.log(max(area_ratio, 1e-6))))

    weights = {
        "f1": 0.30,
        "iou": 0.18,
        "distance": 0.17,
        "lobe": 0.12,
        "separation": 0.10,
        "precision": 0.06,
        "recall": 0.07,
    }

    positive = (
        weights["f1"] * f1
        + weights["iou"] * iou_20kpc
        + weights["distance"] * distance_factor
        + weights["lobe"] * lobe_factor
        + weights["separation"] * separation_factor
        + weights["precision"] * precision
        + weights["recall"] * recall
    )

    score = 100.0 * (positive - area_penalty)

    exact_match = bool(np.array_equal(model & roi, target & roi))
    if exact_match:
        score = 100.0
        f1 = precision = recall = iou_20kpc = raw_iou = 1.0
        mhd = rmse = mae = 0.0
        area_ratio = 1.0
        distance_factor = lobe_factor = separation_factor = 1.0
        area_penalty = 0.0

    out = {
        "overall_clean_score_0_100": float(max(0.0, min(100.0, score))),
        "f1_20kpc": f1,
        "iou_20kpc": iou_20kpc,
        "raw_iou_0kpc": raw_iou,
        "precision_20kpc": precision,
        "recall_20kpc": recall,
        "symmetric_mhd_kpc": mhd,
        "distance_rmse_kpc": rmse,
        "distance_mae_kpc": mae,
        "area_ratio_model_to_observed": area_ratio,
        "observed_pixels": int(target.sum()),
        "model_pixels": int(model.sum()),
        "score_component_f1": float(weights["f1"] * f1),
        "score_component_iou": float(weights["iou"] * iou_20kpc),
        "score_component_distance": float(weights["distance"] * distance_factor),
        "score_component_lobe": float(weights["lobe"] * lobe_factor),
        "score_component_separation": float(weights["separation"] * separation_factor),
        "score_component_precision": float(weights["precision"] * precision),
        "score_component_recall": float(weights["recall"] * recall),
        "score_penalty_area": float(area_penalty),
        "score_exact_match_guard": exact_match,
    }
    out.update(lobes)
    return out


def validate_scoring_perfect_match(target: np.ndarray, roi: np.ndarray, split: float) -> None:
    """Ensure the scoring function reports 100 for model == target."""
    check = metrics(target, target.copy() & roi, roi, split)
    required = {
        "overall_clean_score_0_100": 100.0,
        "f1_20kpc": 1.0,
        "iou_20kpc": 1.0,
        "raw_iou_0kpc": 1.0,
        "precision_20kpc": 1.0,
        "recall_20kpc": 1.0,
        "symmetric_mhd_kpc": 0.0,
        "distance_rmse_kpc": 0.0,
        "distance_mae_kpc": 0.0,
        "area_ratio_model_to_observed": 1.0,
    }
    for key, expected in required.items():
        if abs(float(check[key]) - expected) > 1e-9:
            raise AssertionError(f"Scoring self-test failed for {key}: {check[key]} != {expected}")


# ---------------------------------------------------------------------------
# Deterministic baselines and closure
# ---------------------------------------------------------------------------

def calibrate_low_order(
    observed: np.ndarray,
    guide: np.ndarray,
    roi: np.ndarray,
    split: float,
    max_shift: int,
    shift_step: int,
    progress_interval_seconds: float,
) -> Dict:
    """Transparent grid-search for low-order lobe transport baseline.

    Progress is printed periodically because broad low-order searches can be
    expensive on laptops and may take hours or days at high resolution.
    """
    guide_left, guide_right, _ = split_by_median_x(guide)

    best = None
    evals = 0
    total_evals = count_low_order_evals(max_shift, shift_step)
    stage_start = time.time()
    last_report = stage_start

    print(f"[start] deterministic low-order grid search: {total_evals:,} evaluations", flush=True)

    for left_dx in range(-max_shift, max_shift + 1, shift_step):
        for left_dy in range(-max_shift, max_shift + 1, shift_step):
            for right_dx in range(-max_shift, max_shift + 1, shift_step):
                for right_dy in range(-max_shift, max_shift + 1, shift_step):
                    for left_thick in [0, 1, 2]:
                        for right_thick in [0, 1, 2]:
                            for bridge_width in [0, 1, 2]:
                                params = LobeParams(left_dx, left_dy, left_thick, right_dx, right_dy, right_thick, bridge_width)
                                model, bridge = build_lobe_model(params, guide_left, guide_right, roi)
                                current_metrics = metrics(observed, model, roi, split)
                                evals += 1

                                if best is None or current_metrics["overall_clean_score_0_100"] > best["metrics"]["overall_clean_score_0_100"]:
                                    best = {"params": params, "model": model, "bridge": bridge, "metrics": current_metrics, "evals": evals}

                                last_report = maybe_print_progress(
                                    stage="low-order grid",
                                    completed=evals,
                                    total=total_evals,
                                    start_time=stage_start,
                                    last_report_time=last_report,
                                    progress_interval_seconds=progress_interval_seconds,
                                    best_score=None if best is None else best["metrics"]["overall_clean_score_0_100"],
                                )

    assert best is not None
    best["evals"] = evals
    print(
        f"[done] deterministic low-order grid search: {evals:,} evaluations, "
        f"best_score={best['metrics']['overall_clean_score_0_100']:.4f}, "
        f"elapsed={format_duration(time.time() - stage_start)}",
        flush=True,
    )
    return best



def residual_closure(
    observed: np.ndarray,
    base_model: np.ndarray,
    roi: np.ndarray,
    split: float,
    mode: str,
) -> Tuple[np.ndarray, List[Dict], Dict[str, float]]:
    """Apply exact or packet residual closure for comparison."""
    packets: List[Dict] = []
    model = base_model.copy() & roi

    if mode == "exact":
        missed = observed & (~model) & roi
        excess = model & (~observed) & roi

        lab, n = label(missed)
        for component_id in range(1, n + 1):
            component = lab == component_id
            if component.sum() == 0:
                continue
            center = centroid(component)
            packets.append(
                {
                    "operation": "add_residual_component",
                    "component": component_id,
                    "pixels": int(component.sum()),
                    "center_x_px": center[0],
                    "center_y_px": center[1],
                }
            )

        packets.append({"operation": "prune_excess_model_pixels", "pixels": int(excess.sum())})
        model = observed.copy() & roi
        return model, packets, metrics(observed, model, roi, split)

    lab, n = label(observed & (~model) & roi)
    for component_id in range(1, n + 1):
        component = lab == component_id
        if component.sum() == 0:
            continue
        current_score = metrics(observed, model, roi, split)["overall_clean_score_0_100"]
        candidate = (model | component) & roi
        candidate_metrics = metrics(observed, candidate, roi, split)
        if candidate_metrics["overall_clean_score_0_100"] >= current_score:
            center = centroid(component)
            packets.append(
                {
                    "operation": "add_residual_component",
                    "component": component_id,
                    "pixels": int(component.sum()),
                    "center_x_px": center[0],
                    "center_y_px": center[1],
                    "score_after": candidate_metrics["overall_clean_score_0_100"],
                }
            )
            model = candidate

    excess = model & (~observed) & roi
    if excess.sum():
        current_score = metrics(observed, model, roi, split)["overall_clean_score_0_100"]
        pruned = model & (~excess) & roi
        pruned_metrics = metrics(observed, pruned, roi, split)
        if pruned_metrics["overall_clean_score_0_100"] >= current_score:
            packets.append({"operation": "prune_excess_model_pixels", "pixels": int(excess.sum()), "score_after": pruned_metrics["overall_clean_score_0_100"]})
            model = pruned

    return model, packets, metrics(observed, model, roi, split)


# ---------------------------------------------------------------------------
# Ensemble model
# ---------------------------------------------------------------------------


def merger_axis_from_guide(guide: np.ndarray) -> Tuple[Tuple[float, float], Tuple[float, float], Dict[str, float]]:
    """Infer the merger-axis unit vector from the BCG+ICL guide lobes.

    This uses only the guide/ICL geometry, not the observed lensing target.
    The result is used to sharpen the ensemble prior: transport-current draws
    are broader along the inferred merger axis and narrower transverse to it.
    """
    guide_left, guide_right, _ = split_by_median_x(guide)
    left_center = centroid(guide_left)
    right_center = centroid(guide_right)

    if any(math.isnan(v) for v in (left_center[0], left_center[1], right_center[0], right_center[1])):
        # Fallback: horizontal axis.
        axis = (1.0, 0.0)
        perp = (0.0, 1.0)
        axis_angle_degrees = 0.0
        separation_px = float("nan")
    else:
        dx = right_center[0] - left_center[0]
        dy = right_center[1] - left_center[1]
        norm = math.hypot(dx, dy)
        if norm <= 1e-9:
            axis = (1.0, 0.0)
            perp = (0.0, 1.0)
            axis_angle_degrees = 0.0
            separation_px = 0.0
        else:
            axis = (dx / norm, dy / norm)
            perp = (-axis[1], axis[0])
            axis_angle_degrees = math.degrees(math.atan2(axis[1], axis[0]))
            separation_px = norm

    info = {
        "guide_left_center_x_px": left_center[0],
        "guide_left_center_y_px": left_center[1],
        "guide_right_center_x_px": right_center[0],
        "guide_right_center_y_px": right_center[1],
        "merger_axis_x": axis[0],
        "merger_axis_y": axis[1],
        "merger_axis_angle_degrees": axis_angle_degrees,
        "guide_lobe_separation_px": separation_px,
        "guide_lobe_separation_kpc": separation_px * KPC_PER_PIXEL if not math.isnan(separation_px) else float("nan"),
    }
    return axis, perp, info


def sample_axis_displacement(
    rng: random.Random,
    axis: Tuple[float, float],
    perp: Tuple[float, float],
    sigma_parallel_px: float,
    sigma_perp_px: float,
    max_shift_px: int,
) -> Tuple[int, int]:
    """Sample an anisotropic transport displacement along/perpendicular to axis."""
    parallel = rng.gauss(0.0, sigma_parallel_px)
    transverse = rng.gauss(0.0, sigma_perp_px)

    dx = int(round(parallel * axis[0] + transverse * perp[0]))
    dy = int(round(parallel * axis[1] + transverse * perp[1]))

    dx = max(-max_shift_px, min(max_shift_px, dx))
    dy = max(-max_shift_px, min(max_shift_px, dy))
    return dx, dy



def weighted_choice(rng: random.Random, values: List[int], weights: List[float]) -> int:
    """Draw one integer from a weighted categorical distribution."""
    total = sum(weights)
    r = rng.random() * total
    acc = 0.0
    for value, weight in zip(values, weights):
        acc += weight
        if r <= acc:
            return value
    return values[-1]


def sample_lobe_params(
    args: argparse.Namespace,
    rng: random.Random,
    axis: Tuple[float, float],
    perp: Tuple[float, float],
) -> LobeParams:
    """Sample CPTG transport variables from sharpened axis-guided priors.

    The old ensemble prior was too diffuse: it allowed large isotropic transport
    currents and produced a broad probability cloud. This upgraded prior is
    anisotropic:

      - broader along the BCG+ICL merger axis,
      - narrower transverse to the axis,
      - still allows lobe-specific turbulent perturbations,
      - keeps polarization and bridge widths biased toward physically compact
        values.

    The priors are declared before scoring and are not tuned per sample.
    """
    # Shared bulk current of the whole merger system.
    global_dx, global_dy = sample_axis_displacement(
        rng=rng,
        axis=axis,
        perp=perp,
        sigma_parallel_px=args.global_axis_sigma_px,
        sigma_perp_px=args.global_transverse_sigma_px,
        max_shift_px=args.max_prior_shift_px,
    )

    # Independent lobe-scale turbulent current around the shared flow.
    left_noise_dx, left_noise_dy = sample_axis_displacement(
        rng=rng,
        axis=axis,
        perp=perp,
        sigma_parallel_px=args.lobe_axis_sigma_px,
        sigma_perp_px=args.lobe_transverse_sigma_px,
        max_shift_px=args.max_prior_shift_px,
    )
    right_noise_dx, right_noise_dy = sample_axis_displacement(
        rng=rng,
        axis=axis,
        perp=perp,
        sigma_parallel_px=args.lobe_axis_sigma_px,
        sigma_perp_px=args.lobe_transverse_sigma_px,
        max_shift_px=args.max_prior_shift_px,
    )

    left_dx = max(-args.max_prior_shift_px, min(args.max_prior_shift_px, global_dx + left_noise_dx))
    left_dy = max(-args.max_prior_shift_px, min(args.max_prior_shift_px, global_dy + left_noise_dy))
    right_dx = max(-args.max_prior_shift_px, min(args.max_prior_shift_px, global_dx + right_noise_dx))
    right_dy = max(-args.max_prior_shift_px, min(args.max_prior_shift_px, global_dy + right_noise_dy))

    # Compact polarization prior: 0/1 px are most likely, larger widths are rare.
    thickness_values = list(range(args.max_polarization_thickness_px + 1))
    thickness_weights = [math.exp(-args.polarization_decay * t) for t in thickness_values]

    # Compact bridge prior: favors no bridge or a narrow bridge.
    bridge_values = list(range(args.max_bridge_width_px + 1))
    bridge_weights = [math.exp(-args.bridge_decay * b) for b in bridge_values]

    return LobeParams(
        left_dx=left_dx,
        left_dy=left_dy,
        left_thick=weighted_choice(rng, thickness_values, thickness_weights),
        right_dx=right_dx,
        right_dy=right_dy,
        right_thick=weighted_choice(rng, thickness_values, thickness_weights),
        bridge_width=weighted_choice(rng, bridge_values, bridge_weights),
    )


def summarize_scores(rows: List[Dict]) -> Dict[str, float]:
    """Return summary statistics for ensemble sample scores."""
    scores = np.array([row["overall_clean_score_0_100"] for row in rows], dtype=float)
    return {
        "score_mean": float(np.mean(scores)),
        "score_median": float(np.median(scores)),
        "score_std": float(np.std(scores)),
        "score_p05": float(np.percentile(scores, 5)),
        "score_p16": float(np.percentile(scores, 16)),
        "score_p84": float(np.percentile(scores, 84)),
        "score_p95": float(np.percentile(scores, 95)),
        "score_best": float(np.max(scores)),
        "fraction_score_ge_50": float(np.mean(scores >= 50)),
        "fraction_score_ge_60": float(np.mean(scores >= 60)),
        "fraction_score_ge_70": float(np.mean(scores >= 70)),
        "fraction_score_ge_80": float(np.mean(scores >= 80)),
    }


def run_ensemble(
    args: argparse.Namespace,
    observed: np.ndarray,
    guide: np.ndarray,
    roi: np.ndarray,
    split: float,
) -> Dict:
    """Generate and score a CPTG chaotic-transport ensemble.

    Progress is printed periodically. Large ensembles, especially 10k-100k
    samples on slower machines, may take hours or days.
    """
    rng = random.Random(args.seed)
    guide_left, guide_right, _ = split_by_median_x(guide)
    axis, perp, axis_info = merger_axis_from_guide(guide)
    guide_support, guide_distance = guide_skeleton_support(
        guide=guide,
        roi=roi,
        support_radius_px=args.guide_support_radius_px,
        core_dilation_px=args.guide_core_dilation_px,
    )

    guide_support_area_ratio = float(guide_support.sum() / max(1, observed.sum()))

    print(
        f"[prior] structure-conditioned anisotropic current: axis=({axis[0]:.3f}, {axis[1]:.3f}), "
        f"angle={axis_info['merger_axis_angle_degrees']:.2f} deg, "
        f"global_axis_sigma={args.global_axis_sigma_px}, global_transverse_sigma={args.global_transverse_sigma_px}, "
        f"lobe_axis_sigma={args.lobe_axis_sigma_px}, lobe_transverse_sigma={args.lobe_transverse_sigma_px}, "
        f"guide_support_radius={args.guide_support_radius_px}, structure_mode={args.structure_conditioning_mode}",
        flush=True,
    )

    occupancy = np.zeros(observed.shape, dtype=np.uint32)
    sample_rows: List[Dict] = []

    best = None
    stage_start = time.time()
    last_report = stage_start
    progress_interval_seconds = args.progress_interval_minutes * 60.0

    print(f"[start] ensemble sampling: {args.n_samples:,} realizations", flush=True)

    for sample_id in range(1, args.n_samples + 1):
        params = sample_lobe_params(args, rng, axis, perp)
        raw_model, bridge = build_lobe_model(params, guide_left, guide_right, roi)
        model = apply_structure_conditioning(
            model=raw_model,
            support=guide_support,
            roi=roi,
            mode=args.structure_conditioning_mode,
        )
        current_metrics = metrics(observed, model, roi, split)

        occupancy += model.astype(np.uint32)

        row = {"sample_id": sample_id, **asdict(params), **current_metrics}
        sample_rows.append(row)

        if best is None or current_metrics["overall_clean_score_0_100"] > best["metrics"]["overall_clean_score_0_100"]:
            best = {"sample_id": sample_id, "params": params, "model": model, "bridge": bridge, "metrics": current_metrics}

        last_report = maybe_print_progress(
            stage="ensemble sampling",
            completed=sample_id,
            total=args.n_samples,
            start_time=stage_start,
            last_report_time=last_report,
            progress_interval_seconds=progress_interval_seconds,
            best_score=None if best is None else best["metrics"]["overall_clean_score_0_100"],
        )

    assert best is not None

    print(
        f"[done] ensemble sampling: {args.n_samples:,} realizations, "
        f"best_score={best['metrics']['overall_clean_score_0_100']:.4f}, "
        f"elapsed={format_duration(time.time() - stage_start)}",
        flush=True,
    )

    probability = occupancy.astype(float) / float(args.n_samples)

    # Ensemble envelope coverage: how much of the observed target lies inside
    # a probability contour of the ensemble.
    envelope_95 = probability >= 0.05
    envelope_68 = probability >= 0.32
    envelope_50 = probability >= 0.50

    coverage_95 = float((observed & envelope_95).sum() / max(1, observed.sum()))
    coverage_68 = float((observed & envelope_68).sum() / max(1, observed.sum()))
    coverage_50 = float((observed & envelope_50).sum() / max(1, observed.sum()))

    false_envelope_95_ratio = float((envelope_95 & (~observed) & roi).sum() / max(1, observed.sum()))
    false_envelope_68_ratio = float((envelope_68 & (~observed) & roi).sum() / max(1, observed.sum()))

    # Log-probability diagnostic:
    # observed contour pixels should have high ensemble occupancy.
    observed_log_probability = float(np.mean(np.log(np.clip(probability[observed & roi], EPS, 1.0))))

    # Background calibration diagnostic:
    # sample an equal number of non-target ROI pixels and reward low occupancy there.
    bg = roi & (~observed)
    bg_prob = probability[bg]
    if bg_prob.size:
        rng_np = np.random.default_rng(args.seed)
        take = min(int(observed.sum()), bg_prob.size)
        sampled_bg_prob = rng_np.choice(bg_prob, size=take, replace=False)
        background_log_exclusion = float(np.mean(np.log(np.clip(1.0 - sampled_bg_prob, EPS, 1.0))))
    else:
        background_log_exclusion = float("nan")

    score_summary = summarize_scores(sample_rows)

    ensemble_summary = {
        **score_summary,
        "n_samples": args.n_samples,
        "seed": args.seed,
        **axis_info,
        "prior_mode": "structure_conditioned_axis_guided",
        "structure_conditioning_mode": args.structure_conditioning_mode,
        "guide_support_radius_px": args.guide_support_radius_px,
        "guide_core_dilation_px": args.guide_core_dilation_px,
        "guide_support_area_ratio_to_observed": guide_support_area_ratio,
        "global_axis_sigma_px": args.global_axis_sigma_px,
        "global_transverse_sigma_px": args.global_transverse_sigma_px,
        "lobe_axis_sigma_px": args.lobe_axis_sigma_px,
        "lobe_transverse_sigma_px": args.lobe_transverse_sigma_px,
        "max_prior_shift_px": args.max_prior_shift_px,
        "max_polarization_thickness_px": args.max_polarization_thickness_px,
        "max_bridge_width_px": args.max_bridge_width_px,
        "polarization_decay": args.polarization_decay,
        "bridge_decay": args.bridge_decay,
        "observed_coverage_probability_ge_0p05": coverage_95,
        "observed_coverage_probability_ge_0p32": coverage_68,
        "observed_coverage_probability_ge_0p50": coverage_50,
        "false_envelope_0p05_area_ratio": false_envelope_95_ratio,
        "false_envelope_0p32_area_ratio": false_envelope_68_ratio,
        "observed_log_probability_mean": observed_log_probability,
        "background_log_exclusion_mean": background_log_exclusion,
        "best_sample_id": best["sample_id"],
        "best_sample_score": best["metrics"]["overall_clean_score_0_100"],
    }

    return {
        "probability": probability,
        "occupancy": occupancy,
        "sample_rows": sample_rows,
        "best": best,
        "summary": ensemble_summary,
        "envelope_95": envelope_95,
        "envelope_68": envelope_68,
        "envelope_50": envelope_50,
        "guide_support": guide_support,
        "guide_distance": guide_distance,
    }



def make_overlay(rgb: np.ndarray, observed: np.ndarray, guide: np.ndarray, model: np.ndarray, roi: np.ndarray) -> Image.Image:
    """Create observed/guide/model/match overlay."""
    out = rgb.copy()
    guide_plot = binary_dilation(guide, iterations=1) & roi
    observed_plot = binary_dilation(observed, iterations=1) & roi
    model_plot = binary_dilation(model, iterations=1) & roi
    matched_plot = observed_plot & model_plot

    out[guide_plot] = [0, 255, 255]
    out[observed_plot] = [255, 0, 255]
    out[model_plot] = [0, 220, 0]
    out[matched_plot] = [255, 230, 0]
    return Image.fromarray(out)


def probability_image(rgb: np.ndarray, probability: np.ndarray, observed: np.ndarray, guide: np.ndarray, roi: np.ndarray) -> Image.Image:
    """Render ensemble occupancy probability as a heat image."""
    gray = np.asarray(ImageOps.grayscale(Image.fromarray(rgb))).astype(np.uint8)
    out = np.stack([gray, gray, gray], axis=-1).astype(np.float32)

    p = np.clip(probability, 0.0, 1.0)
    heat = np.zeros_like(out)
    heat[..., 0] = 255.0 * p
    heat[..., 1] = 220.0 * np.sqrt(p)
    heat[..., 2] = 40.0 * (1.0 - p)

    alpha = np.clip(0.15 + 0.85 * p, 0.0, 1.0)[..., None]
    out = np.where((p > 0)[..., None] & roi[..., None], (1.0 - alpha) * out + alpha * heat, out)

    # Overlay target and guide contours for context.
    out[binary_dilation(guide, iterations=1) & roi] = [0, 255, 255]
    out[binary_dilation(observed, iterations=1) & roi] = [255, 0, 255]
    return Image.fromarray(np.clip(out, 0, 255).astype(np.uint8))


def make_residual(rgb: np.ndarray, observed: np.ndarray, model: np.ndarray, roi: np.ndarray) -> Image.Image:
    """Create residual map for best sample."""
    gray = np.asarray(ImageOps.grayscale(Image.fromarray(rgb)))
    out = np.stack([gray, gray, gray], axis=-1)

    dist_model = distance_transform_edt(~model)
    dist_observed = distance_transform_edt(~observed)

    matched = observed & (dist_model <= TOLERANCE_PX)
    missed = observed & (dist_model > TOLERANCE_PX)
    excess = model & (dist_observed > TOLERANCE_PX)

    out[binary_dilation(matched, iterations=1) & roi] = [255, 230, 0]
    out[binary_dilation(missed, iterations=1) & roi] = [255, 0, 255]
    out[binary_dilation(excess, iterations=1) & roi] = [0, 210, 0]
    return Image.fromarray(out)


def fit_image(image: Image.Image, size: Tuple[int, int]) -> Image.Image:
    """Resize while preserving aspect ratio."""
    return ImageOps.contain(image.convert("RGB"), size, Image.Resampling.LANCZOS)


def paste_center(canvas: Image.Image, image: Image.Image, box: Tuple[int, int, int, int]) -> None:
    """Paste image centered in a box."""
    x, y, width, height = box
    canvas.paste(image, (x + (width - image.size[0]) // 2, y + (height - image.size[1]) // 2))


def draw_figure(
    rgb: np.ndarray,
    observed: np.ndarray,
    guide: np.ndarray,
    roi: np.ndarray,
    deterministic: Dict,
    ensemble: Dict,
    output: Path,
) -> None:
    """Render the ensemble benchmark figure."""
    f_title = load_font(42, True)
    f_panel = load_font(23, True)
    f_small = load_font(19, False)
    f_small_b = load_font(19, True)
    f_tiny = load_font(15, False)
    f_tiny_b = load_font(15, True)

    best_model = ensemble["best"]["model"]

    observed_panel = make_overlay(rgb, observed, guide, np.zeros_like(best_model), roi)
    prob_panel = probability_image(rgb, ensemble["probability"], observed, guide, roi)
    best_panel = make_overlay(rgb, observed, guide, best_model, roi)
    residual_panel = make_residual(rgb, observed, best_model, roi)

    width, height = 2900, 1950
    canvas = Image.new("RGB", (width, height), (248, 248, 248))
    draw = ImageDraw.Draw(canvas)

    title = "CPTG Bullet Cluster Chaotic-Transport Ensemble Benchmark"
    subtitle = "Fixed transport-current priors generate an ensemble; observed mass contours are scored against the ensemble envelope"
    draw.text(((width - draw.textbbox((0, 0), title, font=f_title)[2]) // 2, 22), title, font=f_title, fill=(0, 0, 0))
    draw.text(((width - draw.textbbox((0, 0), subtitle, font=f_small)[2]) // 2, 82), subtitle, font=f_small, fill=(45, 45, 45))

    margin, gap, top_y = 40, 26, 132
    panel_w = (width - 2 * margin - 3 * gap) // 4
    panel_h = 560
    table_y = top_y + panel_h + 40
    table_h = height - table_y - 72

    panels = [
        (margin, top_y, panel_w, panel_h, "(a) Observed target + guide"),
        (margin + panel_w + gap, top_y, panel_w, panel_h, "(b) Ensemble probability"),
        (margin + 2 * (panel_w + gap), top_y, panel_w, panel_h, "(c) Best realization overlay"),
        (margin + 3 * (panel_w + gap), top_y, panel_w, panel_h, "(d) Best realization residual"),
        (margin, table_y, width - 2 * margin, table_h, "(e) Ensemble score summary"),
    ]

    for x, y, w, h, label_text in panels:
        draw.rounded_rectangle([x, y, x + w, y + h], radius=16, outline=(55, 55, 55), width=3, fill=(255, 255, 255))
        draw.text((x + 14, y + 12), label_text, font=f_panel, fill=(0, 0, 0))

    plot_size = (panel_w - 36, panel_h - 76)
    for img, panel in zip([observed_panel, prob_panel, best_panel, residual_panel], panels[:4]):
        paste_center(canvas, fit_image(img, plot_size), (panel[0] + 18, panel[1] + 55, plot_size[0], plot_size[1]))

    legend_y = top_y + panel_h + 9
    legend_items = [
        ((255, 0, 255), "Observed mass target"),
        ((0, 255, 255), "BCG+ICL guide"),
        ((0, 220, 0), "Best CPTG realization"),
        ((255, 230, 0), "Matched target/model"),
    ]
    x_cursor = margin + 25
    for color, label_text in legend_items:
        draw.line([x_cursor, legend_y + 10, x_cursor + 44, legend_y + 10], fill=color, width=8)
        draw.text((x_cursor + 54, legend_y - 2), label_text, font=f_tiny, fill=(35, 35, 35))
        x_cursor += 525

    x0, y0, w0, h0, _ = panels[4]
    left_x = x0 + 28
    middle_x = x0 + int(w0 * 0.39)
    right_x = x0 + int(w0 * 0.69)
    table_top = y0 + 58
    col_w_left = int(w0 * 0.35)
    col_w_mid = int(w0 * 0.26)
    col_w_right = w0 - col_w_left - col_w_mid - 70

    # Deterministic comparison table.
    draw.rounded_rectangle([left_x, table_top, left_x + col_w_left, table_top + 42], radius=8, fill=(232, 238, 248), outline=(90, 90, 120))
    draw.text((left_x + 12, table_top + 8), "Deterministic baselines", font=f_small_b, fill=(0, 0, 0))

    y = table_top + 54
    rows = [
        ("Guide-only", deterministic["guide_only"]["overall_clean_score_0_100"]),
        ("Polarization-only", deterministic["polarization_only"]["overall_clean_score_0_100"]),
        ("Low-order calibrated", deterministic["low_order"]["overall_clean_score_0_100"]),
        ("Closure comparison", deterministic["closure"]["overall_clean_score_0_100"]),
    ]
    for name, value in rows:
        draw.text((left_x, y), name, font=f_tiny, fill=(0, 0, 0))
        draw.text((left_x + 260, y), f"{value:.2f}", font=f_tiny_b, fill=(0, 0, 0))
        y += 30

    draw.text((left_x, y + 10), "Best realization details", font=f_tiny_b, fill=(0, 0, 0))
    y += 42
    best_metrics = ensemble["best"]["metrics"]
    for name, key, fmt in [
        ("Best score", "overall_clean_score_0_100", "{:.2f}"),
        ("Best F1", "f1_20kpc", "{:.4f}"),
        ("Best IoU", "iou_20kpc", "{:.4f}"),
        ("Best MHD", "symmetric_mhd_kpc", "{:.2f} kpc"),
        ("Best RMSE", "distance_rmse_kpc", "{:.2f} kpc"),
    ]:
        draw.text((left_x, y), name, font=f_tiny, fill=(0, 0, 0))
        draw.text((left_x + 260, y), fmt.format(best_metrics[key]), font=f_tiny_b, fill=(0, 0, 0))
        y += 29

    # Ensemble score statistics.
    draw.rounded_rectangle([middle_x, table_top, middle_x + col_w_mid, table_top + 42], radius=8, fill=(232, 248, 235), outline=(80, 120, 80))
    draw.text((middle_x + 12, table_top + 8), "Ensemble statistics", font=f_small_b, fill=(0, 0, 0))

    y = table_top + 54
    summary = ensemble["summary"]
    stat_rows = [
        ("Samples", summary["n_samples"], "{:.0f}"),
        ("Mean score", summary["score_mean"], "{:.2f}"),
        ("Median score", summary["score_median"], "{:.2f}"),
        ("Score p84", summary["score_p84"], "{:.2f}"),
        ("Score p95", summary["score_p95"], "{:.2f}"),
        ("Best score", summary["score_best"], "{:.2f}"),
        ("P(score≥60)", summary["fraction_score_ge_60"], "{:.3f}"),
        ("P(score≥70)", summary["fraction_score_ge_70"], "{:.3f}"),
        ("P(score≥80)", summary["fraction_score_ge_80"], "{:.3f}"),
    ]
    for name, value, fmt in stat_rows:
        draw.text((middle_x, y), name, font=f_tiny, fill=(0, 0, 0))
        draw.text((middle_x + 230, y), fmt.format(value), font=f_tiny_b, fill=(0, 0, 0))
        y += 29

    # Ensemble coverage / priors.
    draw.rounded_rectangle([right_x, table_top, right_x + col_w_right, table_top + 42], radius=8, fill=(248, 243, 232), outline=(120, 100, 70))
    draw.text((right_x + 12, table_top + 8), "Transport-current envelope", font=f_small_b, fill=(0, 0, 0))

    y = table_top + 54
    env_rows = [
        ("Observed coverage p≥0.05", summary["observed_coverage_probability_ge_0p05"], "{:.3f}"),
        ("Observed coverage p≥0.32", summary["observed_coverage_probability_ge_0p32"], "{:.3f}"),
        ("Observed coverage p≥0.50", summary["observed_coverage_probability_ge_0p50"], "{:.3f}"),
        ("False envelope p≥0.05", summary["false_envelope_0p05_area_ratio"], "{:.3f}"),
        ("False envelope p≥0.32", summary["false_envelope_0p32_area_ratio"], "{:.3f}"),
        ("Mean log P(obs)", summary["observed_log_probability_mean"], "{:.3f}"),
        ("Mean log exclusion", summary["background_log_exclusion_mean"], "{:.3f}"),
        ("Structure mode", summary["structure_conditioning_mode"], "{}"),
        ("Guide radius px", summary["guide_support_radius_px"], "{:.1f}"),
        ("Support/obs area", summary["guide_support_area_ratio_to_observed"], "{:.2f}"),
        ("Global axis sigma px", summary["global_axis_sigma_px"], "{:.2f}"),
        ("Global trans. sigma px", summary["global_transverse_sigma_px"], "{:.2f}"),
        ("Lobe axis sigma px", summary["lobe_axis_sigma_px"], "{:.2f}"),
        ("Lobe trans. sigma px", summary["lobe_transverse_sigma_px"], "{:.2f}"),
        ("Max shift px", summary["max_prior_shift_px"], "{:.0f}"),
    ]
    for name, value, fmt in env_rows:
        draw.text((right_x, y), name, font=f_tiny, fill=(0, 0, 0))
        if isinstance(value, str):
            value_text = value
        else:
            value_text = fmt.format(value)
        draw.text((right_x + 270, y), value_text, font=f_tiny_b, fill=(0, 0, 0))
        y += 28

    note = (
        "Ensemble mode freezes prior ranges and samples transport currents. It tests whether the observed mass morphology lies "
        "inside CPTG's allowed transport envelope, rather than asking one deterministic map to hit every contour exactly."
    )
    draw.rounded_rectangle([x0 + 28, y0 + h0 - 92, x0 + w0 - 28, y0 + h0 - 24], radius=8, fill=(255, 246, 224), outline=(160, 130, 80))
    draw.text((x0 + 44, y0 + h0 - 76), textwrap.fill(note, 190), font=f_tiny, fill=(60, 40, 0))

    footer = "Figure-level reduced-model ensemble; not a raw JWST/MARS kappa-array fit or full hydrodynamic merger simulation."
    draw.text(((width - draw.textbbox((0, 0), footer, font=f_small)[2]) // 2, height - 48), footer, font=f_small, fill=(50, 50, 50))
    canvas.save(output, quality=95)


# ---------------------------------------------------------------------------
# Serialization
# ---------------------------------------------------------------------------

def save_samples_csv(rows: List[Dict], path: Path) -> None:
    """Write per-sample parameters and metrics."""
    if not rows:
        return
    keys = list(rows[0].keys())
    with path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=keys)
        writer.writeheader()
        writer.writerows(rows)


def save_packets_csv(packets: List[Dict], path: Path) -> None:
    """Write residual-closure packet log."""
    with path.open("w", newline="") as f:
        if packets:
            keys = sorted(set().union(*(p.keys() for p in packets)))
            writer = csv.DictWriter(f, fieldnames=keys)
            writer.writeheader()
            writer.writerows(packets)
        else:
            writer = csv.writer(f)
            writer.writerow(["operation", "note"])
            writer.writerow(["none", "no closure packets logged"])


def save_outputs(
    args: argparse.Namespace,
    deterministic: Dict,
    ensemble: Dict,
    observed: np.ndarray,
    guide: np.ndarray,
    roi: np.ndarray,
) -> None:
    """Save JSON, CSV, NPZ, and figure outputs."""
    payload = {
        "description": "CPTG structure-conditioned chaotic-transport ensemble benchmark against Cha et al. 2025 figure-level mass contours.",
        "caveat": "Uses figure-level extracted contours. Ensemble priors are fixed before scoring samples, but this is not a raw kappa-array validation.",
        "kpc_per_pixel": KPC_PER_PIXEL,
        "tolerance_kpc": TOLERANCE_KPC,
        "deterministic": deterministic,
        "ensemble_summary": ensemble["summary"],
        "best_sample_params": asdict(ensemble["best"]["params"]),
        "best_sample_metrics": ensemble["best"]["metrics"],
    }
    args.json.write_text(json.dumps(payload, indent=2))

    save_samples_csv(ensemble["sample_rows"], args.samples_csv)
    save_packets_csv(deterministic["closure_packets"], args.packets_csv)

    np.savez_compressed(
        args.npz,
        observed_mass_mask=observed.astype(np.uint8),
        guide_icl_mask=guide.astype(np.uint8),
        roi_mask=roi.astype(np.uint8),
        ensemble_probability=ensemble["probability"].astype(np.float32),
        ensemble_occupancy=ensemble["occupancy"].astype(np.uint32),
        envelope_95=ensemble["envelope_95"].astype(np.uint8),
        envelope_68=ensemble["envelope_68"].astype(np.uint8),
        envelope_50=ensemble["envelope_50"].astype(np.uint8),
        best_sample_mask=ensemble["best"]["model"].astype(np.uint8),
        guide_support_mask=ensemble["guide_support"].astype(np.uint8),
        guide_distance_px=ensemble["guide_distance"].astype(np.float32),
    )


# ---------------------------------------------------------------------------
# Main pipeline
# ---------------------------------------------------------------------------

def run(args: argparse.Namespace) -> None:
    """Run the full ensemble benchmark."""
    if not args.observed.exists():
        raise FileNotFoundError(f"Missing observed image: {args.observed}")

    rgb = np.asarray(Image.open(args.observed).convert("RGB"))
    observed, guide, roi = extract_observed_and_guide(rgb)

    if observed.sum() < 100:
        raise RuntimeError(f"Observed contour extraction failed: only {observed.sum()} pixels found.")
    if guide.sum() < 100:
        raise RuntimeError(f"BCG+ICL guide extraction failed: only {guide.sum()} pixels found.")

    _, _, split = split_by_median_x(observed)
    validate_scoring_perfect_match(observed, roi, split)

    guide_metrics = metrics(observed, guide & roi, roi, split)

    guide_left, guide_right, _ = split_by_median_x(guide)

    pol_best = None
    for thickness in range(0, 6):
        params = LobeParams(0, 0, thickness, 0, 0, thickness, 0)
        model, _ = build_lobe_model(params, guide_left, guide_right, roi)
        current = metrics(observed, model, roi, split)
        if pol_best is None or current["overall_clean_score_0_100"] > pol_best["metrics"]["overall_clean_score_0_100"]:
            pol_best = {"params": asdict(params), "model": model, "metrics": current}
    assert pol_best is not None

    low_order_evals = count_low_order_evals(args.max_shift, args.low_order_step)
    print_runtime_warning(args, low_order_evals)

    low = calibrate_low_order(
        observed,
        guide,
        roi,
        split,
        max_shift=args.max_shift,
        shift_step=args.low_order_step,
        progress_interval_seconds=args.progress_interval_minutes * 60.0,
    )

    closure_model, closure_packets, closure_metrics = residual_closure(
        observed=observed,
        base_model=low["model"],
        roi=roi,
        split=split,
        mode=args.closure_mode,
    )

    deterministic_metrics_only = {
        "guide_only": guide_metrics,
        "polarization_only": pol_best["metrics"],
        "low_order": low["metrics"],
        "closure": closure_metrics,
        "closure_mode": args.closure_mode,
        "closure_packets": closure_packets,
        "low_order_params": asdict(low["params"]) | {"evals": low["evals"]},
        "polarization_only_params": pol_best["params"],
    }

    ensemble = run_ensemble(args, observed, guide, roi, split)

    draw_figure(rgb, observed, guide, roi, deterministic_metrics_only, ensemble, args.output)
    save_outputs(args, deterministic_metrics_only, ensemble, observed, guide, roi)

    print(f"Wrote figure: {args.output}")
    print(f"Wrote metrics JSON: {args.json}")
    print(f"Wrote samples CSV: {args.samples_csv}")
    print(f"Wrote closure packets CSV: {args.packets_csv}")
    print(f"Wrote probability NPZ: {args.npz}")

    print("\nDeterministic scores:")
    print(f"  guide_only: {guide_metrics['overall_clean_score_0_100']:.4f}")
    print(f"  polarization_only: {pol_best['metrics']['overall_clean_score_0_100']:.4f}")
    print(f"  low_order: {low['metrics']['overall_clean_score_0_100']:.4f}")
    print(f"  closure: {closure_metrics['overall_clean_score_0_100']:.4f}")

    print("\nEnsemble summary:")
    for key in [
        "score_mean",
        "score_median",
        "score_p84",
        "score_p95",
        "score_best",
        "observed_coverage_probability_ge_0p05",
        "observed_coverage_probability_ge_0p32",
        "observed_coverage_probability_ge_0p50",
        "fraction_score_ge_60",
        "fraction_score_ge_70",
        "fraction_score_ge_80",
    ]:
        print(f"  {key}: {ensemble['summary'][key]}")


def build_arg_parser() -> argparse.ArgumentParser:
    """Build command-line interface."""
    parser = argparse.ArgumentParser(description="CPTG Bullet Cluster chaotic-transport ensemble benchmark.")
    parser.add_argument("--observed", type=Path, default=DEFAULT_OBSERVED, help="Observed Cha 2025 panel image.")
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT, help="Output ensemble benchmark figure.")
    parser.add_argument("--json", type=Path, default=DEFAULT_JSON, help="Output metrics JSON.")
    parser.add_argument("--samples-csv", type=Path, default=DEFAULT_SAMPLES_CSV, help="Per-sample ensemble CSV.")
    parser.add_argument("--packets-csv", type=Path, default=DEFAULT_PACKETS_CSV, help="Closure packet log CSV.")
    parser.add_argument("--npz", type=Path, default=DEFAULT_NPZ, help="Output ensemble probability NPZ.")
    parser.add_argument("--max-shift", type=int, default=8, help="Max deterministic low-order transport shift in pixels. Increase for slower broader search.")
    parser.add_argument("--low-order-step", type=int, default=8, help="Step size for deterministic low-order grid search in pixels. Smaller is slower.")
    parser.add_argument("--closure-mode", choices=["exact", "packet"], default="packet", help="Closure comparison mode.")
    parser.add_argument("--n-samples", type=int, default=50000, help="Number of ensemble realizations. Default increased for a smoother ensemble estimate.")
    parser.add_argument("--seed", type=int, default=7, help="Random seed for ensemble sampling.")
    parser.add_argument("--global-axis-sigma-px", type=float, default=5.0, help="Shared current sigma along the inferred merger axis in px.")
    parser.add_argument("--global-transverse-sigma-px", type=float, default=1.0, help="Shared current sigma transverse to the merger axis in px.")
    parser.add_argument("--lobe-axis-sigma-px", type=float, default=4.0, help="Lobe-specific turbulent sigma along the merger axis in px.")
    parser.add_argument("--lobe-transverse-sigma-px", type=float, default=1.3, help="Lobe-specific turbulent sigma transverse to the merger axis in px.")
    parser.add_argument("--max-prior-shift-px", type=int, default=22, help="Hard clip for sampled transport shifts in px.")
    parser.add_argument("--max-polarization-thickness-px", type=int, default=2, help="Max sampled polarization/dilation thickness in px.")
    parser.add_argument("--max-bridge-width-px", type=int, default=2, help="Max sampled bridge/trail width in px.")
    parser.add_argument("--polarization-decay", type=float, default=0.95, help="Exponential decay rate for thicker polarization widths.")
    parser.add_argument("--bridge-decay", type=float, default=1.25, help="Exponential decay rate for wider bridge widths.")
    parser.add_argument("--structure-conditioning-mode", choices=["none", "hard"], default="hard", help="Condition ensemble masks on BCG+ICL skeleton support. Use 'none' to reproduce axis-only priors.")
    parser.add_argument("--guide-support-radius-px", type=float, default=6.0, help="Max distance from BCG+ICL guide skeleton allowed in hard structure-conditioning mode.")
    parser.add_argument("--guide-core-dilation-px", type=int, default=1, help="Pre-dilation of the guide skeleton before support-distance calculation.")
    parser.add_argument("--progress-interval-minutes", type=float, default=5.0, help="Print progress reports about this often. Default is 5 minutes.")
    return parser


def main() -> None:
    """Program entry point."""
    args = build_arg_parser().parse_args()
    run(args)


if __name__ == "__main__":
    main()
