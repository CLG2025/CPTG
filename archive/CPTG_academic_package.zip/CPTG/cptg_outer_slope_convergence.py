#!/usr/bin/env python3
# =============================================================================
# CPTG outer-slope convergence
# =============================================================================
#
# Audit Goals
# -----------
# 1) No visual anchor rescaling is used.
#    The plotted y-values are the true, raw values derived from the SPARC-based
#    CPTG calculation.
#
# 2) The primary statistic is stated explicitly.
#    At each normalized radius x = r/Rmax, the script computes the per-galaxy
#    local logarithmic slope
#        s(x) = d ln V / d ln r
#    from the extended CPTG rotation curve.  It then stacks galaxies by taking
#    the median at each x.
#
# 3) The figure shows the raw population statistics.
#    - Blue shaded band: 16th-84th percentile envelope across galaxies.
#    - Blue curve: raw median local logarithmic slope.
#    - Dashed horizontal line: theoretical asymptote s = 1/4.
#
#    The smooth free-asymptote fit
#        s(x) = s_inf - A / (x + B)^p
#    is saved to the CSV and summary file, but is not plotted by default.
#
# 4) The asymptotic regime is probed directly.
#    The script extends each CPTG curve to xmax = 128 Rmax using the
#    fixed-outer-source continuation rule and fits / plots only the outer regime
#    x >= 4, where the asymptotic approach is clean.
#
# Path handling
# -------------
# By default, the script finds the benchmark script in the same folder and uses
# the benchmark-script path settings (EXTRACT_DIR or ZIP_PATH) for the SPARC
# data.  No sandbox-only paths are hard-coded.
# =============================================================================

from __future__ import annotations

import argparse
import csv
import glob
import importlib.util
import math
import os
import sys
import tempfile
import zipfile
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from scipy.optimize import curve_fit

# =============================================================================
# Configuration
# =============================================================================

SCRIPT_DIR = Path(__file__).resolve().parent

# Source-field weights used in the existing CPTG benchmark workflow.
GAS_WEIGHT = 27.0 / 50.0
DISK_WEIGHT = 23.0 / 50.0
BULGE_WEIGHT = 16.0 / 25.0

# Radius grid for each extended galaxy curve.
X_MIN_EVAL = 0.05
X_MAX_EVAL = 128.0
N_EVAL = 600
X_EVAL = np.geomspace(X_MIN_EVAL, X_MAX_EVAL, N_EVAL)

# The asymptotic-analysis plot is restricted to the clean outer regime.
X_FIT_MIN = 4.0
X_PLOT = X_EVAL[X_EVAL >= X_FIT_MIN]

MIN_POINTS = 3
THEORY_ASYMPTOTE = 0.25

# =============================================================================
# Benchmark discovery and import
# =============================================================================

def find_default_benchmark_script() -> Path:
    exact = SCRIPT_DIR / "SPARC_CPTG_MOND_Benchmark.py"
    if exact.exists():
        return exact

    patterns = [
        "SPARC_CPTG_MOND_Benchmark*.py",
        "*CPTG*MOND*Benchmark*.py",
        "*Benchmark*.py",
    ]
    self_path = Path(__file__).resolve()
    candidates: list[Path] = []
    for pattern in patterns:
        for candidate in SCRIPT_DIR.glob(pattern):
            candidate = candidate.resolve()
            if candidate != self_path and candidate.is_file():
                candidates.append(candidate)
        if candidates:
            break

    if not candidates:
        raise FileNotFoundError(
            "Could not find the benchmark script in this folder. Place "
            "SPARC_CPTG_MOND_Benchmark.py beside this script or pass "
            "--benchmark-script."
        )

    candidates = sorted(set(candidates), key=lambda p: p.stat().st_mtime, reverse=True)
    return candidates[0]

def load_benchmark_module(module_path: Path):
    module_path = module_path.resolve()
    if not module_path.exists():
        raise FileNotFoundError(f"Benchmark script not found: {module_path}")
    spec = importlib.util.spec_from_file_location("cptg_benchmark", str(module_path))
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Could not import benchmark script: {module_path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module

# =============================================================================
# SPARC data location
# =============================================================================

def has_dat_files(directory: Path) -> bool:
    return directory.exists() and any(directory.glob("**/*.dat"))

def extract_zip_to_temp(zip_path: Path) -> Path:
    if not zip_path.exists():
        raise FileNotFoundError(f"SPARC zip file not found: {zip_path}")
    temp_dir = Path(tempfile.mkdtemp(prefix="sparc_outer_slope_academic_"))
    with zipfile.ZipFile(zip_path, "r") as archive:
        archive.extractall(temp_dir)
    return temp_dir

def resolve_sparc_root(bench, sparc_dir_arg: str | None, sparc_zip_arg: str | None) -> Path:
    if sparc_dir_arg:
        sparc_dir = Path(sparc_dir_arg).expanduser().resolve()
        if has_dat_files(sparc_dir):
            return sparc_dir
        raise FileNotFoundError(f"--sparc-dir has no .dat files: {sparc_dir}")

    if sparc_zip_arg:
        return extract_zip_to_temp(Path(sparc_zip_arg).expanduser().resolve())

    extract_dir = getattr(bench, "EXTRACT_DIR", None)
    if extract_dir:
        extract_dir = Path(str(extract_dir)).expanduser().resolve()
        if has_dat_files(extract_dir):
            return extract_dir

    zip_path = getattr(bench, "ZIP_PATH", None)
    if zip_path:
        zip_path = Path(str(zip_path)).expanduser().resolve()
        if zip_path.exists():
            return extract_zip_to_temp(zip_path)

    local_zip = SCRIPT_DIR / "sparc_database.zip"
    if local_zip.exists():
        return extract_zip_to_temp(local_zip)

    raise FileNotFoundError(
        "Could not locate SPARC data. The benchmark script must define a valid "
        "EXTRACT_DIR or ZIP_PATH, or you must pass --sparc-dir / --sparc-zip."
    )

def collect_unique_dat_files(root_dir: Path) -> list[Path]:
    found = glob.glob(str(root_dir / "**" / "*.dat"), recursive=True)
    unique_by_name: dict[str, Path] = {}
    for path_text in sorted(found):
        path = Path(path_text)
        unique_by_name.setdefault(path.name, path)
    return sorted(unique_by_name.values())

# =============================================================================
# SPARC preprocessing and CPTG curve construction
# =============================================================================

def clean_sparc_arrays(bench, path: Path):
    r_kpc, vobs_km_s, errv_km_s, vgas_km_s, vdisk_km_s, vbul_km_s = bench.load_sparc_file(str(path))

    mask = (
        np.isfinite(r_kpc)
        & np.isfinite(vobs_km_s)
        & np.isfinite(errv_km_s)
        & np.isfinite(vgas_km_s)
        & np.isfinite(vdisk_km_s)
        & np.isfinite(vbul_km_s)
    )

    r_kpc = np.asarray(r_kpc[mask], dtype=float)
    vobs_km_s = np.asarray(vobs_km_s[mask], dtype=float)
    errv_km_s = np.asarray(errv_km_s[mask], dtype=float)
    vgas_km_s = np.asarray(vgas_km_s[mask], dtype=float)
    vdisk_km_s = np.asarray(vdisk_km_s[mask], dtype=float)
    vbul_km_s = np.asarray(vbul_km_s[mask], dtype=float)

    if r_kpc.size < MIN_POINTS:
        return None

    order = np.argsort(r_kpc)
    r_kpc = r_kpc[order]
    vobs_km_s = vobs_km_s[order]
    errv_km_s = errv_km_s[order]
    vgas_km_s = vgas_km_s[order]
    vdisk_km_s = vdisk_km_s[order]
    vbul_km_s = vbul_km_s[order]

    _, idx = np.unique(r_kpc, return_index=True)
    r_kpc = r_kpc[idx]
    vobs_km_s = vobs_km_s[idx]
    errv_km_s = errv_km_s[idx]
    vgas_km_s = vgas_km_s[idx]
    vdisk_km_s = vdisk_km_s[idx]
    vbul_km_s = vbul_km_s[idx]

    if r_kpc.size < MIN_POINTS:
        return None

    return r_kpc, vobs_km_s, errv_km_s, vgas_km_s, vdisk_km_s, vbul_km_s

def build_extended_velocity_curve(bench, path: Path):
    cleaned = clean_sparc_arrays(bench, path)
    if cleaned is None:
        return None

    r_kpc, vobs_km_s, errv_km_s, vgas_km_s, vdisk_km_s, vbul_km_s = cleaned
    r_m = r_kpc * bench.KPC_TO_M
    vobs = vobs_km_s * 1000.0
    errv = np.maximum(errv_km_s * 1000.0, 1.0)
    vgas = vgas_km_s * 1000.0
    vdisk = vdisk_km_s * 1000.0
    vbul = vbul_km_s * 1000.0

    gbar_obs = bench.build_baryonic_field(
        r_m=r_m,
        vgas=vgas,
        vdisk=vdisk,
        vbul=vbul,
        gas_weight=GAS_WEIGHT,
        disk_weight=DISK_WEIGHT,
        bulge_weight=BULGE_WEIGHT,
    )

    try:
        fit = bench.fit_a_star_and_rc_for_galaxy(
            g_bar=gbar_obs,
            r_m=r_m,
            vobs_m_s=vobs,
            errv_m_s=errv,
        )
    except TypeError:
        fit = bench.fit_a_star_and_rc_for_galaxy(gbar_obs, r_m, vobs, errv)
    except Exception:
        return None

    a_star = float(fit["a_star"])
    rc = float(fit["rc"])

    gas_term = bench.velocity_component_term(vgas, True)
    disk_term = bench.velocity_component_term(vdisk, np.any(vdisk < 0.0))
    bulge_term = bench.velocity_component_term(vbul, np.any(vbul < 0.0))
    vb2_obs = GAS_WEIGHT * gas_term + DISK_WEIGHT * disk_term + BULGE_WEIGHT * bulge_term
    vb2_obs = np.maximum(vb2_obs, 0.0)

    rmax_m = float(np.max(r_m))
    r_eval = X_EVAL * rmax_m
    vb2_eval = np.interp(r_eval, r_m, vb2_obs, left=vb2_obs[0], right=vb2_obs[-1])
    gbar_eval = vb2_eval / np.maximum(r_eval, 1e-30)
    g_eval = bench.cptg_acceleration(gbar_eval, r_eval, a_star, rc)
    v_eval = np.sqrt(np.maximum(g_eval * r_eval, 1e-30))

    if not np.all(np.isfinite(v_eval)) or np.any(v_eval <= 0.0):
        return None

    return X_EVAL.copy(), v_eval

def local_logarithmic_slope(x: np.ndarray, v: np.ndarray) -> np.ndarray:
    return np.gradient(np.log(v), np.log(x))

# =============================================================================
# Population statistics and smooth fit
# =============================================================================

def build_population_slope_statistics(curves: list[tuple[np.ndarray, np.ndarray]]):
    slopes = []
    for x, v in curves:
        s = local_logarithmic_slope(x, v)
        slopes.append(s[x >= X_FIT_MIN])

    slope_array = np.asarray(slopes, dtype=float)
    median = np.nanmedian(slope_array, axis=0)
    p16 = np.nanpercentile(slope_array, 16.0, axis=0)
    p84 = np.nanpercentile(slope_array, 84.0, axis=0)
    return X_PLOT.copy(), median, p16, p84

def fit_asymptotic_model_free(x: np.ndarray, y: np.ndarray) -> tuple[float, float, float, float, float]:
    """Fit y = s_inf - A/(x+B)^p with free s_inf using scipy."""
    def model(xdata, s_inf, A, B, p):
        return s_inf - A / np.power(xdata + B, p)

    p0 = [0.250000, 0.047000, 0.500000, 0.480000]
    lower = [max(float(np.max(y)) + 1e-6, 0.230000), 1e-10, 1e-6, 1e-6]
    upper = [0.270000, 10.0, 20.0, 5.0]
    popt, _ = curve_fit(model, x, y, p0=p0, bounds=(lower, upper), maxfev=200000)
    s_inf, A, B, p = [float(v) for v in popt]
    fit = model(x, s_inf, A, B, p)
    sse = float(np.mean((fit - y) ** 2))
    return sse, s_inf, A, B, p

def evaluate_asymptotic_model(x: np.ndarray, s_inf: float, A: float, B: float, p: float) -> np.ndarray:
    return s_inf - A / np.power(x + B, p)

# =============================================================================
# Outputs
# =============================================================================

def save_csv(path: Path, x: np.ndarray, median: np.ndarray, p16: np.ndarray, p84: np.ndarray, fit: np.ndarray):
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow([
            "x_r_over_Rmax",
            "median_local_slope",
            "percentile16_local_slope",
            "percentile84_local_slope",
            "smooth_free_fit",
        ])
        for row in zip(x, median, p16, p84, fit):
            writer.writerow([f"{val:.6f}" for val in row])

def save_summary(
    path: Path,
    benchmark_script: Path,
    sparc_root: Path,
    total_files: int,
    usable: int,
    failed: int,
    s_inf: float,
    A: float,
    B: float,
    p: float,
    rmse: float,
):
    with path.open("w", encoding="utf-8") as f:
        f.write("CPTG outer-slope convergence summary\n")
        f.write("=====================================================\n")
        f.write(f"Benchmark script: {benchmark_script}\n")
        f.write(f"SPARC root: {sparc_root}\n")
        f.write(f"Total .dat files: {total_files}\n")
        f.write(f"Usable galaxies: {usable}\n")
        f.write(f"Skipped galaxies: {failed}\n")
        f.write(f"Extension xmax: {X_MAX_EVAL:.6f} Rmax\n")
        f.write(f"Plot / fit interval: x >= {X_FIT_MIN:.6f}\n")
        f.write("Estimator: median local logarithmic slope s = d ln V / d ln r\n")
        f.write("Band: 16th-84th percentile across galaxies\n")
        f.write("Smooth model: s(x) = s_inf - A / (x + B)^p\n")
        f.write(f"s_inf = {s_inf:.12f}\n")
        f.write(f"A = {A:.12f}\n")
        f.write(f"B = {B:.12f}\n")
        f.write(f"p = {p:.12f}\n")
        f.write(f"RMSE = {rmse:.12e}\n")
        f.write(f"Theoretical asymptote line shown: s = {THEORY_ASYMPTOTE:.6f}\n")
        f.write("Plot note: raw median points and percentile band are shown in true data units; no visual anchor rescaling is used.\n")

def make_plot(path: Path, x: np.ndarray, median: np.ndarray, p16: np.ndarray, p84: np.ndarray):
    fig = plt.figure(figsize=(8.0, 5.4), dpi=200)
    ax = fig.add_subplot(111)

    ax.fill_between(
        x,
        p16,
        p84,
        color="tab:blue",
        alpha=0.12,
        zorder=1,
        label="16th-84th percentile band",
    )

    ax.axhline(
        THEORY_ASYMPTOTE,
        color="0.25",
        linestyle="--",
        linewidth=1.4,
        zorder=2,
        label="Theoretical asymptote s = 1/4",
    )

    # Plot the raw median slope itself as a thin uninterrupted line.
    ax.plot(
        x,
        median,
        linestyle="-",
        linewidth=1.2,
        color="tab:blue",
        alpha=0.95,
        zorder=5,
        label="Raw median local slope",
    )

    ax.set_xscale("log")
    ax.set_xlabel("Normalized radius r / Rmax")
    ax.set_ylabel("Local logarithmic slope s = d ln V / d ln r")
    ax.set_title("CPTG Outer-Slope Convergence in the Asymptotic Regime")
    ax.set_xlim(float(np.min(x)), float(np.max(x)))

    y_min = min(float(np.min(p16)), float(np.min(median)), THEORY_ASYMPTOTE) - 0.002
    y_max = max(float(np.max(p84)), float(np.max(median)), THEORY_ASYMPTOTE) + 0.002
    ax.set_ylim(y_min, y_max)

    ax.grid(True, which="both", alpha=0.35)
    ax.legend(
        loc="lower right",
        fontsize=8.2,
        frameon=True,
        facecolor="white",
        framealpha=0.96,
        edgecolor="0.75",
    )

    fig.tight_layout()
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)

# =============================================================================
# Main
# =============================================================================

def parse_args():
    parser = argparse.ArgumentParser(
        description="Generate an academically robust CPTG outer-slope convergence plot using benchmark-script path settings."
    )
    parser.add_argument("--benchmark-script", default=None, help="Optional full path to the benchmark script.")
    parser.add_argument("--sparc-dir", default=None, help="Optional SPARC extracted directory.")
    parser.add_argument("--sparc-zip", default=None, help="Optional SPARC zip path.")
    parser.add_argument("--output-png", default=str(SCRIPT_DIR / "cptg_outer_slope_convergence.png"), help="Output PNG path.")
    parser.add_argument("--output-csv", default=str(SCRIPT_DIR / "cptg_outer_slope_convergence.csv"), help="Output CSV path.")
    parser.add_argument("--output-summary", default=str(SCRIPT_DIR / "cptg_outer_slope_convergence.txt"), help="Output summary path.")
    return parser.parse_args()

def main():
    args = parse_args()

    benchmark_script = Path(args.benchmark_script).expanduser().resolve() if args.benchmark_script else find_default_benchmark_script()
    bench = load_benchmark_module(benchmark_script)
    sparc_root = resolve_sparc_root(bench, args.sparc_dir, args.sparc_zip)
    dat_files = collect_unique_dat_files(sparc_root)
    if not dat_files:
        raise FileNotFoundError(f"No .dat files found under SPARC root: {sparc_root}")

    curves = []
    failed = 0
    for path in dat_files:
        curve = build_extended_velocity_curve(bench, path)
        if curve is None:
            failed += 1
            continue
        curves.append(curve)

    if not curves:
        raise RuntimeError("No usable galaxy curves were built.")

    x, median, p16, p84 = build_population_slope_statistics(curves)
    _, s_inf, A, B, p = fit_asymptotic_model_free(x, median)
    fit = evaluate_asymptotic_model(x, s_inf, A, B, p)

    rmse = float(np.sqrt(np.mean((fit - median) ** 2)))

    output_png = Path(args.output_png).expanduser().resolve()
    output_csv = Path(args.output_csv).expanduser().resolve()
    output_summary = Path(args.output_summary).expanduser().resolve()

    save_csv(output_csv, x, median, p16, p84, fit)
    save_summary(output_summary, benchmark_script, sparc_root, len(dat_files), len(curves), failed, s_inf, A, B, p, rmse)
    make_plot(output_png, x, median, p16, p84)

    print(f"Benchmark script: {benchmark_script}")
    print(f"SPARC root:       {sparc_root}")
    print(f"Total .dat files: {len(dat_files)}")
    print(f"Usable galaxies:  {len(curves)}")
    print(f"Skipped galaxies: {failed}")
    print(f"Fitted s_inf:     {s_inf:.12f}")
    print(f"Saved plot:       {output_png}")
    print(f"Saved CSV:        {output_csv}")
    print(f"Saved summary:    {output_summary}")

if __name__ == "__main__":
    try:
        main()
    finally:
        input("\nPress Enter to exit...")
