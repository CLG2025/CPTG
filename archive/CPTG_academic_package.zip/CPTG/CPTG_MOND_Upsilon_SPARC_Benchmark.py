#!/usr/bin/env python3
# =============================================================================
# CPTG vs MOND Upsilon Comparison Benchmark
# =============================================================================
#
# Purpose
# -------
# Run a single, auditable SPARC comparison covering four model comparisons:
#
#   1) CPTG vs MOND                 : both base / no Upsilon_* nuisance parameter
#   2) CPTG vs MOND + Upsilon*     : MOND gets one stellar M/L nuisance parameter
#   3) CPTG + Upsilon_* vs MOND     : CPTG gets one stellar M/L nuisance parameter
#   4) CPTG + Upsilon_* vs MOND + Upsilon* : both get the same nuisance parameter
#
# Design choices
# --------------
# - This script reads the SPARC rotmod galaxy files from --sparc-dir and computes
#   the galaxy-specific CPTG baseline scale a_star and Rc directly from those files.
# - MOND keeps fixed a0. The +Upsilon* audit changes only the stellar source scaling.
# - Gas is fixed in all +Upsilon* fits. Disk and bulge are scaled together by one
#   Upsilon* per galaxy.
# - The CPTG baseline structural scale a_star is inferred from each galaxy
#   rotation curve and Rc is derived from a_star. Therefore the table's
#   nuisance-parameter row counts only additional Upsilon_* parameters, not
#   the structural CPTG scale inference itself.
# - All displayed numbers use 6-digit precision.
#
# Expected files beside this script, or passed by CLI:
# - sparc_database/                         extracted SPARC rotmod .dat files
# - SPARC_Lelli2016c.mrt                    optional metadata for primary sample labels
#
# Example
# -------
#   python CPTG_MOND_Upsilon_Benchmark.py --sparc-dir ./sparc_database
#   python CPTG_MOND_Upsilon_Benchmark.py --sparc-dir ./sparc_database --metadata SPARC_Lelli2016c.mrt
#
# Outputs
# -------
# - CPTG_MOND_Upsilon_Benchmark_Summary.txt
# - CPTG_MOND_Upsilon_Benchmark_Galaxies.csv
# - CPTG_MOND_Upsilon_Benchmark_Summary.json
# =============================================================================

from __future__ import annotations

import argparse
import csv
import glob
import json
import math
import re
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Callable

import numpy as np

# =============================================================================
# Constants and fixed model coefficients
# =============================================================================

C_LIGHT = 299792458.0
KPC_TO_M = 3.085677581491367e19
A0_MOND = 1.2e-10

# CPTG fixed source mapping and fixed geometric response coefficients.
CPTG_GAS_WEIGHT = 27.0 / 50.0
CPTG_DISK_WEIGHT = 23.0 / 50.0
CPTG_BULGE_WEIGHT = 16.0 / 25.0
ETA = 1.0 / 2.0
CPTG_INNER_SUPPRESSION_POWER = 123.0 / 50.0
CPTG_OUTER_SUPPRESSION_POWER = 11.0 / 50.0
CPTG_GEOM_NUMERATOR_POWER = 7.0 / 5.0
CPTG_GEOM_DENOMINATOR_POWER = 12.0 / 5.0

# MOND fixed source mapping in the base law.
MOND_GAS_WEIGHT = 1.0
MOND_DISK_WEIGHT = 1.0
MOND_BULGE_WEIGHT = 1.0

# SPARC mass-model sign conventions.
SPARC_SIGNED_GAS_BY_DEFAULT = True
SPARC_SIGNED_DISK_IF_NEGATIVE = True
SPARC_SIGNED_BULGE_IF_NEGATIVE = True

# SPARC primary-sample rule used when metadata are available.
SCIENCE_SAMPLE_MIN_INCLINATION_DEG = 30.0
SCIENCE_SAMPLE_EXCLUDED_Q_FLAGS = {3}


# =============================================================================
# Data containers
# =============================================================================

@dataclass
class GalaxyScale:
    filename: str
    a_star: float
    rc: float
    primary_sample: bool | None

@dataclass
class GalaxyResult:
    filename: str
    primary_sample: bool | None
    n_points: int
    a_star: float
    rc: float
    chi2_cptg: float
    chi2_mond: float
    chi2_cptg_u: float
    chi2_mond_u: float
    rms_cptg: float
    rms_mond: float
    rms_cptg_u: float
    rms_mond_u: float
    mae_cptg: float
    mae_mond: float
    mae_cptg_u: float
    mae_mond_u: float
    rar_cptg: float
    rar_mond: float
    rar_cptg_u: float
    rar_mond_u: float
    upsilon_cptg: float
    upsilon_mond: float

@dataclass
class AggregateMetrics:
    label: str
    n_galaxies: int
    n_points: int
    chi2_cptg: float
    chi2_mond: float
    chi2_cptg_u: float
    chi2_mond_u: float
    chi2_per_point_cptg: float
    chi2_per_point_mond: float
    chi2_per_point_cptg_u: float
    chi2_per_point_mond_u: float
    rms_cptg: float
    rms_mond: float
    rms_cptg_u: float
    rms_mond_u: float
    mae_cptg: float
    mae_mond: float
    mae_cptg_u: float
    mae_mond_u: float
    rar_cptg: float
    rar_mond: float
    rar_cptg_u: float
    rar_mond_u: float
    wins_cptg_vs_mond: int
    wins_mond_vs_cptg: int
    wins_cptg_vs_mond_u: int
    wins_mond_u_vs_cptg: int
    wins_cptg_u_vs_mond: int
    wins_mond_vs_cptg_u: int
    wins_cptg_u_vs_mond_u: int
    wins_mond_u_vs_cptg_u: int

# =============================================================================
# Utility functions
# =============================================================================

def f6(x: float) -> str:
    return f"{float(x):.6f}"



def ascii_table(headers: list[str], rows: list[list[str]], aligns: list[str] | None = None) -> str:
    """Return a plain-ASCII boxed table with evenly aligned columns."""
    table_rows = [[str(cell) for cell in row] for row in rows]
    header_cells = [str(h) for h in headers]
    all_rows = [header_cells] + table_rows
    widths = [max(len(row[i]) for row in all_rows) for i in range(len(header_cells))]
    if aligns is None:
        aligns = ["left"] * len(header_cells)

    def fmt_cell(text: str, width: int, align: str) -> str:
        if align == "right":
            return text.rjust(width)
        if align == "center":
            return text.center(width)
        return text.ljust(width)

    def fmt_row(row: list[str]) -> str:
        cells = [fmt_cell(str(cell), widths[i], aligns[i]) for i, cell in enumerate(row)]
        return "| " + " | ".join(cells) + " |"

    border = "+-" + "-+-".join("-" * w for w in widths) + "-+"
    lines = [border, fmt_row(header_cells), border]
    lines.extend(fmt_row(row) for row in table_rows)
    lines.append(border)
    return "\n".join(lines)

def ascii_box(lines: list[str]) -> str:
    """Return a plain-ASCII box around one or more text lines."""
    text_lines = [str(line) for line in lines]
    width = max(len(line) for line in text_lines) if text_lines else 0
    border = "+-" + "-" * width + "-+"
    body = ["| " + line.ljust(width) + " |" for line in text_lines]
    return "\n".join([border] + body + [border])

def model_totals_table(agg: AggregateMetrics) -> str:
    """Return model totals with models as columns and benchmark metrics as rows."""
    rows = [
        ["Upsilon params", "0", "0", "1", "1"],
        ["chi2", f6(agg.chi2_cptg), f6(agg.chi2_mond), f6(agg.chi2_cptg_u), f6(agg.chi2_mond_u)],
        ["chi2/pt", f6(agg.chi2_per_point_cptg), f6(agg.chi2_per_point_mond), f6(agg.chi2_per_point_cptg_u), f6(agg.chi2_per_point_mond_u)],
        ["RMS m/s", f6(agg.rms_cptg), f6(agg.rms_mond), f6(agg.rms_cptg_u), f6(agg.rms_mond_u)],
        ["MAE m/s", f6(agg.mae_cptg), f6(agg.mae_mond), f6(agg.mae_cptg_u), f6(agg.mae_mond_u)],
        ["RAR", f6(agg.rar_cptg), f6(agg.rar_mond), f6(agg.rar_cptg_u), f6(agg.rar_mond_u)],
    ]
    return ascii_table(
        ["Benchmark", "CPTG", "MOND", "CPTG+Upsilon", "MOND+Upsilon"],
        rows,
        ["left", "right", "right", "right", "right"],
    )

def comparisons_table(agg: AggregateMetrics) -> str:
    rows = []
    for row in comparison_rows(agg):
        rows.append([
            str(row["comparison"]),
            f6(row["chi2_improvement_percent"]),
            f6(row["chi2_per_point_improvement_percent"]),
            f6(row["rms_improvement_percent"]),
            f6(row["mae_improvement_percent"]),
            f6(row["rar_improvement_percent"]),
            f"{row['model_wins']} / {row['reference_wins']}",
        ])
    return ascii_table(
        ["Comparison", "chi2 %", "chi2/pt %", "RMS %", "MAE %", "RAR %", "Wins"],
        rows,
        ["left", "right", "right", "right", "right", "right", "right"],
    )

def upsilon_distribution_table(results: list[GalaxyResult], args) -> str:
    """Return Upsilon distributions with models as columns and statistics as rows."""
    u_cptg = np.asarray([r.upsilon_cptg for r in results], dtype=float)
    u_mond = np.asarray([r.upsilon_mond for r in results], dtype=float)
    rows = [
        ["Mean", f6(np.mean(u_cptg)), f6(np.mean(u_mond))],
        ["Median", f6(np.median(u_cptg)), f6(np.median(u_mond))],
        ["Min", f6(np.min(u_cptg)), f6(np.min(u_mond))],
        ["Max", f6(np.max(u_cptg)), f6(np.max(u_mond))],
        ["Lower hits", str(int(np.sum(np.isclose(u_cptg, args.upsilon_min, atol=5e-6)))), str(int(np.sum(np.isclose(u_mond, args.upsilon_min, atol=5e-6))))],
        ["Upper hits", str(int(np.sum(np.isclose(u_cptg, args.upsilon_max, atol=5e-6)))), str(int(np.sum(np.isclose(u_mond, args.upsilon_max, atol=5e-6))))],
    ]
    return ascii_table(
        ["Benchmark", "CPTG+Upsilon", "MOND+Upsilon"],
        rows,
        ["left", "right", "right"],
    )

def improvement(reference: float, model: float) -> float:
    """Percent improvement of model relative to reference. Positive means model is smaller/better."""
    reference = float(reference)
    model = float(model)
    if not np.isfinite(reference) or reference == 0.0:
        return float("nan")
    return 100.0 * (reference - model) / reference

def rms(arr: np.ndarray) -> float:
    arr = np.asarray(arr, dtype=float)
    if arr.size == 0:
        return float("nan")
    return float(np.sqrt(np.mean(arr * arr)))

def mae(arr: np.ndarray) -> float:
    arr = np.asarray(arr, dtype=float)
    if arr.size == 0:
        return float("nan")
    return float(np.mean(np.abs(arr)))

def scatter(arr: np.ndarray) -> float:
    arr = np.asarray(arr, dtype=float)
    arr = arr[np.isfinite(arr)]
    if arr.size == 0:
        return float("nan")
    return float(np.std(arr))

def signed_square(v: np.ndarray) -> np.ndarray:
    arr = np.asarray(v, dtype=float)
    return arr * np.abs(arr)

def velocity_component_term(v: np.ndarray, use_signed: bool) -> np.ndarray:
    arr = np.asarray(v, dtype=float)
    return signed_square(arr) if use_signed else arr ** 2

def clean_filename(name: str) -> str:
    base = Path(name.strip()).name
    while base.endswith("*") or base.endswith("!"):
        base = base[:-1]
    return base

def canonical_galaxy_key(name: str) -> str:
    """Return a comparison key for SPARC galaxy names and rotmod filenames."""
    text = clean_filename(str(name)).strip()
    text = re.sub(r"_rotmod\.dat$", "", text, flags=re.IGNORECASE)
    text = re.sub(r"\.(dat|txt|csv)$", "", text, flags=re.IGNORECASE)
    text = re.sub(r"[^A-Za-z0-9]+", "", text).upper()
    return text

def parse_float_or_none(text: Any) -> float | None:
    try:
        value = float(str(text).strip())
    except Exception:
        return None
    return value if np.isfinite(value) else None

def parse_int_or_none(text: Any) -> int | None:
    try:
        return int(float(str(text).strip()))
    except Exception:
        return None

def find_metadata_file(script_dir: Path, sparc_root: Path, explicit: str | None) -> Path | None:
    """Find SPARC Lelli2016 metadata, including downloaded names like SPARC_Lelli2016c(4).mrt."""
    if explicit:
        path = Path(explicit).expanduser().resolve()
        if not path.exists():
            raise FileNotFoundError(f"Metadata file not found: {path}")
        return path

    roots: list[Path] = []
    for root in [Path.cwd(), script_dir, sparc_root, sparc_root.parent]:
        try:
            root = root.expanduser().resolve()
        except Exception:
            continue
        if root.exists() and root not in roots:
            roots.append(root)
        for parent in list(root.parents)[:3]:
            if parent.exists() and parent not in roots:
                roots.append(parent)

    patterns = ["SPARC_Lelli2016c.mrt", "SPARC_Lelli2016c*.mrt", "*SPARC*Lelli*.mrt", "*Lelli*2016*.mrt", "*.mrt"]
    candidates: list[Path] = []
    for root in roots:
        for pattern in patterns:
            candidates.extend(Path(p).resolve() for p in glob.glob(str(root / pattern)))
    candidates = sorted(set(candidates), key=lambda p: ("SPARC" not in p.name.upper(), -p.stat().st_mtime))
    return candidates[0] if candidates else None

def _parse_sparc_mrt_split(parts: list[str]) -> dict[str, Any] | None:
    if len(parts) < 18:
        return None
    galaxy = parts[0].strip()
    if not galaxy or galaxy.startswith("#"):
        return None
    if parse_int_or_none(parts[1]) is None:
        return None
    distance_mpc = parse_float_or_none(parts[2])
    if distance_mpc is None:
        return None
    return {
        "name": galaxy,
        "distance_mpc": distance_mpc,
        "e_distance_mpc": parse_float_or_none(parts[3]),
        "distance_method_flag": parse_int_or_none(parts[4]),
        "inc_deg": parse_float_or_none(parts[5]),
        "e_inc_deg": parse_float_or_none(parts[6]),
        "l36_1e9_lsun": parse_float_or_none(parts[7]),
        "e_l36_1e9_lsun": parse_float_or_none(parts[8]),
        "reff_kpc": parse_float_or_none(parts[9]),
        "sbeff_lsun_pc2": parse_float_or_none(parts[10]),
        "rdisk_kpc": parse_float_or_none(parts[11]),
        "sbdisk_lsun_pc2": parse_float_or_none(parts[12]),
        "mhi_1e9_msun": parse_float_or_none(parts[13]),
        "rhi_kpc": parse_float_or_none(parts[14]),
        "vflat_km_s": parse_float_or_none(parts[15]),
        "e_vflat_km_s": parse_float_or_none(parts[16]),
        "q_flag": parse_int_or_none(parts[17]),
    }

def _parse_sparc_mrt_fixed_width(line: str) -> dict[str, Any] | None:
    if len(line) < 99:
        return None
    galaxy = line[0:11].strip()
    if not galaxy:
        return None
    t_type = parse_int_or_none(line[11:13].strip())
    distance_mpc = parse_float_or_none(line[13:19].strip())
    if t_type is None or distance_mpc is None:
        return None
    return {
        "name": galaxy,
        "distance_mpc": distance_mpc,
        "e_distance_mpc": parse_float_or_none(line[19:24].strip()),
        "distance_method_flag": parse_int_or_none(line[24:26].strip()),
        "inc_deg": parse_float_or_none(line[26:30].strip()),
        "e_inc_deg": parse_float_or_none(line[30:34].strip()),
        "l36_1e9_lsun": parse_float_or_none(line[34:41].strip()),
        "e_l36_1e9_lsun": parse_float_or_none(line[41:48].strip()),
        "reff_kpc": parse_float_or_none(line[48:53].strip()),
        "sbeff_lsun_pc2": parse_float_or_none(line[53:61].strip()),
        "rdisk_kpc": parse_float_or_none(line[61:66].strip()),
        "sbdisk_lsun_pc2": parse_float_or_none(line[66:74].strip()),
        "mhi_1e9_msun": parse_float_or_none(line[74:81].strip()),
        "rhi_kpc": parse_float_or_none(line[81:86].strip()),
        "vflat_km_s": parse_float_or_none(line[86:91].strip()),
        "e_vflat_km_s": parse_float_or_none(line[91:96].strip()),
        "q_flag": parse_int_or_none(line[96:99].strip()),
    }

def load_sparc_mrt_metadata(path: Path | None) -> dict[str, dict[str, Any]]:
    """Load SPARC Lelli2016c metadata for primary-sample labels; returns empty dict if unavailable."""
    if path is None:
        return {}
    metadata: dict[str, dict[str, Any]] = {}
    with path.open("r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            row = _parse_sparc_mrt_split(line.split())
            if row is None:
                row = _parse_sparc_mrt_fixed_width(line.rstrip("\n"))
            if row is None:
                continue
            key = canonical_galaxy_key(row["name"])
            if key:
                metadata[key] = row
    return metadata

def get_metadata_for_file(path: Path, metadata: dict[str, dict[str, Any]]) -> dict[str, Any] | None:
    key = canonical_galaxy_key(path.name)
    if key in metadata:
        return metadata[key]
    def strip_catalog_zeros(s: str) -> str:
        return re.sub(r"^(NGC|UGC|IC|DDO|ESO)0+", r"\1", s)
    slim = strip_catalog_zeros(key)
    for mkey, row in metadata.items():
        if strip_catalog_zeros(mkey) == slim:
            return row
    return None

def metadata_primary_sample_flag(metadata_row: dict[str, Any] | None) -> bool | None:
    """Return SPARC primary-sample flag from metadata if possible."""
    if not metadata_row:
        return None
    q_flag = metadata_row.get("q_flag")
    inc_deg = metadata_row.get("inc_deg")
    if q_flag is None and inc_deg is None:
        return None
    if q_flag in SCIENCE_SAMPLE_EXCLUDED_Q_FLAGS:
        return False
    if inc_deg is not None and float(inc_deg) < SCIENCE_SAMPLE_MIN_INCLINATION_DEG:
        return False
    return True

def rc_from_a_star(a_star: float) -> float:
    return (48.0 * np.pi * C_LIGHT ** 2) / max(float(a_star), 1e-30)

# =============================================================================
# SPARC data loading
# =============================================================================

def find_sparc_dir(script_dir: Path, user_dir: str | None) -> Path:
    if user_dir:
        root = Path(user_dir).expanduser().resolve()
    else:
        root = script_dir / "sparc_database"
    if not root.exists():
        raise FileNotFoundError(f"SPARC directory not found: {root}")
    if not list(root.glob("**/*.dat")):
        raise FileNotFoundError(f"No .dat files found under SPARC directory: {root}")
    return root

def collect_dat_files(root: Path) -> list[Path]:
    found = sorted(Path(p) for p in glob.glob(str(root / "**" / "*.dat"), recursive=True))
    by_name: dict[str, Path] = {}
    for p in found:
        by_name.setdefault(p.name, p)
    return [by_name[k] for k in sorted(by_name)]

def load_sparc_file(path: Path):
    rows: list[list[float]] = []
    with path.open("r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split()
            if len(parts) < 6:
                continue
            try:
                rows.append([float(parts[i]) for i in range(6)])
            except ValueError:
                continue

    arr = np.asarray(rows, dtype=float)
    if arr.ndim != 2 or arr.shape[0] < 1 or arr.shape[1] < 6:
        raise ValueError(f"No usable SPARC rows in {path}")

    r_kpc = arr[:, 0]
    vobs_km_s = arr[:, 1]
    errv_km_s = arr[:, 2]
    vgas_km_s = arr[:, 3]
    vdisk_km_s = arr[:, 4]
    vbul_km_s = arr[:, 5]

    mask = (
        np.isfinite(r_kpc)
        & np.isfinite(vobs_km_s)
        & np.isfinite(errv_km_s)
        & np.isfinite(vgas_km_s)
        & np.isfinite(vdisk_km_s)
        & np.isfinite(vbul_km_s)
        & (r_kpc > 0.0)
    )
    r_kpc = r_kpc[mask]
    vobs_km_s = vobs_km_s[mask]
    errv_km_s = errv_km_s[mask]
    vgas_km_s = vgas_km_s[mask]
    vdisk_km_s = vdisk_km_s[mask]
    vbul_km_s = vbul_km_s[mask]
    if r_kpc.size == 0:
        raise ValueError(f"No finite SPARC rows in {path}")

    order = np.argsort(r_kpc)
    r_kpc = r_kpc[order]
    vobs_km_s = vobs_km_s[order]
    errv_km_s = errv_km_s[order]
    vgas_km_s = vgas_km_s[order]
    vdisk_km_s = vdisk_km_s[order]
    vbul_km_s = vbul_km_s[order]

    return r_kpc, vobs_km_s, errv_km_s, vgas_km_s, vdisk_km_s, vbul_km_s

# =============================================================================
# Model equations
# =============================================================================

def component_terms(vgas: np.ndarray, vdisk: np.ndarray, vbul: np.ndarray):
    use_signed_gas = SPARC_SIGNED_GAS_BY_DEFAULT or np.any(vgas < 0.0)
    use_signed_disk = SPARC_SIGNED_DISK_IF_NEGATIVE and np.any(vdisk < 0.0)
    use_signed_bulge = SPARC_SIGNED_BULGE_IF_NEGATIVE and np.any(vbul < 0.0)
    gas_term = velocity_component_term(vgas, use_signed_gas)
    disk_term = velocity_component_term(vdisk, use_signed_disk)
    bulge_term = velocity_component_term(vbul, use_signed_bulge)
    return gas_term, disk_term, bulge_term

def build_gbar(r_m: np.ndarray, gas_term: np.ndarray, disk_term: np.ndarray, bulge_term: np.ndarray, gas_w: float, disk_w: float, bulge_w: float, upsilon: float = 1.0) -> np.ndarray:
    vb2_signed = gas_w * gas_term + upsilon * (disk_w * disk_term + bulge_w * bulge_term)
    vb2 = np.maximum(vb2_signed, 0.0)
    return vb2 / np.maximum(r_m, 1e-30)

def mond_acceleration(gbar: np.ndarray) -> np.ndarray:
    gbar = np.maximum(np.asarray(gbar, dtype=float), 1e-30)
    x = np.maximum(gbar / A0_MOND, 1e-30)
    return gbar / (1.0 - np.exp(-np.sqrt(x)))

def cptg_acceleration(gbar: np.ndarray, r_m: np.ndarray, a_star: float, rc: float, n_iter: int = 300, tol: float = 1e-13) -> np.ndarray:
    gbar = np.maximum(np.asarray(gbar, dtype=float), 1e-30)
    r_m = np.maximum(np.asarray(r_m, dtype=float), 1e-30)
    a_star = max(float(a_star), 1e-30)
    rc = max(float(rc), 1e-30)
    g = gbar.copy()
    x = r_m / rc
    x_num = x ** CPTG_GEOM_NUMERATOR_POWER
    x_den = x ** CPTG_GEOM_DENOMINATOR_POWER
    g_geom = ETA * a_star * x_num / (1.0 + x_den)
    numerator = np.sqrt(np.maximum(a_star * gbar, 0.0)) + g_geom
    for _ in range(n_iter):
        denominator = (1.0 + (g / a_star) ** CPTG_INNER_SUPPRESSION_POWER) ** CPTG_OUTER_SUPPRESSION_POWER
        g_new = gbar + numerator / denominator
        rel = float(np.max(np.abs(g_new - g) / np.maximum(np.abs(g_new), 1e-30)))
        g = g_new
        if rel < tol:
            break
    return g

def velocity_from_acceleration(g: np.ndarray, r_m: np.ndarray) -> np.ndarray:
    return np.sqrt(np.maximum(g, 0.0) * np.maximum(r_m, 1e-30))

# =============================================================================
# One-dimensional bounded minimization without scipy dependency
# =============================================================================

def bounded_minimize(func: Callable[[float], float], lo: float, hi: float, max_iter: int = 60, tol: float = 1e-5) -> tuple[float, float]:
    """Bounded minimization on [lo, hi]. Uses scipy when available, otherwise golden-section."""
    try:
        from scipy.optimize import minimize_scalar  # type: ignore
        result = minimize_scalar(func, bounds=(lo, hi), method="bounded", options={"xatol": tol})
        x = float(result.x) if result.success and np.isfinite(result.fun) else 0.5 * (lo + hi)
        fx = float(func(x))
    except Exception:
        gr = (math.sqrt(5.0) - 1.0) / 2.0
        a = float(lo)
        b = float(hi)
        c = b - gr * (b - a)
        d = a + gr * (b - a)
        fc = float(func(c))
        fd = float(func(d))
        for _ in range(max_iter):
            if abs(b - a) <= tol:
                break
            if fc < fd:
                b, d, fd = d, c, fc
                c = b - gr * (b - a)
                fc = float(func(c))
            else:
                a, c, fc = c, d, fd
                d = a + gr * (b - a)
                fd = float(func(d))
        x = 0.5 * (a + b)
        fx = float(func(x))

    # Include exact bounds so boundary solutions are captured cleanly.
    flo = float(func(lo))
    fhi = float(func(hi))
    candidates = [(x, fx), (float(lo), flo), (float(hi), fhi)]
    best_x, best_f = min(candidates, key=lambda t: t[1])
    return float(best_x), float(best_f)

def fit_cptg_scale_for_galaxy(
    g_bar: np.ndarray,
    r_m: np.ndarray,
    vobs_m_s: np.ndarray,
    errv_m_s: np.ndarray,
) -> GalaxyScale:
    """Infer the CPTG structural scale a_star directly from one galaxy file.

    This is the default path requested for this standalone benchmark:
    the SPARC rotmod file supplies the observed curve and baryonic components,
    CPTG builds the source field, infers a_star, and derives Rc from a_star.
    """
    err_safe = np.maximum(errv_m_s, 1.0)

    def chi2_of_log_a(x: float) -> float:
        a_star = 10.0 ** float(x)
        rc = rc_from_a_star(a_star)
        g_cptg = cptg_acceleration(g_bar, r_m, a_star=a_star, rc=rc)
        v_cptg = velocity_from_acceleration(g_cptg, r_m)
        resid = (vobs_m_s - v_cptg) / err_safe
        return float(np.sum(resid * resid))

    # Stage 1: bounded log-space inference.  Stage 2: small deterministic
    # local refinement.  This mirrors the audited benchmark's two-stage search
    # while keeping this script self-contained.
    x0, _ = bounded_minimize(chi2_of_log_a, -12.0, -9.0, tol=1e-8)
    x_grid = np.linspace(max(-12.0, x0 - 0.02), min(-9.0, x0 + 0.02), 161)
    chi_grid = np.asarray([chi2_of_log_a(x) for x in x_grid], dtype=float)
    best_log_a = float(x_grid[int(np.argmin(chi_grid))])
    a_star = 10.0 ** best_log_a
    rc = rc_from_a_star(a_star)
    return GalaxyScale(filename="", a_star=float(a_star), rc=float(rc), primary_sample=None)

def compute_scale_from_file(path: Path, primary_sample: bool | None) -> GalaxyScale:
    """Load one rotmod file and compute its CPTG baseline a_star/Rc from the file contents."""
    r_kpc, vobs_km_s, errv_km_s, vgas_km_s, vdisk_km_s, vbul_km_s = load_sparc_file(path)
    r_m = r_kpc * KPC_TO_M
    vobs = vobs_km_s * 1000.0
    errv = np.maximum(errv_km_s * 1000.0, 1.0)
    vgas = vgas_km_s * 1000.0
    vdisk = vdisk_km_s * 1000.0
    vbul = vbul_km_s * 1000.0
    gas_term, disk_term, bulge_term = component_terms(vgas, vdisk, vbul)
    gbar_cptg = build_gbar(r_m, gas_term, disk_term, bulge_term, CPTG_GAS_WEIGHT, CPTG_DISK_WEIGHT, CPTG_BULGE_WEIGHT, upsilon=1.0)
    scale = fit_cptg_scale_for_galaxy(gbar_cptg, r_m, vobs, errv)
    scale.filename = path.name
    scale.primary_sample = primary_sample
    return scale

# =============================================================================
# Per-galaxy evaluation
# =============================================================================

def fit_upsilon_for_model(
    model: str,
    r_m: np.ndarray,
    vobs: np.ndarray,
    errv: np.ndarray,
    gas_term: np.ndarray,
    disk_term: np.ndarray,
    bulge_term: np.ndarray,
    a_star: float | None,
    rc: float | None,
    lo: float,
    hi: float,
) -> tuple[float, np.ndarray, np.ndarray, np.ndarray, float]:
    err_safe = np.maximum(errv, 1.0)

    if model == "mond":
        gas_w, disk_w, bulge_w = MOND_GAS_WEIGHT, MOND_DISK_WEIGHT, MOND_BULGE_WEIGHT
    elif model == "cptg":
        gas_w, disk_w, bulge_w = CPTG_GAS_WEIGHT, CPTG_DISK_WEIGHT, CPTG_BULGE_WEIGHT
        if a_star is None or rc is None:
            raise ValueError("CPTG Upsilon fit requires fixed a_star and Rc")
    else:
        raise ValueError(f"Unknown model: {model}")

    def chi2_for_u(u: float) -> float:
        gbar = build_gbar(r_m, gas_term, disk_term, bulge_term, gas_w, disk_w, bulge_w, upsilon=u)
        if model == "mond":
            g = mond_acceleration(gbar)
        else:
            g = cptg_acceleration(gbar, r_m, float(a_star), float(rc))
        vmodel = velocity_from_acceleration(g, r_m)
        resid = (vobs - vmodel) / err_safe
        return float(np.sum(resid * resid))

    u_best, chi2_best = bounded_minimize(chi2_for_u, lo, hi)
    gbar_best = build_gbar(r_m, gas_term, disk_term, bulge_term, gas_w, disk_w, bulge_w, upsilon=u_best)
    if model == "mond":
        g_best = mond_acceleration(gbar_best)
    else:
        g_best = cptg_acceleration(gbar_best, r_m, float(a_star), float(rc))
    v_best = velocity_from_acceleration(g_best, r_m)
    return u_best, gbar_best, g_best, v_best, chi2_best

def evaluate_galaxy(path: Path, scale: GalaxyScale, upsilon_bounds: tuple[float, float]) -> GalaxyResult:
    r_kpc, vobs_km_s, errv_km_s, vgas_km_s, vdisk_km_s, vbul_km_s = load_sparc_file(path)
    r_m = r_kpc * KPC_TO_M
    vobs = vobs_km_s * 1000.0
    errv = np.maximum(errv_km_s * 1000.0, 1.0)
    vgas = vgas_km_s * 1000.0
    vdisk = vdisk_km_s * 1000.0
    vbul = vbul_km_s * 1000.0
    gas_term, disk_term, bulge_term = component_terms(vgas, vdisk, vbul)

    # Base CPTG, zero additional fitted parameters.
    gbar_cptg = build_gbar(r_m, gas_term, disk_term, bulge_term, CPTG_GAS_WEIGHT, CPTG_DISK_WEIGHT, CPTG_BULGE_WEIGHT, upsilon=1.0)
    g_cptg = cptg_acceleration(gbar_cptg, r_m, scale.a_star, scale.rc)
    v_cptg = velocity_from_acceleration(g_cptg, r_m)

    # Base MOND, zero fitted parameters.
    gbar_mond = build_gbar(r_m, gas_term, disk_term, bulge_term, MOND_GAS_WEIGHT, MOND_DISK_WEIGHT, MOND_BULGE_WEIGHT, upsilon=1.0)
    g_mond = mond_acceleration(gbar_mond)
    v_mond = velocity_from_acceleration(g_mond, r_m)

    # MOND + Upsilon_*.
    u_mond, gbar_mond_u, g_mond_u, v_mond_u, chi2_mond_u = fit_upsilon_for_model(
        "mond", r_m, vobs, errv, gas_term, disk_term, bulge_term, None, None, upsilon_bounds[0], upsilon_bounds[1]
    )

    # CPTG + Upsilon_* with a_star and Rc fixed to the base CPTG scale.
    u_cptg, gbar_cptg_u, g_cptg_u, v_cptg_u, chi2_cptg_u = fit_upsilon_for_model(
        "cptg", r_m, vobs, errv, gas_term, disk_term, bulge_term, scale.a_star, scale.rc, upsilon_bounds[0], upsilon_bounds[1]
    )

    err_safe = np.maximum(errv, 1.0)
    g_obs = np.maximum((vobs * vobs) / np.maximum(r_m, 1e-30), 1e-30)

    def chi2(vmodel: np.ndarray) -> float:
        resid = (vobs - vmodel) / err_safe
        return float(np.sum(resid * resid))

    def rar(gmodel: np.ndarray) -> float:
        return scatter(np.log10(np.maximum(g_obs / np.maximum(gmodel, 1e-30), 1e-300)))

    return GalaxyResult(
        filename=path.name,
        primary_sample=scale.primary_sample,
        n_points=int(r_m.size),
        a_star=float(scale.a_star),
        rc=float(scale.rc),
        chi2_cptg=chi2(v_cptg),
        chi2_mond=chi2(v_mond),
        chi2_cptg_u=float(chi2_cptg_u),
        chi2_mond_u=float(chi2_mond_u),
        rms_cptg=rms(vobs - v_cptg),
        rms_mond=rms(vobs - v_mond),
        rms_cptg_u=rms(vobs - v_cptg_u),
        rms_mond_u=rms(vobs - v_mond_u),
        mae_cptg=mae(vobs - v_cptg),
        mae_mond=mae(vobs - v_mond),
        mae_cptg_u=mae(vobs - v_cptg_u),
        mae_mond_u=mae(vobs - v_mond_u),
        rar_cptg=rar(g_cptg),
        rar_mond=rar(g_mond),
        rar_cptg_u=rar(g_cptg_u),
        rar_mond_u=rar(g_mond_u),
        upsilon_cptg=float(u_cptg),
        upsilon_mond=float(u_mond),
    )

# =============================================================================
# Aggregation and reporting
# =============================================================================

def aggregate(results: list[GalaxyResult], label: str) -> AggregateMetrics:
    n_gal = len(results)
    n_pts = sum(r.n_points for r in results)

    def total(attr: str) -> float:
        return float(sum(getattr(r, attr) for r in results))

    def weighted_rms(attr: str) -> float:
        # Reconstruct aggregate RMS approximately from per-galaxy RMS and counts.
        if n_pts == 0:
            return float("nan")
        return float(np.sqrt(sum((getattr(r, attr) ** 2) * r.n_points for r in results) / n_pts))

    def weighted_mae(attr: str) -> float:
        if n_pts == 0:
            return float("nan")
        return float(sum(getattr(r, attr) * r.n_points for r in results) / n_pts)

    def weighted_mean(attr: str) -> float:
        if n_pts == 0:
            return float("nan")
        return float(sum(getattr(r, attr) * r.n_points for r in results) / n_pts)

    chi2_cptg = total("chi2_cptg")
    chi2_mond = total("chi2_mond")
    chi2_cptg_u = total("chi2_cptg_u")
    chi2_mond_u = total("chi2_mond_u")

    return AggregateMetrics(
        label=label,
        n_galaxies=n_gal,
        n_points=n_pts,
        chi2_cptg=chi2_cptg,
        chi2_mond=chi2_mond,
        chi2_cptg_u=chi2_cptg_u,
        chi2_mond_u=chi2_mond_u,
        chi2_per_point_cptg=chi2_cptg / max(n_pts, 1),
        chi2_per_point_mond=chi2_mond / max(n_pts, 1),
        chi2_per_point_cptg_u=chi2_cptg_u / max(n_pts, 1),
        chi2_per_point_mond_u=chi2_mond_u / max(n_pts, 1),
        rms_cptg=weighted_rms("rms_cptg"),
        rms_mond=weighted_rms("rms_mond"),
        rms_cptg_u=weighted_rms("rms_cptg_u"),
        rms_mond_u=weighted_rms("rms_mond_u"),
        mae_cptg=weighted_mae("mae_cptg"),
        mae_mond=weighted_mae("mae_mond"),
        mae_cptg_u=weighted_mae("mae_cptg_u"),
        mae_mond_u=weighted_mae("mae_mond_u"),
        rar_cptg=weighted_mean("rar_cptg"),
        rar_mond=weighted_mean("rar_mond"),
        rar_cptg_u=weighted_mean("rar_cptg_u"),
        rar_mond_u=weighted_mean("rar_mond_u"),
        wins_cptg_vs_mond=sum(1 for r in results if r.chi2_cptg < r.chi2_mond),
        wins_mond_vs_cptg=sum(1 for r in results if r.chi2_mond < r.chi2_cptg),
        wins_cptg_vs_mond_u=sum(1 for r in results if r.chi2_cptg < r.chi2_mond_u),
        wins_mond_u_vs_cptg=sum(1 for r in results if r.chi2_mond_u < r.chi2_cptg),
        wins_cptg_u_vs_mond=sum(1 for r in results if r.chi2_cptg_u < r.chi2_mond),
        wins_mond_vs_cptg_u=sum(1 for r in results if r.chi2_mond < r.chi2_cptg_u),
        wins_cptg_u_vs_mond_u=sum(1 for r in results if r.chi2_cptg_u < r.chi2_mond_u),
        wins_mond_u_vs_cptg_u=sum(1 for r in results if r.chi2_mond_u < r.chi2_cptg_u),
    )

def model_metric(agg: AggregateMetrics, model: str, metric: str) -> float:
    key = f"{metric}_{model}"
    return float(getattr(agg, key))

def comparison_rows(agg: AggregateMetrics) -> list[dict[str, str | float | int]]:
    # model names map to aggregate suffixes.
    comparisons = [
        ("CPTG vs MOND (base)", "mond", "cptg", agg.wins_cptg_vs_mond, agg.wins_mond_vs_cptg),
        ("CPTG vs MOND+Upsilon", "mond_u", "cptg", agg.wins_cptg_vs_mond_u, agg.wins_mond_u_vs_cptg),
        ("CPTG+Upsilon vs MOND", "mond", "cptg_u", agg.wins_cptg_u_vs_mond, agg.wins_mond_vs_cptg_u),
        ("CPTG+Upsilon vs MOND+Upsilon", "mond_u", "cptg_u", agg.wins_cptg_u_vs_mond_u, agg.wins_mond_u_vs_cptg_u),
    ]
    rows = []
    for name, reference, model, model_wins, reference_wins in comparisons:
        rows.append({
            "comparison": name,
            "reference": reference,
            "model": model,
            "reference_chi2": model_metric(agg, reference, "chi2"),
            "model_chi2": model_metric(agg, model, "chi2"),
            "chi2_improvement_percent": improvement(model_metric(agg, reference, "chi2"), model_metric(agg, model, "chi2")),
            "reference_chi2_per_point": model_metric(agg, reference, "chi2_per_point"),
            "model_chi2_per_point": model_metric(agg, model, "chi2_per_point"),
            "chi2_per_point_improvement_percent": improvement(model_metric(agg, reference, "chi2_per_point"), model_metric(agg, model, "chi2_per_point")),
            "reference_rms": model_metric(agg, reference, "rms"),
            "model_rms": model_metric(agg, model, "rms"),
            "rms_improvement_percent": improvement(model_metric(agg, reference, "rms"), model_metric(agg, model, "rms")),
            "reference_mae": model_metric(agg, reference, "mae"),
            "model_mae": model_metric(agg, model, "mae"),
            "mae_improvement_percent": improvement(model_metric(agg, reference, "mae"), model_metric(agg, model, "mae")),
            "reference_rar": model_metric(agg, reference, "rar"),
            "model_rar": model_metric(agg, model, "rar"),
            "rar_improvement_percent": improvement(model_metric(agg, reference, "rar"), model_metric(agg, model, "rar")),
            "model_wins": model_wins,
            "reference_wins": reference_wins,
        })
    return rows

def write_galaxies_csv(path: Path, results: list[GalaxyResult]) -> None:
    fields = list(asdict(results[0]).keys()) if results else []
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for r in results:
            writer.writerow(asdict(r))

def write_summary_text(path: Path, args, metadata_path: Path | None, sparc_dir: Path, aggs: list[AggregateMetrics], results: list[GalaxyResult]) -> None:
    with path.open("w", encoding="utf-8") as f:
        f.write(ascii_box([
            "CPTG vs MOND comparison benchmark",
            "All displayed numeric values use 6-digit precision.",
        ]))
        f.write("\n\n")
        f.write(f"SPARC directory: {sparc_dir}\n")
        f.write("CPTG baseline scales: computed directly from SPARC files\n")
        f.write(f"SPARC metadata: {metadata_path if metadata_path is not None else 'not loaded'}\n")
        f.write(f"Upsilon bounds: {args.upsilon_min:.6f} <= Upsilon_* <= {args.upsilon_max:.6f}\n")
        f.write("Base comparison: CPTG and MOND use no Upsilon_* nuisance parameter.\n")
        f.write("CPTG a_star is inferred from each galaxy rotation curve and Rc is derived from a_star.\n")
        f.write("+Upsilon comparison: one fitted stellar M/L nuisance parameter per galaxy; gas fixed; disk+bulge scaled together.\n")
        f.write("CPTG+Upsilon holds a_star and Rc fixed to the selected baseline scale source.\n")
        f.write("MOND+Upsilon holds a0 fixed at 1.2e-10 m/s^2.\n\n")

        f.write(ascii_box(["UPSILON DISTRIBUTIONS"]))
        f.write("\n")
        f.write(upsilon_distribution_table(results, args))
        f.write("\n")

        for agg in aggs:
            f.write("\n")
            f.write(ascii_box([
                agg.label.upper(),
                f"Files/points: {agg.n_galaxies} / {agg.n_points}",
            ]))
            f.write("\n\n")
            f.write("MODEL TOTALS\n")
            f.write(model_totals_table(agg))
            f.write("\n\n")
            f.write("AUDITED COMPARISONS\n")
            f.write("Positive improvement means the CPTG-side model is lower/better.\n")
            f.write(comparisons_table(agg))
            f.write("\n")

def write_summary_json(path: Path, args, metadata_path: Path | None, sparc_dir: Path, aggs: list[AggregateMetrics], results: list[GalaxyResult]) -> None:
    payload = {
        "sparc_dir": str(sparc_dir),
        "scale_source": "computed_from_sparc_files",
        "metadata": str(metadata_path) if metadata_path is not None else None,
        "upsilon_bounds": [args.upsilon_min, args.upsilon_max],
        "aggregates": [asdict(a) for a in aggs],
        "comparisons": {a.label: comparison_rows(a) for a in aggs},
        "upsilon_distribution": {
            "mond_u": {
                "mean": float(np.mean([r.upsilon_mond for r in results])),
                "median": float(np.median([r.upsilon_mond for r in results])),
                "min": float(np.min([r.upsilon_mond for r in results])),
                "max": float(np.max([r.upsilon_mond for r in results])),
            },
            "cptg_u": {
                "mean": float(np.mean([r.upsilon_cptg for r in results])),
                "median": float(np.median([r.upsilon_cptg for r in results])),
                "min": float(np.min([r.upsilon_cptg for r in results])),
                "max": float(np.max([r.upsilon_cptg for r in results])),
            },
        },
    }
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")

def print_console_summary(aggs: list[AggregateMetrics], results: list[GalaxyResult], args) -> None:
    print("\n" + ascii_box([
        "CPTG vs MOND comparison benchmark",
        "All displayed numeric values use 6-digit precision.",
    ]))
    print(f"Upsilon bounds: {args.upsilon_min:.6f} <= Upsilon_* <= {args.upsilon_max:.6f}")
    print("\n" + ascii_box(["UPSILON DISTRIBUTIONS"]))
    print(upsilon_distribution_table(results, args))

    for agg in aggs:
        print("\n" + ascii_box([
            agg.label.upper(),
            f"Files/points: {agg.n_galaxies} / {agg.n_points}",
        ]))
        print("\nMODEL TOTALS")
        print(model_totals_table(agg))
        print("\nAUDITED COMPARISONS")
        print("Positive improvement means the CPTG-side model is lower/better.")
        print(comparisons_table(agg))

# =============================================================================
# Main
# =============================================================================

def parse_args():
    parser = argparse.ArgumentParser(description="Run CPTG vs MOND comparison benchmark with base and Upsilon_* audits.")
    parser.add_argument("--sparc-dir", default=None, help="Path to extracted SPARC rotmod directory. Default: ./sparc_database beside this script.")
    parser.add_argument("--metadata", default=None, help="Optional SPARC_Lelli2016c.mrt metadata file for primary-sample labels; auto-detected if omitted.")
    parser.add_argument("--output-prefix", default="CPTG_MOND_Upsilon_Benchmark", help="Output file prefix.")
    parser.add_argument("--upsilon-min", type=float, default=0.1, help="Lower bound for Upsilon_* fits.")
    parser.add_argument("--upsilon-max", type=float, default=2.0, help="Upper bound for Upsilon_* fits.")
    parser.add_argument("--progress", action="store_true", help="Print progress per galaxy.")
    parser.add_argument("--max-galaxies", type=int, default=None, help="Optional debug cap on number of galaxies processed.")
    parser.add_argument("--pause-at-end", action="store_true", help="Wait for Enter before exiting when run from a double-click console.")
    return parser.parse_args()

def main():
    args = parse_args()
    if args.upsilon_min <= 0.0 or args.upsilon_max <= args.upsilon_min:
        raise ValueError("Require 0 < --upsilon-min < --upsilon-max")

    script_dir = Path(__file__).resolve().parent
    sparc_dir = find_sparc_dir(script_dir, args.sparc_dir)
    metadata_path = find_metadata_file(script_dir, sparc_dir, args.metadata)
    metadata = load_sparc_mrt_metadata(metadata_path)
    dat_files = collect_dat_files(sparc_dir)

    if args.max_galaxies is not None:
        dat_files = dat_files[: max(0, args.max_galaxies)]

    results: list[GalaxyResult] = []
    skipped: list[str] = []
    for idx, path in enumerate(dat_files, start=1):
        meta = get_metadata_for_file(path, metadata)
        primary_sample = metadata_primary_sample_flag(meta)
        scale = None
        if args.progress:
            print(f"[{idx:03d}/{len(dat_files):03d}] {path.name}")
        try:
            scale = compute_scale_from_file(path, primary_sample)
            results.append(evaluate_galaxy(path, scale, (args.upsilon_min, args.upsilon_max)))
        except Exception as exc:
            skipped.append(f"{path.name}: {exc}")

    if not results:
        raise RuntimeError("No galaxies were processed successfully.")

    full = aggregate(results, "Full sample")
    primary_results = [r for r in results if r.primary_sample is True]
    aggs = [full]
    if primary_results:
        aggs.append(aggregate(primary_results, "Primary sample"))

    out_prefix = Path(args.output_prefix).expanduser()
    if not out_prefix.is_absolute():
        out_prefix = script_dir / out_prefix
    summary_txt = out_prefix.with_name(out_prefix.name + "_Summary.txt")
    galaxies_csv = out_prefix.with_name(out_prefix.name + "_Galaxies.csv")
    summary_json = out_prefix.with_name(out_prefix.name + "_Summary.json")
    skipped_txt = out_prefix.with_name(out_prefix.name + "_skipped.txt")

    write_galaxies_csv(galaxies_csv, results)
    write_summary_text(summary_txt, args, metadata_path, sparc_dir, aggs, results)
    write_summary_json(summary_json, args, metadata_path, sparc_dir, aggs, results)
    if skipped:
        skipped_txt.write_text("\n".join(skipped) + "\n", encoding="utf-8")

    print_console_summary(aggs, results, args)
    print("\nSaved outputs:")
    print(f"  {summary_txt}")
    print(f"  {galaxies_csv}")
    print(f"  {summary_json}")
    if skipped:
        print(f"  {skipped_txt} ({len(skipped)} skipped)")

if __name__ == "__main__":
    try:
        main()
    finally:
        input("\nPress Enter to exit...")