#!/usr/bin/env python3
# =============================================================================
# CPTG vs MOND Upsilon Responsive-Scale SPARC Benchmark
# =============================================================================
"""
Single-script CPTG vs MOND SPARC benchmark with permanent scale-response audit:

  1) CPTG base
     No Upsilon_* nuisance parameter. a_star is inferred from the baseline
     CPTG source field and Rc is derived from a_star.

  2) MOND base
     No Upsilon_* nuisance parameter. a0 is fixed at 1.2e-10 m/s^2.

  3) CPTG+Upsilon fixed scale
     Conservative control from the earlier script. Upsilon_* is fitted, but
     a_star/Rc remain fixed to the baseline Upsilon=1 CPTG scale.

  4) CPTG+Upsilon recomputed scale
     Physically responsive CPTG variant. For each Upsilon_* trial, the stellar
     source field is updated, a_star is re-inferred, Rc is re-derived, and the
     CPTG curve is scored. This is the headline CPTG+Upsilon result if CPTG's
     scale is understood as structurally inferred rather than universal.

  5) MOND+Upsilon
     Upsilon_* is fitted, gas is fixed, disk+bulge are scaled together, and
     a0 remains fixed.

Difference note
---------------
The earlier benchmark line "CPTG+Upsilon holds a_star and Rc fixed" is retained
only as a conservative control. The new recomputed-scale column is the physically
faithful CPTG+Upsilon mode because changing Upsilon_* changes the baryonic
source field from which CPTG infers a_star.

Expected files beside this script, or passed by CLI:
  - sparc_database/              extracted SPARC rotmod .dat files
  - SPARC_Lelli2016c.mrt         optional metadata for primary sample labels

Examples:
  python CPTG_MOND_Upsilon_SPARC_Benchmark_Responsive.py --sparc-dir ./sparc_database
  python CPTG_MOND_Upsilon_SPARC_Benchmark_Responsive.py --sparc-dir ./sparc_database --scale-mode nested --progress
  python CPTG_MOND_Upsilon_SPARC_Benchmark_Responsive.py --sparc-dir ./sparc_database --scale-mode two-stage --progress

Outputs:
  - CPTG_MOND_Upsilon_Benchmark_Summary.txt
  - CPTG_MOND_Upsilon_Benchmark_Galaxies.csv
  - CPTG_MOND_Upsilon_Benchmark_Summary.json
"""

from __future__ import annotations

import argparse
import csv
import glob
import json
import math
import re
import time
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Callable, Dict, List, Tuple

import numpy as np

# =============================================================================
# Constants and fixed model coefficients
# =============================================================================

C_LIGHT = 299792458.0
KPC_TO_M = 3.085677581491367e19
A0_MOND = 1.2e-10

# CPTG fixed source mapping and fixed geometric response coefficients.
CPTG_GAS_WEIGHT = 27.0 / 50.0
CPTG_DISK_WEIGHT = 23.0 / 50.0
CPTG_BULGE_WEIGHT = 16.0 / 25.0
ETA = 1.0 / 2.0
CPTG_INNER_SUPPRESSION_POWER = 123.0 / 50.0
CPTG_OUTER_SUPPRESSION_POWER = 11.0 / 50.0
CPTG_GEOM_NUMERATOR_POWER = 7.0 / 5.0
CPTG_GEOM_DENOMINATOR_POWER = 12.0 / 5.0

# MOND fixed source mapping in the base law.
MOND_GAS_WEIGHT = 1.0
MOND_DISK_WEIGHT = 1.0
MOND_BULGE_WEIGHT = 1.0

# SPARC mass-model sign conventions.
SPARC_SIGNED_GAS_BY_DEFAULT = True
SPARC_SIGNED_DISK_IF_NEGATIVE = True
SPARC_SIGNED_BULGE_IF_NEGATIVE = True

# SPARC primary-sample rule used when metadata are available.
SCIENCE_SAMPLE_MIN_INCLINATION_DEG = 30.0
SCIENCE_SAMPLE_EXCLUDED_Q_FLAGS = {3}

# =============================================================================
# Data containers
# =============================================================================

@dataclass
class GalaxyScale:
    """CPTG structural scale inferred for one galaxy."""
    filename: str
    a_star: float
    rc: float
    primary_sample: bool | None

@dataclass
class GalaxyResult:
    """Per-galaxy benchmark result with fixed and recomputed CPTG+Upsilon."""
    filename: str
    primary_sample: bool | None
    n_points: int
    scale_mode: str

    # Baseline structural scale inferred at Upsilon=1.
    a_star_base: float
    rc_base: float

    # Base models.
    chi2_cptg: float
    chi2_mond: float
    rms_cptg: float
    rms_mond: float
    mae_cptg: float
    mae_mond: float
    rar_cptg: float
    rar_mond: float

    # Conservative original CPTG+Upsilon: Upsilon fitted, scale fixed.
    upsilon_cptg_fixed: float
    chi2_cptg_u_fixed: float
    rms_cptg_u_fixed: float
    mae_cptg_u_fixed: float
    rar_cptg_u_fixed: float

    # Physically responsive CPTG+Upsilon: Upsilon fitted, scale re-inferred.
    upsilon_cptg_recomputed: float
    a_star_recomputed: float
    rc_recomputed: float
    chi2_cptg_u_recomputed: float
    rms_cptg_u_recomputed: float
    mae_cptg_u_recomputed: float
    rar_cptg_u_recomputed: float

    # MOND+Upsilon: Upsilon fitted, a0 fixed.
    upsilon_mond: float
    chi2_mond_u: float
    rms_mond_u: float
    mae_mond_u: float
    rar_mond_u: float

# =============================================================================
# Utility/data/model functions inherited from the original benchmark
# =============================================================================

def f6(x: float) -> str:
    return f"{float(x):.6f}"

def ascii_table(headers: list[str], rows: list[list[str]], aligns: list[str] | None = None) -> str:
    """Return a plain-ASCII boxed table with evenly aligned columns."""
    table_rows = [[str(cell) for cell in row] for row in rows]
    header_cells = [str(h) for h in headers]
    all_rows = [header_cells] + table_rows
    widths = [max(len(row[i]) for row in all_rows) for i in range(len(header_cells))]
    if aligns is None:
        aligns = ["left"] * len(header_cells)

    def fmt_cell(text: str, width: int, align: str) -> str:
        if align == "right":
            return text.rjust(width)
        if align == "center":
            return text.center(width)
        return text.ljust(width)

    def fmt_row(row: list[str]) -> str:
        cells = [fmt_cell(str(cell), widths[i], aligns[i]) for i, cell in enumerate(row)]
        return "| " + " | ".join(cells) + " |"

    border = "+-" + "-+-".join("-" * w for w in widths) + "-+"
    lines = [border, fmt_row(header_cells), border]
    lines.extend(fmt_row(row) for row in table_rows)
    lines.append(border)
    return "\n".join(lines)

def ascii_box(lines: list[str]) -> str:
    """Return a plain-ASCII box around one or more text lines."""
    text_lines = [str(line) for line in lines]
    width = max(len(line) for line in text_lines) if text_lines else 0
    border = "+-" + "-" * width + "-+"
    body = ["| " + line.ljust(width) + " |" for line in text_lines]
    return "\n".join([border] + body + [border])

def improvement(reference: float, model: float) -> float:
    """Percent improvement of model relative to reference. Positive means model is smaller/better."""
    reference = float(reference)
    model = float(model)
    if not np.isfinite(reference) or reference == 0.0:
        return float("nan")
    return 100.0 * (reference - model) / reference

def rms(arr: np.ndarray) -> float:
    arr = np.asarray(arr, dtype=float)
    if arr.size == 0:
        return float("nan")
    return float(np.sqrt(np.mean(arr * arr)))

def mae(arr: np.ndarray) -> float:
    arr = np.asarray(arr, dtype=float)
    if arr.size == 0:
        return float("nan")
    return float(np.mean(np.abs(arr)))

def scatter(arr: np.ndarray) -> float:
    arr = np.asarray(arr, dtype=float)
    arr = arr[np.isfinite(arr)]
    if arr.size == 0:
        return float("nan")
    return float(np.std(arr))

def signed_square(v: np.ndarray) -> np.ndarray:
    arr = np.asarray(v, dtype=float)
    return arr * np.abs(arr)

def velocity_component_term(v: np.ndarray, use_signed: bool) -> np.ndarray:
    arr = np.asarray(v, dtype=float)
    return signed_square(arr) if use_signed else arr ** 2

def clean_filename(name: str) -> str:
    base = Path(name.strip()).name
    while base.endswith("*") or base.endswith("!"):
        base = base[:-1]
    return base

def canonical_galaxy_key(name: str) -> str:
    """Return a comparison key for SPARC galaxy names and rotmod filenames."""
    text = clean_filename(str(name)).strip()
    text = re.sub(r"_rotmod\.dat$", "", text, flags=re.IGNORECASE)
    text = re.sub(r"\.(dat|txt|csv)$", "", text, flags=re.IGNORECASE)
    text = re.sub(r"[^A-Za-z0-9]+", "", text).upper()
    return text

def parse_float_or_none(text: Any) -> float | None:
    try:
        value = float(str(text).strip())
    except Exception:
        return None
    return value if np.isfinite(value) else None

def parse_int_or_none(text: Any) -> int | None:
    try:
        return int(float(str(text).strip()))
    except Exception:
        return None

def find_metadata_file(script_dir: Path, sparc_root: Path, explicit: str | None) -> Path | None:
    """Find SPARC Lelli2016 metadata, including downloaded names like SPARC_Lelli2016c(4).mrt."""
    if explicit:
        path = Path(explicit).expanduser().resolve()
        if not path.exists():
            raise FileNotFoundError(f"Metadata file not found: {path}")
        return path

    roots: list[Path] = []
    for root in [Path.cwd(), script_dir, sparc_root, sparc_root.parent]:
        try:
            root = root.expanduser().resolve()
        except Exception:
            continue
        if root.exists() and root not in roots:
            roots.append(root)
        for parent in list(root.parents)[:3]:
            if parent.exists() and parent not in roots:
                roots.append(parent)

    patterns = ["SPARC_Lelli2016c.mrt", "SPARC_Lelli2016c*.mrt", "*SPARC*Lelli*.mrt", "*Lelli*2016*.mrt", "*.mrt"]
    candidates: list[Path] = []
    for root in roots:
        for pattern in patterns:
            candidates.extend(Path(p).resolve() for p in glob.glob(str(root / pattern)))
    candidates = sorted(set(candidates), key=lambda p: ("SPARC" not in p.name.upper(), -p.stat().st_mtime))
    return candidates[0] if candidates else None

def _parse_sparc_mrt_split(parts: list[str]) -> dict[str, Any] | None:
    if len(parts) < 18:
        return None
    galaxy = parts[0].strip()
    if not galaxy or galaxy.startswith("#"):
        return None
    if parse_int_or_none(parts[1]) is None:
        return None
    distance_mpc = parse_float_or_none(parts[2])
    if distance_mpc is None:
        return None
    return {
        "name": galaxy,
        "distance_mpc": distance_mpc,
        "e_distance_mpc": parse_float_or_none(parts[3]),
        "distance_method_flag": parse_int_or_none(parts[4]),
        "inc_deg": parse_float_or_none(parts[5]),
        "e_inc_deg": parse_float_or_none(parts[6]),
        "l36_1e9_lsun": parse_float_or_none(parts[7]),
        "e_l36_1e9_lsun": parse_float_or_none(parts[8]),
        "reff_kpc": parse_float_or_none(parts[9]),
        "sbeff_lsun_pc2": parse_float_or_none(parts[10]),
        "rdisk_kpc": parse_float_or_none(parts[11]),
        "sbdisk_lsun_pc2": parse_float_or_none(parts[12]),
        "mhi_1e9_msun": parse_float_or_none(parts[13]),
        "rhi_kpc": parse_float_or_none(parts[14]),
        "vflat_km_s": parse_float_or_none(parts[15]),
        "e_vflat_km_s": parse_float_or_none(parts[16]),
        "q_flag": parse_int_or_none(parts[17]),
    }

def _parse_sparc_mrt_fixed_width(line: str) -> dict[str, Any] | None:
    if len(line) < 99:
        return None
    galaxy = line[0:11].strip()
    if not galaxy:
        return None
    t_type = parse_int_or_none(line[11:13].strip())
    distance_mpc = parse_float_or_none(line[13:19].strip())
    if t_type is None or distance_mpc is None:
        return None
    return {
        "name": galaxy,
        "distance_mpc": distance_mpc,
        "e_distance_mpc": parse_float_or_none(line[19:24].strip()),
        "distance_method_flag": parse_int_or_none(line[24:26].strip()),
        "inc_deg": parse_float_or_none(line[26:30].strip()),
        "e_inc_deg": parse_float_or_none(line[30:34].strip()),
        "l36_1e9_lsun": parse_float_or_none(line[34:41].strip()),
        "e_l36_1e9_lsun": parse_float_or_none(line[41:48].strip()),
        "reff_kpc": parse_float_or_none(line[48:53].strip()),
        "sbeff_lsun_pc2": parse_float_or_none(line[53:61].strip()),
        "rdisk_kpc": parse_float_or_none(line[61:66].strip()),
        "sbdisk_lsun_pc2": parse_float_or_none(line[66:74].strip()),
        "mhi_1e9_msun": parse_float_or_none(line[74:81].strip()),
        "rhi_kpc": parse_float_or_none(line[81:86].strip()),
        "vflat_km_s": parse_float_or_none(line[86:91].strip()),
        "e_vflat_km_s": parse_float_or_none(line[91:96].strip()),
        "q_flag": parse_int_or_none(line[96:99].strip()),
    }

def load_sparc_mrt_metadata(path: Path | None) -> dict[str, dict[str, Any]]:
    """Load SPARC Lelli2016c metadata for primary-sample labels; returns empty dict if unavailable."""
    if path is None:
        return {}
    metadata: dict[str, dict[str, Any]] = {}
    with path.open("r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            row = _parse_sparc_mrt_split(line.split())
            if row is None:
                row = _parse_sparc_mrt_fixed_width(line.rstrip("\n"))
            if row is None:
                continue
            key = canonical_galaxy_key(row["name"])
            if key:
                metadata[key] = row
    return metadata

def get_metadata_for_file(path: Path, metadata: dict[str, dict[str, Any]]) -> dict[str, Any] | None:
    key = canonical_galaxy_key(path.name)
    if key in metadata:
        return metadata[key]
    def strip_catalog_zeros(s: str) -> str:
        return re.sub(r"^(NGC|UGC|IC|DDO|ESO)0+", r"\1", s)
    slim = strip_catalog_zeros(key)
    for mkey, row in metadata.items():
        if strip_catalog_zeros(mkey) == slim:
            return row
    return None

def metadata_primary_sample_flag(metadata_row: dict[str, Any] | None) -> bool | None:
    """Return SPARC primary-sample flag from metadata if possible."""
    if not metadata_row:
        return None
    q_flag = metadata_row.get("q_flag")
    inc_deg = metadata_row.get("inc_deg")
    if q_flag is None and inc_deg is None:
        return None
    if q_flag in SCIENCE_SAMPLE_EXCLUDED_Q_FLAGS:
        return False
    if inc_deg is not None and float(inc_deg) < SCIENCE_SAMPLE_MIN_INCLINATION_DEG:
        return False
    return True

def rc_from_a_star(a_star: float) -> float:
    return (48.0 * np.pi * C_LIGHT ** 2) / max(float(a_star), 1e-30)

def find_sparc_dir(script_dir: Path, user_dir: str | None) -> Path:
    if user_dir:
        root = Path(user_dir).expanduser().resolve()
    else:
        root = script_dir / "sparc_database"
    if not root.exists():
        raise FileNotFoundError(f"SPARC directory not found: {root}")
    if not list(root.glob("**/*.dat")):
        raise FileNotFoundError(f"No .dat files found under SPARC directory: {root}")
    return root

def collect_dat_files(root: Path) -> list[Path]:
    found = sorted(Path(p) for p in glob.glob(str(root / "**" / "*.dat"), recursive=True))
    by_name: dict[str, Path] = {}
    for p in found:
        by_name.setdefault(p.name, p)
    return [by_name[k] for k in sorted(by_name)]

def load_sparc_file(path: Path):
    rows: list[list[float]] = []
    with path.open("r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split()
            if len(parts) < 6:
                continue
            try:
                rows.append([float(parts[i]) for i in range(6)])
            except ValueError:
                continue

    arr = np.asarray(rows, dtype=float)
    if arr.ndim != 2 or arr.shape[0] < 1 or arr.shape[1] < 6:
        raise ValueError(f"No usable SPARC rows in {path}")

    r_kpc = arr[:, 0]
    vobs_km_s = arr[:, 1]
    errv_km_s = arr[:, 2]
    vgas_km_s = arr[:, 3]
    vdisk_km_s = arr[:, 4]
    vbul_km_s = arr[:, 5]

    mask = (
        np.isfinite(r_kpc)
        & np.isfinite(vobs_km_s)
        & np.isfinite(errv_km_s)
        & np.isfinite(vgas_km_s)
        & np.isfinite(vdisk_km_s)
        & np.isfinite(vbul_km_s)
        & (r_kpc > 0.0)
    )
    r_kpc = r_kpc[mask]
    vobs_km_s = vobs_km_s[mask]
    errv_km_s = errv_km_s[mask]
    vgas_km_s = vgas_km_s[mask]
    vdisk_km_s = vdisk_km_s[mask]
    vbul_km_s = vbul_km_s[mask]
    if r_kpc.size == 0:
        raise ValueError(f"No finite SPARC rows in {path}")

    order = np.argsort(r_kpc)
    r_kpc = r_kpc[order]
    vobs_km_s = vobs_km_s[order]
    errv_km_s = errv_km_s[order]
    vgas_km_s = vgas_km_s[order]
    vdisk_km_s = vdisk_km_s[order]
    vbul_km_s = vbul_km_s[order]

    return r_kpc, vobs_km_s, errv_km_s, vgas_km_s, vdisk_km_s, vbul_km_s

def component_terms(vgas: np.ndarray, vdisk: np.ndarray, vbul: np.ndarray):
    use_signed_gas = SPARC_SIGNED_GAS_BY_DEFAULT or np.any(vgas < 0.0)
    use_signed_disk = SPARC_SIGNED_DISK_IF_NEGATIVE and np.any(vdisk < 0.0)
    use_signed_bulge = SPARC_SIGNED_BULGE_IF_NEGATIVE and np.any(vbul < 0.0)
    gas_term = velocity_component_term(vgas, use_signed_gas)
    disk_term = velocity_component_term(vdisk, use_signed_disk)
    bulge_term = velocity_component_term(vbul, use_signed_bulge)
    return gas_term, disk_term, bulge_term

def build_gbar(r_m: np.ndarray, gas_term: np.ndarray, disk_term: np.ndarray, bulge_term: np.ndarray, gas_w: float, disk_w: float, bulge_w: float, upsilon: float = 1.0) -> np.ndarray:
    vb2_signed = gas_w * gas_term + upsilon * (disk_w * disk_term + bulge_w * bulge_term)
    vb2 = np.maximum(vb2_signed, 0.0)
    return vb2 / np.maximum(r_m, 1e-30)

def mond_acceleration(gbar: np.ndarray) -> np.ndarray:
    gbar = np.maximum(np.asarray(gbar, dtype=float), 1e-30)
    x = np.maximum(gbar / A0_MOND, 1e-30)
    return gbar / (1.0 - np.exp(-np.sqrt(x)))

def cptg_acceleration(gbar: np.ndarray, r_m: np.ndarray, a_star: float, rc: float, n_iter: int = 300, tol: float = 1e-13) -> np.ndarray:
    gbar = np.maximum(np.asarray(gbar, dtype=float), 1e-30)
    r_m = np.maximum(np.asarray(r_m, dtype=float), 1e-30)
    a_star = max(float(a_star), 1e-30)
    rc = max(float(rc), 1e-30)
    g = gbar.copy()
    x = r_m / rc
    x_num = x ** CPTG_GEOM_NUMERATOR_POWER
    x_den = x ** CPTG_GEOM_DENOMINATOR_POWER
    g_geom = ETA * a_star * x_num / (1.0 + x_den)
    numerator = np.sqrt(np.maximum(a_star * gbar, 0.0)) + g_geom
    for _ in range(n_iter):
        denominator = (1.0 + (g / a_star) ** CPTG_INNER_SUPPRESSION_POWER) ** CPTG_OUTER_SUPPRESSION_POWER
        g_new = gbar + numerator / denominator
        rel = float(np.max(np.abs(g_new - g) / np.maximum(np.abs(g_new), 1e-30)))
        g = g_new
        if rel < tol:
            break
    return g

def velocity_from_acceleration(g: np.ndarray, r_m: np.ndarray) -> np.ndarray:
    return np.sqrt(np.maximum(g, 0.0) * np.maximum(r_m, 1e-30))

def bounded_minimize(func: Callable[[float], float], lo: float, hi: float, max_iter: int = 60, tol: float = 1e-5) -> tuple[float, float]:
    """Bounded minimization on [lo, hi]. Uses scipy when available, otherwise golden-section."""
    try:
        from scipy.optimize import minimize_scalar  # type: ignore
        result = minimize_scalar(func, bounds=(lo, hi), method="bounded", options={"xatol": tol})
        x = float(result.x) if result.success and np.isfinite(result.fun) else 0.5 * (lo + hi)
        fx = float(func(x))
    except Exception:
        gr = (math.sqrt(5.0) - 1.0) / 2.0
        a = float(lo)
        b = float(hi)
        c = b - gr * (b - a)
        d = a + gr * (b - a)
        fc = float(func(c))
        fd = float(func(d))
        for _ in range(max_iter):
            if abs(b - a) <= tol:
                break
            if fc < fd:
                b, d, fd = d, c, fc
                c = b - gr * (b - a)
                fc = float(func(c))
            else:
                a, c, fc = c, d, fd
                d = a + gr * (b - a)
                fd = float(func(d))
        x = 0.5 * (a + b)
        fx = float(func(x))

    # Include exact bounds so boundary solutions are captured cleanly.
    flo = float(func(lo))
    fhi = float(func(hi))
    candidates = [(x, fx), (float(lo), flo), (float(hi), fhi)]
    best_x, best_f = min(candidates, key=lambda t: t[1])
    return float(best_x), float(best_f)

def fit_cptg_scale_for_galaxy(
    g_bar: np.ndarray,
    r_m: np.ndarray,
    vobs_m_s: np.ndarray,
    errv_m_s: np.ndarray,
) -> GalaxyScale:
    """Infer the CPTG structural scale a_star directly from one galaxy file.

    This is the default path requested for this standalone benchmark:
    the SPARC rotmod file supplies the observed curve and baryonic components,
    CPTG builds the source field, infers a_star, and derives Rc from a_star.
    """
    err_safe = np.maximum(errv_m_s, 1.0)

    def chi2_of_log_a(x: float) -> float:
        a_star = 10.0 ** float(x)
        rc = rc_from_a_star(a_star)
        g_cptg = cptg_acceleration(g_bar, r_m, a_star=a_star, rc=rc)
        v_cptg = velocity_from_acceleration(g_cptg, r_m)
        resid = (vobs_m_s - v_cptg) / err_safe
        return float(np.sum(resid * resid))

    # Stage 1: bounded log-space inference.  Stage 2: small deterministic
    # local refinement.  This mirrors the audited benchmark's two-stage search
    # while keeping this script self-contained.
    x0, _ = bounded_minimize(chi2_of_log_a, -12.0, -9.0, tol=1e-8)
    x_grid = np.linspace(max(-12.0, x0 - 0.02), min(-9.0, x0 + 0.02), 161)
    chi_grid = np.asarray([chi2_of_log_a(x) for x in x_grid], dtype=float)
    best_log_a = float(x_grid[int(np.argmin(chi_grid))])
    a_star = 10.0 ** best_log_a
    rc = rc_from_a_star(a_star)
    return GalaxyScale(filename="", a_star=float(a_star), rc=float(rc), primary_sample=None)

def fit_upsilon_for_model(
    model: str,
    r_m: np.ndarray,
    vobs: np.ndarray,
    errv: np.ndarray,
    gas_term: np.ndarray,
    disk_term: np.ndarray,
    bulge_term: np.ndarray,
    a_star: float | None,
    rc: float | None,
    lo: float,
    hi: float,
) -> tuple[float, np.ndarray, np.ndarray, np.ndarray, float]:
    err_safe = np.maximum(errv, 1.0)

    if model == "mond":
        gas_w, disk_w, bulge_w = MOND_GAS_WEIGHT, MOND_DISK_WEIGHT, MOND_BULGE_WEIGHT
    elif model == "cptg":
        gas_w, disk_w, bulge_w = CPTG_GAS_WEIGHT, CPTG_DISK_WEIGHT, CPTG_BULGE_WEIGHT
        if a_star is None or rc is None:
            raise ValueError("CPTG Upsilon fit requires fixed a_star and Rc")
    else:
        raise ValueError(f"Unknown model: {model}")

    def chi2_for_u(u: float) -> float:
        gbar = build_gbar(r_m, gas_term, disk_term, bulge_term, gas_w, disk_w, bulge_w, upsilon=u)
        if model == "mond":
            g = mond_acceleration(gbar)
        else:
            g = cptg_acceleration(gbar, r_m, float(a_star), float(rc))
        vmodel = velocity_from_acceleration(g, r_m)
        resid = (vobs - vmodel) / err_safe
        return float(np.sum(resid * resid))

    u_best, chi2_best = bounded_minimize(chi2_for_u, lo, hi)
    gbar_best = build_gbar(r_m, gas_term, disk_term, bulge_term, gas_w, disk_w, bulge_w, upsilon=u_best)
    if model == "mond":
        g_best = mond_acceleration(gbar_best)
    else:
        g_best = cptg_acceleration(gbar_best, r_m, float(a_star), float(rc))
    v_best = velocity_from_acceleration(g_best, r_m)
    return u_best, gbar_best, g_best, v_best, chi2_best

# =============================================================================
# Responsive-scale CPTG+Upsilon functions
# =============================================================================

def chi2_from_v(vobs: np.ndarray, vmodel: np.ndarray, errv: np.ndarray) -> float:
    """Return chi-square from velocity residuals."""
    resid = (vobs - vmodel) / np.maximum(errv, 1.0)
    return float(np.sum(resid * resid))

def rar_scatter(vobs: np.ndarray, r_m: np.ndarray, gmodel: np.ndarray) -> float:
    """Return RAR scatter using the same definition as the original benchmark."""
    g_obs = np.maximum((vobs * vobs) / np.maximum(r_m, 1e-30), 1e-30)
    return scatter(np.log10(np.maximum(g_obs / np.maximum(gmodel, 1e-30), 1e-300)))

def summarize_model(vobs: np.ndarray, vmodel: np.ndarray, errv: np.ndarray, r_m: np.ndarray, gmodel: np.ndarray) -> Dict[str, float]:
    """Return chi2/RMS/MAE/RAR for one predicted curve."""
    residual = vobs - vmodel
    return {
        "chi2": chi2_from_v(vobs, vmodel, errv),
        "rms": rms(residual),
        "mae": mae(residual),
        "rar": rar_scatter(vobs, r_m, gmodel),
    }

def cptg_curve_for_upsilon_with_recomputed_scale(
    u: float,
    r_m: np.ndarray,
    vobs: np.ndarray,
    errv: np.ndarray,
    gas_term: np.ndarray,
    disk_term: np.ndarray,
    bulge_term: np.ndarray,
) -> Tuple[float, float, np.ndarray, np.ndarray, np.ndarray, float]:
    """Build a CPTG curve at Upsilon=u after re-inferring a_star/Rc.

    This is the physically responsive version: Upsilon changes the stellar
    source field, so gbar changes, so the CPTG structural scale is re-inferred.
    """
    gbar = build_gbar(
        r_m,
        gas_term,
        disk_term,
        bulge_term,
        CPTG_GAS_WEIGHT,
        CPTG_DISK_WEIGHT,
        CPTG_BULGE_WEIGHT,
        upsilon=u,
    )
    scale = fit_cptg_scale_for_galaxy(gbar, r_m, vobs, errv)
    g = cptg_acceleration(gbar, r_m, scale.a_star, scale.rc)
    v = velocity_from_acceleration(g, r_m)
    chi2 = chi2_from_v(vobs, v, errv)
    return float(scale.a_star), float(scale.rc), gbar, g, v, chi2

def fit_cptg_upsilon_recomputed_nested(
    r_m: np.ndarray,
    vobs: np.ndarray,
    errv: np.ndarray,
    gas_term: np.ndarray,
    disk_term: np.ndarray,
    bulge_term: np.ndarray,
    lo: float,
    hi: float,
) -> Tuple[float, float, float, np.ndarray, np.ndarray, float]:
    """Fit Upsilon while re-inferring a_star/Rc at every trial Upsilon.

    This is the rigorous responsive-scale benchmark. It is slower because each
    Upsilon trial contains an inner a_star inference.
    """
    cache: Dict[float, Tuple[float, float, np.ndarray, np.ndarray, np.ndarray, float]] = {}

    def eval_u(u: float):
        key = round(float(u), 10)
        if key not in cache:
            cache[key] = cptg_curve_for_upsilon_with_recomputed_scale(
                float(u), r_m, vobs, errv, gas_term, disk_term, bulge_term
            )
        return cache[key]

    def objective(u: float) -> float:
        return eval_u(u)[5]

    u_best, _ = bounded_minimize(objective, lo, hi, tol=1e-5)
    a_star, rc, _gbar, g, v, chi2 = eval_u(u_best)
    return float(u_best), float(a_star), float(rc), g, v, float(chi2)

def fit_cptg_upsilon_recomputed_two_stage(
    fixed_u: float,
    r_m: np.ndarray,
    vobs: np.ndarray,
    errv: np.ndarray,
    gas_term: np.ndarray,
    disk_term: np.ndarray,
    bulge_term: np.ndarray,
) -> Tuple[float, float, float, np.ndarray, np.ndarray, float]:
    """Fast diagnostic: recompute scale once at fixed-scale best Upsilon."""
    a_star, rc, _gbar, g, v, chi2 = cptg_curve_for_upsilon_with_recomputed_scale(
        fixed_u, r_m, vobs, errv, gas_term, disk_term, bulge_term
    )
    return float(fixed_u), float(a_star), float(rc), g, v, float(chi2)

def evaluate_galaxy(path: Path, primary_sample: bool | None, upsilon_bounds: Tuple[float, float], scale_mode: str) -> GalaxyResult:
    """Evaluate one galaxy across all benchmark models."""
    r_kpc, vobs_km_s, errv_km_s, vgas_km_s, vdisk_km_s, vbul_km_s = load_sparc_file(path)
    r_m = r_kpc * KPC_TO_M
    vobs = vobs_km_s * 1000.0
    errv = np.maximum(errv_km_s * 1000.0, 1.0)
    vgas = vgas_km_s * 1000.0
    vdisk = vdisk_km_s * 1000.0
    vbul = vbul_km_s * 1000.0
    gas_term, disk_term, bulge_term = component_terms(vgas, vdisk, vbul)

    # Baseline CPTG scale inferred at Upsilon=1.
    gbar_cptg_base = build_gbar(
        r_m, gas_term, disk_term, bulge_term,
        CPTG_GAS_WEIGHT, CPTG_DISK_WEIGHT, CPTG_BULGE_WEIGHT, upsilon=1.0
    )
    scale = fit_cptg_scale_for_galaxy(gbar_cptg_base, r_m, vobs, errv)

    # Base CPTG.
    g_cptg = cptg_acceleration(gbar_cptg_base, r_m, scale.a_star, scale.rc)
    v_cptg = velocity_from_acceleration(g_cptg, r_m)
    m_cptg = summarize_model(vobs, v_cptg, errv, r_m, g_cptg)

    # Base MOND.
    gbar_mond = build_gbar(
        r_m, gas_term, disk_term, bulge_term,
        MOND_GAS_WEIGHT, MOND_DISK_WEIGHT, MOND_BULGE_WEIGHT, upsilon=1.0
    )
    g_mond = mond_acceleration(gbar_mond)
    v_mond = velocity_from_acceleration(g_mond, r_m)
    m_mond = summarize_model(vobs, v_mond, errv, r_m, g_mond)

    # MOND + Upsilon: unchanged from the original benchmark.
    u_mond, _gbar_mond_u, g_mond_u, v_mond_u, _chi2_mond_u = fit_upsilon_for_model(
        "mond", r_m, vobs, errv, gas_term, disk_term, bulge_term,
        None, None, upsilon_bounds[0], upsilon_bounds[1]
    )
    m_mond_u = summarize_model(vobs, v_mond_u, errv, r_m, g_mond_u)

    # CPTG + Upsilon fixed-scale: original conservative/control method.
    u_cptg_fixed, _gbar_cptg_u_fixed, g_cptg_u_fixed, v_cptg_u_fixed, _chi2_cptg_u_fixed = fit_upsilon_for_model(
        "cptg", r_m, vobs, errv, gas_term, disk_term, bulge_term,
        scale.a_star, scale.rc, upsilon_bounds[0], upsilon_bounds[1]
    )
    m_cptg_fixed = summarize_model(vobs, v_cptg_u_fixed, errv, r_m, g_cptg_u_fixed)

    # CPTG + Upsilon recomputed-scale: physically responsive method.
    if scale_mode == "two-stage":
        u_re, a_re, rc_re, g_re, v_re, _chi2_re = fit_cptg_upsilon_recomputed_two_stage(
            u_cptg_fixed, r_m, vobs, errv, gas_term, disk_term, bulge_term
        )
    elif scale_mode == "nested":
        u_re, a_re, rc_re, g_re, v_re, _chi2_re = fit_cptg_upsilon_recomputed_nested(
            r_m, vobs, errv, gas_term, disk_term, bulge_term, upsilon_bounds[0], upsilon_bounds[1]
        )
    else:
        raise ValueError(f"Unknown scale_mode: {scale_mode}")
    m_cptg_re = summarize_model(vobs, v_re, errv, r_m, g_re)

    return GalaxyResult(
        filename=path.name,
        primary_sample=primary_sample,
        n_points=int(r_m.size),
        scale_mode=scale_mode,
        a_star_base=float(scale.a_star),
        rc_base=float(scale.rc),
        chi2_cptg=m_cptg["chi2"],
        chi2_mond=m_mond["chi2"],
        rms_cptg=m_cptg["rms"],
        rms_mond=m_mond["rms"],
        mae_cptg=m_cptg["mae"],
        mae_mond=m_mond["mae"],
        rar_cptg=m_cptg["rar"],
        rar_mond=m_mond["rar"],
        upsilon_cptg_fixed=float(u_cptg_fixed),
        chi2_cptg_u_fixed=m_cptg_fixed["chi2"],
        rms_cptg_u_fixed=m_cptg_fixed["rms"],
        mae_cptg_u_fixed=m_cptg_fixed["mae"],
        rar_cptg_u_fixed=m_cptg_fixed["rar"],
        upsilon_cptg_recomputed=float(u_re),
        a_star_recomputed=float(a_re),
        rc_recomputed=float(rc_re),
        chi2_cptg_u_recomputed=m_cptg_re["chi2"],
        rms_cptg_u_recomputed=m_cptg_re["rms"],
        mae_cptg_u_recomputed=m_cptg_re["mae"],
        rar_cptg_u_recomputed=m_cptg_re["rar"],
        upsilon_mond=float(u_mond),
        chi2_mond_u=m_mond_u["chi2"],
        rms_mond_u=m_mond_u["rms"],
        mae_mond_u=m_mond_u["mae"],
        rar_mond_u=m_mond_u["rar"],
    )

# =============================================================================
# Aggregation and reporting
# =============================================================================

def total(results: List[GalaxyResult], attr: str) -> float:
    return float(sum(getattr(r, attr) for r in results))

def weighted_rms(results: List[GalaxyResult], attr: str) -> float:
    n = sum(r.n_points for r in results)
    return float(np.sqrt(sum((getattr(r, attr) ** 2) * r.n_points for r in results) / max(1, n)))

def weighted_mean(results: List[GalaxyResult], attr: str) -> float:
    n = sum(r.n_points for r in results)
    return float(sum(getattr(r, attr) * r.n_points for r in results) / max(1, n))

def count_wins(results: List[GalaxyResult], model_attr: str, reference_attr: str) -> Tuple[int, int]:
    model_wins = sum(1 for r in results if getattr(r, model_attr) < getattr(r, reference_attr))
    reference_wins = sum(1 for r in results if getattr(r, reference_attr) < getattr(r, model_attr))
    return model_wins, reference_wins

def aggregate(results: List[GalaxyResult], label: str) -> Dict[str, Any]:
    """Aggregate full or primary sample results."""
    n_points = sum(r.n_points for r in results)
    model_suffixes = ["cptg", "mond", "cptg_u_fixed", "cptg_u_recomputed", "mond_u"]

    out: Dict[str, Any] = {"label": label, "n_galaxies": len(results), "n_points": n_points}
    for suffix in model_suffixes:
        out[f"chi2_{suffix}"] = total(results, f"chi2_{suffix}")
        out[f"chi2_per_point_{suffix}"] = out[f"chi2_{suffix}"] / max(1, n_points)
        out[f"rms_{suffix}"] = weighted_rms(results, f"rms_{suffix}")
        out[f"mae_{suffix}"] = weighted_mean(results, f"mae_{suffix}")
        out[f"rar_{suffix}"] = weighted_mean(results, f"rar_{suffix}")

    comparison_specs = [
        ("CPTG vs MOND (base)", "cptg", "mond"),
        ("CPTG vs MOND+Upsilon", "cptg", "mond_u"),
        ("CPTG+U fixed vs MOND+Upsilon", "cptg_u_fixed", "mond_u"),
        ("CPTG+U recomputed vs MOND+Upsilon", "cptg_u_recomputed", "mond_u"),
        ("CPTG+U recomputed vs CPTG+U fixed", "cptg_u_recomputed", "cptg_u_fixed"),
        ("CPTG+U recomputed vs MOND (base)", "cptg_u_recomputed", "mond"),
    ]
    comparisons = []
    for name, model, reference in comparison_specs:
        mw, rw = count_wins(results, f"chi2_{model}", f"chi2_{reference}")
        row = {
            "comparison": name,
            "model": model,
            "reference": reference,
            "model_wins": mw,
            "reference_wins": rw,
        }
        for metric in ["chi2", "chi2_per_point", "rms", "mae", "rar"]:
            row[f"model_{metric}"] = out[f"{metric}_{model}"]
            row[f"reference_{metric}"] = out[f"{metric}_{reference}"]
            row[f"{metric}_improvement_percent"] = improvement(out[f"{metric}_{reference}"], out[f"{metric}_{model}"])
        comparisons.append(row)
    out["comparisons"] = comparisons
    return out

def model_totals_table(agg: Dict[str, Any]) -> str:
    """Return model totals with models as columns and benchmark metrics as rows."""
    cols = ["CPTG", "MOND", "CPTG+U fixed", "CPTG+U recomputed", "MOND+U"]
    suffixes = ["cptg", "mond", "cptg_u_fixed", "cptg_u_recomputed", "mond_u"]
    rows = [
        ["Upsilon params", "0", "0", "1", "1", "1"],
        ["Scale behavior", "inferred", "fixed a0", "fixed to base", "recomputed", "fixed a0"],
    ]
    for metric, label in [("chi2", "chi2"), ("chi2_per_point", "chi2/pt"), ("rms", "RMS m/s"), ("mae", "MAE m/s"), ("rar", "RAR")]:
        rows.append([label] + [f6(agg[f"{metric}_{s}"]) for s in suffixes])
    return ascii_table(["Benchmark"] + cols, rows, ["left", "right", "right", "right", "right", "right"])

def comparisons_table(agg: Dict[str, Any]) -> str:
    """Return audited comparison rows."""
    rows = []
    for row in agg["comparisons"]:
        rows.append([
            str(row["comparison"]),
            f6(row["chi2_improvement_percent"]),
            f6(row["chi2_per_point_improvement_percent"]),
            f6(row["rms_improvement_percent"]),
            f6(row["mae_improvement_percent"]),
            f6(row["rar_improvement_percent"]),
            f"{row['model_wins']} / {row['reference_wins']}",
        ])
    return ascii_table(
        ["Comparison", "chi2 %", "chi2/pt %", "RMS %", "MAE %", "RAR %", "Wins"],
        rows,
        ["left", "right", "right", "right", "right", "right", "right"],
    )

def upsilon_distribution_table(results: List[GalaxyResult], args: argparse.Namespace) -> str:
    """Return Upsilon distributions for all fitted-Upsilon models."""
    arrays = {
        "CPTG+U fixed": np.asarray([r.upsilon_cptg_fixed for r in results], dtype=float),
        "CPTG+U recomputed": np.asarray([r.upsilon_cptg_recomputed for r in results], dtype=float),
        "MOND+U": np.asarray([r.upsilon_mond for r in results], dtype=float),
    }
    rows = []
    for stat in ["Mean", "Median", "Min", "Max", "Lower hits", "Upper hits"]:
        row = [stat]
        for arr in arrays.values():
            if stat == "Mean":
                row.append(f6(np.mean(arr)))
            elif stat == "Median":
                row.append(f6(np.median(arr)))
            elif stat == "Min":
                row.append(f6(np.min(arr)))
            elif stat == "Max":
                row.append(f6(np.max(arr)))
            elif stat == "Lower hits":
                row.append(str(int(np.sum(np.isclose(arr, args.upsilon_min, atol=5e-6)))))
            elif stat == "Upper hits":
                row.append(str(int(np.sum(np.isclose(arr, args.upsilon_max, atol=5e-6)))))
        rows.append(row)
    return ascii_table(["Benchmark"] + list(arrays.keys()), rows, ["left", "right", "right", "right"])

def scale_distribution_table(results: List[GalaxyResult]) -> str:
    """Return how recomputed CPTG scale differs from baseline scale."""
    a_ratio = np.asarray([r.a_star_recomputed / max(r.a_star_base, 1e-300) for r in results], dtype=float)
    rc_ratio = np.asarray([r.rc_recomputed / max(r.rc_base, 1e-300) for r in results], dtype=float)
    rows = [
        ["a_star ratio mean", f6(np.mean(a_ratio))],
        ["a_star ratio median", f6(np.median(a_ratio))],
        ["a_star ratio min", f6(np.min(a_ratio))],
        ["a_star ratio max", f6(np.max(a_ratio))],
        ["Rc ratio mean", f6(np.mean(rc_ratio))],
        ["Rc ratio median", f6(np.median(rc_ratio))],
        ["Rc ratio min", f6(np.min(rc_ratio))],
        ["Rc ratio max", f6(np.max(rc_ratio))],
    ]
    return ascii_table(["Scale response statistic", "Value"], rows, ["left", "right"])

def write_galaxies_csv(path: Path, results: List[GalaxyResult]) -> None:
    fields = list(asdict(results[0]).keys()) if results else []
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for r in results:
            writer.writerow(asdict(r))

def write_summary_text(path: Path, args: argparse.Namespace, metadata_path: Path | None, sparc_dir: Path, aggs: List[Dict[str, Any]], results: List[GalaxyResult], skipped: List[str]) -> None:
    with path.open("w", encoding="utf-8") as f:
        f.write(ascii_box([
            "CPTG vs MOND responsive-scale Upsilon benchmark",
            "All displayed numeric values use 6-digit precision.",
        ]))
        f.write("\n\n")
        f.write(f"SPARC directory: {sparc_dir}\n")
        f.write(f"SPARC metadata: {metadata_path if metadata_path is not None else 'not loaded'}\n")
        f.write(f"Scale mode: {args.scale_mode}\n")
        f.write(f"Upsilon bounds: {args.upsilon_min:.6f} <= Upsilon_* <= {args.upsilon_max:.6f}\n")
        f.write(f"Skipped galaxies: {len(skipped)}\n\n")
        f.write("MODEL DIFFERENCE NOTE\n")
        f.write("  CPTG+U fixed is the original conservative control: Upsilon_* is fitted, but a_star/Rc are fixed to the Upsilon=1 baseline.\n")
        f.write("  CPTG+U recomputed is the physically responsive CPTG variant: Upsilon_* changes the source field, then a_star/Rc are re-inferred.\n")
        f.write("  MOND+U fits Upsilon_* while keeping universal a0 fixed at 1.2e-10 m/s^2.\n")
        f.write("  Nested scale mode re-inferrs a_star/Rc at every Upsilon trial; two-stage mode is a faster diagnostic.\n\n")

        f.write(ascii_box(["UPSILON DISTRIBUTIONS"]))
        f.write("\n")
        f.write(upsilon_distribution_table(results, args))
        f.write("\n\n")
        f.write(ascii_box(["CPTG SCALE RESPONSE DISTRIBUTION"]))
        f.write("\n")
        f.write(scale_distribution_table(results))
        f.write("\n")

        for agg in aggs:
            f.write("\n")
            f.write(ascii_box([
                agg["label"].upper(),
                f"Files/points: {agg['n_galaxies']} / {agg['n_points']}",
            ]))
            f.write("\n\n")
            f.write("MODEL TOTALS\n")
            f.write(model_totals_table(agg))
            f.write("\n\n")
            f.write("AUDITED COMPARISONS\n")
            f.write("Positive improvement means the CPTG-side model is lower/better.\n")
            f.write(comparisons_table(agg))
            f.write("\n")

def write_summary_json(path: Path, args: argparse.Namespace, metadata_path: Path | None, sparc_dir: Path, aggs: List[Dict[str, Any]], results: List[GalaxyResult], skipped: List[str]) -> None:
    payload = {
        "sparc_dir": str(sparc_dir),
        "metadata": str(metadata_path) if metadata_path is not None else None,
        "scale_mode": args.scale_mode,
        "upsilon_bounds": [args.upsilon_min, args.upsilon_max],
        "model_difference_note": {
            "cptg_u_fixed": "Upsilon fitted; a_star/Rc fixed to Upsilon=1 baseline. Conservative control.",
            "cptg_u_recomputed": "Upsilon fitted; a_star/Rc re-inferred from updated source field. Physically responsive CPTG.",
            "mond_u": "Upsilon fitted; a0 fixed.",
        },
        "aggregates": aggs,
        "upsilon_distribution": {
            "cptg_u_fixed": {
                "mean": float(np.mean([r.upsilon_cptg_fixed for r in results])),
                "median": float(np.median([r.upsilon_cptg_fixed for r in results])),
                "min": float(np.min([r.upsilon_cptg_fixed for r in results])),
                "max": float(np.max([r.upsilon_cptg_fixed for r in results])),
            },
            "cptg_u_recomputed": {
                "mean": float(np.mean([r.upsilon_cptg_recomputed for r in results])),
                "median": float(np.median([r.upsilon_cptg_recomputed for r in results])),
                "min": float(np.min([r.upsilon_cptg_recomputed for r in results])),
                "max": float(np.max([r.upsilon_cptg_recomputed for r in results])),
            },
            "mond_u": {
                "mean": float(np.mean([r.upsilon_mond for r in results])),
                "median": float(np.median([r.upsilon_mond for r in results])),
                "min": float(np.min([r.upsilon_mond for r in results])),
                "max": float(np.max([r.upsilon_mond for r in results])),
            },
        },
        "skipped": skipped,
    }
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")

def print_console_summary(aggs: List[Dict[str, Any]], results: List[GalaxyResult], args: argparse.Namespace) -> None:
    print("\n" + ascii_box([
        "CPTG vs MOND responsive-scale Upsilon benchmark",
        "All displayed numeric values use 6-digit precision.",
    ]))
    print(f"Scale mode: {args.scale_mode}")
    print(f"Upsilon bounds: {args.upsilon_min:.6f} <= Upsilon_* <= {args.upsilon_max:.6f}")
    print("\nMODEL DIFFERENCE NOTE")
    print("  CPTG+U fixed:      Upsilon fitted, a_star/Rc fixed to Upsilon=1 baseline.")
    print("  CPTG+U recomputed: Upsilon fitted, a_star/Rc re-inferred from updated source field.")
    print("  MOND+U:            Upsilon fitted, a0 fixed.\n")
    print(ascii_box(["UPSILON DISTRIBUTIONS"]))
    print(upsilon_distribution_table(results, args))

    for agg in aggs:
        print("\n" + ascii_box([
            agg["label"].upper(),
            f"Files/points: {agg['n_galaxies']} / {agg['n_points']}",
        ]))
        print("\nMODEL TOTALS")
        print(model_totals_table(agg))
        print("\nAUDITED COMPARISONS")
        print("Positive improvement means the CPTG-side model is lower/better.")
        print(comparisons_table(agg))

def format_minutes(seconds: float) -> str:
    return f"{seconds / 60.0:.1f} min"

# =============================================================================
# Main
# =============================================================================

def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run CPTG vs MOND SPARC benchmark with fixed and recomputed CPTG+Upsilon scales.")
    parser.add_argument("--sparc-dir", default=None, help="Path to extracted SPARC rotmod directory. Default: ./sparc_database beside this script.")
    parser.add_argument("--metadata", default=None, help="Optional SPARC_Lelli2016c.mrt metadata file for primary-sample labels; auto-detected if omitted.")
    parser.add_argument("--output-prefix", default="CPTG_MOND_Upsilon_Benchmark", help="Output file prefix.")
    parser.add_argument("--upsilon-min", type=float, default=0.1, help="Lower bound for Upsilon_* fits.")
    parser.add_argument("--upsilon-max", type=float, default=2.0, help="Upper bound for Upsilon_* fits.")
    parser.add_argument("--scale-mode", choices=["nested", "two-stage"], default="nested", help="Recomputed-scale mode. nested is rigorous but slower; two-stage is faster diagnostic.")
    parser.add_argument("--progress", action="store_true", help="Print progress per galaxy.")
    parser.add_argument("--progress-interval-minutes", type=float, default=5.0, help="Progress report interval.")
    parser.add_argument("--max-galaxies", type=int, default=None, help="Optional debug cap on number of galaxies processed.")
    parser.add_argument("--pause-at-end", action="store_true", help="Wait for Enter before exiting when run from a double-click console.")
    return parser.parse_args()

def main() -> None:
    args = parse_args()
    if args.upsilon_min <= 0.0 or args.upsilon_max <= args.upsilon_min:
        raise ValueError("Require 0 < --upsilon-min < --upsilon-max")

    script_dir = Path(__file__).resolve().parent
    sparc_dir = find_sparc_dir(script_dir, args.sparc_dir)
    metadata_path = find_metadata_file(script_dir, sparc_dir, args.metadata)
    metadata = load_sparc_mrt_metadata(metadata_path)
    dat_files = collect_dat_files(sparc_dir)

    if args.max_galaxies is not None:
        dat_files = dat_files[: max(0, args.max_galaxies)]

    print("CPTG vs MOND responsive-scale Upsilon benchmark")
    print(f"Galaxies to process: {len(dat_files)}")
    print(f"Scale mode: {args.scale_mode}")
    if args.scale_mode == "nested":
        print("Runtime warning: nested mode is expensive because each Upsilon trial re-inferrs a_star/Rc.")
        print("Full SPARC runs may take minutes or hours depending on database size and CPU speed.")
    print()

    start = time.time()
    last_report = start
    results: List[GalaxyResult] = []
    skipped: List[str] = []
    for idx, path in enumerate(dat_files, start=1):
        meta = get_metadata_for_file(path, metadata)
        primary_sample = metadata_primary_sample_flag(meta)
        if args.progress:
            print(f"[{idx:03d}/{len(dat_files):03d}] {path.name}", flush=True)
        try:
            results.append(evaluate_galaxy(path, primary_sample, (args.upsilon_min, args.upsilon_max), args.scale_mode))
        except Exception as exc:
            skipped.append(f"{path.name}: {exc}")
        now = time.time()
        if args.progress and (now - last_report >= args.progress_interval_minutes * 60.0 or idx == len(dat_files)):
            elapsed = now - start
            frac = idx / max(1, len(dat_files))
            eta = elapsed * (1.0 - frac) / max(frac, 1e-12)
            print(f"[progress] {idx}/{len(dat_files)} ({100.0*frac:.1f}%), elapsed={format_minutes(elapsed)}, ETA={format_minutes(eta)}", flush=True)
            last_report = now

    if not results:
        raise RuntimeError("No galaxies were processed successfully.")

    full = aggregate(results, "Full sample")
    primary_results = [r for r in results if r.primary_sample is True]
    aggs = [full]
    if primary_results:
        aggs.append(aggregate(primary_results, "Primary sample"))

    out_prefix = Path(args.output_prefix).expanduser()
    if not out_prefix.is_absolute():
        out_prefix = script_dir / out_prefix
    summary_txt = out_prefix.with_name(out_prefix.name + "_Summary.txt")
    galaxies_csv = out_prefix.with_name(out_prefix.name + "_Galaxies.csv")
    summary_json = out_prefix.with_name(out_prefix.name + "_Summary.json")
    skipped_txt = out_prefix.with_name(out_prefix.name + "_skipped.txt")

    write_galaxies_csv(galaxies_csv, results)
    write_summary_text(summary_txt, args, metadata_path, sparc_dir, aggs, results, skipped)
    write_summary_json(summary_json, args, metadata_path, sparc_dir, aggs, results, skipped)
    if skipped:
        skipped_txt.write_text("\n".join(skipped) + "\n", encoding="utf-8")

    print_console_summary(aggs, results, args)
    print("\nSaved outputs:")
    print(f"  {summary_txt}")
    print(f"  {galaxies_csv}")
    print(f"  {summary_json}")
    if skipped:
        print(f"  {skipped_txt} ({len(skipped)} skipped)")

    print(f"\nElapsed: {format_minutes(time.time() - start)}")

if __name__ == "__main__":
    try:
        main()
    finally:
        # Windows-friendly default:
        # Keep the shell open after the benchmark finishes so results/errors remain visible.
        #
        # For automated batch workflows, pass:
        #     --no-pause-at-end
        try:
            import sys
            if "--no-pause-at-end" not in sys.argv:
                input("\nPress Enter to exit...")
        except Exception:
            pass
