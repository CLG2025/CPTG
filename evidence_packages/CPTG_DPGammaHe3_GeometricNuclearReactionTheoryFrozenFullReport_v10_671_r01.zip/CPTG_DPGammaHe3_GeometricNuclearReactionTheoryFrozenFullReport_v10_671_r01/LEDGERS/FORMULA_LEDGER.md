# Formula Ledger

|id|family|formula|explanation|status_or_source|
|---|---|---|---|---|
|E01|Reaction scope|^2H + p -> ^3He + gamma|Forward deuterium-proton radiative capture channel; the locked commissioning reaction.|retained current-chain scope|
|E02|Reverse channel|^3He + gamma -> p + ^2H|Reverse photodisintegration channel linked by detailed-balance closure in the current chain.|retained current-chain scope|
|E03|CPTG native ordering|CPTG-native geometric quantity -> comparison-coordinate quantity -> reported observational quantity|Prevents comparison coordinates from becoming hidden fit parameters; all reported quantities are projections of native geometry.|authority and public status|
|E04|CPTG action schematic|S_CPTG = integral d^4x sqrt(-g)[c^4 R/(16 pi G) + L_pol + L_trans + L_m]|Schematic native action separating Einstein-Hilbert term, curvature-polarization sector, curvature-transport sector, and matter source.|theory-side schematic|
|E05|CPTG field equation schematic|G_mu_nu + Pi^pol_mu_nu + Theta^trans_mu_nu = (8 pi G/c^4) T_mu_nu|Schematic metric variation: nonlinear polarization and transport terms supplement the Einstein tensor.|theory-side schematic|
|E06|Pi branch native exponent|p_C = pi|Locked native curvature exponent used in the pi branch and BBN coordinate conversion.|locked comparison branch|
|E07|Acoustic exponent|p_ac = 3 - pi/100 = 2.968584073464|Acoustic comparison exponent used for CMB/acoustic and BBN transport conversion.|locked comparison branch|
|E08|Acoustic transport|G_T = p_ac/p_C = 0.9449296585513721|Transport factor from native pi branch to acoustic/BBN comparison coordinate.|locked comparison branch|
|E09|Square-root transport|sqrt(G_T) = 0.9720749243506758|Multiplier that converts acoustic eta10 to BBN abundance eta10.|locked comparison branch|
|E10|BBN abundance eta|eta10_BBN = eta10_ac sqrt(G_T) = 5.998071834744|Transported BBN baryon-to-photon coordinate; used by PRyMordial and AlterBBN replay.|locked BBN coordinate|
|E11|Physical eta argument|eta_BBN = eta10_BBN * 1e-10 = 5.998071834744e-10|Correct AlterBBN alter_eta.x argument; v10.668 corrected the order and units.|fresh AlterBBN closure|
|E12|Effective radiation comparison|N_eff^CPTG = p_ac = 2.968584073464|CPTG BBN/CMB radiation comparison value.|locked comparison branch|
|E13|Observed pull|Delta_X = (X_CPTG - X_obs)/sigma_X|Signed residual used for D/H, Yp, and Li7/H tests.|abundance screening|
|E14|Admissibility screen|\|Delta_X\| < 2|General 2-sigma gate for reported abundance comparisons.|abundance screening|
|E15|Background admission|\|Delta_D/H\| < 2 and \|Delta_Yp\| < 2|D/H and Yp must pass before lithium gate is judged.|abundance screening|
|E16|Surviving mass-seven definition|Y7 = Y7Li + Y7Be|Final lithium problem is treated as surviving A=7 abundance, including Be7 that later appears as Li7.|lithium authority|
|E17|Mass-seven final abundance|Y7_final = Y7_raw exp[- integral Gamma7,trans(t) dt]|General survival form for a live transport gate acting on mass-seven abundance.|lithium authority|
|E18|Locked optical depth|integral Gamma7,trans(t) dt = ln(pi)|Fixed CPTG geometric optical depth; not a fitted depletion coefficient.|authorized locked gate|
|E19|Locked survival|Y7_CPTG = Y7_raw exp[-ln(pi)] = Y7_raw/pi|Authorized survival factor for the live A=7 gate.|authorized locked gate|
|E20|Survival factor|1/pi = 0.3183098861837907|Numerical multiplier used in v10.660, v10.668, and v10.669 closure.|authorized locked gate|
|E21|Thermal gate rate|Gamma7,trans(T) = Gamma0 W7[T(t)]|Gate-shape form; the shape/support may vary as robustness control while total optical depth remains locked.|lithium authority|
|E22|Thermal gate normalization|integral Gamma0 W7[T(t)] dt = ln(pi)|Enforces fixed optical depth for any accepted thermal support/shape.|lithium authority|
|E23|Live Li7 RHS|dY_Li7/dt -> (dY_Li7/dt)_BBN - Gamma7(T) Y_Li7|Live source-network application to lithium channel.|authorized live gate|
|E24|Live Be7 RHS|dY_Be7/dt -> (dY_Be7/dt)_BBN - Gamma7(T) Y_Be7|Live source-network application to beryllium channel.|authorized live gate|
|E25|AlterBBN live indices|Y8 = Y7Li; Y9 = Y7Be|AlterBBN source patch mapping; Be7 contribution must not be double counted in final reported Li7/H.|AlterBBN implementation|
|E26|AlterBBN live RHS|dY8/dt -> dY8/dt - Gamma7(T)Y8; dY9/dt -> dY9/dt - Gamma7(T)Y9|AlterBBN live-channel equivalent of the locked A=7 RHS gate.|AlterBBN implementation|
|E27|Support count|NP3 = NP3A + NP3B = 56 + 12 = 68|Row-362 support-index count.|v10.641 current chain|
|E28|Support-slot record count|68 support indices x 4 scalar components = 272|C4 physical support-slot value ledger.|v10.641 current chain|
|E29|Coherent term count|68 support indices x 5 current/source coefficients = 340|C6 coherent source-amplitude term count.|v10.641 current chain|
|E30|Row-362 energy reconstruction|T_A3 + V_NN + V_3NF = -7.739492600000001 MeV|Energy-balance reconstruction from table-certified row-362 state.|v10.641 current chain|
|E31|Energy residual|abs((-7.739492600000001) - (-7.73945407385108)) = 0.000038526148920858816 MeV|Residual below row-specific structural-zero floor 0.00010005000000500001 MeV.|v10.641 current chain|
|E32|Coherent amplitude|A_C6 = 17.5595746398194|Retained coherent pre-rate source amplitude.|v10.641 current chain|
|E33|Source intensity|I_C7 = \|A_C6\|^2 = 308.3386615313886|C7 source-intensity operator.|v10.641 current chain|
|E34|S-factor normalization|K_S0 = S12_best(0)/I_C7 = 0.0006956636541608783 eV b|Single-observable normalization anchor.|anchored S-factor comparison|
|E35|Anchored S factor|S_CPTG(0) = K_S0 I_C7 = 0.2145 eV b|Dimensional S-factor anchor row.|anchored S-factor comparison|
|E36|LUNA residual|(0.2145 - 0.216)/0.010 = -0.15 sigma|Independent public cross-check row.|anchored S-factor comparison|
|E37|Current-chain live gate ratio|1.7118494965634585e-10 / 5.377924732128783e-10 = 0.3183104230404215|Current-chain live A=7 gate ratio; close to 1/pi.|v10.641 current chain|
|E38|PRyMordial fresh gate|5.266820229187348e-10 / pi = 1.6764809477031113e-10|v10.660 fresh PRyMordial PDF-authorized closure row.|fresh two-code closure|
|E39|AlterBBN fresh gate|5.291e-10 / pi = 1.6841776077984365e-10|v10.668 fresh local AlterBBN physical-eta closure row.|fresh two-code closure|
|E40|Progress percentage|percent = closed / total x 100|Used for strict contracts, subgates, support records, and closure accounting.|audit accounting|