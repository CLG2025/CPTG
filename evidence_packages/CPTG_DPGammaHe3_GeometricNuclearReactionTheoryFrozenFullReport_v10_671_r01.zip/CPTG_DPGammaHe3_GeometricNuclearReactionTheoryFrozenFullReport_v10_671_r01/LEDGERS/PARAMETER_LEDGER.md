# Parameter Ledger

|parameter|value|unit_or_error|explanation|
|---|---|---|---|
|reaction_id|D_P_GAMMA_HE3||Locked commissioning reaction: deuterium-proton radiative capture.|
|forward_reaction|^2H + p -> ^3He + gamma||Forward capture channel.|
|reverse_reaction|^3He + gamma -> p + ^2H||Reverse photodisintegration channel.|
|p_C|pi||Native curvature exponent.|
|p_ac|2.968584073464||Acoustic exponent, 3 - pi/100.|
|G_T|0.9449296585513721||Acoustic transport p_ac/p_C.|
|sqrt_G_T|0.9720749243506758||BBN eta transport factor.|
|eta10_ac|6.170380167710||Acoustic/CMB baryon-to-photon coordinate.|
|eta10_BBN|5.998071834744||Transported BBN abundance coordinate.|
|eta_BBN_argument|5.998071834744e-10||AlterBBN alter_eta.x physical eta argument.|
|Omega_b_h2_BBN|0.021898765370||Transport-scaled BBN physical baryon density coordinate.|
|N_eff_CPTG|2.968584073464||Effective radiation comparison value.|
|D/H_obs|25.08e-6|sigma=0.29e-6|Deuterium observational anchor used in abundance comparisons.|
|Yp_obs|0.245|sigma=0.003|Helium mass-fraction observational anchor.|
|Li7/H_obs|1.45e-10|sigma=0.25e-10|Lithium observational anchor.|
|He3/H_upper|1.1e-5|upper limit/advisory|He3 advisory upper-limit row used in fresh closure.|
|NUCWF_row_index|362||Retained A=3 state row.|
|row362_hashname|4faa3edcfbff73257c73efade1c5e1dacab105fad4148eecb3d982919213a5e6||Row-362 hashname.|
|NORM|0.99993||Row-362 state norm.|
|NP3|68||Support indices.|
|support_slot_records|272||68 support indices x 4 scalar components.|
|amplitude_terms|340||68 support indices x 5 coefficients.|
|T_A3|27.0897|MeV|Row-362 kinetic component.|
|V_NN|-34.8757|MeV|Native A=3 NN potential component.|
|V_3NF|0.0465074|MeV|TNFME/3NF component.|
|E_table|-7.73945407385108|MeV|Table-certified energy row.|
|energy_reconstruction|-7.739492600000001|MeV|T + V_NN + V_3NF.|
|energy_abs_residual|0.000038526148920858816|MeV|Below structural-zero floor.|
|structural_zero_floor|0.00010005000000500001|MeV|Row-specific pass threshold.|
|c1|-1.23|GeV^-1|Current/source coefficient.|
|c3|-4.65|GeV^-1|Current/source coefficient.|
|c4|3.28|GeV^-1|Current/source coefficient.|
|cD|0.8918|dimensionless|Current/source coefficient.|
|cE|-0.38595|dimensionless|Current/source coefficient.|
|A_C6|17.5595746398194||Coherent pre-rate source amplitude.|
|I_C7|308.3386615313886||Source intensity \|A_C6\|^2.|
|S12_best_0_anchor|0.2145|eV b|S-factor normalization anchor.|
|K_S0|0.0006956636541608783|eV b per dimensionless intensity|Dimensional conversion from C7 intensity to S-factor.|
|LUNA_S12_0|0.216 ± 0.010|eV b|Independent cross-check row.|
|solar_Gamow_E0|6.64|keV|Solar Gamow benchmark energy.|
|S12_E0_CPTG|0.25163174176576003|eV b|Transported S12(E0) benchmark row.|
|PRIMAT_payloads|13/13||Source-required small MT payloads closed.|
|current_chain_raw_D/H|2.4794272036813933e-05||Raw current-chain abundance before live A=7 gate.|
|current_chain_raw_He3/H|1.0199932320844196e-05||Raw current-chain abundance before live A=7 gate.|
|current_chain_raw_Yp|2.4699580513634747e-01||Raw current-chain abundance before live A=7 gate.|
|current_chain_raw_Li7/H|5.3779247321287830e-10||Raw current-chain abundance before live A=7 gate.|
|current_chain_live_gated_Li7/H|1.7118494965634585e-10||Current-chain locked live A=7 gate output.|
|current_chain_live_raw_ratio|0.3183104230404215||Current-chain live/raw ratio.|
|target_survival|0.3183098861837907||1/pi.|
|PRyMordial_raw_Li7/H|5.266820229187348e-10||Fresh PRyMordial raw A=7 row.|
|PRyMordial_gated_Li7/H|1.6764809477031113e-10||Fresh PRyMordial after 1/pi gate.|
|PRyMordial_Li_pull|0.9059237908124455|sigma|Fresh PRyMordial pass.|
|AlterBBN_row|correct_physical_eta_cptg_bbn_failsafe1||Canonical fresh local AlterBBN row.|
|AlterBBN_raw_D/H|2.5e-05||Fresh AlterBBN physical-eta replay.|
|AlterBBN_D_pull|-0.27586206896551463|sigma|Fresh AlterBBN D/H residual.|
|AlterBBN_Yp|0.2471||Fresh AlterBBN physical-eta replay.|
|AlterBBN_Yp_pull|0.699999999999997|sigma|Fresh AlterBBN Yp residual.|
|AlterBBN_He3/H|1.041e-05||Fresh AlterBBN physical-eta replay.|
|AlterBBN_raw_Li7/H|5.291e-10||Fresh AlterBBN raw lithium.|
|AlterBBN_gated_Li7/H|1.6841776077984365e-10||Fresh AlterBBN after 1/pi gate.|
|AlterBBN_Li_pull|0.9367104311937463|sigma|Fresh AlterBBN pass.|