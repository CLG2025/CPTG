# CPTG D(p,gamma)He3 Geometric Nuclear Reaction Theory Freeze Package v10.671 r01

This archive freezes the current testing lane and compiles the full report, formulas, parameter ledger, and auditable evidence chain.

Primary report:

- `REPORTS/CPTG_Geometric_Nuclear_Reaction_Theory_Frozen_Full_Report_v10_671_r01.pdf`
- `REPORTS/CPTG_Geometric_Nuclear_Reaction_Theory_Frozen_Full_Report_v10_671_r01.docx`
- `REPORTS/CPTG_Geometric_Nuclear_Reaction_Theory_Frozen_Full_Report_v10_671_r01.md`

Machine-readable ledgers:

- `LEDGERS/FORMULA_LEDGER.csv`
- `LEDGERS/PARAMETER_LEDGER.csv`
- `LEDGERS/TIMELINE_AND_DECISION_LEDGER.csv`
- `LEDGERS/EVIDENCE_PACKAGE_AUDIT.csv`
- `LEDGERS/SOURCE_PACKAGE_AUDIT.csv`
- `LEDGERS/AUTHORITY_AND_INPUT_FILES.csv`
- `LEDGERS/FROZEN_RESULTS_SUMMARY.json`

Frozen state:

```text
Retained integrated current-chain frontier: v10.641 / C7BP
Fresh PRyMordial/PDF-authorized locked A=7 gate: v10.660 / C7CG PASS
Fresh local AlterBBN physical-eta locked A=7 gate: v10.668 / C7CO PASS
Fresh two-code locked-gate reconciliation: v10.669 / C7CP CLOSED
Complete report/handoff baseline: v10.670 / C7CQ READY
This freeze package: v10.671 / r01
```

Do not rerun v10.659 or v10.662. They are superseded.
