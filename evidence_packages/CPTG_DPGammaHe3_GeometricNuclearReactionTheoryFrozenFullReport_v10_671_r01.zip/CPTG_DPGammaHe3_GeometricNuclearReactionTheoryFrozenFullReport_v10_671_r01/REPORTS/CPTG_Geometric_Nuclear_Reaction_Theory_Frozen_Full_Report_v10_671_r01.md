---
title: "CPTG Geometric Nuclear Reaction Theory Freeze Report"
subtitle: "D(p,gamma)He3 source-to-amplitude, S-factor, BBN, and locked A=7 two-code closure evidence package"
author: "Compiled for Carter L. Glass Jr."
date: "2026-07-06"
geometry: margin=0.75in
fontsize: 10pt
---

# 1. Freeze declaration

Testing is frozen for the current geometric nuclear reaction lane. The frozen scope is the audit-first CPTG chain that carries the locked `D_P_GAMMA_HE3` reaction through source/state closure, a coherent source amplitude, anchored S-factor comparison, native `p + D -> He3 + gamma` rate integration, PRIMAT-compatible BBN/current-chain evidence, and the locked live A=7 abundance gate. The fresh PRyMordial and fresh local AlterBBN replay lane is closed, and the v10.670 report/handoff baseline is accepted as the current freeze point.

This freeze does **not** claim that every conceivable future CPTG test is finished. It means the current blocker-clearing lane is complete and should not be reopened unless a future project deliberately expands the theory, data coverage, or code environments.

|Item|Frozen state|Meaning|
|---|---|---|
|Testing freeze|FROZEN for current lane|No additional validation scripts are required for the current source-to-amplitude, S-factor, BBN, locked A=7, fresh two-code closure chain.|
|Retained integrated frontier|v10.641 / C7BP|Integrated PRIMAT-compatible current-chain frontier retained and not overwritten.|
|Fresh PRyMordial closure|v10.660 / C7CG PASS|Literal PDF-authorized 1/pi locked A=7 gate applied to fresh PRyMordial canonical row.|
|Fresh AlterBBN closure|v10.668 / C7CO PASS|Correct physical eta replay with alter_eta.x and failsafe=1; locked 1/pi gate passes.|
|Two-code reconciliation|v10.669 / C7CP CLOSED|Fresh PRyMordial and fresh local AlterBBN closure reconciled.|
|Report/handoff baseline|v10.670 / C7CQ READY|Complete evidence report and AI handoff verified.|
|Current report package|v10.671 / r01|This freeze package compiles the full theory report, equations, parameters, and audit ledgers.|

# 2. Executive conclusion

The frozen result is a combined evidence chain, not a single isolated numerical coincidence. The retained integrated current-chain frontier is `v10.641 / C7BP`. The fresh two-code locked A=7 gate closure is `v10.669 / C7CP`. The verified report and AI handoff baseline is `v10.670 / C7CQ`. This package, `v10.671 / r01`, compiles the frozen theory report and audit archive.

The central nuclear-reaction mission is:

```text
^2H + p -> ^3He + gamma
^3He + gamma -> p + ^2H
```

The nuclear chain establishes a source-to-amplitude and anchored S-factor path for the D(p,gamma)He3 reaction. The abundance lane then uses the transported CPTG BBN coordinate and the locked live A=7 transport gate. The A=7 gate is not fitted: its optical depth is fixed to `ln(pi)` and its survival factor is exactly `1/pi`.

The fresh two-code closure table is:

|Code/lane|Canonical row|D/H pull|Yp pull|Raw Li7/H|After 1/pi|Li pull|Status|
|---|---|---|---|---|---|---|---|
|PRyMordial|transport_sqrtGT_large_PRIMAT|-0.019 sigma|+0.231 sigma|5.266820229187348e-10|1.6764809477031113e-10|0.9059 sigma|PASS|
|AlterBBN|correct_physical_eta_cptg_bbn_failsafe1|-0.2759 sigma|+0.7000 sigma|5.291e-10|1.6841776077984365e-10|0.9367 sigma|PASS|

# 3. Claim boundary

The frozen claim has four layers.

1. **Retained integrated current-chain claim.** v10.641 / C7BP remains the retained integrated PRIMAT-compatible current-chain frontier. It covers the source-to-amplitude chain, anchored S-factor comparison, native p+D rate branch, PRIMAT-compatible BBN integration, live A=7 RHS gate, structured support scan, randomized support/width MC preflight, and reference two-code crosswalk.
2. **Fresh PRyMordial claim.** v10.660 / C7CG closes the fresh PRyMordial/PDF-authorized locked-gate lane by applying only the literal `tau7 = ln(pi)`, `1/pi` formula to the canonical fresh PRyMordial row.
3. **Fresh local AlterBBN claim.** v10.668 / C7CO closes the fresh local AlterBBN lane using `alter_eta.x 5.9980718347440000E-10 1`, where the first argument is physical eta, not raw eta10, and the second argument is `failsafe=1`.
4. **Reconciliation claim.** v10.669 / C7CP reconciles the fresh two-code evidence without overwriting v10.641 / C7BP.

The frozen claim does **not** convert diagnostic coefficient near-matches into authorized formulas. v10.658 found numerical near candidates but no authorized closure candidate. The later closure is authorized only by the literal mass-seven transport gate from the CPTG lithium authority.

# 4. Theory architecture

## 4.1 Native-to-comparison ordering

CPTG uses a strict ordering:

```text
CPTG-native geometric quantity
-> comparison-coordinate quantity
-> reported observational quantity
```

For primordial abundances, the ordering is:

```text
native curvature transport
-> transported BBN abundance coordinate
-> live lithium source-network gate
-> observed light-element abundances
```

This is important because the lithium step is not a post-hoc abundance division in the frozen claim. The authorized form is a live source-network gate acting on the A=7 channels. The report also retains the comparison-layer distinction: external BBN codes and source packages are replay environments and comparison layers, not new CPTG branch parameters.

## 4.2 Schematic native field structure

The schematic CPTG action retained in the authority papers is:


```text
S_{{\rm CPTG}} = \int d^4x\,\sqrt{{-g}}\left[\frac{{c^4}}{{16\pi G}}R + L_{{\rm pol}} + L_{{\rm trans}} + L_m\right].
```


The schematic metric field equation is:


```text
G_{{\mu\nu}} + \Pi^{{\rm pol}}_{{\mu\nu}} + \Theta^{{\rm trans}}_{{\mu\nu}} = \frac{{8\pi G}}{{c^4}}T_{{\mu\nu}}.
```


Here `L_pol` and `Pi^pol` represent curvature polarization, while `L_trans` and `Theta^trans` represent curvature transport. The nuclear/abundance work is a reduced channel of this structure.

# 5. Locked pi-branch BBN coordinate

The frozen BBN coordinate is transported from the acoustic/CMB coordinate. The retained formulas are:


```text
p_C = \pi.
```



```text
p_{{\rm ac}} = 3 - \frac{{\pi}}{{100}} = 2.968584073464.
```



```text
G_T = \frac{{p_{{\rm ac}}}}{{p_C}} = 0.9449296585513721.
```



```text
\sqrt{{G_T}} = 0.9720749243506758.
```



```text
\eta^{{\rm BBN}}_{{10}} = \eta^{{\rm ac}}_{{10}}\sqrt{{G_T}} = 5.998071834744.
```



```text
\Omega_b h^2_{{\rm BBN}} = 0.021898765370.
```



```text
N^{{\rm CPTG}}_{{\rm eff}} = p_{{\rm ac}} = 2.968584073464.
```


The fresh AlterBBN closure uses the physical eta argument, not raw eta10:


```text
\eta_{{\rm BBN}} = \eta^{{\rm BBN}}_{{10}} \times 10^{{-10}} = 5.998071834744\times 10^{{-10}}.
```


This correction matters. v10.667 had identified the correct `alter_eta.x` route but passed the arguments incorrectly. v10.668 corrected both the argument order and the units.

# 6. Reaction-specific nuclear chain

## 6.1 Reaction scope lock

The reaction is locked to deuterium-proton radiative capture and its reverse channel:


```text
^2{\rm H} + p \rightarrow ^3{\rm He} + \gamma.
```



```text
^3{\rm He} + \gamma \rightarrow p + ^2{\rm H}.
```


This scope is a commissioning/validation scope lock. It does not imply that all nuclear reactions have been reduced to CPTG yet.

## 6.2 Row-362 A=3 state

The retained A=3 state used for the source-to-amplitude chain is row 362:

```text
NUCWF row index: 362
hashname: 4faa3edcfbff73257c73efade1c5e1dacab105fad4148eecb3d982919213a5e6
NORM: 0.99993
NP3 support indices: 68
support-slot scalar records: 68 x 4 = 272
amplitude terms: 68 x 5 = 340
```

The row-specific energy-balance check is:


```text
T_{{A3}} = 27.0897\, {\rm MeV}.
```



```text
V_{{NN}} = -34.8757\, {\rm MeV}.
```



```text
V_{{3NF}} = 0.0465074\, {\rm MeV}.
```



```text
E_{{\rm table}} = -7.73945407385108\, {\rm MeV}.
```



```text
T_{{A3}} + V_{{NN}} + V_{{3NF}} = -7.739492600000001\, {\rm MeV}.
```



```text
|\Delta E| = 0.000038526148920858816\, {\rm MeV}.
```


The residual is below the row-specific structural-zero floor:


```text
0.000038526148920858816 < 0.00010005000000500001.
```


Therefore the row-362 energy-balance check is retained as `PASS`.

## 6.3 Source/state support contracts

The retained source-contract chain includes the native bound-state and continuum-state handling for `D_P_GAMMA_HE3`, the accepted 96 x 96 auxiliary/common-support grid and interpolation stencils, the 99-anchor radial six-map expansion, sparse six-map pullback/adjoint transport, global affine support registry of 272 nodes, active operator-support union of 199 nodes, exact production pp 1S0 matrices at 1, 5, 10, and 25 MeV, verified 104-matrix pp/np/nn production-grid ledger, TNFME/3NF executable backend evidence, LMAX13 recoupling and factorized 3NF backend replay, table-certified A=3 bound-state evidence, and five current/source coefficients.

The verified production-grid charge-sector ledger is:

```text
np: 48 matrices
pp: 28 matrices
nn: 28 matrices
total: 104 matrices
```

The accepted matrix set contains:

```text
single-channel matrices: 72 at 81 x 81
coupled-channel matrices: 32 at 162 x 162
```

The NN source-ledger support projection remains closed: 96 of 104 source-ledger rows project to native A=3 NN support. The eight accounted source-extra rows are `np 1P1` and `np 1F3` at 1, 5, 10, and 25 MeV.

# 7. C4-C7 source-to-S-factor chain

## 7.1 Support-slot values

The C4 support-slot value ledger is:


```text
NP3 = NP3A + NP3B = 56 + 12 = 68.
```



```text
N_{{\rm support-slot}} = 68 \times 4 = 272.
```


The four scalar components are:

```text
T_A3_mev = 27.0897
V_NN_native_A3_mev = -34.8757
V_TNFME_or_3NF_native_A3_mev = 0.0465074
binding_energy_candidate_mev = 7.73945407385108
```

## 7.2 Current/source coefficients

The retained C5 current/source coefficient ledger is:

```text
c1 = -1.23     GeV^-1
c3 = -4.65     GeV^-1
c4 =  3.28     GeV^-1
cD =  0.8918   dimensionless
cE = -0.38595  dimensionless
```

There are five physical current/source coefficients, and the physical coefficient gate is closed as `5/5 = 100%`.

## 7.3 Coherent source amplitude

The coherent pre-rate source amplitude is:


```text
A_{{C6}} = 17.5595746398194.
```


The number of coherent terms is:


```text
68 \times 5 = 340.
```


The C7a source-intensity operator is:


```text
I_{{C7}} = |A_{{C6}}|^2 = 308.3386615313886.
```


## 7.4 Anchored S-factor comparison

The dimensional S-factor comparison uses a single-observable anchor:


```text
S_{{12,{\rm best}}}(0) = 0.2145\, {\rm eV\,b}.
```



```text
K_{{S0}} = \frac{{S_{{12,{\rm best}}}(0)}}{{I_{{C7}}}} = 0.0006956636541608783\, {\rm eV\,b}.
```



```text
S_{{\rm CPTG}}(0) = K_{{S0}} I_{{C7}} = 0.2145\, {\rm eV\,b}.
```


The independent LUNA row is:


```text
\Delta_{{\rm LUNA}} = \frac{{0.2145 - 0.216}}{{0.010}} = -0.15\sigma.
```


The solar Gamow benchmark row is:

```text
E0 = 6.64 keV
S12(E0)_CPTG = 0.25163174176576003 eV b
status: PASS within stated benchmark band
```

This is an anchored comparison. The anchor fixes the dimensional scale. The LUNA and solar Gamow rows are cross-checks, not free refits.

# 8. C7 rate and BBN current chain

The retained C7 chain extends beyond S-factor-only closure. It carries the native CPTG p+D rate branch into the PRIMAT-compatible BBN current chain. The source-required PRIMAT small MT payloads are closed as `13/13 = 100%`. Forward/reverse table-backed closures, temperature-domain blockers, physical initial-vector authority, HT weak-only seed propagation, MT Saha/NSE seed, MT-to-LT seed, LT raw final vector, and observed abundance comparison are all retained as closed in the current chain.

The raw current-chain abundance projection before the live A=7 gate is:

```text
D/H     = 2.4794272036813933e-05
He3/H   = 1.0199932320844196e-05
Yp_BBN  = 2.4699580513634747e-01
Li7/H   = 5.3779247321287830e-10
```

The raw lithium row reproduces the standard BBN mass-seven excess. It is not treated as a failure of the D(p,gamma)He3 source chain; it is the target of the locked live A=7 transport-gate test.

# 9. Locked live A=7 transport gate

## 9.1 Definition of the surviving A=7 channel

The surviving A=7 abundance is:


```text
Y_7 = Y_{{^7{\rm Li}}} + Y_{{^7{\rm Be}}}.
```


This is necessary because much of final primordial lithium is carried through Be7 during the nuclear epoch and appears later as Li7 after electron capture.

## 9.2 Locked gate relation

The general survival relation is:


```text
Y_{{7,{\rm final}}} = Y_{{7,{\rm raw}}}\exp\left[-\int \Gamma_{{7,{\rm trans}}}(t)\,dt\right].
```


The CPTG optical-depth condition is locked:


```text
\int \Gamma_{{7,{\rm trans}}}(t)\,dt = \ln \pi.
```


Therefore:


```text
Y_{{7,{\rm CPTG}}} = Y_{{7,{\rm raw}}} e^{{-\ln\pi}} = \frac{{Y_{{7,{\rm raw}}}}}{{\pi}}.
```


The survival factor is:


```text
\frac{{1}}{{\pi}} = 0.3183098861837907.
```


The report records this as an authorized formula, not a numerical near-match.

## 9.3 Thermal support form

For a thermal gate, the transport rate is written:


```text
\Gamma_{{7,{\rm trans}}}(T) = \Gamma_0 W_7[T(t)].
```


The normalization is always locked:


```text
\int \Gamma_0 W_7[T(t)]\,dt = \ln \pi.
```


Gate shape and thermal support may be varied as robustness controls. The integrated optical depth is not fitted.

## 9.4 Live source-network RHS implementation

The live Li7 channel is evolved as:


```text
\frac{{dY_{{^7{\rm Li}}}}}{{dt}} \rightarrow \left(\frac{{dY_{{^7{\rm Li}}}}}{{dt}}\right)_{{\rm BBN}} - \Gamma_7(T)Y_{{^7{\rm Li}}}.
```


The live Be7 channel is evolved as:


```text
\frac{{dY_{{^7{\rm Be}}}}}{{dt}} \rightarrow \left(\frac{{dY_{{^7{\rm Be}}}}}{{dt}}\right)_{{\rm BBN}} - \Gamma_7(T)Y_{{^7{\rm Be}}}.
```


For AlterBBN source-patch notation:


```text
Y_8 = Y_{{^7{\rm Li}}}, \quad Y_9 = Y_{{^7{\rm Be}}}.
```



```text
\frac{{dY_8}}{{dt}} \rightarrow \frac{{dY_8}}{{dt}} - \Gamma_7(T)Y_8.
```



```text
\frac{{dY_9}}{{dt}} \rightarrow \frac{{dY_9}}{{dt}} - \Gamma_7(T)Y_9.
```


AlterBBN reports final mass-seven lithium through its own convention; the Be7 diagnostic column is not added a second time.

# 10. Observed comparison rules

For each observable:


```text
\Delta_X = \frac{{X_{{\rm CPTG}} - X_{{\rm obs}}}}{{\sigma_X}}.
```


The abundance screening gate is:


```text
|\Delta_X| < 2.
```


The background is admitted only if:


```text
|\Delta_{{D/H}}| < 2, \quad |\Delta_{{Y_p}}| < 2.
```


Lithium is judged only after D/H and Yp admission, because raw lithium excess is the target of the A=7 gate. The locked-gate lithium test is:


```text
|\Delta_{{^7{\rm Li}/H}}| < 2.
```


The observational anchors used in this freeze are:

```text
D/H_obs    = (25.08 +/- 0.29) x 10^-6
Yp_obs     = 0.245 +/- 0.003
Li7/H_obs  = (1.45 +/- 0.25) x 10^-10
He3/H upper/advisory row = 1.1 x 10^-5
```

# 11. Current-chain live-gate outcome

The retained current-chain live-gate implementation gives:

```text
raw-parent Li7/H = 5.377924732128783e-10
live-gated Li7/H = 1.7118494965634585e-10
live/raw ratio = 0.3183104230404215
target 1/pi = 0.3183098861837907
```

The structured and randomized current-chain support checks give:

```text
structured live-gate scenarios: 10/10 pass
randomized live-gate support/width MC: 12/12 pass
Li7/H randomized range: 1.7118266510084370e-10 to 1.7121051910835793e-10
Li sigma randomized range: +1.04730660403 to +1.04842076433
D/H sigma randomized range: -0.98526877172 to -0.98478538709
Yp sigma randomized range: +0.665269188026 to +0.665272107275
He3/H: advisory upper-limit pass in all samples
max tau error vs ln(pi): 3.552713678800501e-15
```

# 12. Fresh PRyMordial replay lane

The fresh PRyMordial lane began by binding the preferred Python interpreter and the known local PRyMordial roots. v10.654 found the preferred interpreter and two known roots. v10.655 captured the source snapshot and executed local scripts, but the first parser under-credited the canonical CSV. v10.656 corrected the parser and closed D/H plus Yp while leaving lithium open. v10.657 isolated the mass-seven residual. v10.658 refused unauthorized numerical near-matches. v10.660 then used the literal PDF authority for `tau7 = ln(pi)` and `1/pi`.

The canonical v10.660 result is:

```text
row: transport_sqrtGT_large_PRIMAT
raw Li7/H = 5.266820229187348e-10
survival factor = 1/pi = 0.3183098861837907
gated Li7/H = 1.6764809477031113e-10
observed Li7/H = 1.45e-10
sigma = 0.25e-10
pull = +0.9059237908124455 sigma
status: PASS
```

The D/H and Yp controls retained from the canonical PRyMordial CSV row are:

```text
D/H = 2.5074383114428336e-05, pull = -0.019 sigma
Yp = 0.24569433819526384, pull = +0.231 sigma
He3/H = 1.0489348718552855e-05, advisory upper-limit PASS
```

# 13. Fresh local AlterBBN replay lane

The initial explicit-root probe v10.662 did not know the exact local path. The user supplied:

```python
DEFAULT_ROOT = Path(r"D:\Downloads\alterbbn_v2.2\alterbbn_v2.2")
```

v10.663 found the source root. v10.664 found source/build files but no build tools in that run. v10.665 resolved `gcc` and `make`, built `stand_cosmo.x`, and reached replay-not-parsed. v10.666 parsed a stand_cosmo route but was corrected because `stand_cosmo.x argv[1]` is `failsafe`, not eta. v10.667 found the `alter_eta.x` route but passed arguments in the wrong order and units. v10.668 corrected the command shape.

The correct command semantics are:

```text
alter_eta.x <eta baryon-to-photon ratio> <failsafe>
eta10_BBN = 5.998071834744
eta argument = eta10_BBN * 1e-10 = 5.9980718347440000E-10
failsafe = 1
```

The canonical v10.668 row is:

```text
row: correct_physical_eta_cptg_bbn_failsafe1
command: alter_eta.x 5.9980718347440000E-10 1
D/H = 2.500e-05, pull = -0.27586206896551463 sigma
Yp = 0.2471, pull = +0.699999999999997 sigma
He3/H = 1.041e-05, advisory upper-limit PASS
raw Li7/H = 5.291e-10
Li7/H after 1/pi = 1.6841776077984365e-10
Li7 pull after gate = +0.9367104311937463 sigma
status: PASS
```

# 14. Fresh two-code closure reconciliation

v10.669 reconciles the v10.660 PRyMordial lane and v10.668 AlterBBN lane. It does not rerun the full integrated current chain and does not overwrite v10.641. It verifies that both fresh code lanes pass the locked A=7 gate using the same `1/pi` survival factor.

The reconciliation state is:

```text
v10.660 state: C7CG_LITERAL_PDF_AUTHORITY_AUTHORIZES_LOCKED_MASS7_GATE_FASTPATH_PASS
v10.668 state: C7CO_FRESH_ALTERBBN_CORRECT_PHYSICAL_ETA_REPLAY_LOCKED_GATE_PASS
canonical AlterBBN row: correct_physical_eta_cptg_bbn_failsafe1
fresh PRyMordial locked gate pass: true
fresh AlterBBN locked gate pass: true
claim boundary: does not overwrite v10.641/C7BP
```

# 15. Progress accounting

|Metric|Closed|Total|Percent|
|---|---|---|---|
|Strict physical contracts|6|6|100%|
|Evidentiary subgates|27|27|100%|
|C2.4 action elements|10|10|100%|
|Native/all-anchor angular row pairs|9,504|9,504|100%|
|Support-explicit six-map records|114,048|114,048|100%|
|Exact exchange reconstruction links|57,024|57,024|100%|
|Support-slot physical values|272|272|100%|
|Physical current/source coefficients|5|5|100%|

The final status line is:

```text
Fresh PRyMordial replay: CLOSED
Fresh AlterBBN replay: CLOSED
Fresh two-code locked A=7 gate: CLOSED
Retained integrated PRIMAT-compatible current-chain frontier: v10.641 / C7BP retained, not overwritten
Current report/handoff frontier: v10.670 / C7CQ
Current freeze report package: v10.671 / r01
```

# 16. Evidence-chain timeline

|Version|Decision/status|Role|
|---|---|---|
|v10.641 / C7BP|RETAINED_INTEGRATED_PRIMAT_COMPATIBLE_CURRENT_CHAIN_FRONTIER|Retained integrated PRIMAT-compatible current-chain frontier from public status; not overwritten by later fresh two-code lane.|
|v10.654|C7CA_PREFERRED_PRYMORDIAL_IMPORT_BOUND_NEXT_REPLAY_READY|Preferred Python and PRyMordial known-root binding established.|
|v10.655|C7CB_PRYMORDIAL_KNOWN_ROOT_SCRIPTS_EXECUTED_UNPARSED_SOURCE_SNAPSHOT_READY|PRyMordial known-root source snapshot and local script execution; generic parser under-credited result.|
|v10.656|C7CC_FRESH_PRYMORDIAL_TRANSPORT_DH_YP_PASS_LI7_LIVE_GATE_OPEN|Canonical PRyMordial CSV parser closed D/H + Yp transport gate; Li/mass-seven still open.|
|v10.657|C7CD_MASS7_RESIDUAL_ISOLATED_REQUIRED_SUPPRESSION_NOT_AUTHORIZED|Isolated mass-seven residual and proved eta-retuning path inadmissible.|
|v10.658|C7CE_NATIVE_MASS7_NEAR_CANDIDATES_FOUND_NOT_AUTHORIZED|Audited numerical near-candidates; zero authorized closure candidates.|
|v10.659 / C7CF|ABORTED_BY_USER_SUPERSEDED_BY_V10_660|Broad source locator aborted/superseded; do not rerun.|
|v10.660|C7CG_LITERAL_PDF_AUTHORITY_AUTHORIZES_LOCKED_MASS7_GATE_FASTPATH_PASS|Fast literal PDF authority applied; PRyMordial locked 1/pi gate pass.|
|v10.661|C7CH_PUBLIC_STATUS_FRONTIER_RECONCILED_V10_660_FASTPATH_LOCKED_MASS7_AUTHORITY_RETAINED|Frontier reconciliation; retained v10.641 integrated chain while keeping v10.660 fastpath closure.|
|v10.662|C7CI_ALTERBBN_LOCAL_ROOT_NOT_FOUND_EXPLICIT_PATH_REQUIRED_REFERENCE_TWO_CODE_RETAINED|Superseded explicit-root probe that missed exact AlterBBN default root.|
|v10.663|C7CJ_ALTERBBN_DEFAULT_ROOT_SOURCE_FOUND_BUILD_REPLAY_NEXT|Exact AlterBBN DEFAULT_ROOT found: D:\Downloads\alterbbn_v2.2\alterbbn_v2.2.|
|v10.664|C7CK_ALTERBBN_SOURCE_FOUND_BUILD_TOOL_NOT_FOUND|AlterBBN source found; build tools not found in this run.|
|v10.665|C7CL_ALTERBBN_BUILD_SUCCEEDED_REPLAY_NOT_PARSED_REVIEW_REQUIRED|Compiler/make resolved; build succeeded; replay still unparsed.|
|v10.666|C7CM_FRESH_ALTERBBN_REPLAY_PARSED_LOCKED_GATE_COMPARISON_READY|stand_cosmo path parsed but later identified as wrong argv semantics for eta.|
|v10.667|C7CN_FRESH_ALTERBBN_ALTER_ETA_PARSED_LOCKED_GATE_NOT_CLOSED_REVIEW_REQUIRED|alter_eta route found but argument order/units wrong; eta=0 diagnostic failure.|
|v10.668|C7CO_FRESH_ALTERBBN_CORRECT_PHYSICAL_ETA_REPLAY_LOCKED_GATE_PASS|Correct alter_eta physical eta replay; fresh local AlterBBN locked gate pass.|
|v10.669|C7CP_FRESH_PRYMORDIAL_AND_ALTERBBN_LOCKED_GATE_TWO_CODE_CLOSURE_RECONCILED|Fresh PRyMordial + AlterBBN two-code locked-gate reconciliation closed.|
|v10.670|C7CQ_COMPLETE_FRESH_TWO_CODE_CLOSURE_EVIDENCE_REPORT_AND_HANDOFF_READY|Complete evidence-chain report and AI handoff baseline verified.|

# 17. Superseded and forbidden reruns

The following packages are explicitly superseded:

```text
v10.659 broad locator: aborted/superseded; do not rerun.
v10.662 explicit-root probe: superseded by v10.663 exact DEFAULT_ROOT check; do not rerun.
```

The following interpretive errors are forbidden:

```text
Do not use v10.666 stand_cosmo parsed rows as eta replay closure rows.
Do not use v10.667 eta=0 rows as physical abundance results.
Do not elevate v10.658 numerical near-matches to authorized CPTG formulas.
Do not treat v10.660/v10.668 fresh two-code closure as overwriting the retained integrated v10.641 current chain.
Do not double-count Be7 in AlterBBN final Li7/H when the code's report convention already carries Be7 into final Li7/H.
```

# 18. Revisit protocol

To revisit the frozen result later:

1. Start with this package: `CPTG_DPGammaHe3_GeometricNuclearReactionTheoryFrozenFullReport_v10_671_r01.zip`.
2. Open `LEDGERS/FREEZE_PACKAGE_SHA256_MANIFEST.csv` and verify all embedded files.
3. Use `LEDGERS/EVIDENCE_PACKAGE_AUDIT.csv` to verify the included user-run output ZIPs from v10.654-v10.670.
4. Use `LEDGERS/SOURCE_PACKAGE_AUDIT.csv` if source-package reconstruction is needed.
5. Read `REPORTS/CPTG_Geometric_Nuclear_Reaction_Theory_Frozen_Full_Report_v10_671_r01.md` first.
6. Use `LEDGERS/FORMULA_LEDGER.csv` and `LEDGERS/PARAMETER_LEDGER.csv` as the authoritative quick-reference equation/parameter tables.
7. Use `EVIDENCE_OUTPUT_ZIPS/CPTG_v10_670_outputs_r01.zip` and its internal `OUTPUTS/` files to reproduce the immediate handoff baseline.
8. Do not rerun superseded v10.659 or v10.662. If new testing is ever resumed, begin as a new expansion lane from this frozen state, not as a repair to this lane.

# 19. File map for this freeze package

```text
REPORTS/
  CPTG_Geometric_Nuclear_Reaction_Theory_Frozen_Full_Report_v10_671_r01.md
  CPTG_Geometric_Nuclear_Reaction_Theory_Frozen_Full_Report_v10_671_r01.docx
  CPTG_Geometric_Nuclear_Reaction_Theory_Frozen_Full_Report_v10_671_r01.pdf
LEDGERS/
  FORMULA_LEDGER.csv
  PARAMETER_LEDGER.csv
  TIMELINE_AND_DECISION_LEDGER.csv
  EVIDENCE_PACKAGE_AUDIT.csv
  SOURCE_PACKAGE_AUDIT.csv
  AUTHORITY_AND_INPUT_FILES.csv
  FROZEN_RESULTS_SUMMARY.json
AUTHORITY/
  uploaded CPTG lithium, pi-branch, and unified-framework authority PDFs
INPUT_STATUS/
  public status text, README baseline, README update diff
EVIDENCE_OUTPUT_ZIPS/
  user-run output ZIPs v10.654 through v10.670 where present
EVIDENCE_SOURCE_PACKAGES/
  source packages v10.654 through v10.670
```

# 20. Final frozen statement

The current geometric nuclear reaction theory lane is frozen as follows:

```text
Retained integrated current-chain frontier: v10.641 / C7BP
Fresh PRyMordial/PDF-authorized locked A=7 gate: v10.660 / C7CG PASS
Fresh local AlterBBN physical-eta locked A=7 gate: v10.668 / C7CO PASS
Fresh two-code locked-gate reconciliation: v10.669 / C7CP CLOSED
Complete evidence report/handoff baseline: v10.670 / C7CQ READY
Frozen full theory report package: v10.671 / r01
```

Within this frozen lane, there is no remaining validation script to run. Future work would be expansion work, such as broader eta/rate sampling, additional network replay environments, wider reaction coverage, or manuscript consolidation. It should not be treated as required blocker-clearing for the frozen v10.641-v10.670 chain.

# Appendix A. Full formula ledger

See `LEDGERS/FORMULA_LEDGER.csv` for the machine-readable equation list. The same ledger is reproduced below for readability.


**E01. Reaction scope**  
Formula: `^2H + p -> ^3He + gamma`  
Explanation: Forward deuterium-proton radiative capture channel; the locked commissioning reaction.  
Status/source: retained current-chain scope.

**E02. Reverse channel**  
Formula: `^3He + gamma -> p + ^2H`  
Explanation: Reverse photodisintegration channel linked by detailed-balance closure in the current chain.  
Status/source: retained current-chain scope.

**E03. CPTG native ordering**  
Formula: `CPTG-native geometric quantity -> comparison-coordinate quantity -> reported observational quantity`  
Explanation: Prevents comparison coordinates from becoming hidden fit parameters; all reported quantities are projections of native geometry.  
Status/source: authority and public status.

**E04. CPTG action schematic**  
Formula: `S_CPTG = integral d^4x sqrt(-g)[c^4 R/(16 pi G) + L_pol + L_trans + L_m]`  
Explanation: Schematic native action separating Einstein-Hilbert term, curvature-polarization sector, curvature-transport sector, and matter source.  
Status/source: theory-side schematic.

**E05. CPTG field equation schematic**  
Formula: `G_mu_nu + Pi^pol_mu_nu + Theta^trans_mu_nu = (8 pi G/c^4) T_mu_nu`  
Explanation: Schematic metric variation: nonlinear polarization and transport terms supplement the Einstein tensor.  
Status/source: theory-side schematic.

**E06. Pi branch native exponent**  
Formula: `p_C = pi`  
Explanation: Locked native curvature exponent used in the pi branch and BBN coordinate conversion.  
Status/source: locked comparison branch.

**E07. Acoustic exponent**  
Formula: `p_ac = 3 - pi/100 = 2.968584073464`  
Explanation: Acoustic comparison exponent used for CMB/acoustic and BBN transport conversion.  
Status/source: locked comparison branch.

**E08. Acoustic transport**  
Formula: `G_T = p_ac/p_C = 0.9449296585513721`  
Explanation: Transport factor from native pi branch to acoustic/BBN comparison coordinate.  
Status/source: locked comparison branch.

**E09. Square-root transport**  
Formula: `sqrt(G_T) = 0.9720749243506758`  
Explanation: Multiplier that converts acoustic eta10 to BBN abundance eta10.  
Status/source: locked comparison branch.

**E10. BBN abundance eta**  
Formula: `eta10_BBN = eta10_ac sqrt(G_T) = 5.998071834744`  
Explanation: Transported BBN baryon-to-photon coordinate; used by PRyMordial and AlterBBN replay.  
Status/source: locked BBN coordinate.

**E11. Physical eta argument**  
Formula: `eta_BBN = eta10_BBN * 1e-10 = 5.998071834744e-10`  
Explanation: Correct AlterBBN alter_eta.x argument; v10.668 corrected the order and units.  
Status/source: fresh AlterBBN closure.

**E12. Effective radiation comparison**  
Formula: `N_eff^CPTG = p_ac = 2.968584073464`  
Explanation: CPTG BBN/CMB radiation comparison value.  
Status/source: locked comparison branch.

**E13. Observed pull**  
Formula: `Delta_X = (X_CPTG - X_obs)/sigma_X`  
Explanation: Signed residual used for D/H, Yp, and Li7/H tests.  
Status/source: abundance screening.

**E14. Admissibility screen**  
Formula: `|Delta_X| < 2`  
Explanation: General 2-sigma gate for reported abundance comparisons.  
Status/source: abundance screening.

**E15. Background admission**  
Formula: `|Delta_D/H| < 2 and |Delta_Yp| < 2`  
Explanation: D/H and Yp must pass before lithium gate is judged.  
Status/source: abundance screening.

**E16. Surviving mass-seven definition**  
Formula: `Y7 = Y7Li + Y7Be`  
Explanation: Final lithium problem is treated as surviving A=7 abundance, including Be7 that later appears as Li7.  
Status/source: lithium authority.

**E17. Mass-seven final abundance**  
Formula: `Y7_final = Y7_raw exp[- integral Gamma7,trans(t) dt]`  
Explanation: General survival form for a live transport gate acting on mass-seven abundance.  
Status/source: lithium authority.

**E18. Locked optical depth**  
Formula: `integral Gamma7,trans(t) dt = ln(pi)`  
Explanation: Fixed CPTG geometric optical depth; not a fitted depletion coefficient.  
Status/source: authorized locked gate.

**E19. Locked survival**  
Formula: `Y7_CPTG = Y7_raw exp[-ln(pi)] = Y7_raw/pi`  
Explanation: Authorized survival factor for the live A=7 gate.  
Status/source: authorized locked gate.

**E20. Survival factor**  
Formula: `1/pi = 0.3183098861837907`  
Explanation: Numerical multiplier used in v10.660, v10.668, and v10.669 closure.  
Status/source: authorized locked gate.

**E21. Thermal gate rate**  
Formula: `Gamma7,trans(T) = Gamma0 W7[T(t)]`  
Explanation: Gate-shape form; the shape/support may vary as robustness control while total optical depth remains locked.  
Status/source: lithium authority.

**E22. Thermal gate normalization**  
Formula: `integral Gamma0 W7[T(t)] dt = ln(pi)`  
Explanation: Enforces fixed optical depth for any accepted thermal support/shape.  
Status/source: lithium authority.

**E23. Live Li7 RHS**  
Formula: `dY_Li7/dt -> (dY_Li7/dt)_BBN - Gamma7(T) Y_Li7`  
Explanation: Live source-network application to lithium channel.  
Status/source: authorized live gate.

**E24. Live Be7 RHS**  
Formula: `dY_Be7/dt -> (dY_Be7/dt)_BBN - Gamma7(T) Y_Be7`  
Explanation: Live source-network application to beryllium channel.  
Status/source: authorized live gate.

**E25. AlterBBN live indices**  
Formula: `Y8 = Y7Li; Y9 = Y7Be`  
Explanation: AlterBBN source patch mapping; Be7 contribution must not be double counted in final reported Li7/H.  
Status/source: AlterBBN implementation.

**E26. AlterBBN live RHS**  
Formula: `dY8/dt -> dY8/dt - Gamma7(T)Y8; dY9/dt -> dY9/dt - Gamma7(T)Y9`  
Explanation: AlterBBN live-channel equivalent of the locked A=7 RHS gate.  
Status/source: AlterBBN implementation.

**E27. Support count**  
Formula: `NP3 = NP3A + NP3B = 56 + 12 = 68`  
Explanation: Row-362 support-index count.  
Status/source: v10.641 current chain.

**E28. Support-slot record count**  
Formula: `68 support indices x 4 scalar components = 272`  
Explanation: C4 physical support-slot value ledger.  
Status/source: v10.641 current chain.

**E29. Coherent term count**  
Formula: `68 support indices x 5 current/source coefficients = 340`  
Explanation: C6 coherent source-amplitude term count.  
Status/source: v10.641 current chain.

**E30. Row-362 energy reconstruction**  
Formula: `T_A3 + V_NN + V_3NF = -7.739492600000001 MeV`  
Explanation: Energy-balance reconstruction from table-certified row-362 state.  
Status/source: v10.641 current chain.

**E31. Energy residual**  
Formula: `abs((-7.739492600000001) - (-7.73945407385108)) = 0.000038526148920858816 MeV`  
Explanation: Residual below row-specific structural-zero floor 0.00010005000000500001 MeV.  
Status/source: v10.641 current chain.

**E32. Coherent amplitude**  
Formula: `A_C6 = 17.5595746398194`  
Explanation: Retained coherent pre-rate source amplitude.  
Status/source: v10.641 current chain.

**E33. Source intensity**  
Formula: `I_C7 = |A_C6|^2 = 308.3386615313886`  
Explanation: C7 source-intensity operator.  
Status/source: v10.641 current chain.

**E34. S-factor normalization**  
Formula: `K_S0 = S12_best(0)/I_C7 = 0.0006956636541608783 eV b`  
Explanation: Single-observable normalization anchor.  
Status/source: anchored S-factor comparison.

**E35. Anchored S factor**  
Formula: `S_CPTG(0) = K_S0 I_C7 = 0.2145 eV b`  
Explanation: Dimensional S-factor anchor row.  
Status/source: anchored S-factor comparison.

**E36. LUNA residual**  
Formula: `(0.2145 - 0.216)/0.010 = -0.15 sigma`  
Explanation: Independent public cross-check row.  
Status/source: anchored S-factor comparison.

**E37. Current-chain live gate ratio**  
Formula: `1.7118494965634585e-10 / 5.377924732128783e-10 = 0.3183104230404215`  
Explanation: Current-chain live A=7 gate ratio; close to 1/pi.  
Status/source: v10.641 current chain.

**E38. PRyMordial fresh gate**  
Formula: `5.266820229187348e-10 / pi = 1.6764809477031113e-10`  
Explanation: v10.660 fresh PRyMordial PDF-authorized closure row.  
Status/source: fresh two-code closure.

**E39. AlterBBN fresh gate**  
Formula: `5.291e-10 / pi = 1.6841776077984365e-10`  
Explanation: v10.668 fresh local AlterBBN physical-eta closure row.  
Status/source: fresh two-code closure.

**E40. Progress percentage**  
Formula: `percent = closed / total x 100`  
Explanation: Used for strict contracts, subgates, support records, and closure accounting.  
Status/source: audit accounting.


# Appendix B. Full parameter ledger

See `LEDGERS/PARAMETER_LEDGER.csv` for the machine-readable parameter list. The same ledger is reproduced below for readability.


**reaction_id** = `D_P_GAMMA_HE3`. Locked commissioning reaction: deuterium-proton radiative capture.

**forward_reaction** = `^2H + p -> ^3He + gamma`. Forward capture channel.

**reverse_reaction** = `^3He + gamma -> p + ^2H`. Reverse photodisintegration channel.

**p_C** = `pi`. Native curvature exponent.

**p_ac** = `2.968584073464`. Acoustic exponent, 3 - pi/100.

**G_T** = `0.9449296585513721`. Acoustic transport p_ac/p_C.

**sqrt_G_T** = `0.9720749243506758`. BBN eta transport factor.

**eta10_ac** = `6.170380167710`. Acoustic/CMB baryon-to-photon coordinate.

**eta10_BBN** = `5.998071834744`. Transported BBN abundance coordinate.

**eta_BBN_argument** = `5.998071834744e-10`. AlterBBN alter_eta.x physical eta argument.

**Omega_b_h2_BBN** = `0.021898765370`. Transport-scaled BBN physical baryon density coordinate.

**N_eff_CPTG** = `2.968584073464`. Effective radiation comparison value.

**D/H_obs** = `25.08e-6`; sigma=0.29e-6. Deuterium observational anchor used in abundance comparisons.

**Yp_obs** = `0.245`; sigma=0.003. Helium mass-fraction observational anchor.

**Li7/H_obs** = `1.45e-10`; sigma=0.25e-10. Lithium observational anchor.

**He3/H_upper** = `1.1e-5`; upper limit/advisory. He3 advisory upper-limit row used in fresh closure.

**NUCWF_row_index** = `362`. Retained A=3 state row.

**row362_hashname** = `4faa3edcfbff73257c73efade1c5e1dacab105fad4148eecb3d982919213a5e6`. Row-362 hashname.

**NORM** = `0.99993`. Row-362 state norm.

**NP3** = `68`. Support indices.

**support_slot_records** = `272`. 68 support indices x 4 scalar components.

**amplitude_terms** = `340`. 68 support indices x 5 coefficients.

**T_A3** = `27.0897`; MeV. Row-362 kinetic component.

**V_NN** = `-34.8757`; MeV. Native A=3 NN potential component.

**V_3NF** = `0.0465074`; MeV. TNFME/3NF component.

**E_table** = `-7.73945407385108`; MeV. Table-certified energy row.

**energy_reconstruction** = `-7.739492600000001`; MeV. T + V_NN + V_3NF.

**energy_abs_residual** = `0.000038526148920858816`; MeV. Below structural-zero floor.

**structural_zero_floor** = `0.00010005000000500001`; MeV. Row-specific pass threshold.

**c1** = `-1.23`; GeV^-1. Current/source coefficient.

**c3** = `-4.65`; GeV^-1. Current/source coefficient.

**c4** = `3.28`; GeV^-1. Current/source coefficient.

**cD** = `0.8918`; dimensionless. Current/source coefficient.

**cE** = `-0.38595`; dimensionless. Current/source coefficient.

**A_C6** = `17.5595746398194`. Coherent pre-rate source amplitude.

**I_C7** = `308.3386615313886`. Source intensity |A_C6|^2.

**S12_best_0_anchor** = `0.2145`; eV b. S-factor normalization anchor.

**K_S0** = `0.0006956636541608783`; eV b per dimensionless intensity. Dimensional conversion from C7 intensity to S-factor.

**LUNA_S12_0** = `0.216 ± 0.010`; eV b. Independent cross-check row.

**solar_Gamow_E0** = `6.64`; keV. Solar Gamow benchmark energy.

**S12_E0_CPTG** = `0.25163174176576003`; eV b. Transported S12(E0) benchmark row.

**PRIMAT_payloads** = `13/13`. Source-required small MT payloads closed.

**current_chain_raw_D/H** = `2.4794272036813933e-05`. Raw current-chain abundance before live A=7 gate.

**current_chain_raw_He3/H** = `1.0199932320844196e-05`. Raw current-chain abundance before live A=7 gate.

**current_chain_raw_Yp** = `2.4699580513634747e-01`. Raw current-chain abundance before live A=7 gate.

**current_chain_raw_Li7/H** = `5.3779247321287830e-10`. Raw current-chain abundance before live A=7 gate.

**current_chain_live_gated_Li7/H** = `1.7118494965634585e-10`. Current-chain locked live A=7 gate output.

**current_chain_live_raw_ratio** = `0.3183104230404215`. Current-chain live/raw ratio.

**target_survival** = `0.3183098861837907`. 1/pi.

**PRyMordial_raw_Li7/H** = `5.266820229187348e-10`. Fresh PRyMordial raw A=7 row.

**PRyMordial_gated_Li7/H** = `1.6764809477031113e-10`. Fresh PRyMordial after 1/pi gate.

**PRyMordial_Li_pull** = `0.9059237908124455`; sigma. Fresh PRyMordial pass.

**AlterBBN_row** = `correct_physical_eta_cptg_bbn_failsafe1`. Canonical fresh local AlterBBN row.

**AlterBBN_raw_D/H** = `2.5e-05`. Fresh AlterBBN physical-eta replay.

**AlterBBN_D_pull** = `-0.27586206896551463`; sigma. Fresh AlterBBN D/H residual.

**AlterBBN_Yp** = `0.2471`. Fresh AlterBBN physical-eta replay.

**AlterBBN_Yp_pull** = `0.699999999999997`; sigma. Fresh AlterBBN Yp residual.

**AlterBBN_He3/H** = `1.041e-05`. Fresh AlterBBN physical-eta replay.

**AlterBBN_raw_Li7/H** = `5.291e-10`. Fresh AlterBBN raw lithium.

**AlterBBN_gated_Li7/H** = `1.6841776077984365e-10`. Fresh AlterBBN after 1/pi gate.

**AlterBBN_Li_pull** = `0.9367104311937463`; sigma. Fresh AlterBBN pass.


# Appendix C. Audit package hashes

See the CSV files in `LEDGERS/` for full SHA-256, ZIP CRC, member counts, decision files, and package roles. This report package also includes the original user-run output ZIPs and source packages for the recent v10.654-v10.670 lane so the evidence can be re-opened without relying on conversation context.
