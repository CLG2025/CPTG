# R12 final scientific decision

Decision: **PASS**.

All six PRIMAT eta10 anchors passed the frozen finer-frontier continuum qualification. The global 1024→2048 primary discrepancy is 0.0015208908661584173, the global backward-Euler 1024→2048 discrepancy is 0.030301545856681582, the global independently extrapolated cross-method discrepancy is 0.0017207632391533806, and the global P2048→Richardson residual is 0.0005103661629565045. All are inside the preregistered gates.

The observed primary effective order is 1.994412662662596–1.994463964357915 and the backward-Euler effective order is 0.9748101911560706–0.9750270534196244. The preserved convergence behavior plus the r12 PASS resolves the earlier r11 512-ceiling NOT_QUALIFIED outcome as numerical under-resolution within the same frozen graph/source model, without erasing that historical r11 result.

The natural reachable maximum remains A=338. A=338 is present at all six anchors with P2048 amplitudes from 1.8474616946749733e-75 to 5.242253864225718e-75.
