# Claim boundary

This evidence qualifies the prescribed-PRIMAT-bath reduced-graph transport through the independently established natural A=338 frontier under the r12 frozen numerical and structural contract.

It does **not** claim:

- native PRIMAT heavy-network evolution above PRIMAT's native boundary;
- a primordial heavy-element yield prediction;
- convergence of every individual heavy-nuclide coordinate;
- that A=338 amplitudes are source-robust before the separately preregistered source-tail/leave-one-out campaign;
- that r11 retroactively passed.

The A=339 disconnected-rate-island structural classification remains a separate upstream forensic result.
