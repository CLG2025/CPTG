CPTG PRIMAT Post-A119 A160-A338 Finer Frontier Continuum Qualification
FINAL EVIDENCE — 2026-08-18 r01

CONTROLLING DECISION: PASS
ANCHORS: 6/6 PASS
NATURAL REACHABLE FRONTIER: A=338
NEXT MANDATORY STAGE: source-tail robustness

This archive preserves the original immutable r12 executable package and its SHA-256 sidecar, the frozen r12 preregistration, the exact user-reported production transcript, machine-readable anchor/global metrics, claim boundary, and the mandatory next-stage queue.

Original r12 package SHA-256:
d73b2a14626c0217784a8d3fb888b2b4a59b858daa71f7ef276090f1deda0366

Important limitation: the user's local r12 RESULTS/EVIDENCE runtime directories were not uploaded into this chat. This archive therefore preserves the exact reported production transcript and original executable/preregistration package, but does not invent or reconstruct unseen local endpoint CSV files.
