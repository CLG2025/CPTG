# Scientific protocol — PRIMAT-native A=7 core-theory validation

## Primary question

When the already-locked CPTG mass-seven operator is inserted directly into PRIMAT v0.3.2's native low-temperature Li7 and Be7 evolution, does the live network realize the predicted `1/pi` survival while leaving non-A=7 primordial observables unchanged at the preregistered tolerance?

## Frozen implementation

- PRIMAT v0.3.2, pure-Python backend.
- Native `large` network.
- `numerical_precision = 1e-10`.
- Nuclear rate master grid: 4000 points, `1e-3 <= T9 <= 10`.
- Neutron lifetime 878.4 s and the standard PRIMAT v0.3.2 radiative, finite-mass, thermal, spectral-distortion, plasma-QED, weak-rate-normalization, and nuclear-QED corrections explicitly enabled.
- PRIMAT v0.3.2 background sampling explicitly fixed at 600 points per temperature decade.
- Direct live sinks: Li7 and Be7 only.
- Direct analytic-Jacobian diagonal sinks: Li7 and Be7 only.
- Gate support: log-cosine, `0.0175 -> 0.0040 MeV`.
- Gate normalization: independent quadrature on each PRIMAT background so `integral Gamma7 dt = ln(pi)`.

The gate shape/window is not a free parameter in this primary experiment. It is an inherited prospective embedding. Any future window/shape robustness campaign must be a separate frozen experiment.

## Rows

Seven paired coordinates are run, gate-off then gate-on: one row driven by the CPTG transported physical baryon density `Omegabh2=0.021898765370`, plus six completed PRIMAT authority anchors. Total native solves: 14. The CPTG source companion value `eta10_BBN=5.998071834744` is recorded for provenance, but PRIMAT is not told that value; its native API is driven here by `Omegabh2`. `DeltaNeff=0` is explicit in every row so this experiment isolates the A=7 operator from a separate radiation-coordinate translation. The source value `N_eff^CPTG=2.968584073464` is documented but not silently mapped into PRIMAT in this campaign.

## Fail-closed gates

The immutable preregistration contains all thresholds. Among them:

- gate quadrature optical depth relative error <= `1e-12`;
- independent-grid optical-depth relative error <= `2e-6`;
- internal `Y7` and reported `Li7oH` survival relative error to `1/pi` <= `5e-3`;
- paired D/H, YPBBN and He3/H relative changes <= `1e-6`;
- paired Neff relative change <= `1e-10`;
- all six gate-off PRIMAT authority baselines must match the frozen C authority within `5e-6`;
- all six internal baseline Y7 values must match the frozen Python authority within `5e-6`;
- both RHS and analytic-Jacobian gate paths must have nonzero runtime call counts;
- imported PRIMAT code must resolve to the copied/patched tree, and the imported `nuclear_network.py` hash must equal the frozen patch-provenance hash;
- the installed PRIMAT `nuclear_network.py`, `background.py`, and `config.py` must remain byte-identical from pre-patch to final audit.

The observational lithium comparison is reported only after these gates are judged. It is not a hard gate and is not used to determine the survival factor, window, baryon coordinate, or PRIMAT settings.

## Freeze

Preregistration SHA-256:

`444879ac5bbc280f66fe99606a5da22fe99d0cf3f341c0d8cc771beaea6f67b4`
