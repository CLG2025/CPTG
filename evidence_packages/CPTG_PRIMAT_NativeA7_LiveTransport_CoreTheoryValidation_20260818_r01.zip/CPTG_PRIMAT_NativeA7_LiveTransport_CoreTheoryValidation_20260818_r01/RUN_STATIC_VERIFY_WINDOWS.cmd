@echo off
setlocal
cd /d "%~dp0"
set "PYTHON_EXE=D:\Downloads\ChatGPT\cptg-cmb-like\Scripts\python.exe"
if not exist "%PYTHON_EXE%" set "PYTHON_EXE=python"
"%PYTHON_EXE%" SOURCE\static_verify.py
exit /b %ERRORLEVEL%
