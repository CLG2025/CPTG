CPTG PRIMAT-native A=7 live-channel core-theory validation

This is a prospective native-source validation of the locked CPTG mass-seven transport law in PRIMAT v0.3.2. The lithium gate is treated as core theory, not as a fit parameter.

Required PRIMAT Python:
  D:\Downloads\PRIMAT_v0.3.2\venv\Scripts\python.exe

Run in this order:
  RUN_STATIC_VERIFY_WINDOWS.cmd
  RUN_PREFLIGHT_WINDOWS.cmd
  RUN_PREPARE_PATCHED_PRIMAT_WINDOWS.cmd
  RUN_PATCH_SELFTEST_WINDOWS.cmd
  RUN_A7_PRIMARY_VALIDATION_WINDOWS.cmd
  RUN_FINAL_AUDIT_WINDOWS.cmd

The production campaign is 14 native PRIMAT Python-backend solves: seven gate-off and seven gate-on. Rows are restartable and are reused only when preregistration, coordinate, mode, and patched-source identities all match.

Locked theory:
  tau7 = ln(pi)
  survival = 1/pi
  live sink species = Li7 and Be7 only

Primary transported BBN physical-baryon row:
  PRIMAT runtime input Omegabh2 = 0.021898765370
  CPTG source/reference eta10 = 5.998071834744
  CPTG source/reference Neff = 2.968584073464
  DeltaNeff = 0 (native PRIMAT radiation background; operator-isolation scope)
  Full CPTG radiation-coordinate implementation = NO (separate frozen mapping required)

PRIMAT authority stress anchors:
  6.044, 6.080, 6.094, 6.106, 6.128, 6.134

Decisive ending:
  A7_PRIMAT_NATIVE_CORE_THEORY_VALIDATION PASS
or
  A7_PRIMAT_NATIVE_CORE_THEORY_VALIDATION NOT_QUALIFIED

Preregistration SHA-256:
  444879ac5bbc280f66fe99606a5da22fe99d0cf3f341c0d8cc771beaea6f67b4
