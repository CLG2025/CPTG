# Theory authority and claim boundary

This campaign treats the mass-seven live-channel transport gate as **core CPTG theory**. It is not a fitted lithium correction and is not selected from PRIMAT output.

Locked law:

```text
Y7 = Y_Li7 + Y_Be7
dY_Li7/dt -> dY_Li7/dt - Gamma7(t) Y_Li7
dY_Be7/dt -> dY_Be7/dt - Gamma7(t) Y_Be7
integral Gamma7(t) dt = ln(pi)
survival target = exp[-ln(pi)] = 1/pi
```

The temporal embedding is prospectively frozen to the previously established compact log-cosine support from 0.0175 MeV down to 0.0040 MeV. Its normalization is fixed exclusively by `ln(pi)`. No lithium endpoint enters the normalization.

## Primary baryon coordinate and native PRIMAT robustness layer

The package includes the CPTG transported BBN baryon coordinate

```text
eta10_BBN   = 5.998071834744
Omegabh2_BBN = 0.021898765370
```

as a primary operator row. PRIMAT is driven by `Omegabh2=0.021898765370` in that row. The accompanying `eta10_BBN=5.998071834744` is retained as the CPTG source/reference coordinate rather than silently relabeled as PRIMAT's internal baryon conversion.

The same CPTG source lists `N_eff^CPTG=2.968584073464`. This isolated operator experiment deliberately keeps PRIMAT's radiation background native (`DeltaNeff=0`) rather than guessing a code-local translation after the fact. A separate frozen radiation-coordinate mapping is required before any full-CPTG-BBN-coordinate claim. Thus this row tests the locked A=7 operator at the CPTG **physical baryon-density coordinate**, not every CPTG BBN comparison-layer coordinate.

A separate six-anchor layer uses the completed PRIMAT authority coordinates `6.044, 6.080, 6.094, 6.106, 6.128, 6.134` and requires the gate-off Python baselines to reproduce the already frozen PRIMAT authority before any gate-on result can qualify.

## Supplied theory-source identities

- `CPTG_Geometric_Pi_Branch_Comparison_Coordinates(2).pdf`
  SHA-256: `809a9a848ced3fd275bbb891f6b1bbd738c43d745ac2f700b794b4e652520458`
  The source fixes the native-branch-before-comparison discipline, the `1/pi` transport branch weight, and the transported BBN baryon coordinate.
- `CPTG_Unified_Geometric_Framework_Cosmic_Structure_Expansion(1).pdf`
  SHA-256: `832c64c0f85a681411691dceacdfddb6ea7ea03ee363c5afb73218e43d86ff3c`
  The source states the unified transported/polarized geometric framework and separates native theory quantities from downstream comparison coordinates.

The specific live Li7/Be7 `ln(pi)` sink is inherited from the locked CPTG mass-seven theory/evidence chain.
