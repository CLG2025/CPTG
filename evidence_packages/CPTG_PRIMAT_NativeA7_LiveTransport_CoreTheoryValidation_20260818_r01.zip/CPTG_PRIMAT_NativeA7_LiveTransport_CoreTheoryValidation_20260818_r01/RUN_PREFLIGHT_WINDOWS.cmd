@echo off
setlocal
cd /d "%~dp0"
set "PYTHON_EXE=D:\Downloads\PRIMAT_v0.3.2\venv\Scripts\python.exe"
if not exist "%PYTHON_EXE%" (
  echo A7_PRIMAT_PREFLIGHT FAIL missing %PYTHON_EXE%
  exit /b 2
)
"%PYTHON_EXE%" SOURCE\preflight.py
exit /b %ERRORLEVEL%
