from __future__ import annotations
import hashlib, importlib.metadata, importlib.util, json, os, shutil
from pathlib import Path
from common import ROOT, load_config, prereg_sha, sha256_file, write_json

HELPER = r"""
        # --- CPTG LOCKED A=7 LIVE TRANSPORT CORE-THEORY PATCH ---
        _cptg_gate_enabled = os.environ.get("CPTG_A7_GATE_ENABLED", "0").strip().lower() in ("1","true","yes","on")
        _cptg_gate_T_high_MeV = 0.0175
        _cptg_gate_T_low_MeV = 0.0040
        _cptg_tau_target = float(np.log(np.pi))
        _cptg_species_L = list(nucl.species_large)
        if _cptg_species_L.count("Li7") != 1 or _cptg_species_L.count("Be7") != 1:
            raise RuntimeError("CPTG A7 patch requires exactly one Li7 and one Be7 LT coordinate")
        _cptg_i_li7 = _cptg_species_L.index("Li7")
        _cptg_i_be7 = _cptg_species_L.index("Be7")
        _cptg_gamma0 = 0.0
        _cptg_t_gate_start = None
        _cptg_t_gate_end = None
        _cptg_weight_integral = None
        _cptg_tau_grid = None
        _cptg_quad_error = None
        _cptg_diag_path = os.environ.get("CPTG_A7_DIAGNOSTIC_FILE", "").strip()
        _cptg_stats = {"rhs_gamma_calls":0, "rhs_nonzero_gamma_calls":0,
                       "jacobian_gamma_calls":0, "jacobian_nonzero_gamma_calls":0,
                       "max_gamma_s_inv":0.0}

        def _cptg_weight_mev(T_MeV):
            T_MeV = float(T_MeV)
            if T_MeV > _cptg_gate_T_high_MeV or T_MeV < _cptg_gate_T_low_MeV:
                return 0.0
            den = float(np.log(_cptg_gate_T_high_MeV/_cptg_gate_T_low_MeV))
            x = float(np.log(_cptg_gate_T_high_MeV/T_MeV))/den
            if x < 0.0 or x > 1.0:
                return 0.0
            return float(np.sin(np.pi*x)**2)

        def _cptg_gamma_from_TK(T_K, site):
            if site == "rhs":
                _cptg_stats["rhs_gamma_calls"] += 1
            elif site == "jacobian":
                _cptg_stats["jacobian_gamma_calls"] += 1
            if not _cptg_gate_enabled or _cptg_gamma0 == 0.0:
                return 0.0
            g = _cptg_gamma0 * _cptg_weight_mev(float(T_K)/float(cfg.MeV_to_Kelvin))
            if g != 0.0:
                if site == "rhs": _cptg_stats["rhs_nonzero_gamma_calls"] += 1
                elif site == "jacobian": _cptg_stats["jacobian_nonzero_gamma_calls"] += 1
                _cptg_stats["max_gamma_s_inv"] = max(_cptg_stats["max_gamma_s_inv"], float(g))
            return g

        _cptg_diag = None
        if _cptg_gate_enabled:
            from scipy.integrate import quad as _cptg_quad
            # PRIMAT Background.t_of_T/T_of_t use MeV directly; the nuclear kernels
            # receive Kelvin only after the native T_of_t*MeV_to_Kelvin conversion.
            _cptg_t_gate_start = float(background.t_of_T(_cptg_gate_T_high_MeV))
            _cptg_t_gate_end = float(background.t_of_T(_cptg_gate_T_low_MeV))
            if not (t_nucl <= _cptg_t_gate_start < _cptg_t_gate_end <= t_end):
                raise RuntimeError("CPTG A7 gate window lies outside PRIMAT LT integration interval")
            _cptg_weight_integral, _cptg_quad_error = _cptg_quad(
                lambda _tt: _cptg_weight_mev(float(T_of_t(_tt))),
                _cptg_t_gate_start, _cptg_t_gate_end,
                epsabs=1e-12, epsrel=1e-12, limit=500)
            if not np.isfinite(_cptg_weight_integral) or _cptg_weight_integral <= 0.0:
                raise RuntimeError("CPTG A7 gate normalization integral is nonpositive or nonfinite")
            _cptg_gamma0 = _cptg_tau_target / float(_cptg_weight_integral)
            _cptg_ts = np.geomspace(_cptg_t_gate_start, _cptg_t_gate_end, 32769)
            _cptg_Ts = np.asarray(T_of_t(_cptg_ts), dtype=float)
            _cptg_ws = np.array([_cptg_weight_mev(_T) for _T in _cptg_Ts], dtype=float)
            if hasattr(np, "trapezoid"):
                _cptg_int_grid = float(np.trapezoid(_cptg_ws, _cptg_ts))
            else:
                _cptg_int_grid = float(np.trapz(_cptg_ws, _cptg_ts))
            _cptg_tau_grid = _cptg_gamma0 * _cptg_int_grid
            _cptg_diag = {
                "schema":"cptg-primat-native-a7-gate-diagnostic-v2",
                "enabled":True, "shape":"log_cosine",
                "T_high_MeV":_cptg_gate_T_high_MeV, "T_low_MeV":_cptg_gate_T_low_MeV,
                "target_tau":_cptg_tau_target, "target_survival":float(1.0/np.pi),
                "t_gate_start_s":_cptg_t_gate_start, "t_gate_end_s":_cptg_t_gate_end,
                "weight_integral_s":float(_cptg_weight_integral), "quad_error":float(_cptg_quad_error),
                "gamma0_s_inv":float(_cptg_gamma0),
                "tau_check_quad":float(_cptg_gamma0*_cptg_weight_integral),
                "tau_check_independent_grid":float(_cptg_tau_grid),
                "direct_rhs_sink_species":["Li7","Be7"],
                "direct_jacobian_sink_species":["Li7","Be7"],
                "li7_index":int(_cptg_i_li7), "be7_index":int(_cptg_i_be7),
                "runtime_stats":dict(_cptg_stats), "runtime_completed":False
            }
        # --- END CPTG LOCKED A=7 PATCH SETUP ---
"""

RHS_OLD="""        def Y_prime_LT(t, Y):\n            rho = rhoB_BBN(t); T_K = T_of_t(t)*cfg.MeV_to_Kelvin\n            return nucl.rhsLT(Y, T_K, rho, nTOp_frwrd, nTOp_bkwrd)"""
RHS_NEW="""        def Y_prime_LT(t, Y):\n            rho = rhoB_BBN(t); T_K = T_of_t(t)*cfg.MeV_to_Kelvin\n            _cptg_rhs = nucl.rhsLT(Y, T_K, rho, nTOp_frwrd, nTOp_bkwrd)\n            if not _cptg_gate_enabled:\n                return _cptg_rhs\n            _cptg_g = _cptg_gamma_from_TK(T_K, "rhs")\n            if _cptg_g == 0.0:\n                return _cptg_rhs\n            _cptg_rhs = np.asarray(_cptg_rhs, dtype=float).copy()\n            _cptg_rhs[_cptg_i_li7] -= _cptg_g * Y[_cptg_i_li7]\n            _cptg_rhs[_cptg_i_be7] -= _cptg_g * Y[_cptg_i_be7]\n            return _cptg_rhs"""
JAC_OLD="""        def Jacobian_LT(t, Y):\n            rho = rhoB_BBN(t); T_K = T_of_t(t)*cfg.MeV_to_Kelvin\n            return nucl.JacobianLT(Y, T_K, rho, nTOp_frwrd, nTOp_bkwrd)"""
JAC_NEW="""        def Jacobian_LT(t, Y):\n            rho = rhoB_BBN(t); T_K = T_of_t(t)*cfg.MeV_to_Kelvin\n            _cptg_J = nucl.JacobianLT(Y, T_K, rho, nTOp_frwrd, nTOp_bkwrd)\n            if not _cptg_gate_enabled:\n                return _cptg_J\n            _cptg_g = _cptg_gamma_from_TK(T_K, "jacobian")\n            if _cptg_g == 0.0:\n                return _cptg_J\n            _cptg_J = np.asarray(_cptg_J, dtype=float).copy()\n            _cptg_J[_cptg_i_li7, _cptg_i_li7] -= _cptg_g\n            _cptg_J[_cptg_i_be7, _cptg_i_be7] -= _cptg_g\n            return _cptg_J"""
SOLVE_OLD="""        sol_LT = solve_ivp(Y_prime_LT, [t_nucl, t_end], Yi_LT,\n                           method='BDF', jac=Jacobian_LT,\n                           rtol=10.*cfg.numerical_precision, atol=atol)"""
SOLVE_NEW=SOLVE_OLD+"""\n        if _cptg_gate_enabled:\n            if _cptg_diag is None:\n                raise RuntimeError("CPTG A7 diagnostic object missing in gated run")\n            _cptg_diag["runtime_stats"] = dict(_cptg_stats)\n            _cptg_diag["runtime_completed"] = bool(sol_LT.success)\n            _cptg_diag["solver_message"] = str(sol_LT.message)\n            if _cptg_diag_path:\n                with open(_cptg_diag_path,"w",encoding="utf-8") as _f:\n                    json = __import__("json")\n                    json.dump(_cptg_diag,_f,indent=2,sort_keys=True)\n                    _f.write("\\n")"""

def patch_text(text:str):
    start=text.find('    def _solve_LT(self, t_nucl, t_end, mt_final_raw, _show):')
    if start<0: raise RuntimeError('missing _solve_LT signature')
    nxt=text.find('\n    def ',start+10)
    end=len(text) if nxt<0 else nxt
    block=text[start:end]
    if 'CPTG LOCKED A=7' in block: raise RuntimeError('source already contains CPTG A7 patch')
    anchor='        nTOp_bkwrd = background.weak_nTOp_bkwrd\n'
    if block.count(anchor)!=1: raise RuntimeError(f'expected one LT nTOp_bkwrd anchor, found {block.count(anchor)}')
    if block.count(RHS_OLD)!=1: raise RuntimeError(f'expected exact PRIMAT v0.3.2 LT RHS contract once, found {block.count(RHS_OLD)}')
    if block.count(JAC_OLD)!=1: raise RuntimeError(f'expected exact PRIMAT v0.3.2 LT Jacobian contract once, found {block.count(JAC_OLD)}')
    if block.count(SOLVE_OLD)!=1: raise RuntimeError(f'expected exact PRIMAT v0.3.2 LT solve contract once, found {block.count(SOLVE_OLD)}')
    block=block.replace(anchor,anchor+HELPER,1)
    block=block.replace(RHS_OLD,RHS_NEW,1).replace(JAC_OLD,JAC_NEW,1).replace(SOLVE_OLD,SOLVE_NEW,1)
    out=text[:start]+block+text[end:]
    report={'rhs_replacements':1,'jacobian_replacements':1,'solve_posthook_replacements':1,
            'direct_species':['Li7','Be7'], 'source_contract':'PRIMAT v0.3.2 _solve_LT exact form'}
    return out, report

def locate():
    spec=importlib.util.find_spec('primat')
    if spec is None or not spec.submodule_search_locations: raise RuntimeError('primat package not importable')
    return Path(list(spec.submodule_search_locations)[0]).resolve()

def prepare(dest=None):
    cfg=load_config(); src=locate(); ver=importlib.metadata.version('primat')
    if ver != cfg['primat_authority']['required_version']:
        raise RuntimeError(f"PRIMAT version mismatch: installed={ver} required={cfg['primat_authority']['required_version']}")
    nn=src/'nuclear_network.py'; bg=src/'background.py'; conf=src/'config.py'
    if not nn.exists() or not bg.exists() or not conf.exists(): raise RuntimeError('missing PRIMAT source files')
    before_nn=sha256_file(nn); before_bg=sha256_file(bg); before_conf=sha256_file(conf)
    original=nn.read_text(encoding='utf-8')
    patched,report=patch_text(original)
    target_parent=Path(dest or ROOT/'WORK'/'primat_patched')
    if target_parent.exists(): shutil.rmtree(target_parent)
    target_parent.mkdir(parents=True)
    target=target_parent/'primat'
    shutil.copytree(src,target,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
    outnn=target/'nuclear_network.py'; outnn.write_text(patched,encoding='utf-8',newline='\n')
    import py_compile; py_compile.compile(str(outnn),doraise=True)
    after_nn=sha256_file(nn); after_bg=sha256_file(bg); after_conf=sha256_file(conf)
    prov={'schema':'cptg-primat-native-a7-source-patch-provenance-v2','prereg_sha256':prereg_sha(),
      'installed_primat_version':ver,'installed_package_root':str(src),
      'installed_nuclear_network_sha256_before':before_nn,'installed_nuclear_network_sha256_after':after_nn,
      'installed_background_sha256_before':before_bg,'installed_background_sha256_after':after_bg,
      'installed_config_sha256_before':before_conf,'installed_config_sha256_after':after_conf,
      'installed_source_unmodified':before_nn==after_nn and before_bg==after_bg and before_conf==after_conf,
      'copied_package_root':str(target),'patched_nuclear_network_sha256':sha256_file(outnn),
      'patch_report':report,'theory_lock':cfg['theory_lock']}
    write_json(ROOT/'EVIDENCE'/'PATCH_PROVENANCE.json',prov)
    if not prov['installed_source_unmodified']: raise RuntimeError('installed PRIMAT source changed during copy/patch preparation')
    print('A7_PATCH_PREPARE PASS')
    print('INSTALLED_NUCLEAR_NETWORK_SHA256',before_nn)
    print('INSTALLED_BACKGROUND_SHA256',before_bg)
    print('PATCHED_NUCLEAR_NETWORK_SHA256',prov['patched_nuclear_network_sha256'])
    print('INSTALLED_SOURCE_MODIFIED False')
    return prov

if __name__=='__main__': prepare()
