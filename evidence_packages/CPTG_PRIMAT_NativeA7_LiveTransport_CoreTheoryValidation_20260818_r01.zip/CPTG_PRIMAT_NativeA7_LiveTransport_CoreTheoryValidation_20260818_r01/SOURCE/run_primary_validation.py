from __future__ import annotations
import json, os, subprocess, sys
from pathlib import Path
from common import ROOT, load_config, prereg_sha
cfg=load_config(); pr=prereg_sha(); patch_parent=ROOT/'WORK'/'primat_patched'; cache_dir=ROOT/'WORK'/'primat_cache'
prov_path=ROOT/'EVIDENCE'/'PATCH_PROVENANCE.json'
if not prov_path.exists(): raise RuntimeError('Run RUN_PREPARE_PATCHED_PRIMAT_WINDOWS.cmd first')
prov=json.loads(prov_path.read_text(encoding='utf-8'))
if prov.get('prereg_sha256')!=pr: raise RuntimeError('patch provenance prereg mismatch')
patch_sha=prov['patched_nuclear_network_sha256']
rowsdir=ROOT/'OUTPUT'/'ROWS'; diags=ROOT/'OUTPUT'/'GATE_DIAGNOSTICS'; rowsdir.mkdir(parents=True,exist_ok=True); diags.mkdir(parents=True,exist_ok=True); cache_dir.mkdir(parents=True,exist_ok=True)
for row in cfg['rows']:
    label=row['label']; delta=float(row.get('DeltaNeff',0.0))
    for mode in ('baseline','gated'):
        out=rowsdir/f'{label}_{mode}.json'; diag=diags/f'{label}_gate.json'
        if out.exists():
            try:
                old=json.loads(out.read_text(encoding='utf-8'))
                same=(old.get('prereg_sha256')==pr and old.get('mode')==mode and old.get('patched_nuclear_network_sha256')==patch_sha
                      and abs(float(old.get('eta10_reference_coordinate'))-float(row['eta10']))<1e-14
                      and abs(float(old.get('Omegabh2'))-float(row['Omegabh2']))<1e-16
                      and abs(float(old.get('DeltaNeff',0.0))-delta)<1e-16)
                if same:
                    if mode=='gated' and not diag.exists(): same=False
                if same: print('A7_ROW_REUSE',label,mode); continue
            except Exception: pass
        print('A7_ROW_START',label,mode,'eta10_reference',row['eta10'],'Omegabh2_PRIMAT_INPUT',row['Omegabh2'],'DeltaNeff',delta,flush=True)
        cmd=[sys.executable,str(ROOT/'SOURCE'/'run_one.py'),'--eta',str(row['eta10']),'--omega',str(row['Omegabh2']),
             '--delta-neff',str(delta),'--label',label,'--mode',mode,'--output',str(out),'--diag',str(diag),
             '--prereg-sha',pr,'--patch-parent',str(patch_parent),'--expected-patch-sha',patch_sha,'--cache-dir',str(cache_dir)]
        subprocess.run(cmd,check=True,cwd=str(ROOT),env=os.environ.copy())
print('A7_NATIVE_ROWS COMPLETE',len(cfg['rows'])*2)
