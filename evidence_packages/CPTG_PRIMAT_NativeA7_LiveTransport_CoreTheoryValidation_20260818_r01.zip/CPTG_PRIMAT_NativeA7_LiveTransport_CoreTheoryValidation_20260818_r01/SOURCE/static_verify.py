from __future__ import annotations
import py_compile
from pathlib import Path
from common import ROOT, load_config, prereg_sha, sha256_file
cfg=load_config(); checks={}
checks['schema']=cfg.get('schema')=='cptg-primat-native-a7-live-transport-core-theory-validation-v1'
checks['core_gate']=cfg['theory_lock']['optical_depth']=='integral Gamma7(t) dt = ln(pi)' and abs(cfg['theory_lock']['survival_target_numeric']-1/3.141592653589793)<1e-16
checks['direct_species']=cfg['theory_lock']['direct_sink_species']==['Li7','Be7']
checks['fixed_window']=cfg['theory_lock']['gate_shape']=='log_cosine' and cfg['theory_lock']['gate_T_high_MeV']==0.0175 and cfg['theory_lock']['gate_T_low_MeV']==0.004
checks['primary_baryon_coordinate']=cfg['primary_baryon_coordinate']['eta10_BBN']==5.998071834744 and cfg['primary_baryon_coordinate']['Omegabh2_BBN']==0.021898765370 and cfg['primary_baryon_coordinate']['DeltaNeff_used']==0.0
checks['six_authority_anchors']=[r['eta10'] for r in cfg['rows'] if r['role']=='primat_authority_anchor']==[6.044,6.08,6.094,6.106,6.128,6.134]
checks['all_rows_delta_neff_explicit']=all('DeltaNeff' in r and r['DeltaNeff']==0.0 for r in cfg['rows'])
checks['physics_profile_explicit']=all(cfg['primat_authority'].get(k) is True for k in ['strict_params','radiative_corrections','finite_mass_corrections','thermal_corrections','spectral_distortions','incomplete_decoupling','QED_corrections','tau_n_normalization','nuclear_qed_corrections']) and cfg['primat_authority']['sampling_temperature_per_decade']==600
checks['no_retuning']=cfg['theory_lock']['retuning_allowed'] is False
checks['observation_not_gate']='downstream diagnostic only' in cfg['observational_comparison']['role']
checks['prereg_sidecar']=(ROOT/'CONFIG'/'FROZEN_A7_PREREGISTRATION.sha256.txt').read_text().split()[0]==prereg_sha()
bad=[]
for line in (ROOT/'MANIFEST.sha256').read_text(encoding='utf-8').splitlines() if (ROOT/'MANIFEST.sha256').exists() else []:
    if not line.strip(): continue
    h,rel=line.split('  ',1); p=ROOT/rel
    if not p.exists() or sha256_file(p)!=h: bad.append(rel)
checks['manifest']=not bad
compiled=0
for p in sorted((ROOT/'SOURCE').glob('*.py')):
    py_compile.compile(str(p),doraise=True); compiled+=1
checks['python_compile']=compiled>=7
for k,v in checks.items(): print('A7_STATIC',k,'PASS' if v else 'FAIL')
print('PYTHON_COMPILE',compiled,'PASS')
if not all(checks.values()): raise SystemExit(2)
print('A7_CORE_THEORY_STATIC_VERIFY PASS'); print('PREREG_SHA256',prereg_sha())
