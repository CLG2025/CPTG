from __future__ import annotations
import hashlib, json, math, os
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
CONFIG=ROOT/'CONFIG'/'FROZEN_A7_PREREGISTRATION.json'
def sha256_file(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()
def load_config(): return json.loads(CONFIG.read_text(encoding='utf-8'))
def prereg_sha(): return sha256_file(CONFIG)
def rel(a,b, floor=1e-300): return abs(float(a)-float(b))/max(abs(float(b)),floor)
def finite_nonnegative_dict(d):
    return bool(d) and all(math.isfinite(float(v)) and float(v)>=0.0 for v in d.values())
def write_json(path,obj):
    path=Path(path); path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n',encoding='utf-8')
