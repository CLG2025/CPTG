from __future__ import annotations
import csv, json, math
from pathlib import Path
from common import ROOT, load_config, prereg_sha, rel, finite_nonnegative_dict, write_json, sha256_file
cfg=load_config(); pr=prereg_sha(); g=cfg['hard_gates']; target=cfg['theory_lock']['survival_target_numeric']; lnpi=math.log(math.pi)
provp=ROOT/'EVIDENCE'/'PATCH_PROVENANCE.json'
if not provp.exists(): raise RuntimeError('PATCH_PROVENANCE missing')
prov=json.loads(provp.read_text(encoding='utf-8')); patch_sha=prov['patched_nuclear_network_sha256']
installed_nn=Path(prov['installed_package_root'])/'nuclear_network.py'; installed_bg=Path(prov['installed_package_root'])/'background.py'; installed_conf=Path(prov['installed_package_root'])/'config.py'
source_unchanged=(installed_nn.exists() and installed_bg.exists() and installed_conf.exists()
                  and sha256_file(installed_nn)==prov['installed_nuclear_network_sha256_before']
                  and sha256_file(installed_bg)==prov['installed_background_sha256_before']
                  and sha256_file(installed_conf)==prov['installed_config_sha256_before']
                  and bool(prov.get('installed_source_unmodified')))
rows=[]; allpass=source_unchanged
for spec in cfg['rows']:
    label=spec['label']; bp=ROOT/'OUTPUT'/'ROWS'/f'{label}_baseline.json'; gp=ROOT/'OUTPUT'/'ROWS'/f'{label}_gated.json'; dp=ROOT/'OUTPUT'/'GATE_DIAGNOSTICS'/f'{label}_gate.json'
    if not (bp.exists() and gp.exists() and dp.exists()):
        print('A7_MISSING_ROW',label); allpass=False; continue
    b=json.loads(bp.read_text()); z=json.loads(gp.read_text()); d=json.loads(dp.read_text())
    identity_ok=(b.get('prereg_sha256')==pr and z.get('prereg_sha256')==pr and b.get('patched_nuclear_network_sha256')==patch_sha and z.get('patched_nuclear_network_sha256')==patch_sha
                 and b.get('force_backend')=='python' and z.get('force_backend')=='python')
    ysur=float(z['Y7_internal'])/float(b['Y7_internal']); lsur=float(z['standard']['Li7oH'])/float(b['standard']['Li7oH'])
    stats=d.get('runtime_stats',{})
    metrics={'Y7_survival':ysur,'Y7_survival_relerr':rel(ysur,target),'Li7oH_survival':lsur,'Li7oH_survival_relerr':rel(lsur,target),
      'DoH_relchange':rel(z['standard']['DoH'],b['standard']['DoH']),'YPBBN_relchange':rel(z['standard']['YPBBN'],b['standard']['YPBBN']),
      'He3oH_relchange':rel(z['standard']['He3oH'],b['standard']['He3oH']),'Neff_relchange':rel(z['standard']['Neff'],b['standard']['Neff']),
      'tau_quad_relerr':rel(d['tau_check_quad'],lnpi),'tau_grid_relerr':rel(d['tau_check_independent_grid'],lnpi),
      'rhs_nonzero_gamma_calls':int(stats.get('rhs_nonzero_gamma_calls',0)),'jacobian_nonzero_gamma_calls':int(stats.get('jacobian_nonzero_gamma_calls',0)),
      'baseline_authority_C_maxrel':None,'baseline_Y7_python_rel':None}
    if spec['authority_C']:
        metrics['baseline_authority_C_maxrel']=max(rel(b['standard'][k],v) for k,v in spec['authority_C'].items())
        metrics['baseline_Y7_python_rel']=rel(b['Y7_internal'],spec['authority_Y7_python'])
    gates={'row_identity_and_patched_import':identity_ok,
      'Y7_survival':metrics['Y7_survival_relerr']<=g['mass7_survival_relative_error_to_1_over_pi_max'],
      'Li7oH_survival':metrics['Li7oH_survival_relerr']<=g['reported_Li7oH_survival_relative_error_to_1_over_pi_max'],
      'DoH_control':metrics['DoH_relchange']<=g['DoH_gated_vs_baseline_relative_change_max'],
      'YP_control':metrics['YPBBN_relchange']<=g['YPBBN_gated_vs_baseline_relative_change_max'],
      'He3_control':metrics['He3oH_relchange']<=g['He3oH_gated_vs_baseline_relative_change_max'],
      'Neff_control':metrics['Neff_relchange']<=g['Neff_gated_vs_baseline_relative_change_max'],
      'tau_quad':metrics['tau_quad_relerr']<=g['gate_quad_tau_relative_error_to_lnpi_max'],
      'tau_grid':metrics['tau_grid_relerr']<=g['gate_independent_grid_tau_relative_error_to_lnpi_max'],
      'finite_nonnegative_baseline':finite_nonnegative_dict(b['Y_final']),'finite_nonnegative_gated':finite_nonnegative_dict(z['Y_final']),
      'direct_rhs_species':d.get('direct_rhs_sink_species')==['Li7','Be7'],'direct_jac_species':d.get('direct_jacobian_sink_species')==['Li7','Be7'],
      'runtime_completed':d.get('runtime_completed') is True,
      'rhs_gate_exercised':metrics['rhs_nonzero_gamma_calls']>=g['gate_rhs_nonzero_call_count_min'],
      'jacobian_gate_exercised':metrics['jacobian_nonzero_gamma_calls']>=g['gate_jacobian_nonzero_call_count_min']}
    if spec['authority_C']:
        gates['authority_C_baseline']=metrics['baseline_authority_C_maxrel']<=g['all_six_authority_baselines_match_frozen_C_observables_max_relative']
        gates['authority_Y7_python']=metrics['baseline_Y7_python_rel']<=g['all_six_authority_baseline_internal_Y7_match_frozen_python_max_relative']
    passed=all(gates.values()); allpass &= passed
    obs=cfg['observational_comparison']; pull=(float(z['standard']['Li7oH'])-obs['Li7_over_H_obs_central'])/obs['Li7_over_H_obs_sigma']
    rec={'label':label,'role':spec['role'],'eta10_reference_coordinate':spec['eta10'],'Omegabh2':spec['Omegabh2'],'DeltaNeff':spec.get('DeltaNeff',0.0),
         'baseline_Li7oH':b['standard']['Li7oH'],'gated_Li7oH':z['standard']['Li7oH'],'observational_pull_sigma_diagnostic_only':pull,
         'metrics':metrics,'gates':gates,'decision':'PASS' if passed else 'NOT_QUALIFIED'}
    rows.append(rec)
    print('A7_COORDINATE',label,rec['decision'],'Y7_SURV',format(ysur,'.12g'),'Y7_RELERR',format(metrics['Y7_survival_relerr'],'.6g'),
          'LI7OH_SURV',format(lsur,'.12g'),'D_REL',format(metrics['DoH_relchange'],'.3g'),'YP_REL',format(metrics['YPBBN_relchange'],'.3g'),
          'HE3_REL',format(metrics['He3oH_relchange'],'.3g'),'TAU_GRID_REL',format(metrics['tau_grid_relerr'],'.3g'),
          'RHS_CALLS',metrics['rhs_nonzero_gamma_calls'],'JAC_CALLS',metrics['jacobian_nonzero_gamma_calls'],'OBS_PULL_DIAG',format(pull,'.6g'))
primary=[r for r in rows if r['role']=='cptg_bbn_baryon_coordinate']; auth=[r for r in rows if r['role']=='primat_authority_anchor']
group_gates={'primary_baryon_coordinate_exactly_one_and_pass':len(primary)==1 and primary[0]['decision']=='PASS',
             'six_authority_anchors_all_pass':len(auth)==6 and all(r['decision']=='PASS' for r in auth),
             'all_14_native_solves_committed':len(rows)==7,
             'installed_PRIMAT_source_unchanged':source_unchanged,
             'patch_provenance_prereg_match':prov.get('prereg_sha256')==pr}
allpass = allpass and all(group_gates.values())
summary={'schema':'cptg-primat-native-a7-primary-validation-result-v2','prereg_sha256':pr,'target_survival':target,'rows':rows,
         'group_gates':group_gates,'decision':'PASS' if allpass else 'NOT_QUALIFIED','observational_status':'diagnostic_only_not_a_gate',
         'scope_note':'CPTG BBN baryon coordinate uses DeltaNeff=0 in this isolated A7-operator campaign; no full CPTG radiation-coordinate claim is made.'}
write_json(ROOT/'RESULTS'/'A7_PRIMARY_VALIDATION.json',summary)
with open(ROOT/'RESULTS'/'A7_SIXANCHOR_PLUS_BARYON_RESULTS.csv','w',newline='',encoding='utf-8') as f:
    w=csv.writer(f); w.writerow(['label','role','eta10_reference_coordinate','Omegabh2','DeltaNeff','baseline_Li7oH','gated_Li7oH','Y7_survival','Y7_survival_relerr','Li7oH_survival','Li7oH_survival_relerr','DoH_relchange','YPBBN_relchange','He3oH_relchange','tau_grid_relerr','rhs_nonzero_calls','jac_nonzero_calls','obs_pull_sigma_diagnostic_only','decision'])
    for r in rows:
      m=r['metrics']; w.writerow([r['label'],r['role'],r['eta10_reference_coordinate'],r['Omegabh2'],r['DeltaNeff'],r['baseline_Li7oH'],r['gated_Li7oH'],m['Y7_survival'],m['Y7_survival_relerr'],m['Li7oH_survival'],m['Li7oH_survival_relerr'],m['DoH_relchange'],m['YPBBN_relchange'],m['He3oH_relchange'],m['tau_grid_relerr'],m['rhs_nonzero_gamma_calls'],m['jacobian_nonzero_gamma_calls'],r['observational_pull_sigma_diagnostic_only'],r['decision']])
print('A7_CPTG_BBN_BARYON_COORDINATE','PASS' if group_gates['primary_baryon_coordinate_exactly_one_and_pass'] else 'NOT_QUALIFIED')
print('A7_SIX_AUTHORITY_ANCHORS','PASS' if group_gates['six_authority_anchors_all_pass'] else 'NOT_QUALIFIED')
print('A7_INSTALLED_PRIMAT_SOURCE_UNCHANGED','PASS' if source_unchanged else 'FAIL')
print('A7_FULL_CPTG_RADIATION_COORDINATE_IMPLEMENTED False')
print('A7_PRIMAT_NATIVE_CORE_THEORY_VALIDATION',summary['decision'])
if not allpass: raise SystemExit(2)
