from __future__ import annotations
import ast, importlib.metadata, importlib.util, platform, sys
from pathlib import Path
from common import ROOT, load_config, prereg_sha, sha256_file, write_json
from prepare_patched_primat import patch_text
cfg=load_config(); checks={}
try:
    v=importlib.metadata.version('primat'); checks['version']=(v==cfg['primat_authority']['required_version'])
    spec=importlib.util.find_spec('primat'); root=Path(list(spec.submodule_search_locations)[0]).resolve() if spec and spec.submodule_search_locations else None
    checks['package_root']=bool(root and root.exists())
    nn=root/'nuclear_network.py' if root else None; bg=root/'background.py' if root else None; conf=root/'config.py' if root else None
    checks['nuclear_network_source']=bool(nn and nn.exists()); checks['background_source']=bool(bg and bg.exists()); checks['config_source']=bool(conf and conf.exists())
    text=nn.read_text(encoding='utf-8') if nn else ''; bgtext=bg.read_text(encoding='utf-8') if bg else ''
    patched,rep=patch_text(text); ast.parse(patched)
    checks['patch_contract']=(rep['rhs_replacements']==1 and rep['jacobian_replacements']==1 and rep['solve_posthook_replacements']==1 and rep['direct_species']==['Li7','Be7'])
    checks['temperature_unit_contract']=('T_K = T_of_t(t)*cfg.MeV_to_Kelvin' in text)
    checks['background_temperature_inverse_contract']=('t_of_T' in bgtext and 'T_of_t' in bgtext)
    checks['patch_dependency_imports']=('import os' in text and ('import numpy as np' in text or 'import numpy' in text))
    import numpy, scipy
    from primat.backend import run_bbn
    from primat.config import DEFAULT_PARAMS
    checks['numpy']=True; checks['scipy']=True; checks['run_bbn_callable']=callable(run_bbn)
    run_keys={'strict_params','Omegabh2','DeltaNeff','network','amax','numerical_precision','sampling_temperature_per_decade',
      'rate_grid_npts','rate_grid_T9_min','rate_grid_T9_max','tau_n_normalization','tau_n','incomplete_decoupling','QED_corrections',
      'spectral_distortions','radiative_corrections','finite_mass_corrections','thermal_corrections','nuclear_qed_corrections','cache_dir',
      'output_time_evolution','output_final_result','output_background_evolution','verbose'}
    missing=sorted(k for k in run_keys if k not in DEFAULT_PARAMS)
    checks['run_parameter_contract']=(not missing)
    out={'schema':'cptg-primat-native-a7-preflight-v3','prereg_sha256':prereg_sha(),'python':sys.executable,
         'platform':platform.platform(),'primat_version':v,'primat_root':str(root),
         'nuclear_network_sha256':sha256_file(nn),'background_sha256':sha256_file(bg),'config_sha256':sha256_file(conf),
         'missing_run_parameter_keys':missing,'patch_report':rep,'checks':checks}
    write_json(ROOT/'OUTPUT'/'PREFLIGHT.json',out)
    for k,val in checks.items(): print('A7_PREFLIGHT',k,'PASS' if val else 'FAIL')
    if not all(x for x in checks.values() if isinstance(x,bool)): raise RuntimeError(out)
    print('A7_PRIMAT_PREFLIGHT PASS'); print('PRIMAT_VERSION',v); print('PRIMAT_ROOT',root)
    print('NUCLEAR_NETWORK_SHA256',out['nuclear_network_sha256']); print('BACKGROUND_SHA256',out['background_sha256']); print('CONFIG_SHA256',out['config_sha256'])
except Exception as e:
    print('A7_PRIMAT_PREFLIGHT FAIL',repr(e)); raise
