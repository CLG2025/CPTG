from __future__ import annotations
import csv,hashlib,json,math,os,re
from pathlib import Path
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
CONFIG=ROOT/"CONFIG"; REF=ROOT/"REFERENCE"; EVIDENCE=ROOT/"EVIDENCE"; OUTPUT=ROOT/"OUTPUT"; RESULTS=ROOT/"RESULTS"; WORK=ROOT/"WORK"; PAPER=ROOT/"PAPER_DATA"
ETA=[6.044,6.080,6.094,6.106,6.128,6.134]
LIGHT={(1,0):"n",(1,1):"p",(2,1):"H2",(3,1):"H3",(3,2):"He3",(4,2):"He4"}

ZMAP={"H":1,"He":2,"Li":3,"Be":4,"B":5,"C":6,"N":7,"O":8,"F":9,"Ne":10,"Na":11,"Mg":12,"Al":13,"Si":14,
"P":15,"S":16,"Cl":17,"Ar":18,"K":19,"Ca":20,"Sc":21,"Ti":22,"V":23,"Cr":24,"Mn":25,"Fe":26,"Co":27,"Ni":28,
"Cu":29,"Zn":30,"Ga":31,"Ge":32,"As":33,"Se":34,"Br":35,"Kr":36,"Rb":37,"Sr":38,"Y":39,"Zr":40,"Nb":41,
"Mo":42,"Tc":43,"Ru":44,"Rh":45,"Pd":46,"Ag":47,"Cd":48,"In":49,"Sn":50}
SYMB={v:k for k,v in ZMAP.items()}

def load_json(p:Path): return json.loads(p.read_text(encoding="utf-8"))

def atomic_json(p:Path,obj):
    p.parent.mkdir(parents=True,exist_ok=True);q=p.with_suffix(p.suffix+".tmp")
    with q.open("w",encoding="utf-8",newline="\n") as f:
        f.write(json.dumps(obj,indent=2,sort_keys=True)+"\n");f.flush();os.fsync(f.fileno())
    os.replace(q,p)

def sha_file(p:Path):
    h=hashlib.sha256()
    with p.open("rb") as f:
        for b in iter(lambda:f.read(1024*1024),b""): h.update(b)
    return h.hexdigest()

def eta_tag(x:float): return f"{x:.3f}".replace(".","p")

def parse_primat_name(name:str):
    if name=="n": return 1,0
    if name=="p": return 1,1
    m=re.fullmatch(r"([A-Z][a-z]?)(\d+)",name)
    if not m or m.group(1) not in ZMAP: raise ValueError("cannot parse PRIMAT nuclide "+name)
    return int(m.group(2)),ZMAP[m.group(1)]

def az_name(A:int,Z:int):
    if A==1 and Z==0:return "n"
    if A==1 and Z==1:return "p"
    return f"{SYMB.get(Z,'Z'+str(Z))}{A}"

def symmetric_rel(a,b,floor=1e-300):
    return abs(float(a)-float(b))/max(abs(float(a)),abs(float(b)),floor)

def vector_max_rel(a,b,floor=1e-300):
    return max((symmetric_rel(x,y,floor) for x,y in zip(a,b)),default=0.0)

def load_authority_baselines():
    p=REF/"PRIMAT_AUTHORITY/PRIMAT_BASELINES.csv"
    with p.open(newline="",encoding="utf-8") as f:
        return {float(r["eta10"]):r for r in csv.DictReader(f)}

def verify_native_freeze():
    fp=OUTPUT/"NATIVE_TRAJECTORY_FREEZE.json"
    if not fp.is_file(): raise RuntimeError("native trajectory freeze missing")
    fr=load_json(fp);errs=[]
    for rec in fr["files"]:
        p=ROOT/rec["path"]
        if not p.is_file(): errs.append(rec["path"]+":missing")
        elif sha_file(p)!=rec["sha256"]: errs.append(rec["path"]+":hash")
    if errs: raise RuntimeError("native freeze invalid: "+repr(errs[:10]))
    return fr
