from __future__ import annotations
import json,hashlib,py_compile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def ck(n,c):
    if not c:raise RuntimeError(n+" FAIL")
    print(n,"PASS")
def main():
    p=json.loads((ROOT/"CONFIG/FROZEN_R08_FRONTIER_PREREGISTRATION.json").read_text())
    ck("R08_UNCAPPED_SCOPE",p["graph_rule"]["artificial_Amax"] is None)
    ck("PRIMAT_NATIVE_AUTHORITY",p["authority"]["native_max_A"]==23)
    ck("NO_ENDPOINT_IMPORT",p["authority"]["no_numerical_endpoint_result_import"] is True)
    ck("FRESH_REACLIB",p["graph_rule"]["rate_library"]=="fresh pynucastro ReacLibLibrary 2.11.0")
    ck("NO_SEED_FLOOR",p["graph_rule"]["artificial_seed_or_floor"] is False)
    ck("NO_HISTORICAL_INPUT",p["graph_rule"]["historical_postsilicon_numerical_inputs"]==0)
    ck("FRONTIER_DECISION_LOGIC","GAP_FREE_TO_FRONTIER" in p["decision_logic"])
    ck("SOURCE_TAIL_FUTURE_REQUIRED","tail truncation" in p["future_required_diagnostic"].lower())
    s=(ROOT/"SOURCE/run_uncapped_frontier_census.py").read_text()
    ck("NO_MAXA_ARGUMENT_IN_BFS","d[0]<=" not in s)
    ck("MASS_GAP_CENSUS","first_gap" in s and "UNCAPPED_MASS_SECTOR_CENSUS.csv" in s)
    ck("LIBRARY_CEILING_CLASSIFICATION","eligible_rate_library_max_A" in s and "GRAPH_EXHAUSTION_BELOW_LIBRARY_CEILING" in s)
    pys=sorted((ROOT/"SOURCE").glob("*.py"))
    for q in pys:py_compile.compile(str(q),doraise=True)
    print("PYTHON_COMPILE",f"{len(pys)}/{len(pys)}","PASS")
    bad=[];n=0
    for line in (ROOT/"MANIFEST.sha256").read_text().splitlines():
        if line.strip():
            h,rel=line.split("  ",1);n+=1;q=ROOT/rel
            if not q.is_file() or sha(q)!=h:bad.append(rel)
    ck(f"PACKAGE_MANIFEST {n-len(bad)}/{n}",not bad)
    print("R08_UNCAPPED_FRONTIER_STATIC_VERIFY PASS")
if __name__=="__main__":main()
