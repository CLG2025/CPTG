from __future__ import annotations
import csv,json,importlib.metadata
from collections import defaultdict,deque
import numpy as np
import pynucastro as pyna
from common import *

LIGHT_TUPLES=set(LIGHT)

def nt(n):return int(n.A),int(n.Z)

def select_rates():
    rl=pyna.ReacLibLibrary();caps=[];betas=[];nodes=set()
    for r in rl.get_rates():
        rea=[nt(x) for x in r.reactants];pro=[nt(x) for x in r.products]
        if not r.weak and len(rea)==2 and len(pro)==1:
            ls=[x for x in rea if x in LIGHT_TUPLES]
            if len(ls)==1:
                l=ls[0];h=rea[1] if rea[0]==l else rea[0];d=pro[0]
                if h[0]>=6 and d==(h[0]+l[0],h[1]+l[1]):
                    caps.append((h,l,d,r));nodes.add(h);nodes.add(d)
        if r.weak and getattr(r,"weak_type",None)=="beta_neg" and len(rea)==1 and len(pro)==1:
            s,d=rea[0],pro[0]
            if s[0]>=6 and d[0]==s[0] and d[1]==s[1]+1:
                betas.append((s,d,r));nodes.add(s);nodes.add(d)
    caps.sort(key=lambda x:(x[0],x[1],x[2],str(x[3])))
    betas.sort(key=lambda x:(x[0],x[1],str(x[2])))
    return caps,betas,nodes

def native_sets():
    sets=[]
    for eta in ETA:
        z=np.load(OUTPUT/f"NATIVE_TRAJECTORIES/PRIMAT_NATIVE_TRAJECTORY_ETA{eta_tag(eta)}.npz")
        names=[str(x) for x in z["species"]]
        sets.append(set(parse_primat_name(n) for n in names))
    if any(s!=sets[0] for s in sets[1:]):raise RuntimeError("native species set differs across eta anchors")
    return sets[0]

def main():
    if importlib.metadata.version("pynucastro")!="2.11.0":raise RuntimeError("pynucastro 2.11.0 required")
    if sha_file(OUTPUT/"NATIVE_TRAJECTORY_FREEZE.json")!="97fd7b4f4f4e7466be9e45be264e62faade5b55e80d415201ed4390405080f9a":
        raise RuntimeError("native freeze mismatch")
    if load_json(EVIDENCE/"AUTHORITY_ADOPTION.json").get("pass") is not True:raise RuntimeError("adoption required")
    native=native_sets();caps,betas,eligible_nodes=select_rates()
    src=[(h,l,d,r) for h,l,d,r in caps if h in native and d not in native and d[0]>=24]
    seeds={d for h,l,d,r in src}
    if not seeds:raise RuntimeError("no boundary seeds")
    cb=defaultdict(list);bb=defaultdict(list)
    for h,l,d,r in caps:
        if h[0]>=24:cb[h].append((d,l,r))
    for s,d,r in betas:
        if s[0]>=24:bb[s].append((d,r))
    seen=set(seeds);q=deque(sorted(seeds));edge_rows=[]
    while q:
        s=q.popleft()
        for d,l,r in cb.get(s,[]):
            edge_rows.append(("capture",s,l,d,str(r)))
            if d not in seen:seen.add(d);q.append(d)
        for d,r in bb.get(s,[]):
            edge_rows.append(("beta_minus",s,None,d,str(r)))
            if d not in seen:seen.add(d);q.append(d)
    reachable=sorted(seen,key=lambda x:(x[0],x[1]))
    maxA=max(a for a,z in reachable); maxZ=max(z for a,z in reachable)
    libmax=max(a for a,z in eligible_nodes)
    mass_counts={A:0 for A in range(24,maxA+1)}
    for A,Z in reachable:
        if A>=24:mass_counts[A]+=1
    gaps=[A for A,c in mass_counts.items() if c==0]
    first_gap=gaps[0] if gaps else None
    decision="GAP_FREE_TO_FRONTIER" if not gaps else "FIRST_GAP_FOUND"
    cause="RELEVANT_LIBRARY_CEILING" if maxA==libmax else "GRAPH_EXHAUSTION_BELOW_LIBRARY_CEILING"
    frontier=[(A,Z) for A,Z in reachable if A==maxA]
    # Frontier outgoing eligible edges; none can create a new reachable node or BFS would include it.
    f_out=[]
    for s in frontier:
        for d,l,r in cb.get(s,[]):f_out.append(("capture",s,l,d,str(r),d in seen))
        for d,r in bb.get(s,[]):f_out.append(("beta_minus",s,None,d,str(r),d in seen))
    RESULTS.mkdir(parents=True,exist_ok=True);EVIDENCE.mkdir(parents=True,exist_ok=True)
    with (RESULTS/"UNCAPPED_MASS_SECTOR_CENSUS.csv").open("w",newline="",encoding="utf-8") as f:
        w=csv.writer(f);w.writerow(["A","reachable_nuclide_count","gap"])
        for A,c in mass_counts.items():w.writerow([A,c,c==0])
    with (RESULTS/"UNCAPPED_REACHABLE_NUCLIDES.csv").open("w",newline="",encoding="utf-8") as f:
        w=csv.writer(f);w.writerow(["nuclide","A","Z","frontier"])
        for A,Z in reachable:w.writerow([az_name(A,Z),A,Z,A==maxA])
    with (RESULTS/"UNCAPPED_REACHABLE_EDGES.csv").open("w",newline="",encoding="utf-8") as f:
        w=csv.writer(f);w.writerow(["kind","src","light","dst","rate"])
        for kind,s,l,d,r in edge_rows:w.writerow([kind,az_name(*s),az_name(*l) if l else "",az_name(*d),r])
    out={"schema":"cptg-r08-uncapped-frontier-result-v1","decision":decision,
         "frontier_cause":cause,"boundary_source_edges":len(src),"boundary_seed_nuclides":len(seeds),
         "reachable_nuclides":len(reachable),"reachable_edges_traversed":len(edge_rows),
         "reachable_max_A":maxA,"reachable_max_Z":maxZ,"eligible_rate_library_max_A":libmax,
         "first_gap_A":first_gap,"all_gap_A":gaps,"frontier_nuclides":[az_name(*x) for x in frontier],
         "frontier_nuclide_count":len(frontier),"frontier_outgoing_eligible_edges":[
             {"kind":k,"src":az_name(*s),"light":az_name(*l) if l else None,"dst":az_name(*d),"rate":r,"destination_reachable":dr}
             for k,s,l,d,r,dr in f_out],
         "artificial_Amax_used":False,"artificial_seed_or_floor_used":False,
         "historical_postsilicon_numerical_inputs":0}
    atomic_json(EVIDENCE/"UNCAPPED_STRUCTURAL_FRONTIER.json",out)
    print("R08_FRESH_REACLIB",len(caps),"CAPTURES",len(betas),"BETA_MINUS")
    print("R08_BOUNDARY_SOURCE_EDGES",len(src))
    print("R08_REACHABLE_NUCLIDES",len(reachable))
    print("R08_REACHABLE_EDGES",len(edge_rows))
    print("R08_REACHABLE_MAX_A",maxA)
    print("R08_ELIGIBLE_RATE_LIBRARY_MAX_A",libmax)
    print("R08_FIRST_GAP_A",first_gap)
    print("R08_FRONTIER_CAUSE",cause)
    print("R08_UNCAPPED_STRUCTURAL_FRONTIER",decision)
if __name__=="__main__":main()
