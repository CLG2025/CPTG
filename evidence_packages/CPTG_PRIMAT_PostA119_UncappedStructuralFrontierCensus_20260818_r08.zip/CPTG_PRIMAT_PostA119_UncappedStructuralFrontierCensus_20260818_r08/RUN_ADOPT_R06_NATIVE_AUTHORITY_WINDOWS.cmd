@echo off
setlocal
cd /d "%~dp0"
"D:\Downloads\ChatGPT\cptg-cmb-like\Scripts\python.exe" -u SOURCE\adopt_r06_native_authority.py
exit /b %ERRORLEVEL%
