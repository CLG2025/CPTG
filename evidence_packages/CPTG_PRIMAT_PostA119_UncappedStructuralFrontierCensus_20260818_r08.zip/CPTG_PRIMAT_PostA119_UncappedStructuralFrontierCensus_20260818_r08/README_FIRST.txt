# CPTG PRIMAT Uncapped Structural Frontier Census — r08

This package removes the arbitrary external mass ceiling.

It performs **no heavy-abundance integration**. It asks only how far the frozen reaction
rules can propagate structurally through a fresh ReacLib 2.11.0 graph starting from the
same native PRIMAT boundary.

No A=160, A=200, or other artificial `Amax` is imposed.

Frozen native trajectory:
`97fd7b4f4f4e7466be9e45be264e62faade5b55e80d415201ed4390405080f9a`

## Windows

```cmd
cd /d D:\Downloads\CPTG_PRIMAT_PostA119_UncappedStructuralFrontierCensus_20260818_r08
RUN_STATIC_VERIFY_WINDOWS.cmd
RUN_ADOPT_R06_NATIVE_AUTHORITY_WINDOWS.cmd
RUN_UNCAPPED_FRONTIER_CENSUS_WINDOWS.cmd
```

Required static ending:

```text
PACKAGE_MANIFEST 10/10 PASS
R08_UNCAPPED_FRONTIER_STATIC_VERIFY PASS
```

Required adoption:

```text
R08_AUTHORITY_ADOPTION PASS
FREEZE_SHA256 97fd7b4f4f4e7466be9e45be264e62faade5b55e80d415201ed4390405080f9a
NUMERICAL_ENDPOINT_RESULTS_IMPORTED False
```

The census then reports:

```text
R08_REACHABLE_MAX_A <value>
R08_ELIGIBLE_RATE_LIBRARY_MAX_A <value>
R08_FIRST_GAP_A <None|value>
R08_FRONTIER_CAUSE <RELEVANT_LIBRARY_CEILING|GRAPH_EXHAUSTION_BELOW_LIBRARY_CEILING>
R08_UNCAPPED_STRUCTURAL_FRONTIER <GAP_FREE_TO_FRONTIER|FIRST_GAP_FOUND>
```

This result determines the next numerical-frontier campaign.

`FUTURE_VALIDATION_QUEUE.md` explicitly preserves the source-tail truncation and 14-edge
ablation test as a mandatory later diagnostic.
