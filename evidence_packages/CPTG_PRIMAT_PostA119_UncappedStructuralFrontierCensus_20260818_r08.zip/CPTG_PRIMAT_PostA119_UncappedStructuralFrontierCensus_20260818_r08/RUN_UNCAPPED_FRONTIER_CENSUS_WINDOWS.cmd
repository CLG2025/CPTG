@echo off
setlocal
cd /d "%~dp0"
set "PYTHONDONTWRITEBYTECODE=1"
"D:\Downloads\CPTG_PRIMAT_A1A119_TRANSPORT_ENV_r02\Scripts\python.exe" -u SOURCE\run_uncapped_frontier_census.py
exit /b %ERRORLEVEL%
