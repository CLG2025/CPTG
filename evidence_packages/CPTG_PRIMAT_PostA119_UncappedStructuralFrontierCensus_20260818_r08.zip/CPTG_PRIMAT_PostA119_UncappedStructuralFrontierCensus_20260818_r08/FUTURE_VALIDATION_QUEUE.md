# Required Future Validation Queue

The **source-tail truncation / boundary-source ablation diagnostic remains mandatory**.

After the uncapped census identifies the structural frontier and after numerical validation
is extended into that region, run a separate preregistered campaign that:

- truncates the total native boundary source at frozen relative thresholds over several decades;
- removes each of the 14 native-to-external boundary edges one at a time;
- tracks A=24, 28, 40, 56, 80, 100, 119, 120, 140, 160, and frontier-selected sectors;
- reports both absolute amplitude sensitivity and whether structural support survives;
- uses no artificial seed, abundance floor, or replacement source.

This diagnostic is not optional for deep-tail amplitude claims.
