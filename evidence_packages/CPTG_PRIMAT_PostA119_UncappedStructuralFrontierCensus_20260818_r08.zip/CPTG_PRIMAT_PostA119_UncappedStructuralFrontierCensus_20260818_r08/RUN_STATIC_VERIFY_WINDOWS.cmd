@echo off
setlocal
cd /d "%~dp0"
"D:\Downloads\ChatGPT\cptg-cmb-like\Scripts\python.exe" -u SOURCE\static_verify.py
exit /b %ERRORLEVEL%
