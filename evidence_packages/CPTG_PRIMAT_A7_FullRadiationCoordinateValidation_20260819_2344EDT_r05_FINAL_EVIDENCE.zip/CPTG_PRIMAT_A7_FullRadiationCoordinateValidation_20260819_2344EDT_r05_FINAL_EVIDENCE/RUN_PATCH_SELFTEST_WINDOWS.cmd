@echo off
setlocal
set "PYTHONUTF8=1"
set "PYTHONIOENCODING=utf-8"
set "PYTHONUNBUFFERED=1"
cd /d "%~dp0"
set "PYTHON_EXE=D:\Downloads\ChatGPT\cptg-cmb-like\Scripts\python.exe"
if not exist "%PYTHON_EXE%" set "PYTHON_EXE=python"
"%PYTHON_EXE%" SOURCE\patch_selftest.py
exit /b %ERRORLEVEL%
