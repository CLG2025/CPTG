from __future__ import annotations
import ast
from prepare_patched_primat import patch_text
# Exact structural form of PRIMAT v0.3.2 _solve_LT anchors (surrounding code reduced only for self-test).
sample="""import os\nimport numpy as np\nclass X:\n    def _solve_LT(self, t_nucl, t_end, mt_final_raw, _show):\n        cfg        = self.cfg\n        background = self.background\n        nucl       = self.nucl\n        T_of_t     = background.T_of_t\n        rhoB_BBN   = background.rhoB_BBN\n        nTOp_frwrd = background.weak_nTOp_frwrd\n        nTOp_bkwrd = background.weak_nTOp_bkwrd\n        T_nucl_MeV = cfg.T_nucl / cfg.MeV_to_Kelvin\n\n        def Y_prime_LT(t, Y):\n            rho = rhoB_BBN(t); T_K = T_of_t(t)*cfg.MeV_to_Kelvin\n            return nucl.rhsLT(Y, T_K, rho, nTOp_frwrd, nTOp_bkwrd)\n\n        def Jacobian_LT(t, Y):\n            rho = rhoB_BBN(t); T_K = T_of_t(t)*cfg.MeV_to_Kelvin\n            return nucl.JacobianLT(Y, T_K, rho, nTOp_frwrd, nTOp_bkwrd)\n        species_L = nucl.species_large\n        Yi_LT = [mt_final_raw.get(s, 0.0) for s in species_L]\n        atol = cfg.atol_large_LT\n        sol_LT = solve_ivp(Y_prime_LT, [t_nucl, t_end], Yi_LT,\n                           method='BDF', jac=Jacobian_LT,\n                           rtol=10.*cfg.numerical_precision, atol=atol)\n        return sol_LT, {}\n"""
out,rep=patch_text(sample); ast.parse(out)
assert rep['rhs_replacements']==1 and rep['jacobian_replacements']==1 and rep['solve_posthook_replacements']==1
assert rep['direct_species']==['Li7','Be7']
assert out.count('_cptg_rhs[_cptg_i_li7] -=')==1 and out.count('_cptg_rhs[_cptg_i_be7] -=')==1
assert out.count('_cptg_J[_cptg_i_li7, _cptg_i_li7] -=')==1 and out.count('_cptg_J[_cptg_i_be7, _cptg_i_be7] -=')==1
assert '_cptg_gamma_from_TK(T_K, "rhs")' in out and '_cptg_gamma_from_TK(T_K, "jacobian")' in out
assert 'background.t_of_T(_cptg_gate_T_high_MeV)' in out and 'T_of_t(_cptg_ts)' in out
assert '0.0175' in out and '0.0040' in out and 'np.log(np.pi)' in out
print('A7_RADIATION_SOURCE_PATCH_SELFTEST PASS')
print('A7_EXACT_V032_LT_CONTRACT_SELFTEST PASS')
