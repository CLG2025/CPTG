from __future__ import annotations
import json, shutil, tempfile, zipfile, hashlib
from pathlib import Path
from common import ROOT, sha256_file
from evidence_manifest import write_manifest, verify_manifest
RELEASE_ID='20260819_2344EDT_r05'
resultp=ROOT/'RESULTS'/'A7_FULL_RADIATION_VALIDATION.json'
if not resultp.exists(): raise RuntimeError('result object missing; cannot seal')
result=json.loads(resultp.read_text(encoding='utf-8'))
stage=Path(tempfile.mkdtemp(prefix='cptg_a7_radiation_seal_'))
top=stage/f'CPTG_PRIMAT_A7_FullRadiationCoordinateValidation_{RELEASE_ID}_FINAL_EVIDENCE'
top.mkdir()
for d in ['CONFIG','SOURCE','EVIDENCE','OUTPUT','RESULTS','TRANSCRIPTS']:
    src=ROOT/d
    if src.exists():
        shutil.copytree(src,top/d,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
for f in ROOT.glob('RUN_*_WINDOWS.cmd'): shutil.copy2(f,top/f.name)
for f in ['README_FIRST.txt','RELEASE_NOTES.txt','SCIENTIFIC_PROTOCOL.md','THEORY_AUTHORITY.md']:
    if (ROOT/f).exists(): shutil.copy2(ROOT/f,top/f)
(top/'DECISION.txt').write_text(f"A7_PRIMAT_FULL_RADIATION_COORDINATE_VALIDATION {result['decision']}\n",encoding='utf-8',newline='\n')
manifest_count=write_manifest(top,top/'MANIFEST.sha256')
print('A7_RADIATION_MANIFEST_WRITE PASS')
print('A7_RADIATION_MANIFEST_ENTRIES',manifest_count)
if verify_manifest(top,top/'MANIFEST.sha256') != manifest_count:
    raise RuntimeError('prearchive manifest verification count mismatch')
print('A7_RADIATION_MANIFEST_VERIFY PASS')
out=ROOT.parent/f'CPTG_PRIMAT_A7_FullRadiationCoordinateValidation_{RELEASE_ID}_FINAL_EVIDENCE.zip'
with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted(top.rglob('*')):
        if p.is_file(): z.write(p,p.relative_to(stage).as_posix())
# Reopen the archive and independently verify the embedded manifest and every referenced member.
with zipfile.ZipFile(out,'r') as z:
    names=z.namelist()
    prefix=f'CPTG_PRIMAT_A7_FullRadiationCoordinateValidation_{RELEASE_ID}_FINAL_EVIDENCE/'
    mname=prefix+'MANIFEST.sha256'
    if mname not in names: raise RuntimeError('embedded manifest missing')
    raw=z.read(mname)
    if b'\\n' in raw: raise RuntimeError('embedded manifest contains literal backslash-n separators')
    lines=raw.decode('utf-8').splitlines()
    if len(lines)!=manifest_count: raise RuntimeError('embedded manifest entry count mismatch')
    for line in lines:
        expected,rel=line.split('  ',1)
        member=prefix+rel
        if member not in names: raise RuntimeError(f'embedded manifest member missing: {rel}')
        got=hashlib.sha256(z.read(member)).hexdigest()
        if got!=expected: raise RuntimeError(f'embedded manifest hash mismatch: {rel}')
print('A7_RADIATION_ARCHIVE_MANIFEST_VERIFY PASS')
h=sha256_file(out)
(out.with_suffix(out.suffix+'.sha256.txt')).write_text(f"{h}  {out.name}\n",encoding='utf-8',newline='\n')
print('A7_RADIATION_EVIDENCE_SEAL',result['decision'])
print('EVIDENCE_ZIP',out)
print('EVIDENCE_SHA256',h)
shutil.rmtree(stage,ignore_errors=True)
