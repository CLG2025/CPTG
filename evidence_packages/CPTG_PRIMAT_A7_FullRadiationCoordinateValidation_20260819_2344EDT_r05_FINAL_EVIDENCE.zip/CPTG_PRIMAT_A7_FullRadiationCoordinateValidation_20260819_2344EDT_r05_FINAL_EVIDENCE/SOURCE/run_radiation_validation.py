from __future__ import annotations
import json, os, subprocess, sys
from pathlib import Path
from common import ROOT, MAPPING, load_config, prereg_sha, sha256_file
cfg=load_config(); pr=prereg_sha()
patch_parent=ROOT/'WORK'/'primat_patched'; cache_dir=ROOT/'WORK'/'primat_cache'
prov_path=ROOT/'EVIDENCE'/'PATCH_PROVENANCE.json'
if not prov_path.exists(): raise RuntimeError('Run RUN_PREPARE_PATCHED_PRIMAT_WINDOWS.cmd first')
prov=json.loads(prov_path.read_text(encoding='utf-8'))
if prov.get('prereg_sha256')!=pr: raise RuntimeError('patch provenance prereg mismatch')
patch_sha=prov['patched_nuclear_network_sha256']
# Runtime directory scaffolding is created explicitly so a fresh ZIP extraction
# does not depend on empty-directory preservation by the archive tool.
for _d in (
    ROOT/'TRANSCRIPTS',
    ROOT/'OUTPUT'/'CALIBRATION',
    ROOT/'OUTPUT'/'TARGET',
    ROOT/'OUTPUT'/'GATE_DIAGNOSTICS',
    ROOT/'RESULTS',
    ROOT/'EVIDENCE',
    ROOT/'WORK',
    cache_dir,
):
    _d.mkdir(parents=True,exist_ok=True)
transcript=ROOT/'TRANSCRIPTS'/'RADIATION_VALIDATION_PRODUCTION_TRANSCRIPT.txt'
def tee_run(cmd):
    with transcript.open('a',encoding='utf-8') as tf:
        tf.write('\\n$ '+' '.join(str(x) for x in cmd)+'\\n'); tf.flush()
        child_env=os.environ.copy()
        child_env['PYTHONUTF8']='1'
        child_env['PYTHONIOENCODING']='utf-8'
        child_env['PYTHONUNBUFFERED']='1'
        p=subprocess.Popen(cmd,cwd=str(ROOT),env=child_env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,
                           text=True,encoding='utf-8',errors='replace',bufsize=1)
        assert p.stdout is not None
        for line in p.stdout:
            print(line,end='',flush=True); tf.write(line); tf.flush()
        rc=p.wait()
        if rc: raise subprocess.CalledProcessError(rc,cmd)
def row(output,label,delta,phase,mode='baseline',diag='',mapping_sha=''):
    op=Path(output)
    if op.exists():
        try:
            old=json.loads(op.read_text(encoding='utf-8'))
            same=(old.get('prereg_sha256')==pr and old.get('phase')==phase and old.get('mode')==mode
                  and old.get('patched_nuclear_network_sha256')==patch_sha
                  and abs(float(old.get('Omegabh2'))-float(cfg['cptg_coordinate']['Omegabh2_BBN_PRIMAT_input']))<1e-16
                  and abs(float(old.get('DeltaNeff'))-float(delta))<1e-15
                  and (old.get('mapping_sha256') or '')==(mapping_sha or ''))
            if same and (mode!='gated' or Path(diag).exists()):
                print('A7_RADIATION_ROW_REUSE',phase,label,mode); return
        except Exception: pass
    cmd=[sys.executable,str(ROOT/'SOURCE'/'run_one.py'),
         '--eta',str(cfg['cptg_coordinate']['eta10_BBN_reference']),
         '--omega',str(cfg['cptg_coordinate']['Omegabh2_BBN_PRIMAT_input']),
         '--delta-neff',str(delta),'--label',label,'--phase',phase,'--mode',mode,
         '--output',str(op),'--diag',str(diag),'--prereg-sha',pr,'--mapping-sha',mapping_sha,
         '--patch-parent',str(patch_parent),'--expected-patch-sha',patch_sha,'--cache-dir',str(cache_dir)]
    tee_run(cmd)
# Fresh native radiation-coordinate calibration. Only Neff is consumed by the mapping stage.
mc=cfg['radiation_mapping_preregistration']
row(ROOT/'OUTPUT'/'CALIBRATION'/'RADIATION_CAL_ZERO.json','RADIATION_CAL_ZERO',mc['calibration_DeltaNeff_zero'],'calibration')
row(ROOT/'OUTPUT'/'CALIBRATION'/'RADIATION_CAL_PROBE.json','RADIATION_CAL_PROBE',mc['calibration_probe_DeltaNeff'],'calibration')
tee_run([sys.executable,str(ROOT/'SOURCE'/'derive_radiation_mapping.py')])
mapping=json.loads(MAPPING.read_text(encoding='utf-8')); mapping_sha=sha256_file(MAPPING)
delta=float(mapping['DeltaNeff_CPTG_frozen'])
row(ROOT/'OUTPUT'/'TARGET'/'CPTG_FULL_COORDINATE_baseline.json','CPTG_FULL_COORDINATE',delta,'target','baseline','',mapping_sha)
row(ROOT/'OUTPUT'/'TARGET'/'CPTG_FULL_COORDINATE_gated.json','CPTG_FULL_COORDINATE',delta,'target','gated',
    ROOT/'OUTPUT'/'GATE_DIAGNOSTICS'/'CPTG_FULL_COORDINATE_gate.json',mapping_sha)
print('A7_FULL_RADIATION_NATIVE_ROWS COMPLETE 4')
