from __future__ import annotations
import argparse, json, os, sys, time, importlib.metadata
from pathlib import Path
# Windows cmd.exe commonly starts Python with cp1252 stdout/stderr. PRIMAT v0.3.2
# prints a Unicode banner during PRIMAT() construction, so force UTF-8 before run_bbn.
for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding='utf-8', errors='replace')
    except (AttributeError, ValueError):
        pass
p=argparse.ArgumentParser()
p.add_argument('--eta',type=float,required=True)
p.add_argument('--omega',type=float,required=True)
p.add_argument('--delta-neff',type=float,required=True)
p.add_argument('--label',required=True)
p.add_argument('--mode',choices=['baseline','gated'],required=True)
p.add_argument('--phase',choices=['calibration','target'],required=True)
p.add_argument('--output',required=True)
p.add_argument('--diag',default='')
p.add_argument('--prereg-sha',required=True)
p.add_argument('--mapping-sha',default='')
p.add_argument('--patch-parent',required=True)
p.add_argument('--expected-patch-sha',required=True)
p.add_argument('--cache-dir',required=True)
a=p.parse_args()
patch_parent=Path(a.patch_parent).resolve(); sys.path.insert(0,str(patch_parent))
# Create all per-row writable parents before the native solve begins.
output_path=Path(a.output).resolve(); output_path.parent.mkdir(parents=True,exist_ok=True)
cache_path=Path(a.cache_dir).resolve(); cache_path.mkdir(parents=True,exist_ok=True)
os.environ['CPTG_A7_GATE_ENABLED']='1' if a.mode=='gated' else '0'
if a.mode=='gated':
    if not a.diag:
        raise RuntimeError('gated mode requires --diag')
    diag_path=Path(a.diag).resolve(); diag_path.parent.mkdir(parents=True,exist_ok=True)
    os.environ['CPTG_A7_DIAGNOSTIC_FILE']=str(diag_path)
else:
    os.environ.pop('CPTG_A7_DIAGNOSTIC_FILE',None)
import primat
import primat.nuclear_network as _nn
from primat.backend import run_bbn
primat_file=Path(primat.__file__).resolve(); nn_file=Path(_nn.__file__).resolve()
try:
    primat_file.relative_to(patch_parent); nn_file.relative_to(patch_parent)
except ValueError:
    raise RuntimeError(f'patched import proof failed: primat={primat_file} nuclear_network={nn_file} expected under {patch_parent}')
def _sha(p):
    import hashlib; h=hashlib.sha256()
    with open(p,'rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()
patch_sha=_sha(nn_file)
if patch_sha != a.expected_patch_sha: raise RuntimeError(f'patched source hash mismatch {patch_sha} != {a.expected_patch_sha}')
params={
 'strict_params':True,'Omegabh2':a.omega,'DeltaNeff':a.delta_neff,'network':'large','amax':None,
 'numerical_precision':1e-10,'sampling_temperature_per_decade':600,
 'rate_grid_npts':4000,'rate_grid_T9_min':1e-3,'rate_grid_T9_max':10.0,
 'tau_n_normalization':True,'tau_n':878.4,
 'incomplete_decoupling':True,'QED_corrections':True,'spectral_distortions':True,
 'radiative_corrections':True,'finite_mass_corrections':True,'thermal_corrections':True,
 'nuclear_qed_corrections':True,'cache_dir':str(cache_path),
 'output_time_evolution':False,'output_final_result':False,'output_background_evolution':False,'verbose':True
}
t0=time.time(); res=run_bbn(params,force_backend='python'); sec=time.time()-t0
Y={k:float(v) for k,v in res.get('Y_final',{}).items()}
if 'Li7' not in Y or 'Be7' not in Y: raise RuntimeError('PRIMAT result missing Li7/Be7 Y_final coordinates')
y7=Y['Li7']+Y['Be7']
standard={k:float(res[k]) for k in ['YPBBN','DoH','He3oH','Li7oH','Neff'] if k in res}
if set(standard) != {'YPBBN','DoH','He3oH','Li7oH','Neff'}: raise RuntimeError(f'missing standard output: {standard.keys()}')
from datetime import datetime, timezone
out={'schema':'cptg-primat-a7-full-radiation-row-v1',
     'created_utc':datetime.now(timezone.utc).isoformat(),
     'prereg_sha256':a.prereg_sha,'mapping_sha256':a.mapping_sha or None,
     'phase':a.phase,'label':a.label,'eta10_reference_coordinate':a.eta,
     'eta10_runtime_semantics':'reference metadata only; PRIMAT runtime input is Omegabh2',
     'Omegabh2':a.omega,'DeltaNeff':a.delta_neff,'mode':a.mode,
     'primat_version':importlib.metadata.version('primat'),'runtime_seconds':sec,'params':params,
     'force_backend':'python','imported_primat_file':str(primat_file),
     'imported_nuclear_network_file':str(nn_file),'patched_nuclear_network_sha256':patch_sha,
     'standard':standard,'Y7_internal':y7,'Y_final':Y,
     'gate_diagnostic_file':a.diag if a.mode=='gated' else None}
path=output_path
path.write_text(json.dumps(out,indent=2,sort_keys=True)+'\n',encoding='utf-8')
print('A7_RADIATION_ROW_COMMIT',a.phase,a.label,a.mode,'DeltaNeff',format(a.delta_neff,'.17g'),
      'Neff',format(standard['Neff'],'.17g'),'Y7',format(y7,'.17e'),
      'Li7oH',format(standard['Li7oH'],'.17e'),'SECONDS',format(sec,'.3f'),flush=True)
