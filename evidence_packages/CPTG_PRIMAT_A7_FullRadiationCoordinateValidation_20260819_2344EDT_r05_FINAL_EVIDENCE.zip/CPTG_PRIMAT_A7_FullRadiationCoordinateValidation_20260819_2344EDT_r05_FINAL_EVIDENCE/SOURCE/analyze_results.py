from __future__ import annotations
import csv, json, math
from datetime import datetime
from pathlib import Path
from common import ROOT, MAPPING, load_config, prereg_sha, rel, finite_nonnegative_dict, write_json, sha256_file, utc_now
cfg=load_config(); pr=prereg_sha(); g=cfg['hard_gates']; target=float(cfg['theory_lock']['survival_target_numeric']); lnpi=math.log(math.pi)
required=[ROOT/'OUTPUT'/'CALIBRATION'/'RADIATION_CAL_ZERO.json',
          ROOT/'OUTPUT'/'CALIBRATION'/'RADIATION_CAL_PROBE.json',
          MAPPING,
          ROOT/'OUTPUT'/'TARGET'/'CPTG_FULL_COORDINATE_baseline.json',
          ROOT/'OUTPUT'/'TARGET'/'CPTG_FULL_COORDINATE_gated.json',
          ROOT/'OUTPUT'/'GATE_DIAGNOSTICS'/'CPTG_FULL_COORDINATE_gate.json',
          ROOT/'EVIDENCE'/'PATCH_PROVENANCE.json']
missing=[str(p) for p in required if not p.exists()]
if missing:
    out={'schema':'cptg-primat-a7-full-radiation-result-v1','created_utc':utc_now(),'decision':'NOT_QUALIFIED','missing':missing}
    write_json(ROOT/'RESULTS'/'A7_FULL_RADIATION_VALIDATION.json',out)
    print('A7_FULL_RADIATION_VALIDATION NOT_QUALIFIED missing inputs'); raise SystemExit(2)
z=json.loads(required[0].read_text()); p=json.loads(required[1].read_text())
m=json.loads(MAPPING.read_text()); b=json.loads(required[3].read_text()); q=json.loads(required[4].read_text()); d=json.loads(required[5].read_text())
prov=json.loads(required[6].read_text()); mapping_sha=sha256_file(MAPPING)
installed=Path(prov['installed_package_root'])
source_unchanged=(sha256_file(installed/'nuclear_network.py')==prov['installed_nuclear_network_sha256_before']
                  and sha256_file(installed/'background.py')==prov['installed_background_sha256_before']
                  and sha256_file(installed/'config.py')==prov['installed_config_sha256_before']
                  and bool(prov.get('installed_source_unmodified')))
slope=float(m['empirical_dNeff_dDeltaNeff']); neff_target=float(cfg['cptg_coordinate']['Neff_CPTG_target'])
ysur=float(q['Y7_internal'])/float(b['Y7_internal']); lsur=float(q['standard']['Li7oH'])/float(b['standard']['Li7oH'])
obs=cfg['observational_controls']
d_pull=(float(b['standard']['DoH'])-float(obs['DoH_central']))/float(obs['DoH_sigma'])
yp_pull=(float(b['standard']['YPBBN'])-float(obs['YP_central']))/float(obs['YP_sigma'])
li_pull=(float(q['standard']['Li7oH'])-float(obs['Li7oH_central']))/float(obs['Li7oH_sigma'])
stats=d.get('runtime_stats',{})
def parse_dt(s): return datetime.fromisoformat(s.replace('Z','+00:00'))
metrics={
 'mapping_slope':slope,
 'mapping_slope_abs_error_to_unity':abs(slope-1.0),
 'DeltaNeff_CPTG_frozen':float(m['DeltaNeff_CPTG_frozen']),
 'baseline_Neff':float(b['standard']['Neff']),
 'gated_Neff':float(q['standard']['Neff']),
 'baseline_Neff_abs_error_to_target':abs(float(b['standard']['Neff'])-neff_target),
 'gated_Neff_abs_error_to_target':abs(float(q['standard']['Neff'])-neff_target),
 'Neff_gated_vs_baseline_relchange':rel(q['standard']['Neff'],b['standard']['Neff']),
 'Y7_survival':ysur,'Y7_survival_relerr':rel(ysur,target),
 'Li7oH_survival':lsur,'Li7oH_survival_relerr':rel(lsur,target),
 'DoH_relchange':rel(q['standard']['DoH'],b['standard']['DoH']),
 'YPBBN_relchange':rel(q['standard']['YPBBN'],b['standard']['YPBBN']),
 'He3oH_relchange':rel(q['standard']['He3oH'],b['standard']['He3oH']),
 'baseline_DoH_observational_pull_sigma':d_pull,
 'baseline_YPBBN_observational_pull_sigma':yp_pull,
 'gated_Li7oH_observational_pull_sigma_diagnostic_only':li_pull,
 'tau_quad_relerr':rel(d['tau_check_quad'],lnpi),
 'tau_grid_relerr':rel(d['tau_check_independent_grid'],lnpi),
 'rhs_nonzero_gamma_calls':int(stats.get('rhs_nonzero_gamma_calls',0)),
 'jacobian_nonzero_gamma_calls':int(stats.get('jacobian_nonzero_gamma_calls',0))
}
mapping_before=(parse_dt(m['created_utc']) <= parse_dt(b['created_utc']) and parse_dt(m['created_utc']) <= parse_dt(q['created_utc']))
identity=(b.get('prereg_sha256')==pr and q.get('prereg_sha256')==pr and
          b.get('mapping_sha256')==mapping_sha and q.get('mapping_sha256')==mapping_sha and
          b.get('patched_nuclear_network_sha256')==prov['patched_nuclear_network_sha256'] and
          q.get('patched_nuclear_network_sha256')==prov['patched_nuclear_network_sha256'] and
          b.get('force_backend')=='python' and q.get('force_backend')=='python' and
          b.get('phase')=='target' and q.get('phase')=='target')
gates={
 'mapping_probe_slope':metrics['mapping_slope_abs_error_to_unity']<=g['mapping_probe_slope_abs_difference_from_unity_max'],
 'mapping_frozen_before_target':mapping_before,
 'row_identity_and_patched_import':identity,
 'baseline_Neff_target':metrics['baseline_Neff_abs_error_to_target']<=g['target_Neff_absolute_error_max'],
 'gated_Neff_target':metrics['gated_Neff_abs_error_to_target']<=g['target_Neff_absolute_error_max'],
 'Neff_gate_invariance':metrics['Neff_gated_vs_baseline_relchange']<=g['target_Neff_gated_vs_baseline_relative_change_max'],
 'Y7_survival':metrics['Y7_survival_relerr']<=g['mass7_survival_relative_error_to_1_over_pi_max'],
 'Li7oH_survival':metrics['Li7oH_survival_relerr']<=g['reported_Li7oH_survival_relative_error_to_1_over_pi_max'],
 'DoH_gate_selectivity':metrics['DoH_relchange']<=g['DoH_gated_vs_baseline_relative_change_max'],
 'YP_gate_selectivity':metrics['YPBBN_relchange']<=g['YPBBN_gated_vs_baseline_relative_change_max'],
 'He3_gate_selectivity':metrics['He3oH_relchange']<=g['He3oH_gated_vs_baseline_relative_change_max'],
 'native_DoH_observational_control':abs(d_pull)<=g['native_DoH_abs_observational_pull_max'],
 'native_YPBBN_observational_control':abs(yp_pull)<=g['native_YPBBN_abs_observational_pull_max'],
 'tau_quad':metrics['tau_quad_relerr']<=g['gate_quad_tau_relative_error_to_lnpi_max'],
 'tau_grid':metrics['tau_grid_relerr']<=g['gate_independent_grid_tau_relative_error_to_lnpi_max'],
 'rhs_gate_exercised':metrics['rhs_nonzero_gamma_calls']>=g['gate_rhs_nonzero_call_count_min'],
 'jacobian_gate_exercised':metrics['jacobian_nonzero_gamma_calls']>=g['gate_jacobian_nonzero_call_count_min'],
 'runtime_completed':d.get('runtime_completed') is True,
 'direct_rhs_species':d.get('direct_rhs_sink_species')==['Li7','Be7'],
 'direct_jac_species':d.get('direct_jacobian_sink_species')==['Li7','Be7'],
 'finite_nonnegative_baseline':finite_nonnegative_dict(b['Y_final']),
 'finite_nonnegative_gated':finite_nonnegative_dict(q['Y_final']),
 'installed_PRIMAT_source_unchanged':source_unchanged
}
passed=all(gates.values())
result={'schema':'cptg-primat-a7-full-radiation-result-v1','created_utc':utc_now(),
        'prereg_sha256':pr,'mapping_sha256':mapping_sha,'decision':'PASS' if passed else 'NOT_QUALIFIED',
        'scope':'CPTG transported Omegabh2 and CPTG Neff jointly implemented in PRIMAT, with locked live A7 transport tested gate-off/gate-on.',
        'mapping':m,'metrics':metrics,'gates':gates,
        'baseline_standard':b['standard'],'gated_standard':q['standard'],
        'observational_lithium_status':'diagnostic_only_not_a_gate'}
write_json(ROOT/'RESULTS'/'A7_FULL_RADIATION_VALIDATION.json',result)
with open(ROOT/'RESULTS'/'A7_FULL_RADIATION_RESULT.csv','w',newline='',encoding='utf-8') as f:
    w=csv.writer(f); w.writerow(['quantity','value'])
    for k,v in metrics.items(): w.writerow([k,v])
    for k,v in gates.items(): w.writerow(['GATE_'+k,v])
print('A7_RADIATION_MAPPING_SLOPE',format(slope,'.17g'))
print('A7_DELTA_NEFF_CPTG_FROZEN',format(metrics['DeltaNeff_CPTG_frozen'],'.17g'))
print('A7_TARGET_NEFF_BASELINE',format(metrics['baseline_Neff'],'.17g'),'ABSERR',format(metrics['baseline_Neff_abs_error_to_target'],'.6g'))
print('A7_NATIVE_BACKGROUND_CONTROLS','D_PULL',format(d_pull,'.6g'),'YP_PULL',format(yp_pull,'.6g'))
print('A7_FULL_COORDINATE_SURVIVAL',format(ysur,'.12g'),'RELERR',format(metrics['Y7_survival_relerr'],'.6g'))
print('A7_FULL_COORDINATE_LI7OH_GATED',format(q['standard']['Li7oH'],'.17e'),'OBS_PULL_DIAG',format(li_pull,'.6g'))
for k,v in gates.items(): print('A7_RADIATION_GATE',k,'PASS' if v else 'FAIL')
print('A7_FULL_CPTG_RADIATION_COORDINATE_IMPLEMENTED',True)
print('A7_PRIMAT_FULL_RADIATION_COORDINATE_VALIDATION',result['decision'])
if not passed: raise SystemExit(2)
