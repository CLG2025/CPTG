from __future__ import annotations
import ast, importlib.metadata, importlib.util
from pathlib import Path
from common import ROOT, load_config, prereg_sha, sha256_file, write_json, utc_now
from prepare_patched_primat import patch_text
cfg=load_config(); checks={}
try:
    v=importlib.metadata.version('primat')
    checks['version']=(v==cfg['primat_authority']['required_version'])
    spec=importlib.util.find_spec('primat')
    proot=Path(list(spec.submodule_search_locations)[0]).resolve() if spec and spec.submodule_search_locations else None
    checks['package_root']=bool(proot and proot.exists())
    nn=proot/'nuclear_network.py' if proot else None
    bg=proot/'background.py' if proot else None
    conf=proot/'config.py' if proot else None
    checks['required_sources']=bool(nn and bg and conf and nn.exists() and bg.exists() and conf.exists())
    text=nn.read_text(encoding='utf-8') if nn else ''
    patched,rep=patch_text(text); ast.parse(patched)
    checks['patch_contract']=(rep['rhs_replacements']==1 and rep['jacobian_replacements']==1 and rep['solve_posthook_replacements']==1 and rep['direct_species']==['Li7','Be7'])
    import numpy, scipy
    from primat.backend import run_bbn
    from primat.config import DEFAULT_PARAMS, PRIMATConfig
    checks['run_bbn_callable']=callable(run_bbn)
    checks['delta_neff_default_zero']=float(DEFAULT_PARAMS.get('DeltaNeff'))==0.0
    probe=PRIMATConfig({'strict_params':True,'DeltaNeff':-0.1})
    checks['negative_delta_neff_accepted']=abs(float(probe.DeltaNeff)+0.1)<1e-15
    checks['config_contains_delta_neff']=('"DeltaNeff"' in conf.read_text(encoding='utf-8'))
    out={'schema':'cptg-primat-a7-full-radiation-preflight-v1','created_utc':utc_now(),
         'prereg_sha256':prereg_sha(),'checks':checks,'primat_version':v,
         'installed_package_root':str(proot) if proot else None,
         'installed_source_sha256':{
             'nuclear_network.py':sha256_file(nn) if nn and nn.exists() else None,
             'background.py':sha256_file(bg) if bg and bg.exists() else None,
             'config.py':sha256_file(conf) if conf and conf.exists() else None}}
except Exception as e:
    checks['exception']=False
    out={'schema':'cptg-primat-a7-full-radiation-preflight-v1','created_utc':utc_now(),
         'prereg_sha256':prereg_sha(),'checks':checks,'exception':repr(e)}
write_json(ROOT/'EVIDENCE'/'PREFLIGHT.json',out)
for k,v in checks.items(): print('A7_RADIATION_PREFLIGHT',k,'PASS' if v else 'FAIL')
if not checks or not all(checks.values()): raise SystemExit(2)
print('A7_RADIATION_PREFLIGHT PASS')
print('PREREG_SHA256',prereg_sha())
