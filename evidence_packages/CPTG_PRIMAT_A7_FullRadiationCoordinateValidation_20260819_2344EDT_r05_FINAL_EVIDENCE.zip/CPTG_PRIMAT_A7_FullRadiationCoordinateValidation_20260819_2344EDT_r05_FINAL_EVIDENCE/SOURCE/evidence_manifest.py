from __future__ import annotations
import hashlib, tempfile
from pathlib import Path
from common import sha256_file

def build_manifest_lines(root: Path):
    root=Path(root)
    files=sorted(p for p in root.rglob('*') if p.is_file() and p.name!='MANIFEST.sha256')
    return [f"{sha256_file(p)}  {p.relative_to(root).as_posix()}" for p in files]

def verify_manifest(root: Path, manifest_path: Path):
    root=Path(root); manifest_path=Path(manifest_path)
    raw=manifest_path.read_bytes()
    if b'\\n' in raw:
        raise RuntimeError('manifest contains literal backslash-n separators')
    lines=raw.decode('utf-8').splitlines()
    if not lines:
        raise RuntimeError('manifest is empty')
    bad=[]
    for line in lines:
        if '  ' not in line:
            bad.append(('MALFORMED',line)); continue
        expected,rel=line.split('  ',1)
        p=root/rel
        if not p.exists():
            bad.append(('MISSING',rel)); continue
        got=sha256_file(p)
        if got!=expected:
            bad.append(('HASH',rel,expected,got))
    if bad:
        raise RuntimeError(f'manifest verification failed: {bad[:3]}')
    return len(lines)

def write_manifest(root: Path, manifest_path: Path):
    root=Path(root); manifest_path=Path(manifest_path)
    lines=build_manifest_lines(root)
    text='\n'.join(lines)+'\n'
    manifest_path.write_bytes(text.encode('utf-8'))
    raw=manifest_path.read_bytes()
    if raw.count(b'\n') != len(lines):
        raise RuntimeError('manifest physical-line count mismatch')
    if b'\\n' in raw:
        raise RuntimeError('manifest literal backslash-n serialization detected')
    count=verify_manifest(root,manifest_path)
    if count != len(lines):
        raise RuntimeError('manifest verification count mismatch')
    return count

def selftest_manifest_contract():
    td=Path(tempfile.mkdtemp(prefix='cptg_manifest_selftest_'))
    try:
        (td/'A.txt').write_text('alpha\n',encoding='utf-8',newline='\n')
        (td/'B.txt').write_text('beta\n',encoding='utf-8',newline='\n')
        mp=td/'MANIFEST.sha256'
        count=write_manifest(td,mp)
        raw=mp.read_bytes()
        return count==2 and raw.count(b'\n')==2 and b'\\n' not in raw and verify_manifest(td,mp)==2
    finally:
        import shutil
        shutil.rmtree(td,ignore_errors=True)
