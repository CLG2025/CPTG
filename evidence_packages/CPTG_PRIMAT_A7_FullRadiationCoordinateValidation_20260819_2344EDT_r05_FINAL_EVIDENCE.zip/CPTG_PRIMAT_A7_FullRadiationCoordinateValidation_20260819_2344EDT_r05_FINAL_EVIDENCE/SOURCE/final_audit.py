from __future__ import annotations
import json, subprocess, sys
from pathlib import Path
from common import ROOT, prereg_sha, sha256_file, utc_now, write_json
cmd=[sys.executable,str(ROOT/'SOURCE'/'analyze_results.py')]
audit_env=dict(__import__('os').environ)
audit_env['PYTHONUTF8']='1'; audit_env['PYTHONIOENCODING']='utf-8'; audit_env['PYTHONUNBUFFERED']='1'
p=subprocess.run(cmd,cwd=str(ROOT),text=True,encoding='utf-8',errors='replace',capture_output=True,env=audit_env)
text=(p.stdout or '')+(p.stderr or '')
transcript=ROOT/'TRANSCRIPTS'/'FINAL_AUDIT_TRANSCRIPT.txt'
transcript.parent.mkdir(parents=True,exist_ok=True)
transcript.write_text(text,encoding='utf-8')
print(text,end='')
res=ROOT/'RESULTS'/'A7_FULL_RADIATION_VALIDATION.json'
decision='NOT_QUALIFIED'
if res.exists():
    decision=json.loads(res.read_text(encoding='utf-8')).get('decision','NOT_QUALIFIED')
obj={'schema':'cptg-primat-a7-full-radiation-final-audit-v1','created_utc':utc_now(),
     'prereg_sha256':prereg_sha(),'result_sha256':sha256_file(res) if res.exists() else None,
     'analysis_returncode':p.returncode,'decision':decision}
write_json(ROOT/'EVIDENCE'/'FINAL_AUDIT.json',obj)
print('A7_RADIATION_FINAL_AUDIT',decision)
raise SystemExit(0 if decision=='PASS' and p.returncode==0 else 2)
