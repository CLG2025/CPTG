from __future__ import annotations
import json, py_compile
from pathlib import Path
from common import ROOT, load_config, prereg_sha, sha256_file
from evidence_manifest import selftest_manifest_contract
cfg=load_config(); checks={}
checks['schema']=cfg.get('schema')=='cptg-primat-a7-full-radiation-coordinate-validation-v1'
checks['coordinate']=cfg['cptg_coordinate']['eta10_BBN_reference']==5.998071834744 and cfg['cptg_coordinate']['Omegabh2_BBN_PRIMAT_input']==0.021898765370 and cfg['cptg_coordinate']['Neff_CPTG_target']==2.968584073464
checks['mapping_no_abundance_feedback']=cfg['radiation_mapping_preregistration']['target_endpoint_or_abundance_feedback_allowed'] is False
checks['mapping_probe']=cfg['radiation_mapping_preregistration']['calibration_probe_DeltaNeff']==0.01
checks['core_gate']=cfg['theory_lock']['optical_depth']=='integral Gamma7(t) dt = ln(pi)' and abs(cfg['theory_lock']['survival_target_numeric']-1/3.141592653589793)<1e-16
checks['direct_species']=cfg['theory_lock']['direct_sink_species']==['Li7','Be7']
checks['fixed_window']=cfg['theory_lock']['gate_shape']=='log_cosine' and cfg['theory_lock']['gate_T_high_MeV']==0.0175 and cfg['theory_lock']['gate_T_low_MeV']==0.004
checks['physics_profile']=all(cfg['primat_authority'].get(k) is True for k in ['strict_params','radiative_corrections','finite_mass_corrections','thermal_corrections','spectral_distortions','incomplete_decoupling','QED_corrections','tau_n_normalization','nuclear_qed_corrections'])
checks['no_retuning']=cfg['theory_lock']['retuning_allowed'] is False
checks['li_observation_not_gate']='downstream diagnostic only' in cfg['observational_controls']['Li7_role']
rr=(ROOT/'SOURCE'/'run_radiation_validation.py').read_text(encoding='utf-8')
ro=(ROOT/'SOURCE'/'run_one.py').read_text(encoding='utf-8')
fa=(ROOT/'SOURCE'/'final_audit.py').read_text(encoding='utf-8')
se=(ROOT/'SOURCE'/'seal_evidence.py').read_text(encoding='utf-8')
checks['runtime_directory_scaffolding']=(
    "ROOT/'TRANSCRIPTS'" in rr and "ROOT/'OUTPUT'/'CALIBRATION'" in rr
    and "ROOT/'OUTPUT'/'TARGET'" in rr and "ROOT/'OUTPUT'/'GATE_DIAGNOSTICS'" in rr
    and "diag_path.parent.mkdir(parents=True,exist_ok=True)" in ro
    and "transcript.parent.mkdir(parents=True,exist_ok=True)" in fa)
checks['unique_release_evidence_name']='20260819_2344EDT_r05' in se
checks['evidence_manifest_serialization_contract']=selftest_manifest_contract()
checks['console_utf8_contract']=(
    all('set "PYTHONUTF8=1"' in q.read_text(encoding='utf-8') and
        'set "PYTHONIOENCODING=utf-8"' in q.read_text(encoding='utf-8')
        for q in ROOT.glob('RUN_*_WINDOWS.cmd'))
    and "child_env['PYTHONUTF8']='1'" in rr
    and "child_env['PYTHONIOENCODING']='utf-8'" in rr
    and "encoding='utf-8',errors='replace'" in rr
    and "_stream.reconfigure(encoding='utf-8', errors='replace')" in ro
)
side=(ROOT/'CONFIG'/'FROZEN_RADIATION_PREREGISTRATION.sha256.txt').read_text().split()[0]
checks['prereg_sidecar']=side==prereg_sha()
bad=[]
for line in (ROOT/'MANIFEST.sha256').read_text(encoding='utf-8').splitlines() if (ROOT/'MANIFEST.sha256').exists() else []:
    if not line.strip(): continue
    h,rel=line.split('  ',1); p=ROOT/rel
    if not p.exists() or sha256_file(p)!=h: bad.append(rel)
checks['manifest']=not bad
compiled=0
for p in sorted((ROOT/'SOURCE').glob('*.py')):
    py_compile.compile(str(p),doraise=True); compiled+=1
checks['python_compile']=compiled>=10
for k,v in checks.items(): print('A7_RADIATION_STATIC',k,'PASS' if v else 'FAIL')
print('PYTHON_COMPILE',compiled,'PASS')
if not all(checks.values()): raise SystemExit(2)
print('A7_FULL_RADIATION_STATIC_VERIFY PASS')
print('PREREG_SHA256',prereg_sha())
