from __future__ import annotations
import json, math
from pathlib import Path
from common import ROOT, MAPPING, load_config, prereg_sha, sha256_file, write_json, utc_now
cfg=load_config(); mc=cfg['radiation_mapping_preregistration']
zpath=ROOT/'OUTPUT'/'CALIBRATION'/'RADIATION_CAL_ZERO.json'
ppath=ROOT/'OUTPUT'/'CALIBRATION'/'RADIATION_CAL_PROBE.json'
if not zpath.exists() or not ppath.exists(): raise RuntimeError('calibration rows incomplete')
z=json.loads(zpath.read_text(encoding='utf-8')); p=json.loads(ppath.read_text(encoding='utf-8'))
pr=prereg_sha()
for row,name in ((z,'zero'),(p,'probe')):
    if row.get('prereg_sha256')!=pr or row.get('phase')!='calibration' or row.get('mode')!='baseline':
        raise RuntimeError(f'{name} calibration identity mismatch')
    if abs(float(row['Omegabh2'])-float(cfg['cptg_coordinate']['Omegabh2_BBN_PRIMAT_input']))>1e-16:
        raise RuntimeError(f'{name} calibration Omegabh2 mismatch')
d0=float(mc['calibration_DeltaNeff_zero']); dp=float(mc['calibration_probe_DeltaNeff'])
if abs(float(z['DeltaNeff'])-d0)>1e-16 or abs(float(p['DeltaNeff'])-dp)>1e-16:
    raise RuntimeError('calibration DeltaNeff mismatch')
n0=float(z['standard']['Neff']); np_=float(p['standard']['Neff'])
slope=(np_-n0)/(dp-d0)
if not math.isfinite(slope) or abs(slope-1.0)>float(mc['probe_slope_abs_difference_from_unity_max']):
    raise RuntimeError(f'PRIMAT DeltaNeff->Neff slope failed frozen unity gate: slope={slope:.17g}')
target=float(cfg['cptg_coordinate']['Neff_CPTG_target'])
delta=(target-n0)/slope
if not math.isfinite(delta) or not (float(mc['target_DeltaNeff_min']) <= delta <= float(mc['target_DeltaNeff_max'])):
    raise RuntimeError(f'derived DeltaNeff outside preregistered bounds: {delta:.17g}')
obj={'schema':'cptg-primat-a7-frozen-radiation-mapping-v1','created_utc':utc_now(),
     'prereg_sha256':pr,'mapping_inputs':'Neff only; no abundance endpoint enters this object',
     'Omegabh2':cfg['cptg_coordinate']['Omegabh2_BBN_PRIMAT_input'],
     'eta10_reference':cfg['cptg_coordinate']['eta10_BBN_reference'],
     'Neff_target':target,'DeltaNeff_zero':d0,'Neff_zero':n0,
     'DeltaNeff_probe':dp,'Neff_probe':np_,'empirical_dNeff_dDeltaNeff':slope,
     'DeltaNeff_CPTG_frozen':delta,
     'calibration_zero_row_sha256':sha256_file(zpath),
     'calibration_probe_row_sha256':sha256_file(ppath),
     'mapping_formula':mc['mapping_formula'],
     'target_rows_may_not_modify_mapping':True}
encoded=json.dumps(obj,indent=2,sort_keys=True)+'\n'
if MAPPING.exists():
    old=json.loads(MAPPING.read_text(encoding='utf-8'))
    # Ignore creation timestamp only; every scientific mapping field must be identical.
    old_cmp=dict(old); new_cmp=dict(obj)
    old_cmp.pop('created_utc',None); new_cmp.pop('created_utc',None)
    if old_cmp!=new_cmp: raise RuntimeError('existing frozen mapping conflicts with current calibration; delete no evidence and investigate')
else:
    MAPPING.write_text(encoded,encoding='utf-8')
side=ROOT/'CONFIG'/'FROZEN_RADIATION_MAPPING.sha256.txt'
h=sha256_file(MAPPING)
if side.exists() and side.read_text(encoding='utf-8').split()[0]!=h:
    raise RuntimeError('mapping sidecar mismatch')
side.write_text(f'{h}  FROZEN_RADIATION_MAPPING.json\n',encoding='utf-8')
print('A7_RADIATION_MAPPING_FREEZE PASS')
print('N_EFF_ZERO',format(n0,'.17g'))
print('N_EFF_PROBE',format(np_,'.17g'))
print('DNEFF_DDELTANEFF',format(slope,'.17g'))
print('DELTA_NEFF_CPTG_FROZEN',format(delta,'.17g'))
print('MAPPING_SHA256',h)
