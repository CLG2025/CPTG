Release: CPTG_PRIMAT_A7_FullRadiationCoordinateValidation_20260819_2344EDT_r05
Clean-test scope: fresh execution package with manifest serialization fixed before any native solve.
The frozen scientific preregistration and all scientific gates are unchanged. No prior execution outputs or repaired evidence are included.

CPTG PRIMAT A=7 FULL RADIATION-COORDINATE VALIDATION

Mission:
  Implement the CPTG transported baryon coordinate AND CPTG Neff coordinate
  natively in PRIMAT v0.3.2, then test the locked live A=7 gate.

CPTG coordinate:
  eta10_BBN    = 5.998071834744
  Omegabh2_BBN = 0.021898765370
  Neff_CPTG    = 2.968584073464

Locked A=7 law:
  tau7 = ln(pi)
  survival target = 1/pi
  direct sinks = Li7 and Be7

Required PRIMAT Python:
  D:\Downloads\PRIMAT_v0.3.2\venv\Scripts\python.exe

Recommended one-command execution:
  RUN_ALL_WINDOWS.cmd

The run performs:
  1. static package verification
  2. evidence-manifest serialization self-test
  3. PRIMAT v0.3.2 preflight
  4. copied-source A=7 patch preparation
  5. exact patch self-test
  6. two native Neff-only mapping calibration rows
  7. immutable radiation mapping freeze
  8. full CPTG-coordinate gate-off and gate-on native rows
  9. scientific analysis
 10. final audit
 11. self-sealed uniquely named final evidence ZIP
 12. in-archive SHA-256 manifest re-verification

Total native large-network solves: 4.

The mapping is frozen before target rows and is derived only from PRIMAT's
reported Neff. No abundance endpoint is permitted to determine DeltaNeff.

Preregistration SHA-256:
  ab38b8c5bdb435b6c311e9b5e0fe31bca1c06ec67d2dc3e4a92098f255425162

Expected final evidence artifact:
  CPTG_PRIMAT_A7_FullRadiationCoordinateValidation_20260819_2344EDT_r05_FINAL_EVIDENCE.zip
