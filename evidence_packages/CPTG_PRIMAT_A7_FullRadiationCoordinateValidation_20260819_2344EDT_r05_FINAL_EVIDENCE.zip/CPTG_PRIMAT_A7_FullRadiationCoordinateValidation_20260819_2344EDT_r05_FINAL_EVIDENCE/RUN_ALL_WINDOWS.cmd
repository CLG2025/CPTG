@echo off
setlocal
set "PYTHONUTF8=1"
set "PYTHONIOENCODING=utf-8"
set "PYTHONUNBUFFERED=1"
cd /d "%~dp0"
for %%D in ("TRANSCRIPTS" "OUTPUT\CALIBRATION" "OUTPUT\TARGET" "OUTPUT\GATE_DIAGNOSTICS" "RESULTS" "EVIDENCE" "WORK") do (
  if not exist "%%~D" mkdir "%%~D"
)
call RUN_STATIC_VERIFY_WINDOWS.cmd
if errorlevel 1 exit /b %ERRORLEVEL%
call RUN_PREFLIGHT_WINDOWS.cmd
if errorlevel 1 exit /b %ERRORLEVEL%
call RUN_PREPARE_PATCHED_PRIMAT_WINDOWS.cmd
if errorlevel 1 exit /b %ERRORLEVEL%
call RUN_PATCH_SELFTEST_WINDOWS.cmd
if errorlevel 1 exit /b %ERRORLEVEL%
call RUN_RADIATION_VALIDATION_WINDOWS.cmd
set "SCI_RC=%ERRORLEVEL%"
call RUN_FINAL_AUDIT_WINDOWS.cmd
set "AUDIT_RC=%ERRORLEVEL%"
if not "%SCI_RC%"=="0" exit /b %SCI_RC%
exit /b %AUDIT_RC%
