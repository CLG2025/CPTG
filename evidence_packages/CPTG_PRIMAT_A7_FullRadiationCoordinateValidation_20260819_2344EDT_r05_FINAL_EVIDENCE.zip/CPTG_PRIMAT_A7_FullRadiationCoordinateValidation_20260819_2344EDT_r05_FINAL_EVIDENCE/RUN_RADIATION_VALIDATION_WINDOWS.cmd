@echo off
setlocal
set "PYTHONUTF8=1"
set "PYTHONIOENCODING=utf-8"
set "PYTHONUNBUFFERED=1"
cd /d "%~dp0"
set "PYTHON_EXE=D:\Downloads\PRIMAT_v0.3.2\venv\Scripts\python.exe"
if not exist "%PYTHON_EXE%" (
  echo A7_RADIATION_NATIVE_RUN FAIL missing %PYTHON_EXE%
  exit /b 2
)
set "NUMBA_CACHE_DIR=D:\Downloads\CPTG_PRIMAT_A7_NUMBA_CACHE"
if not exist "%NUMBA_CACHE_DIR%" mkdir "%NUMBA_CACHE_DIR%"
"%PYTHON_EXE%" SOURCE\run_radiation_validation.py
if errorlevel 1 exit /b %ERRORLEVEL%
"%PYTHON_EXE%" SOURCE\analyze_results.py
exit /b %ERRORLEVEL%
