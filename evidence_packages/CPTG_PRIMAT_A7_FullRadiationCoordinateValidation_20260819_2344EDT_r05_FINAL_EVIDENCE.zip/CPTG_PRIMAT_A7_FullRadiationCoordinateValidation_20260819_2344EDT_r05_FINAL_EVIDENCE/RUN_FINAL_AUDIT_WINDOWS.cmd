@echo off
setlocal
set "PYTHONUTF8=1"
set "PYTHONIOENCODING=utf-8"
set "PYTHONUNBUFFERED=1"
cd /d "%~dp0"
set "PYTHON_EXE=D:\Downloads\PRIMAT_v0.3.2\venv\Scripts\python.exe"
if not exist "%PYTHON_EXE%" (
  echo A7_RADIATION_FINAL_AUDIT FAIL missing %PYTHON_EXE%
  exit /b 2
)
"%PYTHON_EXE%" SOURCE\final_audit.py
set "AUDIT_RC=%ERRORLEVEL%"
"%PYTHON_EXE%" SOURCE\seal_evidence.py
if errorlevel 1 exit /b %ERRORLEVEL%
exit /b %AUDIT_RC%
