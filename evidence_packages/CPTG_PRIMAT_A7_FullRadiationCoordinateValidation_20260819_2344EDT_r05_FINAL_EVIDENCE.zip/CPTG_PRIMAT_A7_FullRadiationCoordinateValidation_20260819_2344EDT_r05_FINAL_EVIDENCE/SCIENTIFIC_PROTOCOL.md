# Scientific protocol — PRIMAT A=7 full CPTG radiation-coordinate validation

## Question

At the CPTG transported baryon coordinate

- `eta10_BBN = 5.998071834744` (reference coordinate)
- `Omegabh2_BBN = 0.021898765370` (native PRIMAT runtime input)

does PRIMAT v0.3.2 realize the CPTG radiation coordinate

- `Neff_CPTG = 2.968584073464`

and, with that radiation coordinate frozen, does the locked live `A=7` transport law still produce the preregistered `1/pi` survival behavior without spoiling native D/H, Yp, or He3/H controls?

## Radiation-coordinate translation

PRIMAT exposes `DeltaNeff` as its code-local radiation input. This experiment does not guess a translation constant and does not use lithium or any abundance to derive it.

Before target execution, two gate-off native calibration rows are run at the exact CPTG baryon density:

1. `DeltaNeff = 0`
2. `DeltaNeff = +0.01`

Only the two reported `Neff` values are consumed. The slope

`d Neff / d DeltaNeff`

must agree with unity to `1e-8`. The target code-local value is then computed once as

`DeltaNeff_CPTG = (Neff_CPTG - Neff_zero) / slope`

and hash-frozen before either target row is executed. No target abundance may alter that mapping.

## Target native runs

With the frozen `DeltaNeff_CPTG`, run exactly two PRIMAT large-network rows:

- gate OFF
- gate ON

All PRIMAT physics/numerical settings remain those in the preregistration.

## Independent background gates

The full-coordinate gate-off PRIMAT background must satisfy the declared observational controls:

- `|D/H pull| <= 2`
- `|Yp pull| <= 2`

These are genuine native PRIMAT outcomes. Comparison-table values cannot replace a failed native control.

## A=7 gates

- internal `Y7` survival relative error to `1/pi <= 0.5%`
- reported `Li7/H` survival relative error to `1/pi <= 0.5%`
- gated/baseline D/H, Yp, He3/H relative changes each `<= 1e-6`
- gate-on/off Neff relative change `<= 1e-10`
- independent-grid optical-depth relative error to `ln(pi) <= 2e-6`
- RHS and analytic-Jacobian gate paths exercised
- final states finite and nonnegative
- installed PRIMAT source unchanged

The lithium observational pull is diagnostic only.

## Native solve count

Four native large-network solves total: two radiation calibration rows and two frozen full-coordinate target rows.
