# Theory and software authority

## CPTG coordinate under test

```text
eta10_BBN       = 5.998071834744
Omegabh2_BBN    = 0.021898765370
Neff_CPTG       = 2.968584073464
tau7            = ln(pi)
A=7 survival    = 1/pi
sink species    = Li7, Be7
```

The PRIMAT runtime is driven by `Omegabh2`; `eta10_BBN` is retained as the associated CPTG reference coordinate.

## PRIMAT translation

PRIMAT v0.3.2 is the required authority. Its public API exposes `DeltaNeff` as the extra relativistic-degrees-of-freedom input and reports `Neff` as a standard output. The package is bound to upstream release `v0.3.2` / source commit:

`21ff8f39fa18e3937e9fdf386cfa982361bfdfce`

The code-local translation is independently calibrated and frozen before target execution. It is a radiation-coordinate translation only; no Li7, Be7, D/H, Yp, He3/H, or other abundance endpoint enters the mapping.

## Claim boundary

A PASS establishes that the CPTG transported baryon and radiation coordinates can be jointly instantiated in native PRIMAT v0.3.2 under this declared translation and that the locked A=7 live transport law survives that full coordinate while the preregistered native background controls pass.

A FAIL or NOT_QUALIFIED is retained as the scientific outcome. No alternate `DeltaNeff`, gate normalization, or gate window may be selected after target output is exposed.
