@echo off
setlocal
set "PYTHONUTF8=1"
set "PYTHONIOENCODING=utf-8"
set "PYTHONUNBUFFERED=1"
cd /d "%~dp0"
set "PYTHON_EXE=D:\Downloads\PRIMAT_v0.3.2\venv\Scripts\python.exe"
if not exist "%PYTHON_EXE%" (
  echo A7_RADIATION_PATCH_PREPARE FAIL missing %PYTHON_EXE%
  exit /b 2
)
"%PYTHON_EXE%" SOURCE\prepare_patched_primat.py
exit /b %ERRORLEVEL%
