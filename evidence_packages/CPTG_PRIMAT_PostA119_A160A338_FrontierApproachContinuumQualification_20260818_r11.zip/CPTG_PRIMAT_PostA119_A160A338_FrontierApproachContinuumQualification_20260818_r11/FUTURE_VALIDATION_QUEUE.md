# Required Future Validation Queue

After an r11 PASS:

- apply frozen relative truncation thresholds to all 14 PRIMAT native-boundary source contributions;
- perform all 14 leave-one-edge-out ablations;
- monitor the existing checkpoints plus frontier masses A=330, 334, 336, 337, 338;
- distinguish structural survival from amplitude sensitivity;
- use no replacement seed or abundance floor;
- do not promote external diagnostic populations to native PRIMAT or primordial-yield authority.
