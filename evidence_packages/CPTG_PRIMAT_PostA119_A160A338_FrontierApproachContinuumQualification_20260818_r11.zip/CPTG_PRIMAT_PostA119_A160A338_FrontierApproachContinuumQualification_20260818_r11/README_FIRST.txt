# CPTG PRIMAT A=160–338 Frontier-Approach Continuum Qualification — r11

r09 has now PASSed the full A=120–160 finer continuum qualification at all six PRIMAT anchors.
r08 found the uncapped structural graph gap-free through A=338, while selected eligible ReacLib nodes reach A=339.
r10 is the required forensic gate explaining why A=339 is disconnected.

r11 does **not** impose Amax=338. It rebuilds the frozen reaction graph without an artificial mass ceiling and requires the natural reachable maximum to reproduce exactly at A=338.

It then performs a fresh 128 → 256 → 512 two-method continuum qualification at preregistered frontier-approach checkpoints:

160, 180, 200, 220, 240, 260, 280, 300, 320, 330, 334, 336, 337, 338.

The same strict numerical gates used for r09 are retained. Separately, the 512-step primary solution must remain strictly positive at **every** mass sector A=160…338 for all six anchors. This is not an all-sector convergence claim.

No r09 endpoint vector is imported. The solver starts again from the frozen r06 PRIMAT native trajectories and a fresh ReacLib 2.11.0 graph.

## Required sequence on Windows

First close r10:

```cmd
cd /d D:\Downloads\CPTG_PRIMAT_PostA119_A338A339_StructuralFrontierForensic_20260818_r10
RUN_STATIC_VERIFY_WINDOWS.cmd
RUN_ADOPT_R06_NATIVE_AUTHORITY_WINDOWS.cmd
RUN_FRONTIER_FORENSIC_WINDOWS.cmd
```

r10 must end in `R10_A338_A339_STRUCTURAL_FRONTIER_FORENSIC PASS` with an accepted A339-disconnection classification.

Then run r11:

```cmd
cd /d D:\Downloads\CPTG_PRIMAT_PostA119_A160A338_FrontierApproachContinuumQualification_20260818_r11
RUN_STATIC_VERIFY_WINDOWS.cmd
RUN_ADOPT_UPSTREAM_AUTHORITY_WINDOWS.cmd
RUN_TRANSPORT_SELFTEST_WINDOWS.cmd
RUN_FRONTIER_APPROACH_WINDOWS.cmd
```

Required final decision:

```text
R11_A160_A338_FRONTIER_APPROACH_CONTINUUM_QUALIFICATION PASS
```

or fail-closed:

```text
R11_A160_A338_FRONTIER_APPROACH_CONTINUUM_QUALIFICATION NOT_QUALIFIED
```

A PASS qualifies checkpoint continuum behavior approaching the structural frontier plus full 512-step positive support across A=160–338. It does not turn the external reduced graph into native PRIMAT heavy-network evolution or a primordial heavy-yield prediction.

After PASS, source-tail truncation and all-14 boundary-edge leave-one-out ablations remain mandatory before deep-tail amplitudes are treated as source-robust.
