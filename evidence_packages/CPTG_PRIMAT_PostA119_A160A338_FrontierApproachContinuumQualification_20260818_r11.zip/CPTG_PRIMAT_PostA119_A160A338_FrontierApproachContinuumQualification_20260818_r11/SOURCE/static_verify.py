from __future__ import annotations
import json,hashlib,py_compile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def ck(n,c):
    if not c:raise RuntimeError(n+" FAIL")
    print(n,"PASS")
def main():
    p=json.loads((ROOT/"CONFIG/FROZEN_R11_FRONTIER_APPROACH_PREREGISTRATION.json").read_text(encoding="utf-8"))
    ck("R11_NATURAL_FRONTIER_338",p["graph"]["expected_natural_reachable_max_A"]==338)
    ck("NO_ARTIFICIAL_AMAX",p["graph"]["artificial_Amax"] is None)
    ck("NO_SEED_FLOOR",p["graph"]["artificial_seed_or_floor"] is False)
    ck("NO_ENDPOINT_VECTOR_IMPORT",p["authority"]["no_postsilicon_endpoint_vector_import"] is True)
    ck("R10_FORENSIC_REQUIRED",p["hard_gates"]["r10_forensic_pass_required"] is True)
    ck("R10_NO_BRIDGE_REQUIRED",p["hard_gates"]["r10_reachable_bridge_to_A339_required"]==0)
    ck("R10_NO_ESCAPE_REQUIRED",p["hard_gates"]["r10_A338_escape_edges_required"]==0)
    ck("LEVELS_128_256_512",p["numerics"]["fresh_refinement_levels"]==[128,256,512])
    ck("FRONTIER_CHECKPOINTS",p["numerics"]["frontier_checkpoint_masses"]==[160,180,200,220,240,260,280,300,320,330,334,336,337,338])
    ck("FULL_POSITIVE_REGION",p["numerics"]["full_positive_support_region"]==[160,338])
    ck("STRICT_PRIMARY_GATE",p["hard_gates"]["primary_256_512_checkpoint_max_relative"]==0.005)
    ck("STRICT_RESIDUAL_GATE",p["hard_gates"]["primary_512_to_Richardson_checkpoint_max_relative"]==0.0025)
    ck("STRICT_CROSS_GATE",p["hard_gates"]["continuum_cross_scheme_checkpoint_max_relative"]==0.005)
    ck("SOURCE_TAIL_QUEUED","tail truncation" in p["future_required_diagnostic"].lower() and "leave-one-out" in p["future_required_diagnostic"].lower())
    s=(ROOT/"SOURCE/run_frontier_approach.py").read_text(encoding="utf-8")
    ck("UNCAPPED_BFS","def build_uncapped_graph" in s and "expected_natural_reachable_max_A" not in s)
    ck("RUNTIME_FRONTIER_ASSERT","maxA==g[\"natural_reachable_max_A_exact\"]" in s)
    ck("STRUCTURAL_ALL_A24_A338","STRUCTURAL_REGION=list(range(24,339))" in s)
    ck("POSITIVE_ALL_A160_A338","POSITIVE_REGION=list(range(160,339))" in s)
    ck("TWO_SCHEMES","solve_positive_exponential_inflow" in s and "solve_backward_euler" in s)
    ck("NO_UPSTREAM_ENDPOINT_READ_IN_SOLVER","UPSTREAM_R09_PASS_SUMMARY" not in s and "A120_A160_FINER_ENDPOINTS" not in s)
    pys=sorted((ROOT/"SOURCE").glob("*.py"))
    for q in pys:py_compile.compile(str(q),doraise=True)
    print("PYTHON_COMPILE",f"{len(pys)}/{len(pys)}","PASS")
    bad=[];n=0
    for line in (ROOT/"MANIFEST.sha256").read_text(encoding="utf-8").splitlines():
        if line.strip():
            h,rel=line.split("  ",1);n+=1;q=ROOT/rel
            if not q.is_file() or sha(q)!=h:bad.append(rel)
    ck(f"PACKAGE_MANIFEST {n-len(bad)}/{n}",not bad)
    print("R11_FRONTIER_APPROACH_STATIC_VERIFY PASS")
if __name__=="__main__":main()
