from __future__ import annotations
import json,hashlib,shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
R06=Path(r"D:\Downloads\CPTG_PRIMAT_NativeBoundaryFlux_A1A119_FinalEvidenceValidation_20260818_r06")
R09=Path(r"D:\Downloads\CPTG_PRIMAT_PostA119_A120A160_FinerContinuumQualification_20260818_r09_HOTFIX_r01")
R10=Path(r"D:\Downloads\CPTG_PRIMAT_PostA119_A338A339_StructuralFrontierForensic_20260818_r10")
EXPECT="97fd7b4f4f4e7466be9e45be264e62faade5b55e80d415201ed4390405080f9a"
ALLOWED={"A339_DISCONNECTED_RATE_ISLAND__ALL_INCOMING_SOURCES_UNREACHABLE","A339_ELIGIBLE_NODES_WITH_NO_ALLOWED_INCOMING_EDGE"}
def sha(p):
    h=hashlib.sha256()
    with p.open("rb") as f:
        for b in iter(lambda:f.read(1048576),b""):h.update(b)
    return h.hexdigest()
def main():
    for d in (ROOT/"EVIDENCE",ROOT/"OUTPUT") : d.mkdir(parents=True,exist_ok=True)
    fs=R06/"EVIDENCE/FINAL_VALIDATION_SUMMARY.json"; fp=R06/"OUTPUT/NATIVE_TRAJECTORY_FREEZE.json"
    if not fs.is_file() or json.loads(fs.read_text(encoding="utf-8"))["decision"]!="PASS":raise RuntimeError("r06 PASS required")
    if not fp.is_file() or sha(fp)!=EXPECT:raise RuntimeError("r06 native freeze mismatch")
    fr=json.loads(fp.read_text(encoding="utf-8"))
    for rec in fr["files"]:
        s=R06/rec["path"]
        if not s.is_file() or sha(s)!=rec["sha256"]:raise RuntimeError("native member mismatch "+rec["path"])
        d=ROOT/rec["path"];d.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(s,d)
        if sha(d)!=rec["sha256"]:raise RuntimeError("copy mismatch "+rec["path"])
    shutil.copy2(fp,ROOT/"OUTPUT/NATIVE_TRAJECTORY_FREEZE.json")
    r09p=R09/"EVIDENCE/R09_A120_A160_FINER_CONTINUUM_QUALIFICATION.json"
    if not r09p.is_file():raise RuntimeError("r09 HOTFIX production evidence missing; run r09 first")
    r09=json.loads(r09p.read_text(encoding="utf-8"))
    if r09.get("decision")!="PASS":raise RuntimeError("r09 PASS required")
    r10p=R10/"EVIDENCE/A338_A339_STRUCTURAL_FRONTIER_FORENSIC.json"
    if not r10p.is_file():raise RuntimeError("r10 forensic evidence missing; run r10 first")
    r10=json.loads(r10p.read_text(encoding="utf-8"))
    if r10.get("decision")!="PASS" or r10.get("classification") not in ALLOWED:raise RuntimeError("r10 accepted frontier classification required")
    if r10.get("reachable_max_A")!=338 or r10.get("incoming_edges_to_A339_from_reachable_sources")!=0 or r10.get("A338_outgoing_edges_to_unreachable_nodes")!=0:
        raise RuntimeError("r10 frontier invariants mismatch")
    shutil.copy2(r09p,ROOT/"EVIDENCE/UPSTREAM_R09_PASS_SUMMARY.json")
    shutil.copy2(r10p,ROOT/"EVIDENCE/UPSTREAM_R10_FRONTIER_FORENSIC.json")
    out={"schema":"cptg-r11-upstream-adoption-v1","pass":True,"native_freeze_sha256":EXPECT,
         "r09_decision":"PASS","r10_decision":"PASS","r10_classification":r10["classification"],
         "r10_reachable_max_A":338,"postsilicon_endpoint_vectors_imported":False,
         "upstream_decision_summaries_imported":True,"historical_postsilicon_numerical_inputs":0}
    (ROOT/"EVIDENCE/UPSTREAM_ADOPTION.json").write_text(json.dumps(out,indent=2,sort_keys=True)+"\n",encoding="utf-8")
    print("R11_UPSTREAM_ADOPTION PASS")
    print("FREEZE_SHA256",EXPECT)
    print("R09_DECISION PASS")
    print("R10_FRONTIER_CLASSIFICATION",r10["classification"])
    print("POSTSILICON_ENDPOINT_VECTORS_IMPORTED False")
    print("HISTORICAL_POSTSILICON_NUMERICAL_INPUTS 0")
if __name__=="__main__":main()
