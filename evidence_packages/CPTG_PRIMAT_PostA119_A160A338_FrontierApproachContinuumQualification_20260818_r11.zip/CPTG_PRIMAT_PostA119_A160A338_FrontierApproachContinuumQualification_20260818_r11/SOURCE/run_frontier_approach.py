from __future__ import annotations
import csv,math,importlib.metadata
from collections import defaultdict,deque
import numpy as np
import pynucastro as pyna
from common import *
from positive_transport_core import solve_backward_euler,solve_positive_exponential_inflow
LEVELS=[128,256,512]
CHECKPOINTS=[160,180,200,220,240,260,280,300,320,330,334,336,337,338]
POSITIVE_REGION=list(range(160,339))
STRUCTURAL_REGION=list(range(24,339))
LIGHT_TUPLES=set(LIGHT)
def nt(n):return int(n.A),int(n.Z)
def select_rates():
    rl=pyna.ReacLibLibrary();caps=[];betas=[]
    for r in rl.get_rates():
        rea=[nt(x) for x in r.reactants];pro=[nt(x) for x in r.products]
        if not r.weak and len(rea)==2 and len(pro)==1:
            ls=[x for x in rea if x in LIGHT_TUPLES]
            if len(ls)==1:
                l=ls[0];h=rea[1] if rea[0]==l else rea[0];d=pro[0]
                if h[0]>=6 and d==(h[0]+l[0],h[1]+l[1]):caps.append((h,l,d,r))
        if r.weak and getattr(r,"weak_type",None)=="beta_neg" and len(rea)==1 and len(pro)==1:
            s,d=rea[0],pro[0]
            if s[0]>=6 and d[0]==s[0] and d[1]==s[1]+1:betas.append((s,d,r))
    caps.sort(key=lambda x:(x[0],x[1],x[2],str(x[3])));betas.sort(key=lambda x:(x[0],x[1],str(x[2])))
    return caps,betas
def build_uncapped_graph(native,caps,betas):
    src=[(h,l,d,r) for h,l,d,r in caps if h in native and d not in native and d[0]>=24]
    seeds={d for h,l,d,r in src};cb=defaultdict(list);bb=defaultdict(list)
    for h,l,d,r in caps:
        if h[0]>=24:cb[h].append((d,l,r))
    for s,d,r in betas:
        if s[0]>=24:bb[s].append((d,r))
    seen=set(seeds);q=deque(sorted(seeds))
    while q:
        s=q.popleft()
        for d,l,r in cb.get(s,[]):
            if d not in seen:seen.add(d);q.append(d)
        for d,r in bb.get(s,[]):
            if d not in seen:seen.add(d);q.append(d)
    maxA=max(a for a,z in seen)
    species=sorted(seen,key=lambda x:(x[0],x[1]));idx={s:i for i,s in enumerate(species)}
    inc=[];out=defaultdict(list);escape=[]
    for s in species:
        for d,l,r in cb.get(s,[]):
            out[s].append(("capture",d,l,r))
            if d not in idx:escape.append((s,d,"capture",l,r));continue
            if idx[d]<=idx[s]:raise RuntimeError("non-forward capture")
            inc.append((idx[s],idx[d],"capture",l,r))
        for d,r in bb.get(s,[]):
            out[s].append(("beta",d,None,r))
            if d not in idx:escape.append((s,d,"beta",None,r));continue
            if idx[d]<=idx[s]:raise RuntimeError("non-forward beta")
            inc.append((idx[s],idx[d],"beta",None,r))
    inc.sort(key=lambda e:(e[1],e[0],str(e[4])))
    return src,species,idx,inc,out,maxA,escape
def load_traj(eta):
    z=np.load(OUTPUT/f"NATIVE_TRAJECTORIES/PRIMAT_NATIVE_TRAJECTORY_ETA{eta_tag(eta)}.npz")
    names=[str(x) for x in z["species"]];az=[parse_primat_name(n) for n in names]
    return np.asarray(z["t_s"],float),np.asarray(z["T_K"],float),np.asarray(z["rho_b_g_cm3"],float),az,np.asarray(z["Y"],float)
def precompute(eta,caps,betas):
    t,T,rho,naz,Y=load_traj(eta);native=set(naz);ix={a:i for i,a in enumerate(naz)}
    src,species,idx,inc,out,maxA,escape=build_uncapped_graph(native,caps,betas)
    ns=len(species);ntm=len(t);ne=len(inc)
    S=np.zeros((ns,ntm));L=np.zeros((ns,ntm));C=np.zeros((ne,ntm))
    bath={l:rho*Y[ix[l],:] for l in LIGHT_TUPLES if l in ix};cache={}
    def rv(r):
        k=id(r)
        if k not in cache:cache[k]=np.maximum(np.array([float(r.eval(float(Tv))) for Tv in T]),0.0)
        return cache[k]
    for h,l,d,r in src:S[idx[d],:]+=rv(r)*bath[l]*Y[ix[h],:]
    for e,(si,di,kind,l,r) in enumerate(inc):C[e,:]=rv(r)*bath[l] if kind=="capture" else rv(r)
    for s in species:
        si=idx[s]
        for kind,d,l,r in out.get(s,[]):L[si,:]+=rv(r)*bath[l] if kind=="capture" else rv(r)
    counts=np.zeros(ns,dtype=np.int64)
    for si,di,kind,l,r in inc:counts[di]+=1
    starts=np.zeros(ns+1,dtype=np.int64);starts[1:]=np.cumsum(counts)
    return t,S,L,np.array([x[0] for x in inc],dtype=np.int64),starts,C,species,len(src),maxA,escape
def mass_sums(species,y):
    d={A:0.0 for A in STRUCTURAL_REGION}
    for (A,Z),v in zip(species,y):
        if A in d:d[A]+=float(v)
    return d
def maxrel(a,b,keys):
    by={A:symmetric_rel(a[A],b[A]) for A in keys}
    return max(by.values()),max(by,key=by.get),by
def rich(seq,keys):
    out={};orders={};bad=[]
    for A in keys:
        x0,x1,x2=(float(seq[k][A]) for k in LEVELS)
        d0=abs(x0-x1);d1=abs(x1-x2)
        if not all(math.isfinite(x) and x>0 for x in (x0,x1,x2)) or d0<=0 or d1<=0:
            bad.append(A);continue
        p=math.log(d0/d1,2);den=2.0**p-1.0
        if not math.isfinite(p) or abs(den)<1e-14:bad.append(A);continue
        lim=x2+(x2-x1)/den
        if not math.isfinite(lim) or lim<=0:bad.append(A);continue
        out[A]=lim;orders[A]=p
    return out,orders,bad
def main():
    if importlib.metadata.version("pynucastro")!="2.11.0":raise RuntimeError("pynucastro 2.11.0 required")
    if sha_file(OUTPUT/"NATIVE_TRAJECTORY_FREEZE.json")!="97fd7b4f4f4e7466be9e45be264e62faade5b55e80d415201ed4390405080f9a":raise RuntimeError("freeze mismatch")
    ad=load_json(EVIDENCE/"UPSTREAM_ADOPTION.json")
    if ad.get("pass") is not True or ad.get("r10_reachable_max_A")!=338:raise RuntimeError("upstream adoption required")
    cfg=load_json(CONFIG/"FROZEN_R11_FRONTIER_APPROACH_PREREGISTRATION.json");g=cfg["hard_gates"]
    caps,betas=select_rates();anchors=[]
    globals_={"P256_512":0.0,"BE256_512":0.0,"continuum_cross":0.0,"P512_Richardson":0.0}
    for eta in ETA:
        print("R11_FRONTIER_START",eta,flush=True)
        t,S,L,ii,st,C,species,nsource,maxA,escape=precompute(eta,caps,betas)
        structural={A for A,Z in species};missing=sorted(set(STRUCTURAL_REGION)-structural)
        integ=float(np.trapezoid(np.sum(S,axis=0),t))
        if not math.isfinite(integ) or integ<=0:raise RuntimeError("source integral invalid")
        Sn=S/integ;P={};B={};state_ok=True
        for N in LEVELS:
            y,mn=solve_positive_exponential_inflow(t,Sn,L,ii,st,C,N)
            state_ok=state_ok and mn>=0 and np.min(y)>=0 and np.all(np.isfinite(y));P[N]=mass_sums(species,y)
            y,mn=solve_backward_euler(t,Sn,L,ii,st,C,N)
            state_ok=state_ok and mn>=0 and np.min(y)>=0 and np.all(np.isfinite(y));B[N]=mass_sums(species,y)
        positive_missing=sorted(A for A in POSITIVE_REGION if not math.isfinite(P[512][A]) or P[512][A]<=0)
        checkpoint_nonpositive=sorted(A for A in CHECKPOINTS if any(not math.isfinite(P[N][A]) or P[N][A]<=0 or not math.isfinite(B[N][A]) or B[N][A]<=0 for N in LEVELS))
        p01,p01A,_=maxrel(P[128],P[256],CHECKPOINTS);p12,p12A,_=maxrel(P[256],P[512],CHECKPOINTS)
        b01,b01A,_=maxrel(B[128],B[256],CHECKPOINTS);b12,b12A,_=maxrel(B[256],B[512],CHECKPOINTS)
        po=math.log(p01/p12,2) if p01>0 and p12>0 else None;bo=math.log(b01/b12,2) if b01>0 and b12>0 else None
        PR,PRo,PRbad=rich(P,CHECKPOINTS);BR,BRo,BRbad=rich(B,CHECKPOINTS)
        if PRbad or BRbad:
            cross=pres=None;crossA=presA=None
        else:
            cross,crossA,_=maxrel(PR,BR,CHECKPOINTS);pres,presA,_=maxrel(P[512],PR,CHECKPOINTS)
        ya,mna=solve_positive_exponential_inflow(t,S,L,ii,st,C,512)
        abs_state=mass_sums(species,ya);scaled={A:P[512][A]*integ for A in STRUCTURAL_REGION}
        absrec,absA,_=maxrel(abs_state,scaled,CHECKPOINTS)
        z,_=solve_positive_exponential_inflow(t,S*0,L,ii,st,C,64)
        h,_=solve_positive_exponential_inflow(t,S*0.5,L,ii,st,C,64)
        d,_=solve_positive_exponential_inflow(t,S*2,L,ii,st,C,64)
        q,_=solve_positive_exponential_inflow(t,S,L,ii,st,C,64)
        zero=bool(np.array_equal(z,np.zeros_like(z)));lin=max(vector_max_rel(h*2,q),vector_max_rel(d/2,q))
        ok=(maxA==g["natural_reachable_max_A_exact"] and not escape and not missing and not positive_missing and not checkpoint_nonpositive and state_ok and
            p12<=g["primary_256_512_checkpoint_max_relative"] and po is not None and g["primary_effective_order_min"]<=po<=g["primary_effective_order_max"] and
            pres is not None and pres<=g["primary_512_to_Richardson_checkpoint_max_relative"] and
            b12<=g["BE_256_512_checkpoint_max_relative"] and bo is not None and g["BE_effective_order_min"]<=bo<=g["BE_effective_order_max"] and
            cross is not None and cross<=g["continuum_cross_scheme_checkpoint_max_relative"] and
            zero and lin<=g["source_linearity_full_vector_max_relative"] and absrec<=g["absolute_normalized_reconstruction_checkpoint_max_relative"])
        rec={"eta10":eta,"pass":ok,"source_edges":nsource,"reachable_species":len(species),"natural_reachable_max_A":maxA,
             "escape_edges":len(escape),"structural_missing_A24_A338":missing,"P512_nonpositive_A160_A338":positive_missing,
             "checkpoint_nonpositive":checkpoint_nonpositive,"state_finite_nonnegative":bool(state_ok),
             "P128_256_checkpoint_max":p01,"P128_256_worst_A":p01A,"P256_512_checkpoint_max":p12,"P256_512_worst_A":p12A,"P_effective_order":po,
             "BE128_256_checkpoint_max":b01,"BE128_256_worst_A":b01A,"BE256_512_checkpoint_max":b12,"BE256_512_worst_A":b12A,"BE_effective_order":bo,
             "P_Richardson_invalid":PRbad,"BE_Richardson_invalid":BRbad,"continuum_cross_checkpoint_max":cross,"continuum_cross_worst_A":crossA,
             "P512_Richardson_checkpoint_max":pres,"P512_Richardson_worst_A":presA,"absolute_reconstruction_checkpoint_max":absrec,"absolute_reconstruction_worst_A":absA,
             "zero_source":zero,"linearity_full_vector_max":lin,"A338_P512":P[512][338]}
        anchors.append(rec)
        globals_["P256_512"]=max(globals_["P256_512"],p12);globals_["BE256_512"]=max(globals_["BE256_512"],b12)
        if cross is not None:globals_["continuum_cross"]=max(globals_["continuum_cross"],cross)
        if pres is not None:globals_["P512_Richardson"]=max(globals_["P512_Richardson"],pres)
        ddir=RESULTS/f"ETA{eta_tag(eta)}";ddir.mkdir(parents=True,exist_ok=True)
        with (ddir/"FRONTIER_CHECKPOINT_ENDPOINTS.csv").open("w",newline="",encoding="utf-8") as f:
            w=csv.writer(f);w.writerow(["A","P128","P256","P512","BE128","BE256","BE512","P_Richardson","BE_Richardson"])
            for A in CHECKPOINTS:w.writerow([A,P[128][A],P[256][A],P[512][A],B[128][A],B[256][A],B[512][A],PR.get(A,""),BR.get(A,"")])
        with (ddir/"A160_A338_P512_MASS_SECTORS.csv").open("w",newline="",encoding="utf-8") as f:
            w=csv.writer(f);w.writerow(["A","P512_normalized_source"])
            for A in POSITIVE_REGION:w.writerow([A,P[512][A]])
        print("R11_FRONTIER_ANCHOR",eta,"PASS" if ok else "FAIL","P256_512",p12,"P_ORDER",po,"BE256_512",b12,"BE_ORDER",bo,
              "CONTINUUM_CROSS",cross,"P512_RICH",pres,"WORST_A",crossA,"A338_P512",P[512][338],flush=True)
    overall=all(a["pass"] for a in anchors)
    out={"schema":"cptg-r11-a160a338-frontier-approach-continuum-result-v1","decision":"PASS" if overall else "NOT_QUALIFIED",
         "checkpoints":CHECKPOINTS,"full_positive_support_region":[160,338],"anchors":anchors,
         "global_P256_512_checkpoint_max":globals_["P256_512"],"global_BE256_512_checkpoint_max":globals_["BE256_512"],
         "global_continuum_cross_checkpoint_max":globals_["continuum_cross"],"global_P512_Richardson_checkpoint_max":globals_["P512_Richardson"],
         "claim_boundary":"checkpoint continuum qualification plus full A160-A338 P512 positive support; not all-sector convergence"}
    atomic_json(EVIDENCE/"R11_A160_A338_FRONTIER_APPROACH_CONTINUUM_QUALIFICATION.json",out)
    print("R11_GLOBAL_P256_512",globals_["P256_512"]);print("R11_GLOBAL_BE256_512",globals_["BE256_512"])
    print("R11_GLOBAL_CONTINUUM_CROSS",globals_["continuum_cross"]);print("R11_GLOBAL_P512_RICHARDSON",globals_["P512_Richardson"])
    print("R11_A160_A338_FRONTIER_APPROACH_CONTINUUM_QUALIFICATION","PASS" if overall else "NOT_QUALIFIED")
    if not overall:raise SystemExit(5)
if __name__=="__main__":main()
