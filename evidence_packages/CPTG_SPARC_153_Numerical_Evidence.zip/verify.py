#!/usr/bin/env python3
"""Verify CPTG galaxy calculation inputs, outputs, and declared mass accounting."""
from pathlib import Path
import hashlib
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parent

def require(condition, message):
    if not condition:
        raise AssertionError(message)

# File integrity: only archive source, input, and reference files have fixed hashes.
for line in (ROOT/'SHA256SUMS.txt').read_text().splitlines():
    digest, rel = line.split('  ',1)
    src=ROOT/rel
    require(src.is_file(),'MISSING: '+rel)
    require(hashlib.sha256(src.read_bytes()).hexdigest()==digest,'SHA256 MISMATCH: '+rel)

gal=pd.read_csv(ROOT/'reference/galaxy_summary.csv')
rad=pd.read_csv(ROOT/'reference/radial_results.csv')
gas=pd.read_csv(ROOT/'reference/gas_surface_density.csv')
fits=pd.read_csv(ROOT/'inputs/fit_parameters.csv')
raw_names={f.name.removesuffix('_rotmod.dat') for f in (ROOT/'inputs/galaxies').glob('*_rotmod.dat')}
require(len(gal)==153 and len(rad)==3168 and len(fits)==153,'Unexpected galaxy or radial count')
require(set(gal.galaxy)==set(fits.galaxy)==raw_names,'Galaxy sample differs across files')
require(int(gal.N.sum())==3168,'Incorrect radial counts per galaxy')
require(int(rad.mass_geometric_negative.sum())==196,'Negative remainder count differs')
require(int(rad.loc[rad.mass_geometric_negative,'galaxy'].nunique())==49,'Negative galaxy count differs')
require(not (gal.geometric_pct_last<0).any(),'Unexpected negative outer remainder')
require(len(gas)==4754,'Gas ring table count differs')
require(int(gal.material_catalog_proxy_flag_gt1p3.sum())==14,'Mismatch flag count differs')
require(int((abs(gal.chi2_delta_registry)>0.01).sum())==6,'Chi-square replay discrepancy count differs')
require(abs(float(gal.geometric_pct_last.mean())-77.95836318352137)<1e-8,'Mean fraction differs')
require(abs(float(gal.geometric_pct_last.median())-80.3334382308036)<1e-8,'Median fraction differs')
weighted=100*gal.M_geometric_equiv_last_Msun.sum()/gal.M_total_CPTG_equiv_last_Msun.sum()
require(abs(weighted-79.02951315098295)<1e-8,'Weighted fraction differs')
require(np.allclose(rad.M_CPTG_spherical_field_equiv_Msun,rad.M_material_enclosed_profile_Msun+rad.M_geometric_arithmetic_equiv_Msun,rtol=1e-12,atol=0.02),'Mass closure differs')

for actual,ref in [
    ('ALL153_GALAXY_SUMMARY.csv','galaxy_summary.csv'),
    ('ALL3168_RADIAL_RESULTS.csv','radial_results.csv'),
    ('ALL153_INFERRED_GAS_SURFACE_DENSITY.csv','gas_surface_density.csv'),
]:
    pa=ROOT/'output'/actual
    require(pa.is_file(),'RUN calculate.py FIRST: '+actual)
    a=pd.read_csv(pa)
    b=pd.read_csv(ROOT/'reference'/ref)
    require(a.shape==b.shape,'Output shape mismatch: '+actual)
    require(a.columns.tolist()==b.columns.tolist(),'Output column mismatch: '+actual)
    for c in a.columns:
        if pd.api.types.is_numeric_dtype(a[c]) and pd.api.types.is_numeric_dtype(b[c]):
            require(np.allclose(a[c].to_numpy(dtype=float),b[c].to_numpy(dtype=float),rtol=3e-11,atol=1e-11,equal_nan=True),'NUMERICAL DIFFERENCE: '+actual+' column '+c)
        else:
            require(a[c].astype(str).equals(b[c].astype(str)),'TEXT DIFFERENCE: '+actual+' column '+c)
    print('PASS',actual,len(a),'rows')

g=pd.read_csv(ROOT/'output/ALL153_GALAXY_SUMMARY.csv')
r=pd.read_csv(ROOT/'output/ALL3168_RADIAL_RESULTS.csv')
require(int(r.mass_geometric_negative.sum())==196,'Recalculated signed remainders differ')
print('PASS: 153 galaxies; 3,168 radii; 4,754 gas annuli; 196 signed negative remainders')
print(f'PASS: geometric shares mean={g.geometric_pct_last.mean():.8f}%, median={g.geometric_pct_last.median():.8f}%, weighted={weighted:.8f}%')
print('PASS: SHA256 of numerical sources and all reference inputs')
