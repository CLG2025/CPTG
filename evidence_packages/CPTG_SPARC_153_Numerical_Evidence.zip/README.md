# CPTG SPARC numerical evidence — 153 galaxies

This archive contains only the inputs, numerical functions, fixed fitted coefficients, reference results, and verification code required to reproduce the reported 153-galaxy CPTG field and geometric/material mass-equivalent calculations.

## Environment

Python 3.10+ with NumPy, SciPy, and pandas (see `requirements.txt`). All rotation-curve radii are in kpc and velocities in km/s. The material inventory uses the declared disk and bulge mass-to-light ratios 0.5 and 0.7, plus the nonnegative regularized inverse of the signed gas-force curve.

## Reproduce the results

From the extracted archive directory:

```bash
python -m pip install -r requirements.txt
python calculate.py
python verify.py
```

`calculate.py` reads the 153 original SPARC eight-column files and the supplied galaxy fit coefficients. It solves the registered signed-source CPTG polarization–transport field at every measured radius, reconstructs the disk, bulge, and gas material inventory, and calculates the spherical gravitational mass equivalent and its signed geometric remainder. The material reconstruction uses no observed velocities. The field reconstruction uses observed velocities for its local structural support and is an observation-conditioned reconstruction, not a held-out forecast.

The script produces `output/ALL153_GALAXY_SUMMARY.csv`, `output/ALL3168_RADIAL_RESULTS.csv`, and `output/ALL153_INFERRED_GAS_SURFACE_DENSITY.csv`. The verifier checks their contents against `reference/`, validates file hashes, reports all catalog statistics, and fails if any required result differs beyond numerical tolerance. It preserves signed negative remainders, and never clamps them to zero.

## Archive contents

- `inputs/galaxies/`: 153 original SPARC rotation-model data files.
- `inputs/fit_parameters.csv`: the existing per-galaxy fit coefficients, counts, and chi-square reference values.
- `inputs/material_proxy.csv`: reference photometric/H I material proxy used only for the reported independent mismatch flags.
- `inputs/SPARC_Lelli2016c.mrt`: original SPARC selection metadata, included to establish catalog provenance.
- `source/cptg_field.py`: gravitational-field functions and constants, preserved numerically.
- `source/material_inventory.py`: photometric and gas-inversion calculations, preserved numerically.
- `calculate.py`: end-to-end numerical reproduction.
- `reference/`: expected galaxy, radial, and gas-inversion numerical results.
- `verify.py`: input-hash and output-validation checks.
- `SHA256SUMS.txt`: input, code, and reference data hashes.

No figure-generation programs, images, manuscripts, or unrelated modeling experiments are required for these numerical results.

## Definition of the reported mass equivalents

At radius R, `M_total^eq=R V_CPTG^2/G`; `M_geometric^eq=M_total^eq-M_material(<R)`; `f_geometric=M_geometric^eq/M_total^eq`. The enclosed material mass is calculated from a cylindrical disk aperture plus the independently reconstructed bulge. These are declared arithmetic gravitational mass equivalents, not a separately observed three-dimensional geometric mass. The catalog percentages use one outermost measured radius per galaxy. No new halo component or model parameter is introduced.
