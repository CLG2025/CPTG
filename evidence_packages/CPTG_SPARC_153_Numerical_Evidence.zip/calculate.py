#!/usr/bin/env python3
"""Recompute CPTG field and material mass equivalents for 153 SPARC galaxies."""
from pathlib import Path
import numpy as np,pandas as pd,sys,importlib.util,json,time,hashlib
ROOT=Path(__file__).resolve().parent
INPUT=ROOT/'inputs'
DATA=ROOT/'output'
DATA.mkdir(exist_ok=True)
sys.path.insert(0,str(ROOT/'source'))
import cptg_field as wb
import material_inventory as rec
G=rec.G
F=pd.read_csv(INPUT/'fit_parameters.csv').set_index('galaxy'); assert len(F)==153
s=[]; allrows=[];gasrows=[]; failures=[]
for idx,(name,fit) in enumerate(F.iterrows(),1):
 t0=time.time()
 path=INPUT/'galaxies'/f'{name}_rotmod.dat'
 if not path.exists(): raise RuntimeError('MISSING RAW '+name)
 t=np.loadtxt(path);t=np.atleast_2d(t);r,vo,e,vg,vd,vbul,sb,sbul=t.T
 assert len(r)==int(fit.n)
 rm=r*wb.KPC_TO_M;vobs=vo*1e3;e_ms=e*1e3
 gb=wb.build_physical_baryonic_field(rm,vg*1e3,vd*1e3,vbul*1e3)
 support=wb.resolved_support_state(rm,vobs,e_ms)
 bp=wb.cptg_bpol_from_support(rm,support,float(fit.kappa_C_kpc))
 gc,suppress=wb._solve_cptg_implicit_high_accel(gb,support['a_star_local'],support['Sigma_C_squared'],bp,float(fit.A_C),float(fit.c_C))
 if gc is None: raise RuntimeError('registered field did not close: '+name)
 D=1+float(fit.c_C)*support['Sigma_C_squared'];P=float(fit.A_C)*support['a_star_local']**(2/3)*bp*suppress
 fieldres=float(np.max(np.abs((D*gc-gb-P)/np.maximum(np.abs(D*gc)+np.abs(gb)+np.abs(P),1e-100))))
 if fieldres>2e-7:raise RuntimeError('equation residual '+name+': '+str(fieldres))
 vc=np.sqrt(gc*rm)/1000;chi=float(np.sum(((vc-vo)/e)**2));delta=chi-float(fit.baseline_chi2)
 vmond=np.sqrt(wb.mond_acceleration(gb)*rm)/1000
 vb=np.sign(gb)*np.sqrt(np.abs(gb)*rm)/1000
 vm2=vg*np.abs(vg)+.5*vd**2+.7*vbul**2
 vm=np.sign(vm2)*np.sqrt(np.abs(vm2))
 ggeom=P/D;vr=np.sign(ggeom)*np.sqrt(np.abs(ggeom)*rm)/1000
 # Material inventory is constructed independently of observed circular speed and the CPTG fitted field
 profile,info=rec.phot_profile(r,sb)
 if profile is None: raise RuntimeError('no positive photometry for '+name)
 disk,_=rec.stellar_mass_integral(r,profile,float(r[-1]),.5)
 bulge=np.maximum.accumulate(.7*r*vbul**2/G)
 soft=max(.09,min(.55,.04*float(r[-1])))
 edges,sigma,pred,vpred,gasdiag=rec.gas_fit(r,vg,extent=2,thickness=soft,lam=.12)
 gas=rec.ring_aperture(edges,sigma,r)
 material=disk+bulge+gas
 mtotal=r*vc**2/G
 mgeom=mtotal-material
 fgeom=mgeom/mtotal
 fmat=material/mtotal
 if not np.all(np.isfinite(material)) or not np.all(np.isfinite(mgeom)):raise RuntimeError('mass nan '+name)
 if max(abs((mgeom+material-mtotal)/mtotal))>1e-12:raise RuntimeError('mass closure '+name)
 # source and geometric curves are field equivalents, not sqrt(enclosed mass)
 for i in range(len(r)):
  allrows.append({'galaxy':name,'point_index':i+1,'radius_kpc':r[i],'V_obs_km_s':vo[i],'V_obs_err_km_s':e[i],
    'V_baryonic_signed_km_s':vb[i],'V_material_source_signed_km_s':vm[i],
    'V_geometric_effective_channel_signed_km_s':vr[i],'V_CPTG_km_s':vc[i], 'V_MOND_fixed_a0_km_s':vmond[i],
    'M_CPTG_spherical_field_equiv_Msun':mtotal[i],
    'M_material_enclosed_profile_Msun':material[i],
    'M_geometric_arithmetic_equiv_Msun':mgeom[i],
    'geometric_pct':100*fgeom[i],'material_pct':100*fmat[i],
    'M_disk_stellar_Msun':disk[i],'M_bulge_stellar_Msun':bulge[i],'M_gas_inverted_Msun':gas[i],
    'polarization_channel_signed_km_s2':float(ggeom[i]*rm[i]/1e6),
    'g_source_m_s2':gb[i],'g_CPTG_m_s2':gc[i], 'transport_D':D[i],
    'source_negative':bool(gb[i]<0),'geometric_field_negative':bool(ggeom[i]<0),
    'mass_geometric_negative':bool(mgeom[i]<0)})
 for k in range(len(sigma)):
  gasrows.append({'galaxy':name,'R_inner_kpc':edges[k],'R_outer_kpc':edges[k+1], 'Sigma_gas_Msun_per_pc2':sigma[k]})
 s.append({'galaxy':name,'N':len(r),'R_last_kpc':r[-1],'V_obs_last_km_s':vo[-1], 'errV_last_km_s':e[-1],
 'V_CPTG_last_km_s':vc[-1],'V_MOND_last_km_s':vmond[-1],
 'chi2_CPTG':chi,'chi2_baseline_registry':fit.baseline_chi2,'chi2_delta_registry':delta,
 'chi2_MOND':float(np.sum(((vmond-vo)/e)**2)),
 'M_total_CPTG_equiv_last_Msun':mtotal[-1],
 'M_material_enclosed_last_Msun':material[-1],
 'M_geometric_equiv_last_Msun':mgeom[-1],
 'geometric_pct_last':100*fgeom[-1], 'material_pct_last':100*fmat[-1],
 'M_disk_last_Msun':disk[-1], 'M_bulge_last_Msun':bulge[-1], 'M_gas_last_Msun':gas[-1],
 'gas_signedV_rmse_km_s':gasdiag['gas_velocity_signed_rmse_km_s'], 'gas_solver_success':gasdiag['solver_success'],
 'max_CPTG_equation_residual':fieldres,
 'n_negative_geom_arithmetic_radial':sum(mgeom<0),
 'n_negative_source_radial':sum(gb<0),
 'n_negative_polarization_radial':sum(ggeom<0),
 'photometry_positive_points':info['photometric_n'], 'fit_kappa_C_kpc':fit.kappa_C_kpc, 'fit_A_C':fit.A_C, 'fit_c_C':fit.c_C,
 'file':path.name})
 if idx%20==0 or idx==len(F):print(f'[{idx}/153] {name}, Δχ²={delta:.5g}, fgeom={100*fgeom[-1]:.2f}%, gasRMSE={gasdiag["gas_velocity_signed_rmse_km_s"]:.3f}, wall={time.time()-t0:.2f}s',flush=True)
S=pd.DataFrame(s);A=pd.DataFrame(allrows)
assert len(S)==153 and len(A)==3168
# Independent catalog cross-check: galaxy-wide 0.5 L_3.6 + 1.33 M_HI
# is not used as the mass input or forced as a constraint.
cat=pd.read_csv(INPUT/'material_proxy.csv')
assert len(cat)==153
S=S.merge(cat[['galaxy','photometric_baryon_inventory_proxy_Msun']],on='galaxy',how='left',validate='one_to_one')
assert S.photometric_baryon_inventory_proxy_Msun.notna().all()
S['material_vs_catalog_proxy_ratio']=S.M_material_enclosed_last_Msun/S.photometric_baryon_inventory_proxy_Msun
S['material_catalog_proxy_flag_gt1p3']=S.material_vs_catalog_proxy_ratio>1.3

# Original catalog display ordering
main=S[S.galaxy.str.match(r'^(DDO|ESO|F\d|IC|KK|NGC|UGC(?!A))')].sort_values('file')
other=S[~S.galaxy.isin(main.galaxy)].sort_values('file')
assert len(main)==147 and len(other)==6,(main.shape,other.shape)
S['display_order']=S.galaxy.map({name:i+1 for i,name in enumerate(list(main.galaxy)+list(other.galaxy))})
S=S.sort_values('display_order')
S.to_csv(DATA/'ALL153_GALAXY_SUMMARY.csv',index=False,float_format='%.15g')
A.to_csv(DATA/'ALL3168_RADIAL_RESULTS.csv',index=False,float_format='%.15g')
pd.DataFrame(gasrows).to_csv(DATA/'ALL153_INFERRED_GAS_SURFACE_DENSITY.csv',index=False,float_format='%.15g')
print('SUMMARY',json.dumps({'n':len(S),'radii':len(A),'main':len(main),'outliers':list(other.galaxy),
'negative_outer':int((S.geometric_pct_last<0).sum()),'negative_radial':int(A.mass_geometric_negative.sum()),
'negative_polar':int(A.geometric_field_negative.sum()),'negative_source':int(A.source_negative.sum()),
'chi_delta_max':float(abs(S.chi2_delta_registry).max()),'chi_delta_median':float(abs(S.chi2_delta_registry).median()),
'gas_rmse_median':float(S.gas_signedV_rmse_km_s.median()),
'material_gt_total':int((S.material_pct_last>100).sum()), 'filelist':S.galaxy.tolist()[:5]+S.galaxy.tolist()[-5:]},indent=2),flush=True)
