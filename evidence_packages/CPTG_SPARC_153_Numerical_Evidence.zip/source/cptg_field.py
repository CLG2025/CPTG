"""CPTG radial gravitational-field operations used by the SPARC calculation.
The numerical function bodies are preserved from the registered implementation.
"""
from typing import Dict, Optional, Tuple
import numpy as np
from scipy.interpolate import BSpline, UnivariateSpline
from scipy.optimize import nnls
KPC_TO_M = 3.085677581491367e19
A0_MOND = 1.2e-10
CPTG_KAPPA_MIN_KPC = 1.0e-4
CPTG_SUPPRESSION_INNER_POWER = 123.0 / 50.0
CPTG_SUPPRESSION_OUTER_POWER = 11.0 / 50.0
CPTG_SUPPRESSION_AT_UNIT_RATIO = 2.0 ** (-CPTG_SUPPRESSION_OUTER_POWER)
EPS = 1e-30


def signed_square(v: np.ndarray) -> np.ndarray:
    arr = np.asarray(v, dtype=float)
    return arr * np.abs(arr)

def build_physical_baryonic_field(
    r_m: np.ndarray,
    vgas_m_s: np.ndarray,
    vdisk_m_s: np.ndarray,
    vbulge_m_s: np.ndarray,
) -> np.ndarray:
    """Build the direct physical baryonic acceleration field."""
    gas_term = signed_square(vgas_m_s)
    disk_term = signed_square(vdisk_m_s)
    bulge_term = signed_square(vbulge_m_s)
    # Preserve SPARC signed radial force contributions, including a negative net source.
    vb2 = gas_term + disk_term + bulge_term
    return vb2 / np.maximum(r_m, EPS)

def mond_acceleration(gbar_physical: np.ndarray) -> np.ndarray:
    """Retain the original positive-domain MOND comparison for signed input.

    Negative net baryonic fields cannot be fed directly into this benchmark
    square-root expression; its EPS floor is MOND-only and does not affect CPTG.
    """
    gbar = np.maximum(np.asarray(gbar_physical, dtype=float), EPS)
    x = np.maximum(gbar / A0_MOND, EPS)
    return gbar / (1.0 - np.exp(-np.sqrt(x)))

def _resolved_spline_degree(n_points: int) -> int:
    """Spline degree valid for the available resolved radial points."""
    return max(1, min(3, int(n_points) - 1))

def resolved_support_state(
    r_m: np.ndarray,
    vobs_m_s: np.ndarray,
    errv_m_s: np.ndarray,
) -> Dict[str, np.ndarray]:
    """Resolve the support state without clipping Sigma_C^2.

    Sigma_C^2 = (1 - d(log g_sup)/d(log r))/3
              = -(2/3) d(log(V_obs/r))/d(log r).

    Therefore Sigma_C^2 >= 0 exactly when the reconstructed angular
    velocity V/r is nonincreasing. Use the ORIGINAL uncertainty-weighted
    log-support smoothing spline whenever it satisfies this condition.
    Otherwise, project its B-spline coefficients to the nearest monotone
    coefficient sequence in the original weighted spline metric.

    The monotone B-spline representation has a nonnegative derivative
    *by construction*, with no post-calculation clipping, imposed floor,
    altered local a_star, extra fitted galaxy parameters, or changed CPTG
    polarization/transport law. This is a support-profile constraint,
    not an observational claim that all measured V/r values are monotone.

    Original unconstrained spline values remain in a separate diagnostic.
    """
    r_m = np.asarray(r_m, dtype=float)
    vobs_m_s = np.asarray(vobs_m_s, dtype=float)
    errv_m_s = np.asarray(errv_m_s, dtype=float)
    if r_m.size < 3 or np.any(~np.isfinite(r_m)) or np.any(r_m <= 0.0):
        raise ValueError("Resolved radii must be finite, positive, and contain at least 3 points")
    if np.any(np.diff(r_m) <= 0.0):
        raise ValueError("Resolved radii must be strictly increasing")
    if np.any(~np.isfinite(vobs_m_s)) or np.any(vobs_m_s <= 0.0):
        raise ValueError("Observed velocities must be finite and positive")
    if np.any(~np.isfinite(errv_m_s)) or np.any(errv_m_s <= 0.0):
        raise ValueError("Velocity uncertainties must be finite and positive")

    x = np.log(r_m)
    g_observed = vobs_m_s ** 2 / r_m
    sigma_g = 2.0 * vobs_m_s * errv_m_s / r_m
    w = g_observed / sigma_g
    k = _resolved_spline_degree(r_m.size)
    original_spline = UnivariateSpline(
        x, np.log(g_observed), w=w, s=float(r_m.size), k=k
    )
    t, c_padded, degree = original_spline._eval_args
    n_coef = len(t) - degree - 1
    c = np.asarray(c_padded[:n_coef], dtype=float)

    # The linear function x is exactly a spline of degree k in the same
    # knot vector, with coefficients equal to the Greville abscissae.
    # Therefore log(g_sup/r) has B-spline coefficients c - greville.
    greville = np.array(
        [np.mean(t[i + 1:i + degree + 1]) for i in range(n_coef)],
        dtype=float,
    )
    h_coeff = c - greville
    d_original = -np.diff(h_coeff)

    # Check the unconstrained spline GLOBALLY, not only at galaxy radii.
    # For a cubic spline, its first derivative is quadratic in each knot
    # span, so its maxima occur at endpoints or zeros of its second
    # derivative (linear within a span). Lower degree needs endpoints only.
    active_knots = np.unique(t[degree:n_coef + 1])
    extrema = list(active_knots)
    if degree >= 3:
        second = original_spline.derivative(2)
        for xa, xb in zip(active_knots[:-1], active_knots[1:]):
            if xb <= xa:
                continue
            dxa = float(second(xa + (xb - xa) * 1e-12))
            dxb = float(second(xb - (xb - xa) * 1e-12))
            if dxa * dxb < 0.0:
                stationary = xa - dxa * (xb - xa) / (dxb - dxa)
                if xa < stationary < xb:
                    extrema.append(stationary)
    maximum_unconstrained_slope = float(np.max(original_spline.derivative(1)(np.asarray(extrema))))

    # Preserve the original spline EXACTLY if it is already globally valid.
    # Do not unnecessarily alter valid galaxy profiles.
    if maximum_unconstrained_slope <= 1.0:
        d = d_original
        repaired_coeff = h_coeff
        adjusted = False
    else:
        B = BSpline.design_matrix(x, t, degree, extrapolate=False).toarray()
        # h(x) = c0 - F(x) @ d, with every decrement d_i >= 0.
        # Eliminate free intercept c0 analytically, then solve the convex
        # nonnegative least-squares projection onto the monotone cone.
        F = np.cumsum(B[:, ::-1], axis=1)[:, ::-1][:, 1:]
        target = original_spline(x) - x
        ww = w ** 2
        ybar = np.average(target, weights=ww)
        fbar = np.average(F, axis=0, weights=ww)
        d, _ = nnls(w[:, None] * (F - fbar), w * (ybar - target))
        c0 = ybar + fbar @ d
        repaired_coeff = c0 - np.r_[0.0, np.cumsum(d)]
        adjusted = True

    # Two observational-support quantities are intentionally distinct:
    # a_star_local = Vobs**2 / r, while g_support_smooth drives derivatives.
    # Keep the original FITPACK evaluations bit-for-bit for admissible
    # profiles. This prevents tiny basis-roundoff differences from moving
    # a highly nonlinear galaxy fit between nearby optimization basins.
    if not adjusted:
        log_g_smooth = original_spline(x)
        g_smooth = np.exp(log_g_smooth)
        slope = original_spline.derivative(1)(x)
        sigma_c_squared = (1.0 - slope) / 3.0
        curvature_log_support = original_spline.derivative(2)(x)
    else:
        repaired_log_g = BSpline(t, repaired_coeff + greville, degree)
        log_g_smooth = repaired_log_g(x)
        g_smooth = np.exp(log_g_smooth)
        # Exact nonnegative basis representation; no clipping or flooring.
        derivative_knot_diffs = t[degree + 1:degree + n_coef] - t[1:n_coef]
        if np.any(derivative_knot_diffs <= 0.0):
            raise RuntimeError("Invalid spline derivative knot spans")
        positive_sigma_basis = BSpline(
            t[1:-1], degree * d / (3.0 * derivative_knot_diffs), degree - 1
        )
        sigma_c_squared = np.asarray(positive_sigma_basis(x), dtype=float)
        slope = 1.0 - 3.0 * sigma_c_squared
        curvature_log_support = repaired_log_g.derivative(2)(x)
    # Nonnegative support state; no upper clipping of Sigma_C^2.
    if np.any(~np.isfinite(sigma_c_squared)) or np.any(sigma_c_squared < 0.0):
        raise RuntimeError("Nonnegative spline support-state condition failed")
    dg_dr = g_smooth * slope / r_m
    original_sigma = (1.0 - original_spline.derivative(1)(x)) / 3.0
    support_chi2_original = np.sum(
        ((np.sqrt(np.exp(original_spline(x)) * r_m) - vobs_m_s) / errv_m_s) ** 2
    )
    support_chi2_corrected = np.sum(
        ((np.sqrt(g_smooth * r_m) - vobs_m_s) / errv_m_s) ** 2
    )
    return {
        "x_log_r": x,
        "g_support_observed": g_observed,
        "g_support_smooth": g_smooth,
        "sigma_g": sigma_g,
        "log_slope": slope,
        "log_slope_derivative": np.asarray(curvature_log_support, dtype=float),
        "dg_dr": dg_dr,
        "Sigma_C_squared": sigma_c_squared,
        "Sigma_C_squared_original_unconstrained": original_sigma,
        "support_shape_adjusted": adjusted,
        "support_chi2_original": float(support_chi2_original),
        "support_chi2_corrected": float(support_chi2_corrected),
        "a_star_local": g_observed.copy(),
    }

def cptg_bpol_from_support(
    r_m: np.ndarray,
    support_state: Dict[str, np.ndarray],
    kappa_kpc: float,
) -> np.ndarray:
    """Exact radial derivative of the polarization flux.

    Uses first and second log-radius derivatives of the SAME continuous
    uncertainty-weighted (and, where required, shape-projected) support
    spline. No secondary flux interpolation, additional physics, clipping,
    new fit parameters, or changes to the local a_star are introduced.

    Equivalent to:
      C = g**2 + kappa**2*(gprime**2 + 2*(g/r)**2)
      B_pol = P*g - kappa**2 * (Pprime*gprime + P*gsecond
                             + 2*P/r*(gprime-g/r))
      P = C**(-2/3)
    """
    r_m = np.asarray(r_m, dtype=float)
    g = np.asarray(support_state["g_support_smooth"], dtype=float)
    s = np.asarray(support_state["log_slope"], dtype=float)
    t = np.asarray(support_state["log_slope_derivative"], dtype=float)
    kappa_m = max(float(kappa_kpc), CPTG_KAPPA_MIN_KPC) * KPC_TO_M
    z = (kappa_m / r_m) ** 2
    h = s**2 + 2.0
    # Algebraically identical to the Q polynomial obtained from the exact
    # product rule.  The factored form avoids subtracting s*s+s+t-2 at
    # s nearly 1, where tiny second derivatives matter for large kappa/r.
    q_linear = 4.0 - s - t + (4.0 / 3.0)*s*s
    q_quadratic = h * (s - 1.0) * (s / 3.0 - 2.0) \
        + t * (s*s / 3.0 - 2.0)
    Q = 1.0 + q_linear*z + q_quadratic*z*z
    C = g**2 * (1.0 + h*z)
    return g * C**(-2.0 / 3.0) * Q / (1.0 + h*z)

def _solve_cptg_implicit_high_accel(
    gbar: np.ndarray,
    a_star_local: np.ndarray,
    sigma_c_squared: np.ndarray,
    B_pol: np.ndarray,
    A_C: float,
    c_C: float,
) -> Tuple[Optional[np.ndarray], Optional[np.ndarray]]:
    """Solve the implicit high-acceleration-suppressed field."""
    gbar = np.asarray(gbar, dtype=float)
    a_star_local = np.maximum(np.asarray(a_star_local, dtype=float), EPS)
    sigma_c_squared = np.asarray(sigma_c_squared, dtype=float)
    B_pol = np.asarray(B_pol, dtype=float)

    denominator = 1.0 + float(c_C) * sigma_c_squared
    polarization_raw = float(A_C) * a_star_local ** (2.0 / 3.0) * B_pol

    g = np.maximum(
        (gbar + polarization_raw * CPTG_SUPPRESSION_AT_UNIT_RATIO) / denominator,
        EPS,
    )

    for _ in range(28):
        ratio = np.maximum(g / a_star_local, 1.0e-16)
        ratio_p = ratio ** CPTG_SUPPRESSION_INNER_POWER
        suppression = (1.0 + ratio_p) ** (-CPTG_SUPPRESSION_OUTER_POWER)
        F = denominator * g - gbar - polarization_raw * suppression
        dS_dg = (
            -CPTG_SUPPRESSION_OUTER_POWER
            * CPTG_SUPPRESSION_INNER_POWER
            * ratio ** (CPTG_SUPPRESSION_INNER_POWER - 1.0)
            / a_star_local
            * (1.0 + ratio_p) ** (-CPTG_SUPPRESSION_OUTER_POWER - 1.0)
        )
        dF_dg = denominator - polarization_raw * dS_dg
        if np.any(~np.isfinite(dF_dg)) or np.any(np.abs(dF_dg) < 1.0e-25):
            break
        trial = g - F / dF_dg
        invalid = (~np.isfinite(trial)) | (trial <= 0.0)
        trial = np.where(invalid, 0.5 * g, trial)
        rel = float(np.max(np.abs(trial - g) / np.maximum(np.abs(trial), EPS)))
        g = trial
        if rel < 2.0e-11:
            break

    ratio = np.maximum(g / a_star_local, 1.0e-16)
    suppression = (1.0 + ratio ** CPTG_SUPPRESSION_INNER_POWER) ** (-CPTG_SUPPRESSION_OUTER_POWER)
    F = denominator * g - gbar - polarization_raw * suppression
    scale = np.maximum(
        np.abs(denominator * g) + np.abs(gbar) + np.abs(polarization_raw * suppression),
        EPS,
    )
    normalized_residual = float(np.max(np.abs(F) / scale))

    if (
        np.any(~np.isfinite(g))
        or np.any(g <= 0.0)
        or not np.isfinite(normalized_residual)
        or normalized_residual > 5.0e-8
    ):
        g = np.maximum(
            (gbar + polarization_raw * CPTG_SUPPRESSION_AT_UNIT_RATIO) / denominator,
            EPS,
        )
        for _ in range(180):
            ratio = np.maximum(g / a_star_local, 1.0e-16)
            suppression = (1.0 + ratio ** CPTG_SUPPRESSION_INNER_POWER) ** (-CPTG_SUPPRESSION_OUTER_POWER)
            trial = (gbar + polarization_raw * suppression) / denominator
            if np.any(~np.isfinite(trial)) or np.any(trial <= 0.0):
                return None, None
            updated = 0.55 * trial + 0.45 * g
            rel = float(np.max(np.abs(updated - g) / np.maximum(np.abs(updated), EPS)))
            g = updated
            if rel < 1.0e-11:
                break

        ratio = np.maximum(g / a_star_local, 1.0e-16)
        suppression = (1.0 + ratio ** CPTG_SUPPRESSION_INNER_POWER) ** (-CPTG_SUPPRESSION_OUTER_POWER)
        exact = (gbar + polarization_raw * suppression) / denominator
        if (
            np.any(~np.isfinite(exact))
            or np.any(exact <= 0.0)
            or float(np.max(np.abs(exact - g) / np.maximum(np.abs(exact), EPS))) > 2.0e-7
        ):
            return None, None
        g = exact

    ratio = np.maximum(g / a_star_local, 1.0e-16)
    suppression = (1.0 + ratio ** CPTG_SUPPRESSION_INNER_POWER) ** (-CPTG_SUPPRESSION_OUTER_POWER)
    return g, suppression
