"""Stellar and gas mass reconstruction for the SPARC material inventory.
The numerical function bodies are preserved from the registered implementation.
"""
import numpy as np
from scipy.optimize import lsq_linear
from scipy.interpolate import PchipInterpolator
from numpy.polynomial.legendre import leggauss
G = 4.30091727003628e-6


def phot_profile(r, sb):
  """Log-linear interpolant with log-linear extrapolation anchored to first/last real positive SB.
  Zero SB at a sampled radius is treated as an unavailable/non-detection, not literal zero.
  Inner/outer slope taken from first/last three positive points, with monotonicity bounds.
  """
  ok=(sb>0)&np.isfinite(sb)
  xx=r[ok]; yy=np.log(sb[ok]);
  if len(xx)<3: return None,{'status':'insufficient_photometry'}
  s0=np.polyfit(xx[:min(4,len(xx))],yy[:min(4,len(yy))],1)[0]
  s1=np.polyfit(xx[-min(5,len(xx)):],yy[-min(5,len(xx)):],1)[0]
  s0=min(-0.00001,s0); s1=min(-0.00001,s1)
  interp=PchipInterpolator(xx,yy,extrapolate=False)
  def f(rv):
   rv=np.asarray(rv); out=np.empty_like(rv,dtype=float);
   lo=rv<xx[0];hi=rv>xx[-1];mid=~(lo|hi)
   out[lo]=yy[0]+s0*(rv[lo]-xx[0]);out[hi]=yy[-1]+s1*(rv[hi]-xx[-1]);out[mid]=interp(rv[mid]);
   return np.exp(np.clip(out,-30,25))
  info=dict(status='ok',photometric_n=int(ok.sum()),r_first_photo=float(xx[0]),r_last_photo=float(xx[-1]),inner_log_slope_kpc_inv=float(s0),outer_log_slope_kpc_inv=float(s1))
  return f,info

def ring_kernel(obs_r, edges, thickness, nr=10, nphi=120):
  """K[i,j] = V_signed^2(R_i) per annulus 1 Msun/pc2 constant density.
  Axisymmetric softened Newtonian ring force; sign retains inward/outward attraction.
  """
  x,w=leggauss(nr);phi,wp=leggauss(nphi);phi=(phi+1)*np.pi/2;wp=wp*np.pi/2
  cp=np.cos(phi);M=np.zeros((len(obs_r),len(edges)-1));
  for j,(lo,hi) in enumerate(zip(edges[:-1],edges[1:])):
   aa=(lo+hi)/2+(hi-lo)*x/2
   for i,r in enumerate(obs_r):
    rr=r*r+aa[:,None]**2-2*r*aa[:,None]*cp[None,:]+thickness**2
    jval=(r-aa[:,None]*cp[None,:])/np.power(rr,1.5)
    avg=(jval@wp)/np.pi
    # 2pi a da times density 1Msun/pc2=1e6 Msun/kpc2
    M[i,j]=G*1e6*r*(2*np.pi)*(hi-lo)/2*np.sum(w*aa*avg)
  return M

def ring_aperture(edges,sigma, R):
  R=np.asarray(R,dtype=float); lo=edges[:-1][None,:];hi=edges[1:][None,:]
  frac_area=np.clip(R[:,None]**2-lo**2,0,hi**2-lo**2)
  return np.sum(np.pi*1e6*frac_area*sigma[None,:],axis=1)

def gas_fit(r,vg,extent=2.0, thickness=0.2, lam=0.12):
  """Fitted gas surface-density steps, nonnegative; normalized regularized signed force.
  No Vobs or other galaxy metadata. Add radially exterior rings, because their gravity
  contributes inside the final SPARC radius and can be negative there.
  """
  nbin=max(16, min(42, int(1.2*len(r))+12))
  # more bins where observations constrain profile, spaced linearly inside data region,
  # logarithmically beyond; even inside core to avoid missed centers
  nr_inner=max(12, int(0.68*nbin))
  edges0=np.linspace(0,float(r[-1]),nr_inner+1)
  edges1=np.geomspace(r[-1],max(1.01,extent)*r[-1],nbin-nr_inner+1)[1:]
  edges=np.concatenate((edges0,edges1));
  ker=ring_kernel(r,edges,thickness)
  y=vg*np.abs(vg)
  scale=max(np.max(np.abs(y)),25.)
  A=ker/scale;b=y/scale
  # Penalize second differences in surface density scaled by independently sized prior.
  pos=np.max(np.abs(A),axis=0); scaleS=1/max(np.median(pos[pos>1e-12]),1e-5)
  # unknown x = sigma / scaleS, reasonable x~ order 1
  A=A*scaleS
  d2=np.diff(np.eye(nbin),n=2,axis=0)
  # exponential tail condition last bin weak penalty; doesn't force positivity violation
  reg=np.vstack((lam*d2, np.sqrt(lam)*np.eye(nbin)[-1:,:]))
  sol=lsq_linear(np.vstack((A,reg)),np.r_[b,np.zeros(reg.shape[0])],bounds=(0,np.inf),tol=1e-11,max_iter=800,lsmr_tol='auto')
  sigma=sol.x*scaleS
  pred=ker@sigma
  vpred=np.sign(pred)*np.sqrt(np.abs(pred))
  Vfit_err=np.sqrt(np.mean((vpred-vg)**2))
  stats={'n_bins':nbin,'extent_factor':extent,'thickness_kpc':thickness,'lambda':lam,
    'solver_status':int(sol.status),'solver_success':bool(sol.success),'solver_message':sol.message,
    'condition_kappa_est':float(np.linalg.cond(A)),'gas_signedV2_rmse_km2_s2':float(np.sqrt(np.mean((pred-y)**2))),
    'gas_velocity_signed_rmse_km_s':float(Vfit_err),'gas_mass_inside_last_Msun':float(ring_aperture(edges,sigma,[r[-1]])[0]),
    'gas_mass_all_model_Msun':float(ring_aperture(edges,sigma,[edges[-1]])[0]),
    'positive_bins':int(np.sum(sigma>1e-8)), 'sigma_min_Msun_pc2':float(min(sigma)),
    'sigma_max_Msun_pc2':float(max(sigma))}
  return edges,sigma,pred,vpred,stats

def stellar_mass_integral(r,profile, R, upsilon):
 # Numeric integration of 2pi Sigma_L r from zero to R, with 3.6um luminosity in Lsun/pc2
 x=np.concatenate(([0],np.linspace(0,R*1.5,2500))); x=np.unique(x)
 sb=profile(x); L=2*np.pi*1e6*np.cumsum(np.diff(x)*((x[1:]*sb[1:]+x[:-1]*sb[:-1])/2))
 return upsilon*np.interp(r,x[1:],L), upsilon*L[-1]
