# Required Future Validation Queue

Source-tail truncation remains mandatory.

After numerical validation is extended toward the structural frontier:
- apply frozen relative truncation thresholds to the 14 native boundary-source contributions;
- perform all 14 leave-one-edge-out ablations;
- monitor A=24, 28, 40, 56, 80, 100, 119, 120, 140, 160 and frontier-selected sectors;
- distinguish structural survival from amplitude sensitivity;
- use no replacement seed or abundance floor.
