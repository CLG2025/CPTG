# CPTG PRIMAT A=338→339 Structural Frontier Forensic — r10

r08 established:

```text
reachable_max_A             338
eligible_rate_library_max_A 339
first_gap_A                 None
frontier cause              GRAPH_EXHAUSTION_BELOW_LIBRARY_CEILING
```

r10 explains exactly why A=339 is disconnected under the frozen graph rule.

It imports no heavy numerical endpoint result and imposes no artificial Amax.

## Windows

```cmd
cd /d D:\Downloads\CPTG_PRIMAT_PostA119_A338A339_StructuralFrontierForensic_20260818_r10
RUN_STATIC_VERIFY_WINDOWS.cmd
RUN_ADOPT_R06_NATIVE_AUTHORITY_WINDOWS.cmd
RUN_FRONTIER_FORENSIC_WINDOWS.cmd
```

Expected structural conclusion is one of the frozen classifications, ideally:

```text
R10_FRONTIER_CLASSIFICATION A339_DISCONNECTED_RATE_ISLAND__ALL_INCOMING_SOURCES_UNREACHABLE
R10_A338_A339_STRUCTURAL_FRONTIER_FORENSIC PASS
```

or:

```text
R10_FRONTIER_CLASSIFICATION A339_ELIGIBLE_NODES_WITH_NO_ALLOWED_INCOMING_EDGE
R10_A338_A339_STRUCTURAL_FRONTIER_FORENSIC PASS
```

Any unexpected reachable bridge or frontier escape fails closed with `AUDIT_HOLD`.

Source-tail truncation remains queued in `FUTURE_VALIDATION_QUEUE.md`.
