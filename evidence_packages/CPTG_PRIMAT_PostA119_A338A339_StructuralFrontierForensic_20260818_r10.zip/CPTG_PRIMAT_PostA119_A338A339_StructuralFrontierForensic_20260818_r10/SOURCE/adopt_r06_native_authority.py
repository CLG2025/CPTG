from __future__ import annotations
import json,hashlib,shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; SRC=Path(r"D:\Downloads\CPTG_PRIMAT_NativeBoundaryFlux_A1A119_FinalEvidenceValidation_20260818_r06"); EXPECT="97fd7b4f4f4e7466be9e45be264e62faade5b55e80d415201ed4390405080f9a"
def sha(p):
    h=hashlib.sha256()
    with p.open("rb") as f:
        for b in iter(lambda:f.read(1048576),b""):h.update(b)
    return h.hexdigest()
def main():
    for d in ("EVIDENCE","OUTPUT"):(ROOT/d).mkdir(parents=True,exist_ok=True)
    fp=SRC/"OUTPUT/NATIVE_TRAJECTORY_FREEZE.json"
    fs=SRC/"EVIDENCE/FINAL_VALIDATION_SUMMARY.json"
    if not fs.is_file() or json.loads(fs.read_text())["decision"]!="PASS":raise RuntimeError("r06 PASS required")
    if not fp.is_file() or sha(fp)!=EXPECT:raise RuntimeError("freeze mismatch")
    fr=json.loads(fp.read_text())
    for rec in fr["files"]:
        s=SRC/rec["path"]
        if not s.is_file() or sha(s)!=rec["sha256"]:raise RuntimeError("native member mismatch "+rec["path"])
        d=ROOT/rec["path"];d.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(s,d)
    shutil.copy2(fp,ROOT/"OUTPUT/NATIVE_TRAJECTORY_FREEZE.json")
    out={"schema":"cptg-r10-native-adoption-v1","pass":True,"freeze_sha256":EXPECT,
          "numerical_endpoint_results_imported":False}
    (ROOT/"EVIDENCE/AUTHORITY_ADOPTION.json").write_text(json.dumps(out,indent=2,sort_keys=True)+"\n",encoding="utf-8")
    print("R10_AUTHORITY_ADOPTION PASS")
    print("FREEZE_SHA256",EXPECT)
    print("NUMERICAL_ENDPOINT_RESULTS_IMPORTED False")
if __name__=="__main__":main()
