from __future__ import annotations
import json,hashlib,py_compile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def ck(n,c):
    if not c:raise RuntimeError(n+" FAIL")
    print(n,"PASS")
def main():
    p=json.loads((ROOT/"CONFIG/FROZEN_R10_FRONTIER_FORENSIC.json").read_text())
    ck("R10_SCOPE",p["frozen_r08_observation"]["reachable_max_A"]==338 and p["frozen_r08_observation"]["eligible_rate_library_max_A"]==339)
    ck("R08_DECISION_PRESERVED",p["frozen_r08_observation"]["decision"]=="GAP_FREE_TO_FRONTIER")
    ck("NO_ENDPOINT_IMPORT",p["authority"]["no_numerical_endpoint_import"] is True)
    ck("NO_ARTIFICIAL_AMAX",p["graph_rule"]["artificial_Amax"] is None)
    ck("SAME_R08_GRAPH",p["graph_rule"]["same_as_r08"] is True)
    ck("SOURCE_TAIL_QUEUED","tail truncation" in p["future_required_diagnostic"].lower())
    s=(ROOT/"SOURCE/run_frontier_forensic.py").read_text()
    ck("A338_FRONTIER_INSPECTION","x[0]==338" in s)
    ck("A339_NODE_INSPECTION","x[0]==339" in s)
    ck("A339_INCOMING_FORENSIC","INCOMING_EDGES_TO_A339.csv" in s)
    ck("FRONTIER_OUTGOING_FORENSIC","A338_FRONTIER_OUTGOING_EDGES.csv" in s)
    pys=sorted((ROOT/"SOURCE").glob("*.py"))
    for q in pys:py_compile.compile(str(q),doraise=True)
    print("PYTHON_COMPILE",f"{len(pys)}/{len(pys)}","PASS")
    bad=[];n=0
    for line in (ROOT/"MANIFEST.sha256").read_text().splitlines():
        if line.strip():
            h,rel=line.split("  ",1);n+=1;q=ROOT/rel
            if not q.is_file() or sha(q)!=h:bad.append(rel)
    ck(f"PACKAGE_MANIFEST {n-len(bad)}/{n}",not bad)
    print("R10_FRONTIER_FORENSIC_STATIC_VERIFY PASS")
if __name__=="__main__":main()
