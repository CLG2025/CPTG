from __future__ import annotations
import csv, json, importlib.metadata
from collections import defaultdict, deque
import numpy as np
import pynucastro as pyna
from common import *

LIGHT_TUPLES=set(LIGHT)
def nt(n):return int(n.A),int(n.Z)

def select_rates():
    rl=pyna.ReacLibLibrary();caps=[];betas=[];nodes=set()
    for r in rl.get_rates():
        rea=[nt(x) for x in r.reactants];pro=[nt(x) for x in r.products]
        if not r.weak and len(rea)==2 and len(pro)==1:
            ls=[x for x in rea if x in LIGHT_TUPLES]
            if len(ls)==1:
                l=ls[0];h=rea[1] if rea[0]==l else rea[0];d=pro[0]
                if h[0]>=6 and d==(h[0]+l[0],h[1]+l[1]):
                    caps.append((h,l,d,r));nodes.add(h);nodes.add(d)
        if r.weak and getattr(r,"weak_type",None)=="beta_neg" and len(rea)==1 and len(pro)==1:
            s,d=rea[0],pro[0]
            if s[0]>=6 and d[0]==s[0] and d[1]==s[1]+1:
                betas.append((s,d,r));nodes.add(s);nodes.add(d)
    caps.sort(key=lambda x:(x[0],x[1],x[2],str(x[3])))
    betas.sort(key=lambda x:(x[0],x[1],str(x[2])))
    return caps,betas,nodes

def native():
    sets=[]
    for eta in ETA:
        z=np.load(OUTPUT/f"NATIVE_TRAJECTORIES/PRIMAT_NATIVE_TRAJECTORY_ETA{eta_tag(eta)}.npz")
        sets.append(set(parse_primat_name(str(n)) for n in z["species"]))
    if any(s!=sets[0] for s in sets[1:]):raise RuntimeError("native species identity mismatch")
    return sets[0]

def main():
    if importlib.metadata.version("pynucastro")!="2.11.0":raise RuntimeError("pynucastro 2.11.0 required")
    if sha_file(OUTPUT/"NATIVE_TRAJECTORY_FREEZE.json")!="97fd7b4f4f4e7466be9e45be264e62faade5b55e80d415201ed4390405080f9a":
        raise RuntimeError("freeze mismatch")
    if load_json(EVIDENCE/"AUTHORITY_ADOPTION.json").get("pass") is not True:raise RuntimeError("adoption required")
    nat=native();caps,betas,nodes=select_rates()
    src=[(h,l,d,r) for h,l,d,r in caps if h in nat and d not in nat and d[0]>=24]
    seeds={d for h,l,d,r in src}
    cb=defaultdict(list);bb=defaultdict(list)
    incoming=defaultdict(list)
    for h,l,d,r in caps:
        if h[0]>=24:
            cb[h].append((d,l,r)); incoming[d].append(("capture",h,l,r))
    for s,d,r in betas:
        if s[0]>=24:
            bb[s].append((d,r)); incoming[d].append(("beta_minus",s,None,r))
    seen=set(seeds);q=deque(sorted(seeds))
    while q:
        s=q.popleft()
        for d,l,r in cb.get(s,[]):
            if d not in seen:seen.add(d);q.append(d)
        for d,r in bb.get(s,[]):
            if d not in seen:seen.add(d);q.append(d)
    maxA=max(a for a,z in seen)
    if maxA!=338:raise RuntimeError(f"expected r08 frontier A338, got A{maxA}")
    frontier=sorted([x for x in seen if x[0]==338],key=lambda x:x[1])
    a339=sorted([x for x in nodes if x[0]==339],key=lambda x:x[1])
    inc339=[]
    for d in a339:
        for kind,s,l,r in incoming.get(d,[]):
            inc339.append({"dst":az_name(*d),"dst_Z":d[1],"kind":kind,
                           "src":az_name(*s),"src_A":s[0],"src_Z":s[1],
                           "light":az_name(*l) if l else "",
                           "src_reachable":s in seen,"rate":str(r)})
    frontier_out=[]
    for s in frontier:
        for d,l,r in cb.get(s,[]):
            frontier_out.append({"src":az_name(*s),"kind":"capture","light":az_name(*l),
                                 "dst":az_name(*d),"dst_A":d[0],"dst_Z":d[1],
                                 "dst_reachable":d in seen,"rate":str(r)})
        for d,r in bb.get(s,[]):
            frontier_out.append({"src":az_name(*s),"kind":"beta_minus","light":"",
                                 "dst":az_name(*d),"dst_A":d[0],"dst_Z":d[1],
                                 "dst_reachable":d in seen,"rate":str(r)})
    bridge_to_339=[x for x in inc339 if x["src_reachable"]]
    escape=[x for x in frontier_out if not x["dst_reachable"]]
    reachable_counts={}
    eligible_counts={}
    for A,Z in seen:reachable_counts[A]=reachable_counts.get(A,0)+1
    for A,Z in nodes:eligible_counts[A]=eligible_counts.get(A,0)+1

    RESULTS.mkdir(parents=True,exist_ok=True);EVIDENCE.mkdir(parents=True,exist_ok=True)
    with (RESULTS/"A338_REACHABLE_FRONTIER_NUCLIDES.csv").open("w",newline="",encoding="utf-8") as f:
        w=csv.writer(f);w.writerow(["nuclide","A","Z"])
        for A,Z in frontier:w.writerow([az_name(A,Z),A,Z])
    with (RESULTS/"A339_ELIGIBLE_NUCLIDES.csv").open("w",newline="",encoding="utf-8") as f:
        w=csv.writer(f);w.writerow(["nuclide","A","Z","reachable"])
        for A,Z in a339:w.writerow([az_name(A,Z),A,Z,(A,Z) in seen])
    with (RESULTS/"INCOMING_EDGES_TO_A339.csv").open("w",newline="",encoding="utf-8") as f:
        fields=["dst","dst_Z","kind","src","src_A","src_Z","light","src_reachable","rate"]
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(inc339)
    with (RESULTS/"A338_FRONTIER_OUTGOING_EDGES.csv").open("w",newline="",encoding="utf-8") as f:
        fields=["src","kind","light","dst","dst_A","dst_Z","dst_reachable","rate"]
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(frontier_out)
    rows=[]
    for A in range(330,340):
        rows.append({"A":A,"reachable_nuclides":reachable_counts.get(A,0),
                     "eligible_rule_nodes":eligible_counts.get(A,0)})
    with (RESULTS/"NEAR_FRONTIER_MASS_CENSUS.csv").open("w",newline="",encoding="utf-8") as f:
        w=csv.DictWriter(f,fieldnames=["A","reachable_nuclides","eligible_rule_nodes"]);w.writeheader();w.writerows(rows)

    if bridge_to_339:
        classification="UNEXPECTED_REACHABLE_PREDECESSOR_TO_A339"
    elif escape:
        classification="UNEXPECTED_FRONTIER_ESCAPE_EDGE"
    elif a339 and inc339:
        classification="A339_DISCONNECTED_RATE_ISLAND__ALL_INCOMING_SOURCES_UNREACHABLE"
    elif a339:
        classification="A339_ELIGIBLE_NODES_WITH_NO_ALLOWED_INCOMING_EDGE"
    else:
        classification="NO_A339_ELIGIBLE_NODE"
    out={"schema":"cptg-r10-a338-a339-frontier-forensic-result-v1",
         "decision":"PASS" if classification.startswith("A339_") else "AUDIT_HOLD",
         "classification":classification,
         "reachable_max_A":maxA,
         "A338_reachable_frontier_nuclides":[az_name(*x) for x in frontier],
         "A338_frontier_count":len(frontier),
         "A339_eligible_nuclides":[az_name(*x) for x in a339],
         "A339_eligible_count":len(a339),
         "incoming_edges_to_A339":len(inc339),
         "incoming_edges_to_A339_from_reachable_sources":len(bridge_to_339),
         "A338_outgoing_edges_total":len(frontier_out),
         "A338_outgoing_edges_to_unreachable_nodes":len(escape),
         "near_frontier_mass_census":rows,
         "artificial_Amax_used":False,
         "numerical_endpoint_results_imported":False}
    atomic_json(EVIDENCE/"A338_A339_STRUCTURAL_FRONTIER_FORENSIC.json",out)
    print("R10_A338_FRONTIER_NUCLIDES",len(frontier))
    print("R10_A339_ELIGIBLE_NUCLIDES",len(a339))
    print("R10_A339_INCOMING_EDGES",len(inc339))
    print("R10_A339_INCOMING_FROM_REACHABLE",len(bridge_to_339))
    print("R10_A338_OUTGOING_TO_UNREACHABLE",len(escape))
    print("R10_FRONTIER_CLASSIFICATION",classification)
    print("R10_A338_A339_STRUCTURAL_FRONTIER_FORENSIC",out["decision"])
    if out["decision"]!="PASS":raise SystemExit(5)
if __name__=="__main__":main()
