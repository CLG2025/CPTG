#!/usr/bin/env python3
"""Deterministic DF44 axisymmetric CPTG tensor calculation.

This program contains one calculation path:
  projected Sersic source -> oblate deprojection -> baryonic potential/force ->
  conservative CPTG equipotential response -> axisymmetric Jeans moments ->
  line-of-sight projection -> spatial-resolution convolution -> elliptical apertures.

No dark-halo source, source-weight coefficient, pointwise structural acceleration,
Satoh amplitude, or fitted anisotropy coefficient is used.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
from dataclasses import dataclass
from pathlib import Path

import numpy as np
from numpy.polynomial.legendre import leggauss
from scipy.integrate import cumulative_trapezoid
from scipy.interpolate import PchipInterpolator, RegularGridInterpolator
from scipy.ndimage import gaussian_filter
from scipy.optimize import brentq
from scipy.special import gamma, gammainc, gammaincinv

G_KPC_KMS2_MSUN = 4.300917270036279e-6
C_KMS = 299792.458
KPC_M = 3.0856775814913673e19
MPS2_PER_KMS2_PER_KPC = 1.0e6 / KPC_M
ARCSEC_TO_KPC_AT_100_MPC = 100000.0 / 206265.0

OBS_R_CIRC = np.array([0.23, 0.49, 0.79, 1.13, 1.53, 1.94, 2.55, 3.62, 5.13])
RADIUS_MAJOR_DIVISOR = 0.83
OBS_R_MAJOR = OBS_R_CIRC / RADIUS_MAJOR_DIVISOR
OBS_V = np.array([0.2, -3.4, -3.1, -0.7, 0.5, 0.7, -0.4, 0.3, 5.9])
OBS_V_MINUS = np.array([2.6, 2.8, 2.5, 1.8, 2.6, 2.0, 2.0, 2.5, 4.1])
OBS_V_PLUS = np.array([2.2, 2.6, 2.2, 2.0, 2.0, 2.0, 2.3, 2.3, 3.8])
OBS_SIGMA = np.array([26.1, 26.7, 26.5, 31.8, 29.1, 29.5, 29.3, 34.4, 40.2])
OBS_SIGMA_MINUS = np.array([3.5, 3.4, 2.9, 2.9, 2.4, 2.6, 2.5, 3.6, 7.6])
OBS_SIGMA_PLUS = np.array([4.4, 4.1, 4.4, 3.3, 3.4, 3.0, 3.1, 3.8, 7.9])

@dataclass(frozen=True)
class GalaxyInputs:
    distance_mpc: float = 100.0
    re_major_kpc: float = 4.7
    sersic_n: float = 0.94
    q_projected: float = 0.68
    q_aperture: float = 0.69
    stellar_mass_msun: float = 3.0e8
    half_light_second_moment_kms: float = 33.0
    psf_fwhm_arcsec: float = 1.2


def observed_second_moment():
    eff = np.sqrt(OBS_SIGMA**2 + OBS_V**2)
    # First-order propagation with the velocity error chosen to increase/decrease |v|.
    v_up = np.where(OBS_V >= 0, OBS_V_PLUS, OBS_V_MINUS)
    v_down = np.where(OBS_V >= 0, OBS_V_MINUS, OBS_V_PLUS)
    plus = np.sqrt((OBS_SIGMA / eff * OBS_SIGMA_PLUS) ** 2 +
                   (np.abs(OBS_V) / eff * v_up) ** 2)
    minus = np.sqrt((OBS_SIGMA / eff * OBS_SIGMA_MINUS) ** 2 +
                    (np.abs(OBS_V) / eff * v_down) ** 2)
    return eff, minus, plus


class SersicOblate:
    def __init__(self, inputs: GalaxyInputs, q_intrinsic: float,
                 density_nodes: int = 1400, abel_nodes: int = 240,
                 force_nodes: int = 144):
        self.inputs = inputs
        self.q = float(q_intrinsic)
        self.bn = float(gammaincinv(2.0 * inputs.sersic_n, 0.5))
        n = inputs.sersic_n
        re = inputs.re_major_kpc
        qp = inputs.q_projected
        self.sigma_e = inputs.stellar_mass_msun / (
            2.0 * np.pi * qp * re**2 * n * np.exp(self.bn)
            * self.bn**(-2.0*n) * gamma(2.0*n)
        )
        self._build_density(density_nodes, abel_nodes)
        self._build_force_quadrature(force_nodes)

    def surface_density(self, radius):
        radius = np.asarray(radius)
        n = self.inputs.sersic_n
        return self.sigma_e * np.exp(
            -self.bn * ((radius / self.inputs.re_major_kpc)**(1.0/n) - 1.0)
        )

    def surface_density_derivative(self, radius):
        radius = np.asarray(radius)
        n = self.inputs.sersic_n
        x = np.maximum(radius / self.inputs.re_major_kpc, 1.0e-300)
        return (self.surface_density(radius) * (-self.bn / n / self.inputs.re_major_kpc)
                * x**(1.0/n - 1.0))

    def _build_density(self, density_nodes, abel_nodes):
        m = np.geomspace(1.0e-6, 800.0, density_nodes)
        x, w = leggauss(abel_nodes)
        t = (x + 1.0) * 10.5
        wt = w * 10.5
        fac = -(self.inputs.q_projected / self.q) / np.pi
        pieces = []
        for part in np.array_split(m, 24):
            s = part[:, None] * np.cosh(t)[None, :]
            pieces.append(fac * np.sum(self.surface_density_derivative(s) * wt, axis=1))
        rho = np.concatenate(pieces)
        raw_mass = 4.0 * np.pi * self.q * np.trapezoid(rho * m**2, m)
        rho *= self.inputs.stellar_mass_msun / raw_mass
        self.raw_mass_msun = float(raw_mass)
        self.mass_scale = float(self.inputs.stellar_mass_msun / raw_mass)
        self.m_grid = m
        self.rho_grid = rho
        self.rho_interp = PchipInterpolator(
            np.log(m), np.log(np.maximum(rho, 1.0e-300)), extrapolate=False
        )
        h_integrand = 2.0 * rho * m
        h_cum = cumulative_trapezoid(h_integrand, m, initial=0.0)
        h = h_cum[-1] - h_cum
        self.h0 = float(h[0])
        self.h_interp = PchipInterpolator(m, h, extrapolate=False)

    def density(self, m):
        a = np.asarray(m)
        out = np.zeros_like(a, dtype=float)
        middle = (a >= self.m_grid[0]) & (a <= self.m_grid[-1])
        out[middle] = np.exp(self.rho_interp(np.log(a[middle])))
        out[a < self.m_grid[0]] = self.rho_grid[0]
        return float(out) if np.isscalar(m) else out

    def h_integral(self, m):
        a = np.asarray(m)
        out = np.zeros_like(a, dtype=float)
        out[a < self.m_grid[0]] = self.h0
        middle = (a >= self.m_grid[0]) & (a <= self.m_grid[-1])
        out[middle] = np.maximum(self.h_interp(a[middle]), 0.0)
        return float(out) if np.isscalar(m) else out

    def _build_force_quadrature(self, nodes):
        x, w = leggauss(nodes)
        t = (x + 1.0) / 2.0
        self.u = t / (1.0 - t)
        self.u_weight = (w / 2.0) / (1.0 - t)**2

    def field_and_potential(self, radius, z):
        radius = np.asarray(radius)
        z = np.asarray(z)
        shape = np.broadcast_shapes(radius.shape, z.shape)
        rr = np.broadcast_to(radius, shape).ravel()
        zz = np.broadcast_to(z, shape).ravel()
        grad_r = np.empty_like(rr, dtype=float)
        grad_z = np.empty_like(rr, dtype=float)
        potential = np.empty_like(rr, dtype=float)
        q = self.q
        chunk_size = 3500
        for start in range(0, rr.size, chunk_size):
            sl = slice(start, min(start + chunk_size, rr.size))
            r2 = rr[sl, None]
            z2 = zz[sl, None]
            u = self.u[None, :]
            uw = self.u_weight[None, :]
            m = np.sqrt(r2*r2/(1.0 + u) + z2*z2/(q*q + u))
            rho = self.density(m)
            root = np.sqrt(q*q + u)
            grad_r[sl] = (2.0*np.pi*G_KPC_KMS2_MSUN*q*rr[sl]
                          * np.sum(rho*uw/((1.0+u)**2*root), axis=1))
            grad_z[sl] = (2.0*np.pi*G_KPC_KMS2_MSUN*q*zz[sl]
                          * np.sum(rho*uw/((1.0+u)*(q*q+u)**1.5), axis=1))
            potential[sl] = (-np.pi*G_KPC_KMS2_MSUN*q
                             * np.sum(self.h_integral(m)*uw/((1.0+u)*root), axis=1))
        return grad_r.reshape(shape), grad_z.reshape(shape), potential.reshape(shape)


class TensorModel:
    def __init__(self, inputs: GalaxyInputs, inclination_deg: float, beta_z: float,
                 grid_nodes: int, force_nodes: int, sky_extent_kpc: float,
                 sky_pixel_kpc: float, los_nodes: int):
        self.inputs = inputs
        self.inclination_deg = float(inclination_deg)
        self.beta_z = float(beta_z)
        irad = np.deg2rad(self.inclination_deg)
        sin_i = np.sin(irad)
        cos_i = np.cos(irad)
        q2 = ((inputs.q_projected**2 - cos_i**2) / sin_i**2)
        if q2 <= 0.0:
            raise ValueError("inclination is below the oblate deprojection limit")
        self.q_intrinsic = float(np.sqrt(q2))
        self.source = SersicOblate(inputs, self.q_intrinsic, force_nodes=force_nodes)

        t = np.linspace(0.0, 1.0, grid_nodes)
        self.intrinsic_grid = 50.0 * t**2
        rr, zz = np.meshgrid(self.intrinsic_grid, self.intrinsic_grid, indexing="ij")
        ell = np.sqrt(rr**2 + zz**2/self.q_intrinsic**2)
        self.nu = self.source.density(ell)
        self.grad_r_bar, self.grad_z_bar, self.phi_bar = self.source.field_and_potential(rr, zz)
        self.phi0 = float(self.source.field_and_potential(np.array([0.0]), np.array([0.0]))[2][0])
        self.u_potential = self.phi_bar - self.phi0

        self.sky_extent_kpc = float(sky_extent_kpc)
        self.sky_pixel_kpc = float(sky_pixel_kpc)
        self.los_nodes = int(los_nodes)
        coords = np.arange(-self.sky_extent_kpc,
                           self.sky_extent_kpc + 0.5*self.sky_pixel_kpc,
                           self.sky_pixel_kpc)
        self.x_sky = coords
        self.y_sky = coords
        self.xx, self.yy = np.meshgrid(coords, coords, indexing="xy")
        # The published table reports the circularized/mean aperture coordinate R
        # and states R_major approximately equals R/0.83.  The extraction ellipses
        # therefore use semi-major-axis coordinate R_major.
        self.aperture_radius = np.sqrt(self.xx**2 + (self.yy/inputs.q_aperture)**2)
        self.circular_radius = np.sqrt(self.xx**2 + self.yy**2)

    @staticmethod
    def _scalar_cptg(g_bar, a_star_code, radius):
        rc = 48.0*np.pi*C_KMS**2/a_star_code
        g_geom = (0.5*a_star_code*(radius/rc)**(7.0/5.0)
                  / (1.0 + (radius/rc)**(12.0/5.0)))
        response = np.sqrt(a_star_code*np.maximum(g_bar, 0.0)) + g_geom
        p = 123.0/50.0
        q = 11.0/50.0
        g = g_bar + response
        for _ in range(18):
            x = np.maximum(g/a_star_code, 0.0)
            f = g - g_bar - response/(1.0 + x**p)**q
            df = (1.0 + response*q*p/a_star_code
                  * np.where(x > 0.0, x**(p-1.0), 0.0)
                  * (1.0+x**p)**(-q-1.0))
            candidate = g - f/df
            g = np.where(candidate > g_bar, candidate, 0.5*(g+g_bar))
        return g

    def conservative_amplification(self, a_star_mps2):
        a_code = a_star_mps2 / MPS2_PER_KMS2_PER_KPC
        r_eq = np.concatenate(([0.0], np.geomspace(1.0e-5, 500.0, 1800)))
        g_eq, _, phi_eq = self.source.field_and_potential(r_eq, np.zeros_like(r_eq))
        u_eq = phi_eq - self.phi0
        g_cptg_eq = self._scalar_cptg(g_eq, a_code, r_eq)
        mask = (u_eq > 1.0e-12) & (g_eq > 1.0e-14)
        u = u_eq[mask]
        amp = g_cptg_eq[mask] / g_eq[mask]
        order = np.argsort(u)
        u = u[order]
        amp = amp[order]
        unique = np.r_[True, np.diff(u) > 1.0e-12]
        u = u[unique]
        amp = amp[unique]
        interp = PchipInterpolator(np.log(u), np.log(amp), extrapolate=True)

        def amplification(potential_label):
            x = np.maximum(np.asarray(potential_label), u[0])
            return np.exp(interp(np.log(x)))
        return amplification, a_code

    def intrinsic_second_moments(self, a_star_mps2):
        amplification, _ = self.conservative_amplification(a_star_mps2)
        amp = amplification(self.u_potential)
        grad_r = amp * self.grad_r_bar
        grad_z = amp * self.grad_z_bar

        vertical_integrand = self.nu * grad_z
        z = self.intrinsic_grid
        cumulative = cumulative_trapezoid(vertical_integrand, z, axis=1, initial=0.0)
        pressure_z = cumulative[:, -1, None] - cumulative
        density_floor = 1.0e-20 * np.max(self.nu)
        sigma_z2 = np.divide(pressure_z, self.nu, out=np.zeros_like(pressure_z),
                             where=self.nu > density_floor)
        sigma_r2 = sigma_z2 / (1.0 - self.beta_z)
        pressure_r = self.nu * sigma_r2
        dpressure_dr = np.gradient(pressure_r, self.intrinsic_grid, axis=0, edge_order=2)
        rr = self.intrinsic_grid[:, None]
        vphi2 = (sigma_r2 + rr*grad_r
                 + np.divide(rr*dpressure_dr, self.nu, out=np.zeros_like(pressure_r),
                             where=self.nu > density_floor))
        active = self.nu > 1.0e-10*np.max(self.nu)
        min_vphi2 = float(np.min(vphi2[active]))
        return sigma_r2, sigma_z2, vphi2, min_vphi2

    def projected_maps(self, a_star_mps2, apply_psf=True):
        sigma_r2, sigma_z2, vphi2, min_vphi2 = self.intrinsic_second_moments(a_star_mps2)
        grid = self.intrinsic_grid
        interpolation = dict(bounds_error=False, fill_value=0.0)
        density_i = RegularGridInterpolator((grid, grid), self.nu, **interpolation)
        sr_i = RegularGridInterpolator((grid, grid), sigma_r2, **interpolation)
        sz_i = RegularGridInterpolator((grid, grid), sigma_z2, **interpolation)
        sp_i = RegularGridInterpolator((grid, grid), vphi2, **interpolation)

        nodes, weights = leggauss(self.los_nodes)
        los = 50.0 * nodes
        los_weight = 50.0 * weights
        inc = np.deg2rad(self.inclination_deg)
        si, ci = np.sin(inc), np.cos(inc)
        x = self.xx.ravel()
        ysky = self.yy.ravel()
        denominator = np.zeros_like(x)
        numerator = np.zeros_like(x)

        for sightline, weight in zip(los, los_weight):
            y = ysky*ci - sightline*si
            z = ysky*si + sightline*ci
            radius = np.sqrt(x*x + y*y)
            points = np.column_stack([radius, np.abs(z)])
            nu = density_i(points)
            sr = sr_i(points)
            sz = sz_i(points)
            sp = sp_i(points)
            cosphi = np.divide(x, radius, out=np.ones_like(radius), where=radius > 0.0)
            sinphi = np.divide(y, radius, out=np.zeros_like(radius), where=radius > 0.0)
            second = (si*si*(sinphi*sinphi*sr + cosphi*cosphi*sp) + ci*ci*sz)
            denominator += weight*nu
            numerator += weight*nu*second

        denominator = denominator.reshape(self.xx.shape)
        numerator = numerator.reshape(self.xx.shape)
        if apply_psf:
            sigma_kpc = (self.inputs.psf_fwhm_arcsec*ARCSEC_TO_KPC_AT_100_MPC
                         / 2.354820045)
            sigma_pix = sigma_kpc/self.sky_pixel_kpc
            denominator = gaussian_filter(denominator, sigma_pix, mode="constant", cval=0.0)
            numerator = gaussian_filter(numerator, sigma_pix, mode="constant", cval=0.0)
        return denominator, numerator, min_vphi2

    def elliptical_aperture_sigma(self, denominator, numerator, radius_max):
        use = self.aperture_radius <= radius_max
        return float(np.sqrt(np.sum(numerator[use]) / np.sum(denominator[use])))

    def circular_aperture_sigma(self, denominator, numerator, radius_max):
        use = self.circular_radius <= radius_max
        return float(np.sqrt(np.sum(numerator[use]) / np.sum(denominator[use])))

    def annulus_sigmas(self, denominator, numerator, boundaries):
        values = []
        for inner, outer in zip(boundaries[:-1], boundaries[1:]):
            use = (self.aperture_radius >= inner) & (self.aperture_radius < outer)
            values.append(np.sqrt(np.sum(numerator[use]) / np.sum(denominator[use])))
        return np.asarray(values)

    def determine_a_star(self, target_kms=None):
        target = self.inputs.half_light_second_moment_kms if target_kms is None else float(target_kms)
        cache = {}
        def objective(log10_a):
            key = round(log10_a, 12)
            if key not in cache:
                a = 10.0**log10_a
                den, num, min_vphi2 = self.projected_maps(a, apply_psf=True)
                re_circ = self.inputs.re_major_kpc * np.sqrt(self.inputs.q_projected)
                cache[key] = (self.circular_aperture_sigma(den, num, re_circ), min_vphi2)
            return cache[key][0] - target
        a = 5.0e-10
        for _ in range(5):
            sigma = objective(np.log10(a)) + target
            if not np.isfinite(sigma) or sigma <= 0.0:
                break
            a *= (target/sigma)**4
        final_sigma = objective(np.log10(a)) + target
        if np.isfinite(final_sigma) and abs(final_sigma-target) < 2.0e-3:
            return a
        root = brentq(objective, -10.3, -8.5, xtol=2.0e-5)
        return 10.0**root


def sersic_fraction(radius, inputs):
    b = gammaincinv(2.0*inputs.sersic_n, 0.5)
    return gammainc(2.0*inputs.sersic_n,
                    b*(np.asarray(radius)/inputs.re_major_kpc)**(1.0/inputs.sersic_n))


def luminosity_weighted_mean(inner, outer, inputs):
    x, w = leggauss(96)
    r = 0.5*(outer-inner)*x + 0.5*(outer+inner)
    weight = 0.5*(outer-inner)*w
    b = gammaincinv(2.0*inputs.sersic_n, 0.5)
    surf = np.exp(-b*((r/inputs.re_major_kpc)**(1.0/inputs.sersic_n)-1.0))
    return float(np.sum(weight*r*r*surf)/np.sum(weight*r*surf))


def derive_annulus_boundaries(inputs):
    boundaries = [0.0]
    for target in OBS_R_MAJOR:
        lower = boundaries[-1]
        def f(upper):
            return luminosity_weighted_mean(lower, upper, inputs) - target
        high = max(target*2.0, lower+0.1)
        while f(high) < 0.0:
            high *= 1.3
        boundaries.append(brentq(f, lower+1.0e-8, high, xtol=1.0e-11))
    return np.asarray(boundaries)


def observational_operator(inputs):
    return {
        "tabulated_radius_role": "circularized_or_mean_aperture_coordinate",
        "radius_major_divisor": RADIUS_MAJOR_DIVISOR,
        "q_aperture": inputs.q_aperture,
        "re_major_kpc": inputs.re_major_kpc,
        "re_circularized_kpc": inputs.re_major_kpc*np.sqrt(inputs.q_projected),
        "half_light_normalization_aperture": "projected_circle",
    }

def statistics(prediction):
    obs, minus, plus = observed_second_moment()
    residual = prediction - obs
    directional = np.where(residual >= 0.0, plus, minus)
    pull = residual/directional
    return obs, minus, plus, residual, pull, float(np.sum(pull**2)), float(np.max(np.abs(pull)))


def make_model(inputs, inclination, beta, quality):
    if quality == "publication":
        return TensorModel(inputs, inclination, beta, grid_nodes=320, force_nodes=176,
                           sky_extent_kpc=10.0, sky_pixel_kpc=0.06, los_nodes=180)
    if quality == "verification":
        return TensorModel(inputs, inclination, beta, grid_nodes=180, force_nodes=112,
                           sky_extent_kpc=8.0, sky_pixel_kpc=0.10, los_nodes=100)
    if quality == "screening":
        return TensorModel(inputs, inclination, beta, grid_nodes=120, force_nodes=80,
                           sky_extent_kpc=7.0, sky_pixel_kpc=0.16, los_nodes=60)
    raise ValueError(quality)


def solve_branch(inputs, inclination, beta, quality="verification"):
    boundaries = derive_annulus_boundaries(inputs)
    model = make_model(inputs, inclination, beta, quality)
    a_star = model.determine_a_star()
    den, num, min_vphi2 = model.projected_maps(a_star, apply_psf=True)
    prediction = model.annulus_sigmas(den, num, boundaries)
    half = model.circular_aperture_sigma(den, num, inputs.re_major_kpc*np.sqrt(inputs.q_projected))
    obs, minus, plus, residual, pull, chi2, max_pull = statistics(prediction)
    rc_kpc = 48.0*np.pi*C_KMS**2/(a_star/MPS2_PER_KMS2_PER_KPC)
    return {
        "inclination_deg": inclination,
        "beta_z": beta,
        "q_intrinsic": model.q_intrinsic,
        "a_star_mps2": a_star,
        "rc_gpc": rc_kpc/1.0e6,
        "half_light_kms": half,
        "prediction": prediction,
        "obs": obs,
        "obs_minus": minus,
        "obs_plus": plus,
        "residual": residual,
        "pull": pull,
        "chi2_diag": chi2,
        "max_abs_pull": max_pull,
        "min_vphi2_active": min_vphi2,
        "boundaries": boundaries,
        "model": model,
    }


def stellar_only(inputs, quality="publication"):
    boundaries = derive_annulus_boundaries(inputs)
    model = make_model(inputs, 90.0, 0.0, quality)
    # Setting the force supplied to the Jeans equations to the baryonic field is
    # equivalent to an amplification of unity. Implement directly here.
    grid = model.intrinsic_grid
    f = model.nu*model.grad_z_bar
    cumulative = cumulative_trapezoid(f, grid, axis=1, initial=0.0)
    pz = cumulative[:, -1, None]-cumulative
    floor = 1.0e-20*np.max(model.nu)
    sz = np.divide(pz, model.nu, out=np.zeros_like(pz), where=model.nu>floor)
    sr = sz.copy()
    pr = model.nu*sr
    dpr = np.gradient(pr, grid, axis=0, edge_order=2)
    rr = grid[:, None]
    sp = sr + rr*model.grad_r_bar + np.divide(rr*dpr, model.nu, out=np.zeros_like(pr), where=model.nu>floor)

    opts = dict(bounds_error=False, fill_value=0.0)
    inu = RegularGridInterpolator((grid, grid), model.nu, **opts)
    ir = RegularGridInterpolator((grid, grid), sr, **opts)
    iz = RegularGridInterpolator((grid, grid), sz, **opts)
    ip = RegularGridInterpolator((grid, grid), sp, **opts)
    nodes, weights = leggauss(model.los_nodes)
    los = 50.0*nodes
    lw = 50.0*weights
    x = model.xx.ravel(); ysky=model.yy.ravel()
    num=np.zeros_like(x); den=np.zeros_like(x)
    # edge-on: intrinsic y=-los, z=ysky
    for l,w in zip(los,lw):
        y=-l*np.ones_like(x); z=ysky
        rad=np.sqrt(x*x+y*y)
        pts=np.column_stack([rad,np.abs(z)])
        nu=inu(pts); vr=ir(pts); vz=iz(pts); vp=ip(pts)
        cosphi=np.divide(x,rad,out=np.ones_like(rad),where=rad>0)
        sinphi=np.divide(y,rad,out=np.zeros_like(rad),where=rad>0)
        second=sinphi*sinphi*vr+cosphi*cosphi*vp
        den += w*nu; num += w*nu*second
    den=den.reshape(model.xx.shape); num=num.reshape(model.xx.shape)
    sigma_kpc=inputs.psf_fwhm_arcsec*ARCSEC_TO_KPC_AT_100_MPC/2.354820045
    sigma_pix=sigma_kpc/model.sky_pixel_kpc
    den=gaussian_filter(den,sigma_pix,mode="constant",cval=0.0)
    num=gaussian_filter(num,sigma_pix,mode="constant",cval=0.0)
    pred=model.annulus_sigmas(den,num,boundaries)
    half=model.circular_aperture_sigma(den,num,inputs.re_major_kpc*np.sqrt(inputs.q_projected))
    *_,chi2,maxpull=statistics(pred)
    return pred, half, chi2, maxpull


def write_csv(path, fieldnames, rows):
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer=csv.DictWriter(f,fieldnames=fieldnames)
        writer.writeheader(); writer.writerows(rows)


def run_primary(root):
    inputs=GalaxyInputs()
    result=solve_branch(inputs,90.0,0.0,"publication")
    stellar_pred,stellar_half,stellar_chi2,stellar_max=stellar_only(inputs,"publication")
    rows=[]
    for i in range(len(OBS_R_CIRC)):
        rows.append({
            "radius_circularized_kpc":f"{OBS_R_CIRC[i]:.2f}",
            "radius_major_kpc":f"{OBS_R_MAJOR[i]:.9f}",
            "observed_second_moment_kms":f"{result['obs'][i]:.9f}",
            "observed_minus_kms":f"{result['obs_minus'][i]:.9f}",
            "observed_plus_kms":f"{result['obs_plus'][i]:.9f}",
            "cptg_second_moment_kms":f"{result['prediction'][i]:.9f}",
            "stellar_only_second_moment_kms":f"{stellar_pred[i]:.9f}",
            "cptg_residual_kms":f"{result['residual'][i]:.9f}",
            "cptg_pull":f"{result['pull'][i]:.9f}",
        })
    write_csv(root/"results"/"primary_profile.csv",list(rows[0].keys()),rows)
    summary={
        "a_star_mps2":result["a_star_mps2"],
        "rc_gpc":result["rc_gpc"],
        "half_light_target_kms":inputs.half_light_second_moment_kms,
        "half_light_cptg_kms":result["half_light_kms"],
        "chi2_diag_cptg":result["chi2_diag"],
        "max_abs_pull_cptg":result["max_abs_pull"],
        "min_vphi2_active_kms2":result["min_vphi2_active"],
        "half_light_stellar_only_kms":stellar_half,
        "chi2_diag_stellar_only":stellar_chi2,
        "max_abs_pull_stellar_only":stellar_max,
        "inclination_deg":90.0,
        "beta_z":0.0,
        "q_intrinsic":result["q_intrinsic"],
    }
    (root/"results"/"primary_summary.json").write_text(json.dumps(summary,indent=2)+"\n")

    bounds=result["boundaries"]
    aperture_rows=[]
    for i,(a,b) in enumerate(zip(bounds[:-1],bounds[1:])):
        aperture_rows.append({
            "bin":i+1,
            "inner_major_kpc":f"{a:.9f}",
            "outer_major_kpc":f"{b:.9f}",
            "target_radius_circularized_kpc":f"{OBS_R_CIRC[i]:.9f}",
            "target_radius_major_kpc":f"{OBS_R_MAJOR[i]:.9f}",
            "recovered_mean_major_radius_kpc":f"{luminosity_weighted_mean(a,b,inputs):.9f}",
        })
    write_csv(root/"results"/"aperture_geometry.csv",list(aperture_rows[0].keys()),aperture_rows)
    (root/"results"/"observational_operator.json").write_text(
        json.dumps(observational_operator(inputs),indent=2)+"\n")

    # Spatial-resolution effect at fixed structural state.
    den0,num0,_=result["model"].projected_maps(result["a_star_mps2"],apply_psf=False)
    no_psf=result["model"].annulus_sigmas(den0,num0,bounds)
    psf_rows=[]
    for i in range(len(OBS_R_CIRC)):
        psf_rows.append({"radius_circularized_kpc":f"{OBS_R_CIRC[i]:.2f}",
                         "radius_major_kpc":f"{OBS_R_MAJOR[i]:.9f}",
                         "without_psf_kms":f"{no_psf[i]:.9f}",
                         "with_psf_kms":f"{result['prediction'][i]:.9f}",
                         "difference_kms":f"{result['prediction'][i]-no_psf[i]:.9f}"})
    write_csv(root/"results"/"spatial_resolution.csv",list(psf_rows[0].keys()),psf_rows)


def run_sensitivity(root):
    inputs=GalaxyInputs()
    rows=[]
    for inc in [50.0,60.0,70.0,80.0,90.0]:
        for beta in [-0.2,0.0,0.2,0.4]:
            r=solve_branch(inputs,inc,beta,"screening")
            rows.append({"inclination_deg":f"{inc:.0f}","beta_z":f"{beta:.1f}",
                         "q_intrinsic":f"{r['q_intrinsic']:.9f}","a_star_mps2":f"{r['a_star_mps2']:.12e}",
                         "chi2_diag":f"{r['chi2_diag']:.9f}","max_abs_pull":f"{r['max_abs_pull']:.9f}",
                         "min_vphi2_active_kms2":f"{r['min_vphi2_active']:.9f}"})
    write_csv(root/"results"/"geometry_stress_grid.csv",list(rows[0].keys()),rows)

    massrows=[]
    for mass in [3.0e8,3.75e8,4.5e8]:
        r=solve_branch(GalaxyInputs(stellar_mass_msun=mass),90.0,0.0,"screening")
        massrows.append({"stellar_mass_msun":f"{mass:.9e}","a_star_mps2":f"{r['a_star_mps2']:.12e}",
                         "chi2_diag":f"{r['chi2_diag']:.9f}","max_abs_pull":f"{r['max_abs_pull']:.9f}"})
    write_csv(root/"results"/"stellar_mass_grid.csv",list(massrows[0].keys()),massrows)


def run_convergence(root):
    inputs=GalaxyInputs()
    configs=[
        (120,80,0.16,60,7.0),
        (180,112,0.10,100,8.0),
        (240,136,0.08,140,10.0),
    ]
    rows=[]
    for gn,fn,px,ln,extent in configs:
        model=TensorModel(inputs,90.0,0.0,gn,fn,extent,px,ln)
        a=model.determine_a_star()
        den,num,minvp=model.projected_maps(a,True)
        pred=model.annulus_sigmas(den,num,derive_annulus_boundaries(inputs))
        *_,chi2,maxpull=statistics(pred)
        rows.append({"grid_nodes":gn,"force_nodes":fn,"sky_pixel_kpc":px,"los_nodes":ln,"sky_extent_kpc":extent,
                     "a_star_mps2":f"{a:.12e}","chi2_diag":f"{chi2:.9f}","max_abs_pull":f"{maxpull:.9f}",
                     "min_vphi2_active_kms2":f"{minvp:.9f}"})
    summary_path=root/"results"/"primary_summary.json"
    if summary_path.exists():
        summary=json.loads(summary_path.read_text())
        rows.append({"grid_nodes":320,"force_nodes":176,"sky_pixel_kpc":0.06,"los_nodes":180,"sky_extent_kpc":10.0,
                     "a_star_mps2":f"{summary['a_star_mps2']:.12e}","chi2_diag":f"{summary['chi2_diag_cptg']:.9f}",
                     "max_abs_pull":f"{summary['max_abs_pull_cptg']:.9f}","min_vphi2_active_kms2":f"{summary['min_vphi2_active_kms2']:.9f}"})
    write_csv(root/"results"/"numerical_convergence.csv",list(rows[0].keys()),rows)

def run_mathematical_checks(root):
    inputs=GalaxyInputs()
    source=SersicOblate(inputs,inputs.q_projected,force_nodes=112)

    # Reprojection of the Abel-deprojected density.
    x,w=leggauss(240)
    t=(x+1.0)*10.5
    wt=w*10.5
    rows=[]
    for radius in [0.1,0.5,1.0,4.7,10.0,20.0]:
        m=radius*np.cosh(t)
        projected=2.0*(source.q/source.inputs.q_projected)*np.sum(source.density(m)*radius*np.cosh(t)*wt)
        target=float(source.surface_density(radius))
        rows.append({"radius_kpc":radius,"surface_density_target":f"{target:.12e}",
                     "surface_density_reprojected":f"{projected:.12e}",
                     "relative_error":f"{projected/target-1.0:.12e}"})
    write_csv(root/"results"/"deprojection_reprojection.csv",list(rows[0].keys()),rows)
    (root/"results"/"source_normalization.json").write_text(json.dumps({
        "analytic_stellar_mass_msun":inputs.stellar_mass_msun,
        "density_quadrature_mass_before_normalization_msun":source.raw_mass_msun,
        "density_quadrature_relative_offset":source.raw_mass_msun/inputs.stellar_mass_msun-1.0,
        "density_normalization_factor":source.mass_scale
    },indent=2)+"\n")

    # Scalar CPTG root properties on the observed radial span.
    summary=json.loads((root/"results"/"primary_summary.json").read_text())
    a_mps2=summary["a_star_mps2"]
    a_code=a_mps2/MPS2_PER_KMS2_PER_KPC
    gbar,_,_=source.field_and_potential(OBS_R_MAJOR,np.zeros_like(OBS_R_MAJOR))
    g=TensorModel._scalar_cptg(gbar,a_code,OBS_R_MAJOR)
    rc=48.0*np.pi*C_KMS**2/a_code
    ggeom=0.5*a_code*(OBS_R_MAJOR/rc)**(7.0/5.0)/(1.0+(OBS_R_MAJOR/rc)**(12.0/5.0))
    response=np.sqrt(a_code*gbar)+ggeom
    pexp=123.0/50.0; qexp=11.0/50.0
    xx=g/a_code
    residual=g-gbar-response/(1.0+xx**pexp)**qexp
    derivative=1.0+response*qexp*pexp/a_code*xx**(pexp-1.0)*(1.0+xx**pexp)**(-qexp-1.0)
    rows=[]
    for i in range(len(OBS_R_CIRC)):
        rows.append({"radius_circularized_kpc":OBS_R_CIRC[i],
                     "radius_major_kpc":OBS_R_MAJOR[i],
                     "gbar_kms2_per_kpc":f"{gbar[i]:.12e}",
                     "g_solution_kms2_per_kpc":f"{g[i]:.12e}","equation_residual":f"{residual[i]:.12e}",
                     "root_function_derivative":f"{derivative[i]:.12e}"})
    write_csv(root/"results"/"scalar_root_properties.csv",list(rows[0].keys()),rows)

    # Conservative-field finite-difference curl diagnostic.
    model=TensorModel(inputs,90.0,0.0,grid_nodes=180,force_nodes=112,
                      sky_extent_kpc=8.0,sky_pixel_kpc=0.10,los_nodes=100)
    afun,_=model.conservative_amplification(a_mps2)
    amp=afun(model.u_potential)
    gr=amp*model.grad_r_bar
    gz=amp*model.grad_z_bar
    dgr_dz=np.gradient(gr,model.intrinsic_grid,axis=1,edge_order=2)
    dgz_dr=np.gradient(gz,model.intrinsic_grid,axis=0,edge_order=2)
    curl=dgr_dz-dgz_dr
    b_dgr_dz=np.gradient(model.grad_r_bar,model.intrinsic_grid,axis=1,edge_order=2)
    b_dgz_dr=np.gradient(model.grad_z_bar,model.intrinsic_grid,axis=0,edge_order=2)
    bcurl=b_dgr_dz-b_dgz_dr
    rr,zz=np.meshgrid(model.intrinsic_grid,model.intrinsic_grid,indexing="ij")
    active=(model.nu>1.0e-6*np.max(model.nu))&(rr>0.05)&(zz>0.05)&(rr<10.0)&(zz<10.0)
    denom=np.abs(dgr_dz)+np.abs(dgz_dr)+1.0e-30
    bden=np.abs(b_dgr_dz)+np.abs(b_dgz_dr)+1.0e-30
    ratio=np.abs(curl[active])/denom[active]
    bratio=np.abs(bcurl[active])/bden[active]
    (root/"results"/"field_integrability.json").write_text(json.dumps({
        "active_grid_points":int(np.sum(active)),
        "cptg_normalized_curl_median":float(np.median(ratio)),
        "cptg_normalized_curl_p95":float(np.quantile(ratio,0.95)),
        "cptg_normalized_curl_max":float(np.max(ratio)),
        "baryonic_normalized_curl_median":float(np.median(bratio)),
        "baryonic_normalized_curl_p95":float(np.quantile(bratio,0.95)),
        "baryonic_normalized_curl_max":float(np.max(bratio))
    },indent=2)+"\n")

    curl_rows=[]
    for gn,fn in [(120,80),(180,112),(260,144),(320,176)]:
        cm=TensorModel(inputs,90.0,0.0,grid_nodes=gn,force_nodes=fn,
                       sky_extent_kpc=8.0,sky_pixel_kpc=0.10,los_nodes=60)
        cafun,_=cm.conservative_amplification(a_mps2)
        camp=cafun(cm.u_potential)
        cgr=camp*cm.grad_r_bar
        cgz=camp*cm.grad_z_bar
        cdgr_dz=np.gradient(cgr,cm.intrinsic_grid,axis=1,edge_order=2)
        cdgz_dr=np.gradient(cgz,cm.intrinsic_grid,axis=0,edge_order=2)
        ccurl=cdgr_dz-cdgz_dr
        cb_dgr_dz=np.gradient(cm.grad_r_bar,cm.intrinsic_grid,axis=1,edge_order=2)
        cb_dgz_dr=np.gradient(cm.grad_z_bar,cm.intrinsic_grid,axis=0,edge_order=2)
        cbcurl=cb_dgr_dz-cb_dgz_dr
        crr,czz=np.meshgrid(cm.intrinsic_grid,cm.intrinsic_grid,indexing="ij")
        cactive=(cm.nu>1.0e-6*np.max(cm.nu))&(crr>0.05)&(czz>0.05)&(crr<10.0)&(czz<10.0)
        cratio=np.abs(ccurl[cactive])/(np.abs(cdgr_dz[cactive])+np.abs(cdgz_dr[cactive])+1.0e-30)
        cbratio=np.abs(cbcurl[cactive])/(np.abs(cb_dgr_dz[cactive])+np.abs(cb_dgz_dr[cactive])+1.0e-30)
        curl_rows.append({
            "grid_nodes":gn,"force_nodes":fn,"active_grid_points":int(np.sum(cactive)),
            "cptg_normalized_curl_median":f"{np.median(cratio):.12e}",
            "cptg_normalized_curl_p95":f"{np.quantile(cratio,0.95):.12e}",
            "cptg_normalized_curl_max":f"{np.max(cratio):.12e}",
            "baryonic_normalized_curl_median":f"{np.median(cbratio):.12e}",
            "baryonic_normalized_curl_p95":f"{np.quantile(cbratio,0.95):.12e}",
            "baryonic_normalized_curl_max":f"{np.max(cbratio):.12e}",
        })
    write_csv(root/"results"/"field_integrability_convergence.csv",list(curl_rows[0].keys()),curl_rows)

def write_inputs(root):
    inputs=GalaxyInputs()
    with open(root/"inputs"/"galaxy_inputs.csv","w",newline="",encoding="utf-8") as f:
        w=csv.writer(f); w.writerow(["quantity","value","unit"])
        for key,value in inputs.__dict__.items():
            unit=""
            if key.endswith("_kpc"): unit="kpc"
            elif key.endswith("_mpc"): unit="Mpc"
            elif key.endswith("_msun"): unit="Msun"
            elif key.endswith("_kms"): unit="km/s"
            elif key.endswith("_arcsec"): unit="arcsec"
            w.writerow([key,value,unit])
        w.writerow(["radius_major_divisor",RADIUS_MAJOR_DIVISOR,"dimensionless"])
        w.writerow(["re_circularized_kpc",inputs.re_major_kpc*np.sqrt(inputs.q_projected),"kpc"])
    with open(root/"inputs"/"kcwi_profile.csv","w",newline="",encoding="utf-8") as f:
        w=csv.writer(f); w.writerow(["radius_circularized_kpc","radius_major_kpc","v_kms","v_minus_kms","v_plus_kms","sigma_kms","sigma_minus_kms","sigma_plus_kms"])
        for row in zip(OBS_R_CIRC,OBS_R_MAJOR,OBS_V,OBS_V_MINUS,OBS_V_PLUS,OBS_SIGMA,OBS_SIGMA_MINUS,OBS_SIGMA_PLUS):
            w.writerow(row)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--output",default=str(Path(__file__).resolve().parents[1]))
    parser.add_argument("--mode",choices=["primary","sensitivity","convergence","checks"],required=True)
    args=parser.parse_args()
    root=Path(args.output); (root/"inputs").mkdir(parents=True,exist_ok=True); (root/"results").mkdir(parents=True,exist_ok=True)
    write_inputs(root)
    if args.mode == "primary": run_primary(root)
    if args.mode == "sensitivity": run_sensitivity(root)
    if args.mode == "convergence": run_convergence(root)
    if args.mode == "checks": run_mathematical_checks(root)

if __name__=="__main__":
    main()
