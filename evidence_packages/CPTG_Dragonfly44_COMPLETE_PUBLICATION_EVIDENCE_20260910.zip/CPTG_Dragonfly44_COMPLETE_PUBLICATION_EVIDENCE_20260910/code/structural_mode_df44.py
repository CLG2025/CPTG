#!/usr/bin/env python3
"""Downstream Structural Mode calculation for the solved Dragonfly 44 CPTG field.

The structural coordinate is evaluated only after the gravitational solution is fixed.
The outer coordinate is the outermost modeled KCWI semi-major coordinate,
R = 5.13/0.83 kpc, and the parent domain is evaluated exactly on [R/5, R].

    C_g = g^2 + (kappa_struct dg/dr)^2,
    w   = |dC_g/dr|,
    lambda = integral_(R/5)^R r w dr / integral_(R/5)^R w dr,
    N = R/lambda,

with kappa_struct = 1 kpc when radius is expressed in kpc.
No Structural Mode quantity is used to alter a_star or any dynamical solution.
"""
from __future__ import annotations
import argparse, csv, json
from pathlib import Path
import numpy as np
from scipy.integrate import cumulative_trapezoid
from scipy.interpolate import CubicSpline
from solve_df44 import GalaxyInputs, SersicOblate, TensorModel, MPS2_PER_KMS2_PER_KPC

R_KPC = 5.13 / 0.83
KAPPA_STRUCT_KPC = 1.0
FIELD_POINTS = 32769


def solved_field(r_kpc: np.ndarray, a_star_mps2: float, q_intrinsic: float):
    inputs = GalaxyInputs()
    source = SersicOblate(inputs, q_intrinsic, force_nodes=176)
    gbar_code, _, _ = source.field_and_potential(r_kpc, np.zeros_like(r_kpc))
    a_code = a_star_mps2 / MPS2_PER_KMS2_PER_KPC
    g_code = TensorModel._scalar_cptg(gbar_code, a_code, r_kpc)
    return gbar_code * MPS2_PER_KMS2_PER_KPC, g_code * MPS2_PER_KMS2_PER_KPC


def readout(r_kpc, g_mps2, integration_points):
    gsp = CubicSpline(r_kpc, g_mps2)
    dg_nodes = gsp(r_kpc, 1)
    C_nodes = g_mps2**2 + (KAPPA_STRUCT_KPC * dg_nodes)**2
    Csp = CubicSpline(r_kpc, C_nodes)
    x = np.linspace(r_kpc[0], r_kpc[-1], integration_points)
    dC = Csp(x, 1)
    w = np.abs(dC)
    den = np.trapezoid(w, x)
    lam = np.trapezoid(x*w, x) / den
    return float(lam), float(r_kpc[-1]/lam), dg_nodes, C_nodes, Csp


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', default=None)
    args = ap.parse_args()
    root = Path(args.root).resolve() if args.root else Path(__file__).resolve().parents[1]
    result_dir = root/'results'; result_dir.mkdir(exist_ok=True)
    primary = json.loads((result_dir/'primary_summary.json').read_text())
    a_star = float(primary['a_star_mps2']); q = float(primary['q_intrinsic'])

    lower = R_KPC/5.0
    r = np.linspace(lower, R_KPC, FIELD_POINTS)
    gbar, g = solved_field(r, a_star, q)
    convergence = []
    chosen = None
    for nint in (50001, 100001, 200001):
        lam, N, dg, C, Csp = readout(r, g, nint)
        convergence.append({'integration_points': nint, 'lambda_kpc': lam, 'N': N})
        if nint == 200001:
            chosen = (lam, N, dg, C, Csp)
    lam, N, dg, C, Csp = chosen
    dC = np.abs(Csp(r, 1))
    cum = cumulative_trapezoid(dC, r, initial=0.0)
    if cum[-1] > 0:
        cum /= cum[-1]

    with (result_dir/'structural_mode_profile.csv').open('w', newline='') as f:
        w = csv.writer(f)
        w.writerow(['r_kpc','r_over_R','gbar_mps2','g_cptg_mps2','dg_dr_mps2_per_kpc','C_mps4','abs_dC_dr_mps4_per_kpc','cumulative_weight'])
        for row in zip(r, r/R_KPC, gbar, g, dg, C, dC, cum):
            w.writerow([f'{float(v):.16e}' for v in row])

    # Field-grid convergence at the same exact parent domain.
    field_convergence = []
    for nfield in (8193, 16385, 32769):
        rr = np.linspace(lower, R_KPC, nfield)
        _, gg = solved_field(rr, a_star, q)
        ll, nn, *_ = readout(rr, gg, 100001)
        field_convergence.append({'field_points': nfield, 'lambda_kpc': ll, 'N': nn})

    summary = {
        'a_star_mps2_fixed': a_star,
        'q_intrinsic_fixed': q,
        'kappa_struct_kpc': KAPPA_STRUCT_KPC,
        'domain': {
            'definition': '[R/5, R]',
            'R_kpc': R_KPC,
            'lower_kpc': lower,
            'outer_coordinate_source': '5.13 kpc published aperture coordinate mapped by R_major=R/0.83',
            'field_points': FIELD_POINTS,
        },
        'lambda_kpc': lam,
        'N': N,
        'integration_convergence': convergence,
        'field_grid_convergence': field_convergence,
        'role': 'post_solution_structural_coordinate_only',
    }
    (result_dir/'structural_mode_summary.json').write_text(json.dumps(summary, indent=2)+'\n')
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
