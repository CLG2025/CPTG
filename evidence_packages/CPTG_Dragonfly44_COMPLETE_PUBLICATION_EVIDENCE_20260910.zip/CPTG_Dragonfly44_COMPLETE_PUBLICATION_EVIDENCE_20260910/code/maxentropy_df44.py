#!/usr/bin/env python3
from pathlib import Path
import argparse, json, math, sys
import numpy as np
from scipy.optimize import minimize
from scipy.special import logsumexp
sys.path.insert(0,str(Path(__file__).resolve().parent))
from schwarzschild_df44 import fit_gh
ROOT=Path(__file__).resolve().parent.parent
RES=ROOT/'results'

def solve(library_path, output_stem, eps=1e-7):
    z=np.load(library_path)
    A=z['constraint_A']; b=z['constraint_b']; n=A.shape[1]
    logp=np.full(n,-math.log(n))
    def fg(lam):
        q=logp-A.T@lam; lz=logsumexp(q); w=np.exp(q-lz)
        f=lz+lam@b+0.5*eps*(lam@lam)
        g=b-A@w+eps*lam
        return f,g
    out=minimize(lambda x: fg(x),np.zeros(A.shape[0]),jac=True,method='L-BFGS-B',
                 options={'maxiter':5000,'ftol':1e-14,'gtol':1e-10,'maxls':50})
    lam=out.x; q=logp-A.T@lam; w=np.exp(q-logsumexp(q)); resid=A@w-b
    hist=z['H']@w; sig,h4,loss=fit_gh(hist)
    Dr=float(z['Dr']@w); Qr=float(z['Qr']@w)
    result={
      'library':str(Path(library_path).name),'epsilon':eps,
      'optimizer_success':bool(out.success),'optimizer_message':str(out.message),
      'iterations':int(out.nit),'max_abs_scaled_constraint_residual':float(np.max(np.abs(resid))),
      'rms_scaled_constraint_residual':float(np.sqrt(np.mean(resid**2))),
      'effective_orbit_number':float(1/np.sum(w*w)),'nonzero_orbits':int(np.sum(w>1e-12)),
      'ring_sigma_kms':float(math.sqrt(Qr/Dr)),'gh_sigma_kms':sig,'gh_h4':h4,'gh_cdf_loss':loss,
      'entropy':float(-np.sum(w*np.log(np.maximum(w,1e-300))))}
    np.savez_compressed(RES/f'{output_stem}.npz',weights=w,scaled_residual=resid)
    (RES/f'{output_stem}.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':
    ap=argparse.ArgumentParser(); ap.add_argument('library'); ap.add_argument('output_stem'); ap.add_argument('--epsilon',type=float,default=1e-7)
    a=ap.parse_args(); solve(a.library,a.output_stem,a.epsilon)
