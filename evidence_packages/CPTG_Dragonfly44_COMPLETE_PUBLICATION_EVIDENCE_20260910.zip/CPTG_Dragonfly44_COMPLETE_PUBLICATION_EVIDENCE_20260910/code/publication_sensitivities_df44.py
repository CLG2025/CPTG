#!/usr/bin/env python3
"""Publication-resolution sensitivity calculations for the DF44 CPTG analysis.

Produces three evidence lanes that correspond directly to publication statements:
1. the 30/33/36 km/s half-light normalization sensitivity at publication resolution;
2. the 180 radial-node / 112 force-node neutral inclination table;
3. the 180 radial-node / 112 force-node stellar-mass table.

The structural acceleration remains a system-level quantity.  For each declared
normalization or source/geometry choice it is re-determined from the integrated
half-light support condition; no resolved radial bin is used to set a_star.
"""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import numpy as np

import solve_df44 as s


def write_csv(path: Path, fieldnames, rows):
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        w.writerows(rows)


def normalization_sensitivity(root: Path):
    inputs = s.GalaxyInputs()
    boundaries = s.derive_annulus_boundaries(inputs)
    model = s.make_model(inputs, 90.0, 0.0, "publication")
    summary_rows = []
    profile_rows = []

    for target in (30.0, 33.0, 36.0):
        a_star = model.determine_a_star(target_kms=target)
        den, num, min_vphi2 = model.projected_maps(a_star, apply_psf=True)
        pred = model.annulus_sigmas(den, num, boundaries)
        half = model.circular_aperture_sigma(
            den, num, inputs.re_major_kpc * np.sqrt(inputs.q_projected)
        )
        obs, minus, plus, residual, pull, chi2, max_pull = s.statistics(pred)
        a_code = a_star / s.MPS2_PER_KMS2_PER_KPC
        rc_kpc = 48.0 * np.pi * s.C_KMS**2 / a_code
        summary_rows.append({
            "half_light_target_kms": f"{target:.1f}",
            "a_star_mps2": f"{a_star:.16e}",
            "rc_gpc": f"{rc_kpc/1.0e6:.12f}",
            "half_light_recovered_kms": f"{half:.12f}",
            "chi2_diag": f"{chi2:.12f}",
            "max_abs_pull": f"{max_pull:.12f}",
            "min_vphi2_active_kms2": f"{min_vphi2:.12f}",
        })
        for i in range(len(s.OBS_R_CIRC)):
            profile_rows.append({
                "half_light_target_kms": f"{target:.1f}",
                "radius_circularized_kpc": f"{s.OBS_R_CIRC[i]:.2f}",
                "radius_major_kpc": f"{s.OBS_R_MAJOR[i]:.12f}",
                "observed_second_moment_kms": f"{obs[i]:.12f}",
                "cptg_second_moment_kms": f"{pred[i]:.12f}",
                "residual_kms": f"{residual[i]:.12f}",
                "pull": f"{pull[i]:.12f}",
            })

    write_csv(root / "results" / "normalization_sensitivity.csv", list(summary_rows[0]), summary_rows)
    write_csv(root / "results" / "normalization_sensitivity_profiles.csv", list(profile_rows[0]), profile_rows)


def verification_tables(root: Path):
    inputs = s.GalaxyInputs()
    inclination_rows = []
    for inc in (50.0, 60.0, 70.0, 80.0, 90.0):
        r = s.solve_branch(inputs, inc, 0.0, "verification")
        inclination_rows.append({
            "inclination_deg": f"{inc:.0f}",
            "q_intrinsic": f"{r['q_intrinsic']:.12f}",
            "a_star_mps2": f"{r['a_star_mps2']:.16e}",
            "chi2_diag": f"{r['chi2_diag']:.12f}",
            "max_abs_pull": f"{r['max_abs_pull']:.12f}",
            "min_vphi2_active_kms2": f"{r['min_vphi2_active']:.12f}",
        })
    write_csv(root / "results" / "inclination_grid_180x112.csv", list(inclination_rows[0]), inclination_rows)

    mass_rows = []
    for mass in (3.0e8, 3.75e8, 4.5e8):
        r = s.solve_branch(s.GalaxyInputs(stellar_mass_msun=mass), 90.0, 0.0, "verification")
        mass_rows.append({
            "stellar_mass_msun": f"{mass:.9e}",
            "a_star_mps2": f"{r['a_star_mps2']:.16e}",
            "chi2_diag": f"{r['chi2_diag']:.12f}",
            "max_abs_pull": f"{r['max_abs_pull']:.12f}",
            "min_vphi2_active_kms2": f"{r['min_vphi2_active']:.12f}",
        })
    write_csv(root / "results" / "stellar_mass_grid_180x112.csv", list(mass_rows[0]), mass_rows)


def radius_convention_sensitivity(root: Path):
    """Compare R_major=R/0.83 against the literal approximate relation R_major=1.20 R.

    This is evaluated at verification resolution because it is a convention check, not
    a new primary fit.  Each convention re-determines the single half-light a_star and
    compares the same observed second moments.
    """
    original_divisor = s.RADIUS_MAJOR_DIVISOR
    original_major = s.OBS_R_MAJOR.copy()
    rows = []
    try:
        for label, divisor in (("R_over_0p83", 0.83), ("1p20_times_R", 1.0/1.20)):
            s.RADIUS_MAJOR_DIVISOR = divisor
            s.OBS_R_MAJOR = s.OBS_R_CIRC / divisor
            r = s.solve_branch(s.GalaxyInputs(), 90.0, 0.0, "verification")
            rows.append({
                "radius_convention": label,
                "radius_major_divisor": f"{divisor:.16f}",
                "outer_major_kpc": f"{s.OBS_R_MAJOR[-1]:.12f}",
                "a_star_mps2": f"{r['a_star_mps2']:.16e}",
                "chi2_diag": f"{r['chi2_diag']:.12f}",
                "max_abs_pull": f"{r['max_abs_pull']:.12f}",
            })
    finally:
        s.RADIUS_MAJOR_DIVISOR = original_divisor
        s.OBS_R_MAJOR = original_major
    write_csv(root / "results" / "radius_convention_sensitivity.csv", list(rows[0]), rows)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--lane", choices=["all", "normalization", "tables", "radius"], default="all")
    args = ap.parse_args()
    root = Path(__file__).resolve().parents[1]
    (root / "results").mkdir(exist_ok=True)
    if args.lane in ("all", "normalization"):
        normalization_sensitivity(root)
    if args.lane in ("all", "tables"):
        verification_tables(root)
    if args.lane in ("all", "radius"):
        radius_convention_sensitivity(root)
    summary = {"status": "complete", "lane": args.lane}
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
