#!/usr/bin/env python3
"""Central-limit diagnostic for the conservative DF44 CPTG force construction."""
from __future__ import annotations
import csv, json
from pathlib import Path
import numpy as np
from solve_df44 import GalaxyInputs, SersicOblate, TensorModel, MPS2_PER_KMS2_PER_KPC

root=Path(__file__).resolve().parents[1]
summary=json.loads((root/'results'/'primary_summary.json').read_text())
a=float(summary['a_star_mps2']); q=float(summary['q_intrinsic'])
inputs=GalaxyInputs(); source=SersicOblate(inputs,q,force_nodes=176)
r=np.geomspace(1e-6,1e-2,81)
gbar_code,_,phi=source.field_and_potential(r,np.zeros_like(r))
phi0=float(source.field_and_potential(np.array([0.0]),np.array([0.0]))[2][0])
u=phi-phi0
a_code=a/MPS2_PER_KMS2_PER_KPC
g_code=TensorModel._scalar_cptg(gbar_code,a_code,r)
gbar=gbar_code*MPS2_PER_KMS2_PER_KPC; g=g_code*MPS2_PER_KMS2_PER_KPC
amp=g/gbar
rows=[]
for vals in zip(r,u,gbar,g,amp):
    rows.append(dict(r_kpc=f'{vals[0]:.16e}',u_kms2=f'{vals[1]:.16e}',gbar_mps2=f'{vals[2]:.16e}',g_cptg_mps2=f'{vals[3]:.16e}',amplification=f'{vals[4]:.16e}'))
with (root/'results'/'central_limit_diagnostic.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
# Slopes on innermost decade.
sel=r<=1e-4
def slope(x,y): return float(np.polyfit(np.log(x[sel]),np.log(y[sel]),1)[0])
out={'radial_range_kpc':[float(r[sel][0]),float(r[sel][-1])],
     'log_slope_gbar_vs_r':slope(r,gbar),
     'log_slope_g_cptg_vs_r':slope(r,g),
     'log_slope_amplification_vs_r':slope(r,amp),
     'central_force_limit':'g_CPTG -> 0 while amplification diverges integrably'}
(root/'results'/'central_limit_summary.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
