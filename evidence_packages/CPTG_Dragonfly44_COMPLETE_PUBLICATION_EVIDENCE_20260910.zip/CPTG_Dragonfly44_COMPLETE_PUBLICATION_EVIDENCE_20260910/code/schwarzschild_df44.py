#!/usr/bin/env python3
from __future__ import annotations
import json, math, sys, csv, hashlib, time
from pathlib import Path
import numpy as np
from scipy.interpolate import RegularGridInterpolator, PchipInterpolator
from scipy.integrate import cumulative_trapezoid
from scipy.optimize import minimize, nnls
from scipy.stats import qmc, norm

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from solve_df44 import GalaxyInputs, TensorModel, derive_annulus_boundaries, make_model

ROOT=HERE.parent
RES=ROOT/'results'; RES.mkdir(parents=True,exist_ok=True)
A_STAR=float(json.loads((ROOT/'inputs'/'primary_summary.json').read_text())['a_star_mps2'])
SEED=20260910
N_ORBITS=1024
GRID_NODES=320
FORCE_NODES=176
SKY_EXTENT_KPC=10.0
SKY_PIXEL_KPC=0.06
LOS_NODES=180
NMU=4
DT=0.0012  # kpc/(km/s), ~1.17 Myr
NSTEPS=2400
BURN=300
SAMPLE_EVERY=3
QAP=0.69
R_CIRC_FACTOR=0.83
H4_R=1.3
H4_HALF_WIDTH=0.10
PSF_SIGMA_KPC=(1.2*(100000.0/206265.0))/2.354820045
VEL_EDGES=np.linspace(-160,160,65)


def build_fixed_model():
    inputs=GalaxyInputs()
    model=TensorModel(inputs,90.0,0.0,grid_nodes=GRID_NODES,force_nodes=FORCE_NODES,
                      sky_extent_kpc=SKY_EXTENT_KPC,sky_pixel_kpc=SKY_PIXEL_KPC,los_nodes=LOS_NODES)
    sr2,sz2,sp2,minvp=model.intrinsic_second_moments(A_STAR)
    amp,_=model.conservative_amplification(A_STAR)
    eff_gr=model.grad_r_bar*amp(model.u_potential)
    eff_gz=model.grad_z_bar*amp(model.u_potential)
    opts=dict(bounds_error=False,fill_value=np.nan)
    grid=model.intrinsic_grid
    interps={
        'gr':RegularGridInterpolator((grid,grid),eff_gr,**opts),
        'gz':RegularGridInterpolator((grid,grid),eff_gz,**opts),
        'phi_bar':RegularGridInterpolator((grid,grid),model.phi_bar,**opts),
        'sr2':RegularGridInterpolator((grid,grid),sr2,**opts),
        'sz2':RegularGridInterpolator((grid,grid),sz2,**opts),
        'sp2':RegularGridInterpolator((grid,grid),sp2,**opts),
        '_grarr':eff_gr, '_gzarr':eff_gz, '_phiarr':model.phi_bar,
        '_srarr':sr2, '_szarr':sz2, '_sparr':sp2, '_n':len(grid),
    }
    # Effective potential Phi_eff(u)=int_0^u A(s) ds, consistent with grad Phi_eff=A grad Phi_bar.
    umax=float(np.nanmax(model.u_potential))
    ug=np.unique(np.r_[0.0,np.geomspace(1e-10,1.0,12000),np.linspace(1.0,umax,18000)])
    ag=amp(np.maximum(ug,1e-12))
    phie=cumulative_trapezoid(ag,ug,initial=0.0)
    phi_eff=(ug,phie)
    return inputs,model,interps,phi_eff,sr2,sz2,sp2


def fast_interp(arr,R,Z,n):
    # Native grid is r=50*t^2 with t uniform on [0,1].
    R=np.asarray(R); Z=np.asarray(Z)
    fr=np.sqrt(np.clip(R,0,50)/50.0)*(n-1)
    fz=np.sqrt(np.clip(Z,0,50)/50.0)*(n-1)
    i=np.minimum(fr.astype(np.int64),n-2); j=np.minimum(fz.astype(np.int64),n-2)
    a=fr-i; b=fz-j
    return ((1-a)*(1-b)*arr[i,j] + a*(1-b)*arr[i+1,j] +
            (1-a)*b*arr[i,j+1] + a*b*arr[i+1,j+1])


def accel(interps,x,y,z):
    R=np.sqrt(x*x+y*y); Z=np.abs(z); n=interps['_n']
    bad=(R>=50)|(Z>=50)
    gr=fast_interp(interps['_grarr'],R,Z,n); gz=fast_interp(interps['_gzarr'],R,Z,n)
    invR=np.divide(1.0,R,out=np.zeros_like(R),where=R>0)
    ax=-gr*x*invR; ay=-gr*y*invR; az=-gz*np.sign(z)
    return ax,ay,az,bad


def energy(interps,phi_eff,model,x,y,z,vx,vy,vz):
    R=np.sqrt(x*x+y*y); Z=np.abs(z); n=interps['_n']
    phib=fast_interp(interps['_phiarr'],R,Z,n)
    u=np.clip(phib-model.phi0,0,phi_eff[0][-1])
    pe=np.interp(u,phi_eff[0],phi_eff[1])
    return 0.5*(vx*vx+vy*vy+vz*vz)+pe

def mass_cdf(source,mmax=50.0):
    m=source.m_grid; rho=source.rho_grid
    mask=m<=mmax
    mm=np.r_[0,m[mask]]; rr=np.r_[rho[0],rho[mask]]
    f=4*np.pi*source.q*rr*mm*mm
    c=cumulative_trapezoid(f,mm,initial=0.0); c/=c[-1]
    return mm,c


def initial_conditions(model,interps,n=N_ORBITS,seed=SEED):
    sob=qmc.Sobol(d=6,scramble=True,seed=seed)
    p=int(math.ceil(math.log2(n))); u=sob.random_base2(p)[:n]
    mgrid,cdf=mass_cdf(model.source)
    m=np.interp(u[:,0],cdf,mgrid)
    mu=u[:,1]
    phi=2*np.pi*u[:,2]
    R=m*np.sqrt(np.maximum(0,1-mu*mu)); z=model.q_intrinsic*m*mu
    x=R*np.cos(phi); y=R*np.sin(phi)
    pts=np.column_stack([R,np.abs(z)])
    nn=interps['_n']; sr=np.sqrt(np.maximum(fast_interp(interps['_srarr'],R,np.abs(z),nn),1e-8)); sz=np.sqrt(np.maximum(fast_interp(interps['_szarr'],R,np.abs(z),nn),1e-8)); sp=np.sqrt(np.maximum(fast_interp(interps['_sparr'],R,np.abs(z),nn),1e-8))
    gu=np.clip(u[:,3:6],1e-6,1-1e-6); g=norm.ppf(gu)
    vR=sr*g[:,0]; vphi=sp*g[:,1]; vz=sz*g[:,2]
    vx=vR*np.cos(phi)-vphi*np.sin(phi); vy=vR*np.sin(phi)+vphi*np.cos(phi)
    return x,y,z,vx,vy,vz


def shell_edges(source):
    m,c=mass_cdf(source)
    qs=np.array([0,.10,.25,.45,.65,.80,.90,.97])
    edges=list(np.interp(qs,c,m)); edges[-1]=np.interp(.97,c,m)
    edges.append(50.0)
    return np.array(edges)


def target_intrinsic(model,interps,edges,nmu=None):
    if nmu is None: nmu=NMU
    # Accurate quadrature in m and mu=cos(theta), where dV propto rho(m)m^2 dm dmu.
    from numpy.polynomial.legendre import leggauss
    xm,wm=leggauss(18); xu,wu=leggauss(10)
    nc=(len(edges)-1)*nmu
    D=np.zeros(nc); SR=np.zeros(nc); SZ=np.zeros(nc); SP=np.zeros(nc)
    total=0.0
    cell=0
    for ir,(a,b) in enumerate(zip(edges[:-1],edges[1:])):
      ms=.5*(b-a)*xm+.5*(b+a); mwt=.5*(b-a)*wm
      rho=model.source.density(ms)
      for iu in range(nmu):
        ua,ub=iu/nmu,(iu+1)/nmu
        mus=.5*(ub-ua)*xu+.5*(ub+ua); uwt=.5*(ub-ua)*wu
        M,U=np.meshgrid(ms,mus,indexing='ij'); MW,UW=np.meshgrid(mwt,uwt,indexing='ij')
        R=M*np.sqrt(1-U*U); z=model.q_intrinsic*M*U
        pts=np.column_stack([R.ravel(),z.ravel()])
        wt=(4*np.pi*model.q_intrinsic*(model.source.density(M)*M*M)*MW*UW).ravel()
        d=wt.sum(); D[cell]=d
        SR[cell]=np.sum(wt*interps['sr2'](pts)); SZ[cell]=np.sum(wt*interps['sz2'](pts)); SP[cell]=np.sum(wt*interps['sp2'](pts))
        total+=d; cell+=1
    D/=total; SR/=total; SZ/=total; SP/=total
    return D,SR,SZ,SP


def target_projected(model):
    den,num,_=model.projected_maps(A_STAR,apply_psf=True)
    pix=model.sky_pixel_kpc; M=model.inputs.stellar_mass_msun
    bounds=derive_annulus_boundaries(model.inputs)
    D=[]; Q=[]
    for a,b in zip(bounds[:-1],bounds[1:]):
        use=(model.aperture_radius>=a)&(model.aperture_radius<b)
        D.append(den[use].sum()*pix*pix/M); Q.append(num[use].sum()*pix*pix/M)
    rc=R_CIRC_FACTOR*model.aperture_radius
    use=(rc>=H4_R-H4_HALF_WIDTH)&(rc<H4_R+H4_HALF_WIDTH)
    Dh=den[use].sum()*pix*pix/M; Qh=num[use].sum()*pix*pix/M
    return np.array(D),np.array(Q),Dh,Qh,bounds


def integrate_library(model,interps,phi_eff,edges,seed=SEED,n=N_ORBITS):
    nmu=NMU; nc=(len(edges)-1)*nmu
    D=np.zeros((nc,n)); SR=np.zeros_like(D); SZ=np.zeros_like(D); SP=np.zeros_like(D)
    Dp=np.zeros((9,n)); Qp=np.zeros_like(Dp)
    Dr=np.zeros(n); Qr=np.zeros(n)
    H=np.zeros((len(VEL_EDGES)-1,n))
    x,y,z,vx,vy,vz=initial_conditions(model,interps,n,seed)
    E0=energy(interps,phi_eff,model,x,y,z,vx,vy,vz)
    Lz0=x*vy-y*vx
    max_relE=np.zeros(n); max_relLz=np.zeros(n); max_m=np.zeros(n); escaped=np.zeros(n,bool)
    ax,ay,az,bad=accel(interps,x,y,z); escaped|=bad
    vxh=vx+0.5*DT*ax; vyh=vy+0.5*DT*ay; vzh=vz+0.5*DT*az
    nsamp=0
    rng=np.random.default_rng(seed+8173)
    orbit_idx=np.arange(n)
    bounds=derive_annulus_boundaries(model.inputs)
    for step in range(NSTEPS):
        x=x+DT*vxh; y=y+DT*vyh; z=z+DT*vzh
        ax,ay,az,bad=accel(interps,x,y,z); escaped|=bad
        vxf=vxh+0.5*DT*ax; vyf=vyh+0.5*DT*ay; vzf=vzh+0.5*DT*az
        vxh=vxh+DT*ax; vyh=vyh+DT*ay; vzh=vzh+DT*az
        R=np.sqrt(x*x+y*y); m=np.sqrt(R*R+(z/model.q_intrinsic)**2); max_m=np.maximum(max_m,m)
        if step%80==0:
            Ee=energy(interps,phi_eff,model,x,y,z,vxf,vyf,vzf)
            denom=np.maximum(np.maximum(np.abs(E0),np.abs(Ee)),100.0)
            max_relE=np.maximum(max_relE,np.abs(Ee-E0)/denom)
            Lz=x*vyf-y*vxf
            lden=np.maximum(np.abs(Lz0),1e-8)
            max_relLz=np.maximum(max_relLz,np.abs(Lz-Lz0)/lden)
        if step<BURN or ((step-BURN)%SAMPLE_EVERY):
            continue
        nsamp+=1
        # Intrinsic meridional cells; each numerical orbit represents its time-reversal and z-reflected symmetry bundle.
        mu=np.divide(np.abs(z)/model.q_intrinsic,m,out=np.zeros_like(m),where=m>0)
        ir=np.searchsorted(edges,m,side='right')-1; iu=np.minimum((mu*nmu).astype(int),nmu-1)
        valid=(ir>=0)&(ir<len(edges)-1)&(~escaped)
        cell=ir*nmu+iu
        cos=np.divide(x,R,out=np.ones_like(R),where=R>0); sin=np.divide(y,R,out=np.zeros_like(R),where=R>0)
        vR=vxf*cos+vyf*sin; vphi=-vxf*sin+vyf*cos
        ii=orbit_idx[valid]; cc=cell[valid]
        np.add.at(D,(cc,ii),1.0); np.add.at(SR,(cc,ii),vR[valid]**2); np.add.at(SZ,(cc,ii),vzf[valid]**2); np.add.at(SP,(cc,ii),vphi[valid]**2)
        # PSF-blurred edge-on sky positions. LOS is y, so v_los=vy. Symmetry bundle supplies +/-v_los equally.
        jx=rng.normal(0,PSF_SIGMA_KPC,n); jz=rng.normal(0,PSF_SIGMA_KPC,n)
        xp=x+jx; zp=z+jz
        rmaj=np.sqrt(xp*xp+(zp/QAP)**2)
        ib=np.searchsorted(bounds,rmaj,side='right')-1
        vb=(ib>=0)&(ib<9)&(~escaped)
        jj=orbit_idx[vb]; bb=ib[vb]
        np.add.at(Dp,(bb,jj),1.0); np.add.at(Qp,(bb,jj),vyf[vb]**2)
        rc=R_CIRC_FACTOR*rmaj
        ring=(rc>=H4_R-H4_HALF_WIDTH)&(rc<H4_R+H4_HALF_WIDTH)&(~escaped)
        rridx=orbit_idx[ring]; vr=vyf[ring]
        Dr[rridx]+=1.0; Qr[rridx]+=vr*vr
        # symmetric histogram from time-reversed partner
        if np.any(ring):
            hb=np.searchsorted(VEL_EDGES,vr,side='right')-1
            hm=np.searchsorted(VEL_EDGES,-vr,side='right')-1
            ok=(hb>=0)&(hb<H.shape[0]); np.add.at(H,(hb[ok],rridx[ok]),0.5)
            ok=(hm>=0)&(hm<H.shape[0]); np.add.at(H,(hm[ok],rridx[ok]),0.5)
    scale=1.0/nsamp
    for A in (D,SR,SZ,SP,Dp,Qp,H): A*=scale
    Dr*=scale; Qr*=scale
    retained=(~escaped)&(max_m<49.5)&np.isfinite(max_relE)&np.isfinite(max_relLz)&(max_relE<0.03)&(max_relLz<1e-8)
    return dict(D=D[:,retained],SR=SR[:,retained],SZ=SZ[:,retained],SP=SP[:,retained],Dp=Dp[:,retained],Qp=Qp[:,retained],Dr=Dr[retained],Qr=Qr[retained],H=H[:,retained],max_relE=max_relE[retained],max_relLz=max_relLz[retained],max_m=max_m[retained],retained_idx=np.flatnonzero(retained),nsamp=nsamp,total=n,escaped=int(np.sum(escaped)))


def constraint_matrix(lib,target_intr,target_proj):
    D0,SR0,SZ0,SP0=target_intr; Dp0,Qp0,Dh0,Qh0,_=target_proj
    mats=[]; bs=[]; names=[]
    for tag,A,b in [('D3',lib['D'],D0),('R2',lib['SR'],SR0),('Z2',lib['SZ'],SZ0),('P2',lib['SP'],SP0),('Dproj',lib['Dp'],Dp0),('Q2proj',lib['Qp'],Qp0)]:
        for i in range(len(b)):
            if b[i]>1e-10:
                mats.append(A[i]/b[i]); bs.append(1.0); names.append(f'{tag}_{i}')
    mats.append(lib['Dr']/Dh0);bs.append(1.0);names.append('D_h4ring')
    mats.append(lib['Qr']/Qh0);bs.append(1.0);names.append('Q2_h4ring')
    # Explicit total mass normalization.
    mats.append(np.ones(lib['D'].shape[1]));bs.append(1.0);names.append('mass_total')
    return np.vstack(mats),np.array(bs),names


def solve_regularized(A,b,prior,lam=1e-3):
    # Nonnegative least squares with weak equal-orbit prior regularization.
    Ap=np.vstack([A,math.sqrt(lam)*np.eye(A.shape[1])])
    bp=np.r_[b,math.sqrt(lam)*prior]
    w,resid=nnls(Ap,bp,maxiter=20000)
    w/=w.sum()
    return w,{"residual_norm":float(resid)}


def solve_h4_constrained(A,b,lib,Dh0,Qh0):
    targetp,sig0=target_gh_hist(Qh0/Dh0,0.13)
    Htarget=Dh0*targetp
    good=Htarget>Dh0*2e-4
    Ah=lib['H'][good]/Htarget[good,None]
    bh=np.ones(np.sum(good))
    Aall=np.vstack([8*A,Ah]); ball=np.r_[8*b,bh]
    prior=np.ones(A.shape[1])/A.shape[1]
    Ap=np.vstack([Aall,0.03*np.eye(A.shape[1])]); bp=np.r_[ball,0.03*prior]
    w,resid=nnls(Ap,bp,maxiter=30000)
    w/=w.sum()
    return w,{"residual_norm":float(resid)},targetp,sig0,good

def gh_density(v,sigma,h4):
    y=v/sigma
    H4=(4*(y*y-3)*y*y+3)/math.sqrt(24.0)
    L=np.exp(-0.5*y*y)/(sigma*math.sqrt(2*np.pi))*(1+h4*H4)
    L=np.maximum(L,0.0)
    return L


def fit_gh(hist):
    centers=.5*(VEL_EDGES[:-1]+VEL_EDGES[1:]); widths=np.diff(VEL_EDGES)
    p=np.maximum(hist,0); p/=p.sum()
    def obj(theta):
        sig,h4=theta
        q=gh_density(centers,sig,h4)*widths; q/=q.sum()
        # CDF distance is stable for discrete orbit LOSVDs.
        return np.mean((np.cumsum(p)-np.cumsum(q))**2)
    # initialize from actual second moment
    s0=math.sqrt(np.sum(p*centers**2))
    r=minimize(obj,[s0,0.0],method='Nelder-Mead',options={'maxiter':2000,'xatol':1e-10,'fatol':1e-12})
    sig=float(np.clip(r.x[0],5,100)); h4=float(np.clip(r.x[1],-0.4,0.4))
    return sig,h4,float(r.fun)


def target_gh_hist(second_moment,h4=0.13):
    centers=.5*(VEL_EDGES[:-1]+VEL_EDGES[1:]); widths=np.diff(VEL_EDGES)
    # choose base sigma so the discretized GH profile has the required second moment
    def m2(sig):
        q=gh_density(centers,sig,h4)*widths; q/=q.sum(); return np.sum(q*centers**2)
    lo,hi=5.0,100.0
    for _ in range(80):
        mid=.5*(lo+hi)
        if m2(mid)<second_moment: lo=mid
        else: hi=mid
    sig=.5*(lo+hi); q=gh_density(centers,sig,h4)*widths; q/=q.sum()
    return q,sig


def evaluate(name,w,A,b,lib,Dh0,Qh0):
    resid=A@w-b
    hist=lib['H']@w; sig,h4,loss=fit_gh(hist)
    ringD=float(lib['Dr']@w); ringQ=float(lib['Qr']@w)
    eff=1.0/np.sum(w*w)
    return dict(name=name,max_abs_scaled_constraint_residual=float(np.max(np.abs(resid))),rms_scaled_constraint_residual=float(np.sqrt(np.mean(resid*resid))),ring_mass_fraction=ringD,ring_sigma_kms=math.sqrt(ringQ/ringD),gh_sigma_kms=sig,gh_h4=h4,gh_cdf_loss=loss,effective_orbit_number=eff,nonzero_orbits=int(np.sum(w>1e-10)))


def run(seed=SEED,tag=""):
    suf=("_"+tag) if tag else ""
    t0=time.time(); print('PHASE model',flush=True); inputs,model,interps,phi_eff,sr2,sz2,sp2=build_fixed_model(); (RES/'progress.txt').write_text(f'model {time.time()-t0}\n')
    print('PHASE targets',flush=True); edges=shell_edges(model.source); target_intr=target_intrinsic(model,interps,edges); target_proj=target_projected(model); open(RES/'progress.txt','a').write(f'targets {time.time()-t0}\n')
    print('PHASE integrate',flush=True); lib=integrate_library(model,interps,phi_eff,edges,seed=seed); np.savez_compressed(RES/f'library_raw_seed{seed}.npz',**lib,edges=edges); open(RES/'progress.txt','a').write(f'integrated {time.time()-t0}\n')
    print('PHASE matrix',flush=True); A,b,names=constraint_matrix(lib,target_intr,target_proj); open(RES/'progress.txt','a').write(f'matrix {time.time()-t0}\n')
    prior=np.ones(A.shape[1])/A.shape[1]
    print('PHASE neutral solve',flush=True); w0,out0=solve_regularized(A,b,prior,lam=2e-3); open(RES/'progress.txt','a').write(f'neutral {time.time()-t0}\n')
    e0=evaluate('h4_withheld_regularized',w0,A,b,lib,target_proj[2],target_proj[3])
    print('PHASE h4 solve',flush=True); w1,out1,targetp,sig0,good=solve_h4_constrained(A,b,lib,target_proj[2],target_proj[3]); open(RES/'progress.txt','a').write(f'h4 {time.time()-t0}\n')
    e1=evaluate('h4_constrained',w1,A,b,lib,target_proj[2],target_proj[3])
    # direct mismatch to h4 target LOSVD
    mix=lib['H']@w1; mix/=mix.sum(); e1['target_h4']=0.13; e1['target_gh_base_sigma_kms']=sig0; e1['target_hist_l1']=float(np.sum(np.abs(mix-targetp)))
    # conservation and library ledger
    summary=dict(seed=seed,a_star_mps2=A_STAR,total_orbits_requested=lib['total'],retained_orbits=int(A.shape[1]),escaped_or_outside_orbits=int(lib['total']-A.shape[1]),samples_per_orbit=lib['nsamp'],dt_kpc_per_kms=DT,nsteps=NSTEPS,burn_steps=BURN,sample_every=SAMPLE_EVERY,median_max_relative_energy_drift=float(np.median(lib['max_relE'])),p95_max_relative_energy_drift=float(np.quantile(lib['max_relE'],.95)),max_relative_energy_drift=float(np.max(lib['max_relE'])),median_max_relative_Lz_drift=float(np.median(lib['max_relLz'])),p95_max_relative_Lz_drift=float(np.quantile(lib['max_relLz'],.95)),max_relative_Lz_drift=float(np.max(lib['max_relLz'])),h4_radius_circularized_kpc=H4_R,h4_halfwidth_kpc=H4_HALF_WIDTH,target_ring_mass_fraction=float(target_proj[2]),target_ring_sigma_kms=math.sqrt(target_proj[3]/target_proj[2]),neutral=e0,h4_constrained=e1,elapsed_s=time.time()-t0)
    (RES/f'orbit_summary_seed{seed}{suf}.json').write_text(json.dumps(summary,indent=2)+'\n')
    np.savez_compressed(RES/f'orbit_library_seed{seed}{suf}.npz',D=lib['D'],SR=lib['SR'],SZ=lib['SZ'],SP=lib['SP'],Dp=lib['Dp'],Qp=lib['Qp'],Dr=lib['Dr'],Qr=lib['Qr'],H=lib['H'],max_relE=lib['max_relE'],max_relLz=lib['max_relLz'],max_m=lib['max_m'],retained_idx=lib['retained_idx'],edges=edges,vel_edges=VEL_EDGES,targetD=target_intr[0],targetSR=target_intr[1],targetSZ=target_intr[2],targetSP=target_intr[3],targetDp=target_proj[0],targetQp=target_proj[1],targetDh=np.array([target_proj[2]]),targetQh=np.array([target_proj[3]]),weights_neutral=w0,weights_h4=w1,target_gh=targetp,constraint_A=A,constraint_b=b)
    with open(RES/f'constraint_residuals_seed{seed}{suf}.csv','w',newline='') as f:
      wr=csv.writer(f); wr.writerow(['constraint','neutral_scaled_residual','h4_constrained_scaled_residual'])
      r0=A@w0-b; r1=A@w1-b
      for nm,x0,x1 in zip(names,r0,r1): wr.writerow([nm,f'{x0:.12e}',f'{x1:.12e}'])
    print(json.dumps(summary,indent=2))

if __name__=='__main__':
    import argparse
    ap=argparse.ArgumentParser()
    ap.add_argument('--seed',type=int,default=SEED)
    ap.add_argument('--tag',default='')
    ap.add_argument('--n-orbits',type=int,default=N_ORBITS)
    ap.add_argument('--grid-nodes',type=int,default=GRID_NODES)
    ap.add_argument('--force-nodes',type=int,default=FORCE_NODES)
    ap.add_argument('--sky-extent-kpc',type=float,default=SKY_EXTENT_KPC)
    ap.add_argument('--sky-pixel-kpc',type=float,default=SKY_PIXEL_KPC)
    ap.add_argument('--los-nodes',type=int,default=LOS_NODES)
    ap.add_argument('--nmu',type=int,default=NMU)
    ap.add_argument('--dt',type=float,default=DT)
    ap.add_argument('--nsteps',type=int,default=NSTEPS)
    ap.add_argument('--burn',type=int,default=BURN)
    ap.add_argument('--sample-every',type=int,default=SAMPLE_EVERY)
    ap.add_argument('--h4-halfwidth-kpc',type=float,default=H4_HALF_WIDTH)
    args=ap.parse_args()
    globals().update(N_ORBITS=args.n_orbits,GRID_NODES=args.grid_nodes,FORCE_NODES=args.force_nodes,
        SKY_EXTENT_KPC=args.sky_extent_kpc,SKY_PIXEL_KPC=args.sky_pixel_kpc,LOS_NODES=args.los_nodes,
        NMU=args.nmu,DT=args.dt,NSTEPS=args.nsteps,BURN=args.burn,SAMPLE_EVERY=args.sample_every,
        H4_HALF_WIDTH=args.h4_halfwidth_kpc)
    run(args.seed,args.tag)
