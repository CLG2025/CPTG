#!/usr/bin/env python3
"""Fourth-moment stress test for the Dragonfly 44 CPTG calculation.

The second-moment field and object-level structural acceleration are held fixed.
The declared higher-order closure is M_R4 = M_z4. Remaining even fourth moments
follow from the stationary axisymmetric fourth-order Jeans equations. The final
h4 quantity is an equivalent moment coordinate using the same approximate
kurtosis conversion employed by the source paper for its model comparison; it
is not a direct fit to the observed spectrum.
"""
from __future__ import annotations
import csv, json, math
from pathlib import Path
import numpy as np
from numpy.polynomial.legendre import leggauss
from scipy.integrate import cumulative_trapezoid
from scipy.interpolate import RegularGridInterpolator
from scipy.ndimage import gaussian_filter
from solve_df44 import GalaxyInputs, TensorModel, derive_annulus_boundaries, ARCSEC_TO_KPC_AT_100_MPC

ROOT=Path(__file__).resolve().parents[1]
RESULTS=ROOT/'results'
H4_OBS=0.13
H4_ERR=0.05
H4_RADIUS_KPC=1.3
H4_HALF_WIDTH_KPC=0.10
R_CIRC_FACTOR=0.83

def tail_integral(values,z):
    cumulative=cumulative_trapezoid(values,z,axis=1,initial=0.0)
    return cumulative[:,-1,None]-cumulative

def write_csv(path,fieldnames,rows):
    with open(path,'w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=fieldnames); w.writeheader(); w.writerows(rows)

def run():
    summary=json.loads((RESULTS/'primary_summary.json').read_text())
    a_star=float(summary['a_star_mps2'])
    inputs=GalaxyInputs()
    model=TensorModel(inputs,90.0,0.0,grid_nodes=320,force_nodes=176,
                      sky_extent_kpc=10.0,sky_pixel_kpc=0.06,los_nodes=180)
    sr2,sz2,sp2,_=model.intrinsic_second_moments(a_star)
    amplification,_=model.conservative_amplification(a_star)
    amp=amplification(model.u_potential)
    grad_r=amp*model.grad_r_bar
    grad_z=amp*model.grad_z_bar
    nu=model.nu
    grid=model.intrinsic_grid
    rr=grid[:,None]
    floor=1.0e-20*np.max(nu)

    mz4=np.divide(tail_integral(3.0*nu*sz2*grad_z,grid),nu,out=np.zeros_like(nu),where=nu>floor)
    mr2z2=np.divide(tail_integral(nu*sr2*grad_z,grid),nu,out=np.zeros_like(nu),where=nu>floor)
    mp2z2=np.divide(tail_integral(nu*sp2*grad_z,grid),nu,out=np.zeros_like(nu),where=nu>floor)
    mr4=mz4.copy()

    d_r_mr4=np.gradient(rr*nu*mr4,grid,axis=0,edge_order=2)
    mr2p2=np.divide(d_r_mr4+3.0*rr*nu*sr2*grad_r,3.0*nu,
                    out=np.zeros_like(nu),where=nu>floor)
    d_r_mr2p2=np.gradient(rr*nu*mr2p2,grid,axis=0,edge_order=2)
    mp4=np.divide(d_r_mr2p2+2.0*nu*mr2p2+rr*nu*sp2*grad_r,nu,
                  out=np.zeros_like(nu),where=nu>floor)

    active=nu>1.0e-10*np.max(nu)
    moments={'M_R4':mr4,'M_z4':mz4,'M_phi4':mp4,'M_R2z2':mr2z2,'M_R2phi2':mr2p2,'M_phi2z2':mp2z2}
    minima={k:float(np.min(v[active])) for k,v in moments.items()}
    ratios={
        'M_R4_over_sigma_R4_min':float(np.min(mr4[active]/sr2[active]**2)),
        'M_z4_over_sigma_z4_min':float(np.min(mz4[active]/sz2[active]**2)),
        'M_phi4_over_sigma_phi4_min':float(np.min(mp4[active]/sp2[active]**2)),
        'cauchy_Rz_max':float(np.max(mr2z2[active]**2/(mr4[active]*mz4[active]))),
        'cauchy_Rphi_max':float(np.max(mr2p2[active]**2/(mr4[active]*mp4[active]))),
        'cauchy_phiz_max':float(np.max(mp2z2[active]**2/(mp4[active]*mz4[active]))),
    }

    opts=dict(bounds_error=False,fill_value=0.0)
    inu=RegularGridInterpolator((grid,grid),nu,**opts)
    isr=RegularGridInterpolator((grid,grid),sr2,**opts)
    isp=RegularGridInterpolator((grid,grid),sp2,**opts)
    ir4=RegularGridInterpolator((grid,grid),mr4,**opts)
    ip4=RegularGridInterpolator((grid,grid),mp4,**opts)
    irp=RegularGridInterpolator((grid,grid),mr2p2,**opts)

    nodes,weights=leggauss(model.los_nodes)
    los=50.0*nodes; lw=50.0*weights
    x=model.xx.ravel(); zsky=model.yy.ravel()
    den=np.zeros_like(x); num2=np.zeros_like(x); num4=np.zeros_like(x)
    for y,w in zip(-los,lw):
        radius=np.sqrt(x*x+y*y)
        pts=np.column_stack([radius,np.abs(zsky)])
        dens=inu(pts); r2=isr(pts); p2=isp(pts); r4=ir4(pts); p4=ip4(pts); rp=irp(pts)
        c=np.divide(x,radius,out=np.ones_like(radius),where=radius>0.0)
        s=np.divide(y,radius,out=np.zeros_like(radius),where=radius>0.0)
        second=s*s*r2+c*c*p2
        fourth=s**4*r4+c**4*p4+6.0*s*s*c*c*rp
        den += w*dens; num2 += w*dens*second; num4 += w*dens*fourth
    shape=model.xx.shape
    den=den.reshape(shape); num2=num2.reshape(shape); num4=num4.reshape(shape)
    sigma_kpc=inputs.psf_fwhm_arcsec*ARCSEC_TO_KPC_AT_100_MPC/2.354820045
    sigma_pix=sigma_kpc/model.sky_pixel_kpc
    den=gaussian_filter(den,sigma_pix,mode='constant',cval=0.0)
    num2=gaussian_filter(num2,sigma_pix,mode='constant',cval=0.0)
    num4=gaussian_filter(num4,sigma_pix,mode='constant',cval=0.0)

    bounds=derive_annulus_boundaries(inputs)
    rows=[]
    for i,(inner,outer) in enumerate(zip(bounds[:-1],bounds[1:])):
        use=(model.aperture_radius>=inner)&(model.aperture_radius<outer)
        d=float(np.sum(den[use])); mu2=float(np.sum(num2[use])/d); mu4=float(np.sum(num4[use])/d)
        kappa=mu4/mu2**2-3.0; h4eq=kappa/(8.0*math.sqrt(6.0))
        rows.append({'bin':i+1,'radius_circularized_kpc':f'{[0.23,0.49,0.79,1.13,1.53,1.94,2.55,3.62,5.13][i]:.2f}',
                     'radius_major_kpc':f'{[0.23,0.49,0.79,1.13,1.53,1.94,2.55,3.62,5.13][i]/0.83:.12f}',
                     'second_moment_kms':f'{math.sqrt(mu2):.12f}','excess_kurtosis':f'{kappa:.12f}','h4_equivalent':f'{h4eq:.12f}'})
    write_csv(RESULTS/'fourth_moment_profile.csv',list(rows[0].keys()),rows)

    width_rows=[]
    for halfwidth in [0.02,0.05,0.10,0.20,0.30]:
        rc=R_CIRC_FACTOR*model.aperture_radius
        use=(rc>=H4_RADIUS_KPC-halfwidth)&(rc<H4_RADIUS_KPC+halfwidth)
        d=float(np.sum(den[use])); mu2=float(np.sum(num2[use])/d); mu4=float(np.sum(num4[use])/d)
        kappa=mu4/mu2**2-3.0; h4eq=kappa/(8.0*math.sqrt(6.0))
        width_rows.append({'half_width_kpc':f'{halfwidth:.2f}','second_moment_kms':f'{math.sqrt(mu2):.12f}',
                           'excess_kurtosis':f'{kappa:.12f}','h4_equivalent':f'{h4eq:.12f}'})
    write_csv(RESULTS/'fourth_moment_width_sensitivity.csv',list(width_rows[0].keys()),width_rows)

    center=next(r for r in width_rows if r['half_width_kpc']=='0.10')
    kappa=float(center['excess_kurtosis']); h4eq=float(center['h4_equivalent'])
    out={
        'a_star_mps2_fixed':a_star,
        'closure':'M_R4_equals_M_z4',
        'comparison_radius_kpc':H4_RADIUS_KPC,
        'comparison_half_width_kpc':H4_HALF_WIDTH_KPC,
        'second_moment_kms':float(center['second_moment_kms']),
        'excess_kurtosis':kappa,
        'h4_equivalent':h4eq,
        'observed_h4':H4_OBS,
        'observed_h4_error':H4_ERR,
        'equivalent_h4_pull':(h4eq-H4_OBS)/H4_ERR,
        'observed_kurtosis_equivalent':8.0*math.sqrt(6.0)*H4_OBS,
        'observed_kurtosis_error_equivalent':8.0*math.sqrt(6.0)*H4_ERR,
        'conversion_status':'source_matched_small_deviation_equivalent_coordinate_not_direct_LOSVD_fit',
        'active_moment_minima':minima,
        'moment_inequality_diagnostics':ratios,
    }
    (RESULTS/'fourth_moment_summary.json').write_text(json.dumps(out,indent=2)+'\n')

if __name__=='__main__':
    run()
