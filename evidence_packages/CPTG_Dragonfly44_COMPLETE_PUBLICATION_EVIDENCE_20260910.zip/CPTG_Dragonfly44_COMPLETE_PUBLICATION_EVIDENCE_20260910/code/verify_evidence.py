#!/usr/bin/env python3
from pathlib import Path
import csv, hashlib, json, re, sys
ROOT=Path(__file__).resolve().parents[1]
R=ROOT/'results'
fail=[]

def req(path):
    p=ROOT/path
    if not p.is_file(): fail.append(f'MISSING {path}')
    return p

def close(name,x,y,tol):
    if abs(float(x)-float(y))>tol: fail.append(f'{name}: {x} != {y} tol {tol}')

# Article artifacts are forbidden in the evidence archive.
for p in ROOT.rglob('*'):
    if p.is_file() and p.suffix.lower() in {'.tex','.pdf'}:
        fail.append(f'ARTICLE_ARTIFACT_FORBIDDEN {p.relative_to(ROOT)}')
    if '__pycache__' in p.parts or p.suffix.lower()=='.pyc':
        fail.append(f'CACHE_FORBIDDEN {p.relative_to(ROOT)}')

# Clean-language gate for text/code and filenames.
banned_terms=['leg'+'acy','revi'+'sion','super'+'seded','back'+'up','dra'+'ft','manu'+'script','lock'+'ed']
banned=re.compile('|'.join(banned_terms),re.I)
for p in ROOT.rglob('*'):
    rel=str(p.relative_to(ROOT))
    if banned.search(rel): fail.append(f'BANNED_FILENAME {rel}')
    if p.is_file() and p.suffix.lower() in {'.py','.md','.txt','.csv','.json'}:
        try: txt=p.read_text(errors='strict')
        except Exception: continue
        m=banned.search(txt)
        if m: fail.append(f'BANNED_TEXT {rel}: {m.group(0)}')

required=[
 'README.md','METHOD.md','EVIDENCE_INDEX.md','SOURCE_PROVENANCE.md','VALIDATION_SUMMARY.txt','RUN_COMMANDS.txt','RUNTIME.txt','requirements.txt',
 'code/solve_df44.py','code/fourth_moment_df44.py','code/schwarzschild_df44.py','code/maxentropy_df44.py','code/structural_mode_df44.py','code/publication_sensitivities_df44.py','code/central_limit_df44.py','code/verify_evidence.py',
 'inputs/galaxy_inputs.csv','inputs/kcwi_profile.csv','inputs/primary_summary.json',
 'results/primary_summary.json','results/primary_profile.csv','results/geometry_stress_grid.csv','results/stellar_mass_grid.csv',
 'results/normalization_sensitivity.csv','results/normalization_sensitivity_profiles.csv','results/inclination_grid_180x112.csv','results/stellar_mass_grid_180x112.csv','results/radius_convention_sensitivity.csv',
 'results/central_limit_summary.json','results/central_limit_diagnostic.csv',
 'results/numerical_convergence.csv','results/source_normalization.json','results/deprojection_reprojection.csv','results/scalar_root_properties.csv',
 'results/field_integrability.json','results/field_integrability_convergence.csv','results/fourth_moment_summary.json','results/fourth_moment_profile.csv',
 'results/fourth_moment_width_sensitivity.csv','results/orbit_summary_seed20260920_canonical.json','results/orbit_summary_seed20260922_independent.json',
 'results/orbit_library_seed20260920_canonical.npz','results/orbit_library_seed20260922_independent.npz',
 'results/constraint_residuals_seed20260920_canonical.csv','results/constraint_residuals_seed20260922_independent.csv',
 'results/maxentropy_seed20260920_canonical.json','results/maxentropy_seed20260922_independent.json',
 'results/orbit_summary_seed20260920_dt_half.json','results/orbit_summary_seed20260920_finecells.json',
 'results/orbit_summary_seed20260920_hw0p05.json','results/orbit_summary_seed20260920_hw0p20.json',
 'results/orbit_sensitivity_summary.csv','results/maximum_entropy_summary.csv',
 'results/structural_mode_summary.json','results/structural_mode_profile.csv','logs/structural_mode.log']
for x in required: req(x)

if not fail:
    p=json.loads((R/'primary_summary.json').read_text())
    close('a_star',p['a_star_mps2'],5.293518737484308e-10,5e-22)
    close('rc_gpc',p['rc_gpc'],829.7313815724656,1e-9)
    close('chi2_cptg',p['chi2_diag_cptg'],9.208350835345671,1e-9)
    close('max_pull',p['max_abs_pull_cptg'],1.4611242091774463,1e-9)
    close('stellar_half',p['half_light_stellar_only_kms'],6.13560843005787,1e-9)
    close('stellar_chi2',p['chi2_diag_stellar_only'],539.6572523727573,1e-8)
    if p['min_vphi2_active_kms2']<=0: fail.append('PRIMARY_NEGATIVE_VPHI2')

    rows=list(csv.DictReader((R/'geometry_stress_grid.csv').open()))
    if len(rows)!=20: fail.append(f'STRESS_GRID_ROWS {len(rows)} != 20')
    if any(float(x['min_vphi2_active_kms2'])<=0 for x in rows): fail.append('STRESS_GRID_NEGATIVE_VPHI2')

    conv=list(csv.DictReader((R/'numerical_convergence.csv').open()))
    if len(conv)!=4: fail.append(f'CONVERGENCE_ROWS {len(conv)} != 4')
    if conv and [int(x['grid_nodes']) for x in conv] != [120,180,240,320]: fail.append('CONVERGENCE_GRID_SEQUENCE')

    f=json.loads((R/'fourth_moment_summary.json').read_text())
    close('fourth_kappa',f['excess_kurtosis'],-0.151668894752,2e-10)
    close('fourth_h4eq',f['h4_equivalent'],-0.007739820875,2e-12)
    if any(float(v)<=0 for v in f['active_moment_minima'].values()): fail.append('FOURTH_MOMENT_NONPOSITIVE')
    if any(float(f['moment_inequality_diagnostics'][k])>1+1e-8 for k in ['cauchy_Rz_max','cauchy_Rphi_max','cauchy_phiz_max']): fail.append('FOURTH_CAUCHY_FAIL')

    orbit_cases=[(20260920,'canonical'),(20260922,'independent'),(20260920,'dt_half'),(20260920,'finecells'),(20260920,'hw0p05'),(20260920,'hw0p20')]
    for seed,tag in orbit_cases:
        d=json.loads((R/f'orbit_summary_seed{seed}_{tag}.json').read_text())
        if d['retained_orbits']<1015: fail.append(f'ORBIT_RETAINED_FAIL {seed} {tag}')
        if d['p95_max_relative_energy_drift']>5e-4: fail.append(f'ENERGY_P95_FAIL {seed} {tag}')
        if d['max_relative_Lz_drift']>1e-8: fail.append(f'LZ_FAIL {seed} {tag}')
        h=d['h4_constrained']
        if abs(h['gh_h4']-0.13)>5e-5: fail.append(f'H4_COMPAT_FAIL {seed} {tag} {h["gh_h4"]}')
        if h['max_abs_scaled_constraint_residual']>1e-5: fail.append(f'UPSTREAM_RESID_FAIL {seed} {tag}')
        if h['effective_orbit_number']<300: fail.append(f'ORBIT_EFFECTIVE_NUMBER_FAIL {seed} {tag}')

    for seed,tag in [(20260920,'canonical'),(20260922,'independent')]:
        m=json.loads((R/f'maxentropy_seed{seed}_{tag}.json').read_text())
        if not m['optimizer_success']: fail.append(f'MAXENT_OPT_FAIL {seed}')
        if m['max_abs_scaled_constraint_residual']>1e-5: fail.append(f'MAXENT_RESID_FAIL {seed}')
        if abs(m['gh_h4']-0.13)<0.05: fail.append(f'MAXENT_NOT_WITHHELD_DIAGNOSTIC {seed}')

    # Half-light normalization sensitivity: central solution plus +/-3 km/s endpoints.
    ns=list(csv.DictReader((R/'normalization_sensitivity.csv').open()))
    if [float(x['half_light_target_kms']) for x in ns] != [30.0,33.0,36.0]: fail.append('NORMALIZATION_TARGET_SEQUENCE')
    expected_norm={30.0:(3.5616964646326802e-10,3.698923508781,1.163184817529),
                   33.0:(5.293518737484308e-10,9.208350835346,1.461124209177),
                   36.0:(7.5828133695796768e-10,26.454341987196,2.453507412029)}
    for row in ns:
        t=float(row['half_light_target_kms']); a,chi,mp=expected_norm[t]
        close(f'norm_a_{t}',row['a_star_mps2'],a,5e-22)
        close(f'norm_chi_{t}',row['chi2_diag'],chi,5e-9)
        close(f'norm_pull_{t}',row['max_abs_pull'],mp,5e-9)
        if float(row['min_vphi2_active_kms2'])<=0: fail.append(f'NORMALIZATION_NEGATIVE_VPHI2 {t}')
    nprof=list(csv.DictReader((R/'normalization_sensitivity_profiles.csv').open()))
    if len(nprof)!=27: fail.append(f'NORMALIZATION_PROFILE_ROWS {len(nprof)} != 27')

    # Publication table resolutions.
    inc=list(csv.DictReader((R/'inclination_grid_180x112.csv').open()))
    if len(inc)!=5 or [int(x['inclination_deg']) for x in inc] != [50,60,70,80,90]: fail.append('INCLINATION_180x112_ROWS')
    if inc:
        close('incl50_chi',inc[0]['chi2_diag'],9.305761640483,5e-9)
        close('incl90_chi',inc[-1]['chi2_diag'],9.349158019231,5e-9)
    mass=list(csv.DictReader((R/'stellar_mass_grid_180x112.csv').open()))
    if len(mass)!=3: fail.append(f'MASS_180x112_ROWS {len(mass)} != 3')
    if mass:
        close('mass3_a',mass[0]['a_star_mps2'],5.2858979953002727e-10,5e-22)
        close('mass45_a',mass[-1]['a_star_mps2'],3.3996695522271936e-10,5e-22)
    rad=list(csv.DictReader((R/'radius_convention_sensitivity.csv').open()))
    if len(rad)!=2: fail.append(f'RADIUS_CONVENTION_ROWS {len(rad)} != 2')
    if rad:
        if abs(float(rad[1]['chi2_diag'])-float(rad[0]['chi2_diag']))>0.05: fail.append('RADIUS_CONVENTION_SENSITIVITY_FAIL')

    cl=json.loads((R/'central_limit_summary.json').read_text())
    if not (0.7<float(cl['log_slope_gbar_vs_r'])<1.2): fail.append('CENTRAL_GBAR_SLOPE_FAIL')
    if not (0.3<float(cl['log_slope_g_cptg_vs_r'])<0.7): fail.append('CENTRAL_GCPTG_SLOPE_FAIL')
    if not (-0.7<float(cl['log_slope_amplification_vs_r'])<-0.3): fail.append('CENTRAL_AMP_SLOPE_FAIL')

    sm=json.loads((R/'structural_mode_summary.json').read_text())
    close('structural_a_star_fixed',sm['a_star_mps2_fixed'],p['a_star_mps2'],1e-22)
    dom=sm['domain']
    close('structural_R',dom['R_kpc'],6.1807228915662655,2e-12)
    close('structural_lower',dom['lower_kpc'],6.1807228915662655/5.0,2e-12)
    close('structural_lambda',sm['lambda_kpc'],3.7324869989814067,5e-9)
    close('structural_N',sm['N'],1.6559261675266332,5e-10)
    convN=[float(x['N']) for x in sm['integration_convergence']]
    if len(convN)!=3 or max(convN)-min(convN)>1e-6: fail.append('STRUCTURAL_INTEGRATION_CONVERGENCE_FAIL')
    fieldN=[float(x['N']) for x in sm['field_grid_convergence']]
    if len(fieldN)!=3 or max(fieldN)-min(fieldN)>1e-6: fail.append('STRUCTURAL_FIELD_GRID_CONVERGENCE_FAIL')
    prof=list(csv.DictReader((R/'structural_mode_profile.csv').open()))
    if len(prof)!=32769: fail.append(f'STRUCTURAL_PROFILE_ROWS {len(prof)} != 32769')
    if prof:
        close('structural_profile_lo',prof[0]['r_kpc'],dom['lower_kpc'],2e-12)
        close('structural_profile_R',prof[-1]['r_kpc'],dom['R_kpc'],2e-12)
        close('structural_profile_cumulative_end',prof[-1]['cumulative_weight'],1.0,2e-12)

# Manifest gate if present.
man=ROOT/'SHA256SUMS.txt'
if man.exists():
    listed={}
    for line in man.read_text().splitlines():
        if not line.strip(): continue
        h,rel=line.split('  ',1); listed[rel]=h
    actual=[]
    for p in ROOT.rglob('*'):
        if p.is_file() and p.name!='SHA256SUMS.txt': actual.append(str(p.relative_to(ROOT)))
    if set(actual)!=set(listed):
        fail.append(f'MANIFEST_COVERAGE_DIFF missing={sorted(set(actual)-set(listed))} extra={sorted(set(listed)-set(actual))}')
    for rel,h in listed.items():
        got=hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()
        if got!=h: fail.append(f'HASH_FAIL {rel}')

if fail:
    print('EVIDENCE VERIFICATION FAIL')
    for x in fail: print(x)
    sys.exit(1)
print('EVIDENCE VERIFICATION PASS')
