# Method Contract

## Material source and geometry

The material source is the observed Dragonfly 44 stellar distribution. The projected Sersic source is deprojected as an oblate stellar density and normalized directly to the adopted stellar mass. No dark-halo source or stellar-source weighting coefficient is introduced.

The physical scale uses 100 Mpc. The source-reported radial coordinate is implemented with `R_major = R / 0.83`; a separate calculation checks the literal approximate relation `R_major = 1.20 R`. The projected axis ratio, aperture axis ratio, circularized half-light radius, and Gaussian 1.2-arcsec spatial-resolution approximation are retained explicitly.

The baseline stellar source is 3.0e8 solar masses. The 3.0e8--4.5e8 solar-mass interval is a declared source-sensitivity range; the upper endpoint is not treated as an independent measured mass.

## CPTG field and second moments

One galaxy-level structural acceleration is determined by the circularized half-light second moment. The central result uses 33 km/s. Separate 30 and 36 km/s calculations quantify sensitivity across the quoted +/-3 km/s observational interval. No individual radial measurement receives its own structural acceleration.

The scalar CPTG galaxy field is solved on the equatorial plane. Its axisymmetric continuation uses the baryonic-potential label so that the amplification is constant on baryonic equipotential surfaces. The amplification ratio is evaluated for positive potential label; at the exact center both accelerations vanish and the physical CPTG force is defined by its regular zero limit. The effective-potential integral is convergent at the lower endpoint.

The fixed field is propagated through the stationary axisymmetric Jeans equations. The intrinsic tensor is projected along the line of sight, convolved with the stated spatial-resolution kernel, and integrated over the KCWI apertures. The nine resolved radial measurements are then compared without radial renormalization.

The stellar-only control uses the same source, tensor equations, projection, convolution, and apertures with only the baryonic stellar field supplied to the Jeans equations.

## Higher moments and orbit superposition

For the minimal fourth-order calculation only, the local velocity distribution is taken to be even under independent sign reversals of the velocity components, so odd mixed velocity moments vanish. The solved gravitational field is held fixed. The condition `M_R4 = M_z4` is used only as a minimal higher-order closure. Its equivalent h4 coordinate is a small-deviation diagnostic rather than an exact conversion of the observed line profile.

The three-integral calculation also holds the field fixed. Orbit weights are nonnegative. The intrinsic source is divided into 32 meridional cells. Mass plus three intrinsic second-moment numerators are constrained in every cell. Nine projected-light constraints, nine projected second-moment numerators, the radius-matched light and second-moment constraints, and total mass normalization give 149 upstream scaled constraints before h4 is supplied.

The measured h4 is introduced only in the final LOSVD compatibility weighting. A separate maximum-entropy solve omits h4 and evaluates the neutral orbit-population prediction.

## Structural Mode

Structural Mode is downstream of the dynamical solution. The structural acceleration and source geometry are read from the solved primary result and held fixed. The outer coordinate is the outermost modeled KCWI semi-major coordinate, `R = 5.13/0.83 kpc`, and the exact parent domain `[R/5,R]` is used.

`C_g = g^2 + (kappa_struct dg/dr)^2`, with `kappa_struct = 1 kpc`,

`w = |dC_g/dr|`,

`lambda = integral_(R/5)^R(r w dr) / integral_(R/5)^R(w dr)`,

and `N = R/lambda`.

The Structural Mode lane includes integration and field-grid convergence. No Structural Mode quantity feeds back into the gravitational or orbital solution.
