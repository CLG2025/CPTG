# Source Provenance

Primary observational source:
P. van Dokkum et al., "Spatially Resolved Stellar Kinematics of the Ultra-diffuse Galaxy Dragonfly 44. I. Observations, Kinematics, and Cold Dark Matter Halo Fits," Astrophysical Journal 880, 91 (2019), DOI 10.3847/1538-4357/ab2914.

Supporting stellar-mass source:
P. van Dokkum et al., "A High Stellar Velocity Dispersion and ~100 Globular Clusters for the Ultra-Diffuse Galaxy Dragonfly 44," Astrophysical Journal Letters 828, L6 (2016), DOI 10.3847/2041-8205/828/1/L6.

Inputs used here include the 100 Mpc distance scale, nine KCWI kinematic rows, major-axis effective radius 4.7 kpc, Sersic index 0.94, projected axis ratio 0.68, KCWI aperture axis ratio approximately 0.69, source-stated `R_major` approximately `1.20 R` conversion implemented as `R / 0.83`, circularized half-light second moment `33 +/- 3 km/s`, and spatially averaged Gauss-Hermite `h4 = 0.13 +/- 0.05` assigned to a weighted radius of 1.3 kpc.

The baseline stellar source is 3.0e8 solar masses. The calculations explore 3.0e8--4.5e8 solar masses as a declared source-sensitivity interval; the upper endpoint is an analysis bound rather than an additional measured mass.

The Gaussian 1.2-arcsec spatial-resolution kernel is an adopted approximation to the quoted KCWI spatial resolution.

Structural Mode uses the solved edge-on neutral CPTG field and does not introduce a new observational input. Its outer coordinate is the outermost modeled KCWI semi-major coordinate, `R = 5.13/0.83 = 6.1807228915662655 kpc`, and the parent interval begins exactly at `R/5 = 1.2361445783132532 kpc`.
