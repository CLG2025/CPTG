# Evidence Index

| Calculation or reported quantity | Primary evidence |
|---|---|
| Observational inputs, 100 Mpc scale, and radius convention | `inputs/galaxy_inputs.csv`, `inputs/kcwi_profile.csv`, `SOURCE_PROVENANCE.md` |
| Oblate Sersic source and baryonic field | `code/solve_df44.py`, `results/source_normalization.json`, `results/deprojection_reprojection.csv` |
| CPTG scalar root | `code/solve_df44.py`, `results/scalar_root_properties.csv` |
| Conservative axisymmetric field | `code/solve_df44.py`, `results/field_integrability.json`, `results/field_integrability_convergence.csv` |
| Central-force limiting behavior | `code/central_limit_df44.py`, `results/central_limit_summary.json`, `results/central_limit_diagnostic.csv` |
| Projected observation operator and aperture geometry | `results/observational_operator.json`, `results/aperture_geometry.csv`, `results/spatial_resolution.csv` |
| Primary 33 km/s second-moment result | `results/primary_summary.json`, `results/primary_profile.csv` |
| 30/33/36 km/s normalization sensitivity | `code/publication_sensitivities_df44.py`, `results/normalization_sensitivity.csv`, `results/normalization_sensitivity_profiles.csv` |
| Stellar-only control | `results/primary_summary.json`, `results/primary_profile.csv` |
| Full 20-branch geometry/stress screen | `results/geometry_stress_grid.csv` |
| 180/112 neutral inclination table | `code/publication_sensitivities_df44.py`, `results/inclination_grid_180x112.csv` |
| 180/112 stellar-mass table | `code/publication_sensitivities_df44.py`, `results/stellar_mass_grid_180x112.csv` |
| Radius-convention sensitivity | `code/publication_sensitivities_df44.py`, `results/radius_convention_sensitivity.csv` |
| Numerical convergence | `results/numerical_convergence.csv` |
| Minimal fourth moment | `code/fourth_moment_df44.py`, `results/fourth_moment_summary.json`, `results/fourth_moment_profile.csv`, `results/fourth_moment_width_sensitivity.csv` |
| Three-integral orbit compatibility | `code/schwarzschild_df44.py`, orbit summaries, orbit libraries, constraint-residual tables |
| Orbit numerical sensitivities | `results/orbit_sensitivity_summary.csv` and associated orbit summaries/libraries |
| h4-withheld maximum entropy | `code/maxentropy_df44.py`, `results/maximum_entropy_summary.csv`, maximum-entropy JSON/NPZ files |
| Structural Mode N on exact [R/5,R] | `code/structural_mode_df44.py`, `results/structural_mode_summary.json`, `results/structural_mode_profile.csv` |
| Replay commands | `RUN_COMMANDS.txt` |
| Environment and numerical methods | `RUNTIME.txt`, `requirements.txt` |
| Scientific-value and integrity gates | `code/verify_evidence.py`, `SHA256SUMS.txt` |
