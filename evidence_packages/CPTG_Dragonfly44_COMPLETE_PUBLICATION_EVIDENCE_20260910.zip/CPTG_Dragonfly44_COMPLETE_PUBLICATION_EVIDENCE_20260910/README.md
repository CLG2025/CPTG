# Dragonfly 44 CPTG Complete Publication Evidence

This archive contains the numerical calculation evidence supporting the Dragonfly 44 conservative axisymmetric CPTG stellar-dynamics analysis. It contains no article source and no rendered article.

The evidence covers the complete calculation path used for the reported results:

1. measured Dragonfly 44 stellar and KCWI kinematic inputs, using the adopted 100 Mpc distance scale;
2. oblate Sersic deprojection and baryonic potential;
3. conservative axisymmetric CPTG field construction, including the regular central-force limit;
4. stationary axisymmetric Jeans second moments;
5. line-of-sight projection, Gaussian spatial-resolution convolution, and KCWI aperture integration;
6. the stellar-only control;
7. half-light normalization, inclination, meridional-stress, stellar-mass, radial-coordinate, source, field-integrability, spatial-resolution, and numerical-convergence sensitivities;
8. the fixed-field fourth-moment calculation;
9. nonnegative three-integral orbit-superposition calculations with independent orbit seeds and numerical sensitivities;
10. maximum-entropy h4-withheld calculations; and
11. downstream Structural Mode N evaluated on the exact parent interval [R/5,R].

The central second-moment solution uses the measured 33 km/s half-light value. The 30 and 36 km/s calculations are sensitivity endpoints for the quoted +/-3 km/s observational range; they are not added as independent likelihood terms.

The observed h4 value is dynamically admissible in the fixed CPTG orbit space when supplied only to the final orbit-weighting constraint. It is not independently predicted by the h4-withheld maximum-entropy calculation.

Structural Mode is calculated only after the gravitational solution is fixed and does not alter the structural acceleration, potential, Jeans stresses, orbit library, or orbit weights.

Use `RUN_COMMANDS.txt` for replay commands, `EVIDENCE_INDEX.md` for the calculation-to-file map, and `code/verify_evidence.py` for the fail-closed integrity and scientific-value checks.
