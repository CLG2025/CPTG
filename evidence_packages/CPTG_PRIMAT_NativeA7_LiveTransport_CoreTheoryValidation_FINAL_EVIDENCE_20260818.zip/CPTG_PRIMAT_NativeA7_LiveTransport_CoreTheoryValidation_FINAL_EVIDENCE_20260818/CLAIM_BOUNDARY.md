# Claim boundary

Accepted claim:

The locked CPTG mass-seven live-channel transport operator, with direct Li7 and Be7 RHS/Jacobian sinks and integrated optical depth ln(pi), passed the preregistered PRIMAT v0.3.2 native large-network validation at one CPTG transported baryon-density coordinate and all six frozen PRIMAT authority anchors.

Do not expand this claim to:
- a fitted lithium correction;
- a post-processing division by pi;
- a full CPTG radiation-coordinate implementation in PRIMAT;
- a validation of N_eff^CPTG inside PRIMAT;
- arbitrary untested BBN backgrounds;
- observational lithium as the primary PASS/FAIL criterion.

The final audit explicitly records:
A7_FULL_CPTG_RADIATION_COORDINATE_IMPLEMENTED False
