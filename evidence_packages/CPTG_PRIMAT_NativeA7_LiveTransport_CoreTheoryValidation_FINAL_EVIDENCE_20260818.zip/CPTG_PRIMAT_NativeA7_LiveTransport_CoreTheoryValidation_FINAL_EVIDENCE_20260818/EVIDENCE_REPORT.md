# PRIMAT-native mass-seven live-transport validation — final evidence report

## 1. Purpose

This package closes the prospective PRIMAT-native validation of the already-locked CPTG mass-seven live-channel transport law. The theory gate was treated as core CPTG theory, not as a fitted lithium correction.

The frozen law was:

```text
Y7 = Y_Li7 + Y_Be7
dY_Li7/dt -> dY_Li7/dt - Gamma7(t) Y_Li7
dY_Be7/dt -> dY_Be7/dt - Gamma7(t) Y_Be7
integral Gamma7(t) dt = ln(pi)
survival target = exp[-ln(pi)] = 1/pi
```

The temporal embedding was prospectively frozen to the inherited log-cosine support from 0.0175 MeV to 0.0040 MeV. No lithium endpoint was used to set the survival factor, gate normalization, gate window, baryon coordinate, nuclear rates, neutron lifetime, or numerical tolerance.

## 2. Immutable preregistration

Preregistration SHA-256:

`444879ac5bbc280f66fe99606a5da22fe99d0cf3f341c0d8cc771beaea6f67b4`

Source execution package:

`CPTG_PRIMAT_NativeA7_LiveTransport_CoreTheoryValidation_20260818_r01.zip`

Source execution package SHA-256:

`384fdc86e7899a9b99d4e54883969e596d8073bead383ca5d5024d32b2f909a9`

The original executable/preregistration package is embedded under `SOURCE_PACKAGE/` and the principal preregistration files are copied into `PREREGISTRATION/` for direct inspection.

## 3. PRIMAT execution configuration

- PRIMAT v0.3.2
- forced pure-Python backend
- native `large` network
- numerical precision `1e-10`
- 4000-point nuclear-rate grid over `1e-3 <= T9 <= 10`
- neutron lifetime 878.4 s
- standard frozen radiative, finite-mass, thermal, spectral-distortion, weak-rate-normalization, plasma-QED and nuclear-QED corrections enabled
- direct live sink species: Li7 and Be7 only
- matching direct analytic-Jacobian diagonal sinks: Li7 and Be7 only
- `DeltaNeff = 0` in every row

Seven paired coordinates were executed, gate-off then gate-on: one CPTG transported baryon-density coordinate and six frozen PRIMAT authority anchors, for 14 native solves total.

## 4. Frozen hard gates

The complete machine-readable thresholds are preserved in `PREREGISTRATION/FROZEN_A7_PREREGISTRATION.json`. Principal gates were:

| Test | Frozen acceptance |
|---|---:|
| internal Y7 survival relative error to `1/pi` | <= 0.005 |
| reported Li7/H survival relative error to `1/pi` | <= 0.005 |
| D/H gated-vs-baseline relative change | <= 1e-6 |
| YPBBN gated-vs-baseline relative change | <= 1e-6 |
| He3/H gated-vs-baseline relative change | <= 1e-6 |
| Neff gated-vs-baseline relative change | <= 1e-10 |
| independent-grid tau relative error to `ln(pi)` | <= 2e-6 |
| quadrature tau relative error to `ln(pi)` | <= 1e-12 |
| nonzero RHS gate calls | >= 1 |
| nonzero analytic-Jacobian gate calls | >= 1 |
| installed PRIMAT source unchanged | required |
| six frozen PRIMAT authority baselines | required to reproduce authority before gate-on qualification |

The observational lithium comparison was expressly downstream and non-gating.

## 5. Final results

Target:

`1/pi = 0.3183098861837907`

All seven paired coordinates passed. The measured survival factors were:

| Coordinate | Y7 survival | relative error to 1/pi | D/H rel. change | YPBBN rel. change | He3/H rel. change | tau-grid rel. error | RHS calls | JAC calls | observational pull, diagnostic |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| CPTG_BBN_BARYON | 0.318367445312 | 0.000180827 | 3.14e-09 | 3.79e-12 | 2.02e-10 | 1.5e-07 | 15548 | 473 | 0.868765 |
| ETA6p044 | 0.318366185395 | 0.000176869 | 3.63e-09 | 3.82e-12 | 5.89e-10 | 1.5e-07 | 15314 | 435 | 0.983819 |
| ETA6p080 | 0.318365290272 | 0.000174057 | 3.16e-09 | 3.73e-12 | 2.88e-10 | 1.5e-07 | 15581 | 464 | 1.06828 |
| ETA6p094 | 0.318364947655 | 0.000172981 | 3.87e-09 | 3.83e-12 | 5.69e-10 | 1.5e-07 | 15487 | 458 | 1.10121 |
| ETA6p106 | 0.318364656240 | 0.000172065 | 3.23e-09 | 3.75e-12 | 3.42e-10 | 1.5e-07 | 15470 | 442 | 1.12947 |
| ETA6p128 | 0.318364128306 | 0.000170407 | 3.29e-09 | 3.76e-12 | 2.15e-10 | 1.5e-07 | 15532 | 444 | 1.18136 |
| ETA6p134 | 0.318363988002 | 0.000169966 | 2.79e-09 | 3.69e-12 | 2.16e-11 | 1.5e-07 | 15559 | 446 | 1.19553 |

Aggregate results:

- survival range: `0.318363988002` to `0.318367445312`;
- worst relative error to `1/pi`: `0.000180827` = `0.018083%`, approximately `27.65x` inside the frozen 0.5% survival gate;
- maximum D/H relative disturbance: `3.87e-09`;
- maximum YPBBN relative disturbance: `3.83e-12`;
- maximum He3/H relative disturbance: `5.89e-10`;
- independent-grid optical-depth relative error: `1.5e-07` at every coordinate;
- nonzero RHS calls: `15314` to `15581`;
- nonzero analytic-Jacobian calls: `435` to `473`;
- observational pull diagnostic range: `0.868765` to `1.19553` sigma;
- 14 committed row runtimes sum to `1051.185` s.

At the central PRIMAT authority anchor `eta10 = 6.094`:

```text
baseline Y7    = 4.08074346577861223e-10
gated Y7       = 1.29916567987528558e-10
baseline Li7/H = 5.41925964547088552e-10
gated Li7/H    = 1.72530231335814528e-10
survival       = 0.318364947655
```

At the CPTG transported baryon-density coordinate:

```text
baseline Y7    = 3.94409054504861126e-10
gated Y7       = 1.25567003090824555e-10
baseline Li7/H = 5.23668866791401501e-10
gated Li7/H    = 1.66719119310060441e-10
survival       = 0.318367445312
```

## 6. Adaptive-quadrature warning disposition

The complete production transcript contains `7` SciPy `IntegrationWarning` messages, one for each gated coordinate, stating that roundoff prevented the requested adaptive-quadrature tolerance from being achieved. They are retained in the evidence.

They did not abort the native network solves. All seven gated rows completed. The separately preregistered independent-grid optical-depth reconstruction gave a relative error of `1.5e-07` to `ln(pi)` for every coordinate, within the frozen `2e-6` gate. Accordingly, this package records the warnings as roundoff-limited adaptive-quadrature certification warnings under the requested `1e-12` quadrature tolerance, while relying on the independent-grid gate as the non-identical normalization cross-check.

## 7. Final audit

The independently rerun final audit reported:

```text
A7_CPTG_BBN_BARYON_COORDINATE PASS
A7_SIX_AUTHORITY_ANCHORS PASS
A7_INSTALLED_PRIMAT_SOURCE_UNCHANGED PASS
A7_FULL_CPTG_RADIATION_COORDINATE_IMPLEMENTED False
A7_PRIMAT_NATIVE_CORE_THEORY_VALIDATION PASS
```

The exact supplied final-audit console block is preserved at `EXECUTION/RUN_FINAL_AUDIT_WINDOWS_TRANSCRIPT_20260818.txt`.

## 8. Scientific decision

**PASS.**

Within the preregistered scope, the locked CPTG mass-seven live transport operator is successfully realized inside PRIMAT v0.3.2's native large-network evolution. Direct Li7 and Be7 RHS/Jacobian transport produces mass-seven survival within 0.019% relative of `1/pi` at every tested coordinate while preserving D/H, He3/H and YPBBN far inside the frozen non-A7 disturbance limits.

The slight difference from exact algebraic `1/pi` is retained as the live-network result rather than corrected away.

## 9. Claim boundary

This package supports:

> The locked CPTG A=7 live-channel transport law, with `integral Gamma7 dt = ln(pi)`, passed a prospective native implementation test in PRIMAT v0.3.2's large network across the CPTG transported baryon-density coordinate and six frozen PRIMAT authority anchors.

It does **not** establish:

- a full CPTG radiation-coordinate translation into PRIMAT;
- a PRIMAT implementation of `N_eff^CPTG = 2.968584073464`;
- that `DeltaNeff=0` is equivalent to the CPTG radiation coordinate;
- that observational lithium agreement was a fit target or primary acceptance gate;
- a generic mass-seven result for arbitrary BBN backgrounds outside the tested coordinates.

The explicit final flag `A7_FULL_CPTG_RADIATION_COORDINATE_IMPLEMENTED False` is therefore part of the accepted evidence, not an unresolved execution error.

## 10. Evidence identities

- source execution package SHA-256: `384fdc86e7899a9b99d4e54883969e596d8073bead383ca5d5024d32b2f909a9`
- frozen preregistration SHA-256: `444879ac5bbc280f66fe99606a5da22fe99d0cf3f341c0d8cc771beaea6f67b4`
- complete primary-validation transcript SHA-256: `db24518c9947c0a9a167fe9c4fe18300cd84849c3054e67067a1dcb9f925f0a2`
- final-audit transcript SHA-256: `018c79ba2be8a2caba587b7224b0842443f56b73e9fd950c0d62987d92bd8dc8`
- frozen native PRIMAT trajectory authority SHA-256: `97fd7b4f4f4e7466be9e45be264e62faade5b55e80d415201ed4390405080f9a`

Machine-readable results are in `RESULTS/`.
