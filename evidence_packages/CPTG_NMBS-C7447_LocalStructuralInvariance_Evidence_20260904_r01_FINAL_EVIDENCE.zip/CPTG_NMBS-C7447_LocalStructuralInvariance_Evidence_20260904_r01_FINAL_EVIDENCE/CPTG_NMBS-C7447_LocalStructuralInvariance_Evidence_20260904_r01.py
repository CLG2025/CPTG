#!/usr/bin/env python3
"""Reproduce and audit the numerical results used in the NMBS-C7447 CPTG local-structural-invariance test.

The evidence keeps the bound-system structural state fixed under a pure native-phase sweep,
tracks the phase-dependent cosmological comparison coordinate Xi_star_pi, and reproduces
the same verified Structural Mode reconstruction and sensitivity controls.
"""
import math
import numpy as np
from scipy.integrate import quad, cumulative_trapezoid
from scipy.optimize import brentq
from scipy.special import gamma, gammaincinv
from numpy.polynomial.legendre import leggauss

PI = math.pi
C = 299792458.0
KPC_M = 3.0856775814913673e19
MPC_KM = 3.085677581491367e19
SEC_PER_GYR = 365.25 * 24 * 3600 * 1e9
G_KPC = 4.30091727003628e-6  # kpc (km/s)^2 Msun^-1
ACC_CONV = 1e6 / KPC_M       # (km/s)^2/kpc -> m/s^2

# Observational anchors from van de Sande et al. (2011)
Z = 1.80
SIGMA = 294.0
SIGMA_ERR = 51.0
RE_CIRC = 1.64
RE_CIRC_ERR = 0.15
N_SERSIC = 5.3
N_SERSIC_ERR = 0.4
Q_PROJ = 0.71
Q_PROJ_ERR = 0.01
MSTAR = 1.5e11
LOGM_ERR = 0.2

# Current CPTG native branch
BPI = 1.0 - 1.0 / PI
TPI = 1.0 / PI
H0_PI = 69.4162507897
A_PI0 = PI ** 1.5 * 1e-10
P_AC = 3.0 - PI / 100.0
OM_AC = P_AC / (3.0 * PI)
OL_AC = 1.0 - OM_AC
H0_AC = 67.4777967351
H0_LUM = 73.17


def E_pi(z):
    a = 1.0 / (1.0 + z)
    return math.sqrt(BPI + TPI * a ** (-PI))


def E_ac(z):
    a = 1.0 / (1.0 + z)
    return math.sqrt(BPI + TPI * a ** (-P_AC))


def E_lum(z):
    a = 1.0 / (1.0 + z)
    return math.sqrt(OL_AC + OM_AC * a ** (-P_AC))


def E_lcdm70(z):
    return math.sqrt(0.3 * (1.0 + z) ** 3 + 0.7)


def D_A(z, H0, E):
    integral = quad(lambda zz: 1.0 / E(zz), 0.0, z, epsabs=1e-12, epsrel=1e-12)[0]
    return (299792.458 / H0) * integral / (1.0 + z)


def b_n(n):
    return float(gammaincinv(2.0 * n, 0.5))


def rfrac_over_re(n, frac):
    return (float(gammaincinv(2.0 * n, frac)) / b_n(n)) ** n


def sersic_S(s, re, n):
    return np.exp(-b_n(n) * ((np.asarray(s) / re) ** (1.0 / n) - 1.0))


def sersic_dSds(s, re, n):
    s = np.asarray(s)
    return sersic_S(s, re, n) * (-b_n(n) / n) * (s / re) ** (1.0 / n - 1.0) / re


def sersic_LS(re, n):
    b = b_n(n)
    return 2.0 * PI * n * math.exp(b) * re ** 2 * b ** (-2.0 * n) * gamma(2.0 * n)


def rho_abel_grid(rgrid, re, n, mstar, q=1.0, nquad=480):
    x, w = leggauss(nquad)
    theta = (x + 1.0) * PI / 4.0
    wt = w * PI / 4.0
    sec = 1.0 / np.cos(theta)
    out = np.empty_like(rgrid)
    fac = -mstar / (PI * q * sersic_LS(re, n))
    for i in range(0, len(rgrid), 500):
        rr = rgrid[i:i+500, None]
        s = rr * sec[None, :]
        integ = np.sum(sersic_dSds(s, re, n) * sec[None, :] * wt[None, :], axis=1)
        out[i:i+500] = fac * integ
    return out


def solve_cptg(gbar, astar, r_kpc):
    rc_m = 48.0 * PI * C ** 2 / astar
    r_m = np.asarray(r_kpc) * KPC_M
    ggeom = 0.5 * astar * (r_m / rc_m) ** (7.0 / 5.0) / (1.0 + (r_m / rc_m) ** (12.0 / 5.0))
    result = np.empty_like(gbar)
    for i, (gb, gg) in enumerate(zip(gbar, ggeom)):
        def f(g):
            return g - gb - (math.sqrt(astar * gb) + gg) / (1.0 + (g / astar) ** (123.0 / 50.0)) ** (11.0 / 50.0)
        result[i] = brentq(f, gb, gb + math.sqrt(astar * gb) + gg + 10.0 * astar,
                            xtol=1e-18, rtol=1e-12, maxiter=100)
    return result


def endpoint_mode(r, cstruct):
    r_outer = r[-1]
    r_inner = r_outer / 5.0
    denom = cstruct[0] - cstruct[-1]
    numer = r_inner * cstruct[0] - r_outer * cstruct[-1] + np.trapezoid(cstruct, r)
    lam = numer / denom
    return lam, r_outer / lam


def direct_abs_mode(r, cstruct):
    """Evaluate Structural Mode directly from w=|dC_g/dr|."""
    dcdr = np.gradient(cstruct, r, edge_order=2)
    weight = np.abs(dcdr)
    denom = np.trapezoid(weight, r)
    numer = np.trapezoid(r * weight, r)
    lam = numer / denom
    return lam, r[-1] / lam


def cstruct_diagnostics(r, cstruct):
    diffs = np.diff(cstruct)
    lam_abs, mode_abs = direct_abs_mode(r, cstruct)
    return {
        "monotonic_decreasing": bool(np.all(diffs < 0.0)),
        "max_delta_Cg": float(np.max(diffs)),
        "lambda_abs": float(lam_abs),
        "mode_abs": float(mode_abs),
    }


def structural_mode_spherical(re, n, mstar, astar, nr=6000, frac=0.95, nquad=480):
    r95 = rfrac_over_re(n, frac) * re
    rg = np.geomspace(re * 1e-6, r95, nr)
    rho = rho_abel_grid(rg, re, n, mstar, q=1.0, nquad=nquad)
    menc = cumulative_trapezoid(4.0 * PI * rho * rg ** 2, rg, initial=0.0)
    r = np.linspace(r95 / 5.0, r95, nr)
    mr = np.interp(r, rg, menc)
    gbar = G_KPC * mr / r ** 2 * ACC_CONV
    g = solve_cptg(gbar, astar, r)
    dgdr = np.gradient(g, r, edge_order=2)
    cstruct = g ** 2 + dgdr ** 2  # kappa_struct = 1 kpc
    lam, mode = endpoint_mode(r, cstruct)
    return r95, lam, mode


def structural_mode_oblate(re_major, n, mstar, astar, q, nr=5000, nfield=240, frac=0.95, nquad=480, return_diagnostics=False):
    r95 = rfrac_over_re(n, frac) * re_major
    rg = np.geomspace(re_major * 1e-6, r95, max(nr, 6000))
    rho = rho_abel_grid(rg, re_major, n, mstar, q=q, nquad=nquad)
    r = np.linspace(r95 / 5.0, r95, nr)
    xx, ww = leggauss(nfield)
    x = (xx + 1.0) / 2.0
    wt = ww / 2.0
    denom = np.sqrt(1.0 - (1.0 - q * q) * x * x)
    gbar = np.empty_like(r)
    logrho = np.log(rho)
    logrg = np.log(rg)
    for i in range(0, len(r), 200):
        rr = r[i:i+200, None]
        m = rr * x[None, :]
        rhom = np.exp(np.interp(np.log(m.ravel()), logrg, logrho)).reshape(m.shape)
        integ = np.sum(rhom * x[None, :] ** 2 / denom[None, :] * wt[None, :], axis=1)
        gbar[i:i+200] = 4.0 * PI * G_KPC * q * r[i:i+200] * integ * ACC_CONV
    g = solve_cptg(gbar, astar, r)
    dgdr = np.gradient(g, r, edge_order=2)
    cstruct = g ** 2 + dgdr ** 2
    lam, mode = endpoint_mode(r, cstruct)
    if return_diagnostics:
        return r95, lam, mode, cstruct_diagnostics(r, cstruct)
    return r95, lam, mode


def astar_from(sig, re):
    return (sig * 1000.0) ** 2 / (re * KPC_M)


def main():
    a = 1.0 / (1.0 + Z)
    npi = math.log(a)
    epi = E_pi(Z)
    api = A_PI0 * epi
    astar = astar_from(SIGMA, RE_CIRC)
    frac_astar = math.sqrt((2.0 * SIGMA_ERR / SIGMA) ** 2 + (RE_CIRC_ERR / RE_CIRC) ** 2)
    sig_astar = astar * frac_astar
    xi = astar / api
    sig_xi = sig_astar / api
    rc_local_gpc = (48.0 * PI * C ** 2 / astar) / KPC_M / 1e6
    rc_native_gpc = (48.0 * PI * C ** 2 / api) / KPC_M / 1e6
    sig_rc_local = rc_local_gpc * frac_astar

    h0pi_s = H0_PI / MPC_KM
    tpi = (2.0 / (PI * h0pi_s * math.sqrt(BPI)) *
           math.asinh(math.sqrt(BPI / TPI) * a ** (PI / 2.0))) / SEC_PER_GYR
    tpi0 = (2.0 / (PI * h0pi_s * math.sqrt(BPI)) *
            math.asinh(math.sqrt(BPI / TPI))) / SEC_PER_GYR

    phase_slope = (PI / 2.0) * (TPI * a ** (-PI)) / (BPI + TPI * a ** (-PI))
    xi_present = astar / A_PI0
    sig_xi_present = sig_astar / A_PI0

    da_l70 = D_A(Z, 70.0, E_lcdm70)
    da_ac = D_A(Z, H0_AC, E_ac)
    da_lum = D_A(Z, H0_LUM, E_lum)
    da_mid = 0.5 * (da_ac + da_lum)

    distance_rows = []
    for label, da in [('source_LCDM70', da_l70), ('acoustic', da_ac), ('midpoint', da_mid), ('luminosity', da_lum)]:
        sd = da / da_l70
        re = RE_CIRC * sd
        mstar = MSTAR * sd ** 2
        ast = astar_from(SIGMA, re)
        sx = ast * frac_astar
        x = ast / api
        distance_rows.append((label, da, sd, re, mstar, ast, sx, x, sx/api))

    re_major = RE_CIRC / math.sqrt(Q_PROJ)
    sph95, sphlam, sphn = structural_mode_spherical(RE_CIRC, N_SERSIC, MSTAR, astar, nr=20000, nquad=480)
    maj95, majlam, majn = structural_mode_spherical(re_major, N_SERSIC, MSTAR, astar, nr=16000, nquad=480)
    obl95, obllam, obln, obl_diag = structural_mode_oblate(
        re_major, N_SERSIC, MSTAR, astar, Q_PROJ, nr=12000, nfield=400, nquad=480,
        return_diagnostics=True)
    thin00595, thin005lam, thin005n = structural_mode_oblate(re_major, N_SERSIC, MSTAR, astar, 0.005, nr=5000, nfield=260)
    thin000295, thin0002lam, thin0002n, thin_diag = structural_mode_oblate(
        re_major, N_SERSIC, MSTAR, astar, 0.0002, nr=16000, nfield=800, nquad=600,
        return_diagnostics=True)

    reg_rows = []
    for frac in [0.90, 0.95, 0.99]:
        rr, ll, nn = structural_mode_oblate(re_major, N_SERSIC, MSTAR, astar, Q_PROJ,
                                             nr=5000, nfield=240, frac=frac)
        reg_rows.append((frac, rr, ll, nn))

    def edge(sig=SIGMA, re=RE_CIRC, ns=N_SERSIC, logm=math.log10(MSTAR), qp=Q_PROJ,
             qint=None, nr=2600, nfield=140, nquad=180, return_diagnostics=False):
        ast = astar_from(sig, re)
        remaj = re / math.sqrt(qp)
        if qint is None:
            qint = qp
        result = structural_mode_oblate(remaj, ns, 10.0 ** logm, ast, qint,
                                        nr=nr, nfield=nfield, nquad=nquad,
                                        return_diagnostics=return_diagnostics)
        if return_diagnostics:
            return result[2], result[3]
        return result[2]

    sens_specs = {
        'sigma_low': {'sig': SIGMA-SIGMA_ERR},
        'sigma_high': {'sig': SIGMA+SIGMA_ERR},
        'Re_low': {'re': RE_CIRC-RE_CIRC_ERR},
        'Re_high': {'re': RE_CIRC+RE_CIRC_ERR},
        'n_low': {'ns': N_SERSIC-N_SERSIC_ERR},
        'n_high': {'ns': N_SERSIC+N_SERSIC_ERR},
        'M_low': {'logm': math.log10(MSTAR)-LOGM_ERR},
        'M_high': {'logm': math.log10(MSTAR)+LOGM_ERR},
        'q_low': {'qp': Q_PROJ-Q_PROJ_ERR},
        'q_high': {'qp': Q_PROJ+Q_PROJ_ERR},
    }
    sens = {}
    sens_monotonic = {}
    for key, kwargs in sens_specs.items():
        val, diag = edge(return_diagnostics=True, **kwargs)
        sens[key] = val
        sens_monotonic[key] = diag['monotonic_decreasing']

    import itertools
    corner_axes = [
        [SIGMA-SIGMA_ERR, SIGMA+SIGMA_ERR],
        [RE_CIRC-RE_CIRC_ERR, RE_CIRC+RE_CIRC_ERR],
        [N_SERSIC-N_SERSIC_ERR, N_SERSIC+N_SERSIC_ERR],
        [math.log10(MSTAR)-LOGM_ERR, math.log10(MSTAR)+LOGM_ERR],
        [Q_PROJ-Q_PROJ_ERR, Q_PROJ+Q_PROJ_ERR],
    ]
    edge_corner = []
    thin_corner = []
    edge_corner_monotonic = []
    thin_corner_monotonic = []
    for combo in itertools.product(*corner_axes):
        edge_val, edge_diag = edge(*combo, nr=1200, nfield=80, nquad=100, return_diagnostics=True)
        thin_val, thin_cdiag = edge(*combo, qint=0.0002, nr=1200, nfield=80, nquad=100, return_diagnostics=True)
        edge_corner.append((edge_val, combo))
        thin_corner.append((thin_val, combo))
        edge_corner_monotonic.append(edge_diag['monotonic_decreasing'])
        thin_corner_monotonic.append(thin_cdiag['monotonic_decreasing'])
    edge_min = min(edge_corner, key=lambda x: x[0])
    edge_max = max(edge_corner, key=lambda x: x[0])
    thin_min = min(thin_corner, key=lambda x: x[0])
    thin_max = max(thin_corner, key=lambda x: x[0])

    def refine_corner(item, qint=None):
        combo = item[1]
        sig, re, ns, logm, qp = combo
        ast = astar_from(sig, re)
        remaj = re / math.sqrt(qp)
        qq = qp if qint is None else qint
        nf = 400 if qq > 0.01 else 800
        return structural_mode_oblate(remaj, ns, 10.0 ** logm, ast, qq,
                                      nr=12000, nfield=nf, nquad=600)[2]
    edge_min_ref = refine_corner(edge_min)
    edge_max_ref = refine_corner(edge_max)
    thin_min_ref = refine_corner(thin_min, qint=0.0002)
    thin_max_ref = refine_corner(thin_max, qint=0.0002)

    central = {'sig': SIGMA, 're': RE_CIRC, 'n': N_SERSIC,
               'logm': math.log10(MSTAR), 'q': Q_PROJ}
    errors = {'sig': SIGMA_ERR, 're': RE_CIRC_ERR, 'n': N_SERSIC_ERR,
              'logm': LOGM_ERR, 'q': Q_PROJ_ERR}
    def n_from_dict(d):
        return edge(d['sig'], d['re'], d['n'], d['logm'], d['q'], nr=1800, nfield=100, nquad=120)
    dn = {}
    for key in central:
        h = 0.1 * errors[key]
        plus = dict(central); plus[key] += h
        minus = dict(central); minus[key] -= h
        dn[key] = (n_from_dict(plus) - n_from_dict(minus)) / (2.0 * h)
    dxi = {'sig': 2.0 * xi / SIGMA, 're': -xi / RE_CIRC,
           'n': 0.0, 'logm': 0.0, 'q': 0.0}
    var_xi = sum((dxi[k] * errors[k]) ** 2 for k in central)
    var_n_obs = sum((dn[k] * errors[k]) ** 2 for k in ['sig', 're', 'n', 'q'])
    var_n_all = sum((dn[k] * errors[k]) ** 2 for k in central)
    cov_xi_n = sum(dxi[k] * dn[k] * errors[k] ** 2 for k in central)
    rho_xi_n_all = cov_xi_n / math.sqrt(var_xi * var_n_all)

    # Fixed-state phase sweep. The local structural quantities are deliberately held fixed.
    phase_rows = []
    for z in [0.0, 0.5, 1.0, 1.8, 2.0, 3.0, 4.0]:
        aa = 1.0 / (1.0 + z)
        nnpi = math.log(aa)
        ee = E_pi(z)
        aa_pi = A_PI0 * ee
        rc_native = (48.0 * PI * C ** 2 / aa_pi) / KPC_M / 1e6
        xx = astar / aa_pi
        sxx = sig_astar / aa_pi
        sl = (PI / 2.0) * (TPI * aa ** (-PI)) / (BPI + TPI * aa ** (-PI))
        phase_rows.append((z, aa, nnpi, ee, aa_pi, rc_native, xx, sxx, sl))

    # Pure phase relocation cannot alter the local solve because N_pi is not an argument
    # of the bound-system field equation once the source state and a_star are fixed.
    # The same retained high-resolution local solution therefore applies at every
    # phase label in the fixed-state coordinate sweep.
    phase_mode_values = [obln for _ in phase_rows]
    phase_mode_spread = max(phase_mode_values) - min(phase_mode_values)

    print('NMBS-C7447 CPTG local-structural-invariance evidence r01')
    print(f'a_obs={a:.12f}')
    print(f'N_pi_obs={npi:.12f}')
    print(f'E_pi_obs={epi:.12f}')
    print(f'a_pi0={A_PI0:.15e} m s^-2')
    print(f'a_pi_obs={api:.15e} m s^-2')
    print(f't_pi_obs={tpi:.9f} Gyr')
    print(f't_pi0={tpi0:.9f} Gyr')
    print(f'a_sigma=a_star_est={astar:.15e} +/- {sig_astar:.15e} m s^-2')
    print(f'R_c_local={rc_local_gpc:.9f} +/- {sig_rc_local:.9f} Gpc linearized')
    print(f'R_C_native_obs={rc_native_gpc:.9f} Gpc')
    print(f'Xi_star_pi_obs={xi:.12f} +/- {sig_xi:.12f}')
    print(f'central_fractional_separation={(astar-api)/api:.12f}')
    print(f'fixed_state_dlnXi_dNpi_obs={phase_slope:.12f}')
    print(f'Xi_star_pi_at_a1={xi_present:.12f} +/- {sig_xi_present:.12f}')
    print(f'Xi_corner_low={astar_from(SIGMA-SIGMA_ERR, RE_CIRC+RE_CIRC_ERR)/api:.12f}')
    print(f'Xi_corner_high={astar_from(SIGMA+SIGMA_ERR, RE_CIRC-RE_CIRC_ERR)/api:.12f}')

    print('distance-coordinate sensitivity')
    for label, da, sd, re, ms, ast, sast, xx, sxx in distance_rows:
        print(f'{label}: D_A={da:.9f} Mpc s_D={sd:.12f} R_e={re:.12f} kpc '
              f'Mstar={ms:.9e} Msun a_star={ast:.15e} +/- {sast:.15e} Xi={xx:.12f} +/- {sxx:.12f}')

    print('fixed-state native-phase sweep')
    for row in phase_rows:
        z, aa, nnpi, ee, aa_pi, rc_native, xx, sxx, sl = row
        print(f'z={z:.1f} a={aa:.12f} N_pi={nnpi:.12f} E_pi={ee:.12f} '
              f'a_pi={aa_pi:.15e} R_C_Gpc={rc_native:.9f} Xi={xx:.12f} +/- {sxx:.12f} '
              f'dlnXi_dNpi={sl:.12f} a_star_fixed={astar:.15e} R_c_fixed_Gpc={rc_local_gpc:.9f}')
    print(f'fixed_state_phase_mode_min={min(phase_mode_values):.12f}')
    print(f'fixed_state_phase_mode_max={max(phase_mode_values):.12f}')
    print(f'fixed_state_phase_mode_spread={phase_mode_spread:.12e}')

    print('Structural Mode')
    print(f'R_e_major={re_major:.12f} kpc')
    print(f'spherical_circularized: R95={sph95:.9f} lambda={sphlam:.9f} N={sphn:.9f}')
    print(f'spherical_same_major: R95={maj95:.9f} lambda={majlam:.9f} N={majn:.9f}')
    print(f'oblate_edge_on_q={Q_PROJ:.2f}: R95={obl95:.9f} lambda={obllam:.9f} N={obln:.9f}')
    obl_status = 'PASS' if obl_diag['monotonic_decreasing'] else 'FAIL'
    print(f"oblate_edge_on_q={Q_PROJ:.2f}_Cg_monotonic={obl_status} max_delta_Cg={obl_diag['max_delta_Cg']:.12e}")
    print(f"oblate_edge_on_q={Q_PROJ:.2f}_direct_abs: lambda={obl_diag['lambda_abs']:.9f} N={obl_diag['mode_abs']:.9f} delta_N={obl_diag['mode_abs']-obln:.12e}")
    print(f'oblate_q0.005: R95={thin00595:.9f} lambda={thin005lam:.9f} N={thin005n:.9f}')
    print(f'oblate_q0.0002_near_asymptote: R95={thin000295:.9f} lambda={thin0002lam:.9f} N={thin0002n:.9f}')
    thin_status = 'PASS' if thin_diag['monotonic_decreasing'] else 'FAIL'
    print(f"oblate_q0.0002_Cg_monotonic={thin_status} max_delta_Cg={thin_diag['max_delta_Cg']:.12e}")
    print(f"oblate_q0.0002_direct_abs: lambda={thin_diag['lambda_abs']:.9f} N={thin_diag['mode_abs']:.9f} delta_N={thin_diag['mode_abs']-thin0002n:.12e}")
    one_status = 'PASS' if all(sens_monotonic.values()) else 'FAIL'
    edge_status = 'PASS' if all(edge_corner_monotonic) else 'FAIL'
    thin_corner_status = 'PASS' if all(thin_corner_monotonic) else 'FAIL'
    print(f'one_at_a_time_Cg_monotonic={sum(sens_monotonic.values())}/{len(sens_monotonic)} {one_status}')
    print(f'edge_corner_Cg_monotonic={sum(edge_corner_monotonic)}/{len(edge_corner_monotonic)} {edge_status}')
    print(f'near_thin_corner_Cg_monotonic={sum(thin_corner_monotonic)}/{len(thin_corner_monotonic)} {thin_corner_status}')
    for frac_, rr, ll, nn in reg_rows:
        print(f'oblate_edge_on_R{int(round(frac_*100))}: R={rr:.9f} lambda={ll:.9f} N={nn:.9f}')
    for key, val in sens.items():
        print(f'N_{key}={val:.9f}')
    print(f'N_edge_compound_corner_low={edge_min_ref:.9f} inputs={edge_min[1]}')
    print(f'N_edge_compound_corner_high={edge_max_ref:.9f} inputs={edge_max[1]}')
    print(f'N_near_thin_compound_corner_low={thin_min_ref:.9f} inputs={thin_min[1]}')
    print(f'N_near_thin_compound_corner_high={thin_max_ref:.9f} inputs={thin_max[1]}')
    print(f'N_linearized_sigma_obs_only={math.sqrt(var_n_obs):.9f}')
    print(f'N_linearized_sigma_including_0.2dex_mass={math.sqrt(var_n_all):.9f}')
    print(f'cov_Xi_N_shared={cov_xi_n:.12e}')
    print(f'rho_Xi_N_linearized_including_mass={rho_xi_n_all:.9f}')


if __name__ == '__main__':
    main()
