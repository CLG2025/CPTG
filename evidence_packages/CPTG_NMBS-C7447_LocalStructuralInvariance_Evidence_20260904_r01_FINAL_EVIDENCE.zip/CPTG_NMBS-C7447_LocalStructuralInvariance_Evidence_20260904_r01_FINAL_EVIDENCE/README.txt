CPTG NMBS-C7447 LOCAL STRUCTURAL INVARIANCE EVIDENCE
Evidence package: 2026-09-04 r01 FINAL_EVIDENCE

PURPOSE
-------
Reproduce the numerical calculations used in the manuscript
"NMBS-C7447 at z=1.80 in CPTG: Native-Phase Placement, Local Structural Invariance, and Structural Mode N."

The package treats the observed bound-system structural state as fixed during a pure native-phase coordinate sweep. Redshift selects the CPTG native phase; the local structural acceleration is supplied independently by the declared pressure-supported one-radius estimator a_sigma = sigma_star^2 / R_e.

SCOPE
-----
The script reproduces and audits:
- native phase a, N_pi, E_pi, a_pi, R_C, and native clock coordinates;
- local a_sigma -> a_star estimator and quoted-error propagation;
- local curvature radius R_c;
- descriptive cross-scale coordinate Xi_star_pi = a_star/a_pi = R_C/R_c;
- exact fixed-state phase response d ln Xi_star_pi / d N_pi;
- fixed-state native-phase sweep from z=0 to z=4;
- source-distance sensitivity across source, acoustic, midpoint, and luminosity coordinates;
- Sersic R95 registration;
- spherical and oblate stellar-source reconstruction;
- nonlinear CPTG radial field solution;
- Structural Mode N and CSMI-relevant numerical values;
- R90/R95/R99 outer-registration sensitivity;
- one-at-a-time source sensitivities;
- signed source/geometry corner scans;
- shared-input Xi_star_pi-N covariance diagnostic;
- monotonic-C_g condition for endpoint Structural Mode evaluation;
- direct |dC_g/dr| cross-check of the endpoint evaluation.

FIXED-STATE PHASE SWEEP
-----------------------
The phase sweep is a comparison-coordinate experiment, not a physical evolution model for NMBS-C7447. The baryonic source state and a_star are held fixed. Because N_pi is not an argument of the local bound-system field equation once those quantities are fixed, the retained local field and Structural Mode are identical at every phase label in the sweep. Native cosmological quantities continue to vary with E_pi(a).

RUN
---
python CPTG_NMBS-C7447_LocalStructuralInvariance_Evidence_20260904_r01.py > rerun.txt

A clean reproduction must match the authoritative .txt output byte-for-byte.
