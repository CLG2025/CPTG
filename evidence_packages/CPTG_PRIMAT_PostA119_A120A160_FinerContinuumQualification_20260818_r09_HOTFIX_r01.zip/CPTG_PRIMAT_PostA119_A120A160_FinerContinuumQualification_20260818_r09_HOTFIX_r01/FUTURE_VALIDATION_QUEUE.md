# Required Future Validation Queue

Source-tail robustness remains mandatory and is not satisfied by r09.

After the structural frontier is known and numerical validation has been extended toward it:

1. truncate the 14-edge native boundary source at frozen relative thresholds over several decades;
2. ablate each of the 14 boundary edges independently;
3. monitor A=24, 28, 40, 56, 80, 100, 119, 120, 140, 160, plus frontier-selected masses;
4. distinguish structural survival from amplitude sensitivity;
5. use no artificial seed, floor, or replacement source.
