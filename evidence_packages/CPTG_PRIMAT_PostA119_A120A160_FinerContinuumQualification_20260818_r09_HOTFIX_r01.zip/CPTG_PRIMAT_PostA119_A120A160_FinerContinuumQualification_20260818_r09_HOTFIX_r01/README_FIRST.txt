# CPTG PRIMAT A=120–160 Finer Continuum Qualification — r09 HOTFIX r01

r07 remains NOT_QUALIFIED at its frozen 256-step ceiling.

This hotfix preserves `CONFIG/FROZEN_R09_PREREGISTRATION.json` byte-for-byte. It repairs only an r09 output-writer/indexing defect and stale evidence labels; no scientific gate, graph rule, anchor, or refinement level is changed.

r09 does not relax any acceptance threshold. It keeps the same graph, all 41 A=120…160
mass sectors, and all six PRIMAT anchors, but runs a fresh finer ladder:

```text
128 → 256 → 512
```

If all unchanged gates pass, 512 is qualified for A=120–160 production.

Frozen native trajectory:
`97fd7b4f4f4e7466be9e45be264e62faade5b55e80d415201ed4390405080f9a`

## Windows

```cmd
cd /d D:\Downloads\CPTG_PRIMAT_PostA119_A120A160_FinerContinuumQualification_20260818_r09_HOTFIX_r01
RUN_STATIC_VERIFY_WINDOWS.cmd
RUN_ADOPT_R06_AUTHORITY_WINDOWS.cmd
RUN_TRANSPORT_SELFTEST_WINDOWS.cmd
RUN_A120_A160_FINER_WINDOWS.cmd
```

Required final result:

```text
R09_A120_A160_FINER_CONTINUUM_QUALIFICATION PASS
```

or fail-closed `NOT_QUALIFIED`.

Source-tail truncation and 14-edge ablation remain explicitly queued in
`FUTURE_VALIDATION_QUEUE.md`.
