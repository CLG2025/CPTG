@echo off
setlocal
cd /d "%~dp0"
set "NUMBA_CACHE_DIR=D:\Downloads\CPTG_PRIMAT_POSTA119_NUMBA_CACHE_r09"
set "PYTHONDONTWRITEBYTECODE=1"
"D:\Downloads\CPTG_PRIMAT_A1A119_TRANSPORT_ENV_r02\Scripts\python.exe" -u SOURCE\transport_selftest.py
exit /b %ERRORLEVEL%
