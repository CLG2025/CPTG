from __future__ import annotations
import json,math,importlib.metadata,csv
from collections import defaultdict,deque
import numpy as np
import pynucastro as pyna
from common import *
from positive_transport_core import solve_backward_euler,solve_positive_exponential_inflow

LEVELS=[128,256,512]
REGION=list(range(120,161))
LIGHT_TUPLES=set(LIGHT)

def nt(n): return int(n.A),int(n.Z)

def rates():
    rl=pyna.ReacLibLibrary();caps=[];betas=[]
    for r in rl.get_rates():
        rea=[nt(x) for x in r.reactants]; pro=[nt(x) for x in r.products]
        if not r.weak and len(rea)==2 and len(pro)==1:
            ls=[x for x in rea if x in LIGHT_TUPLES]
            if len(ls)==1:
                l=ls[0]; h=rea[1] if rea[0]==l else rea[0]; d=pro[0]
                if h[0]>=6 and d==(h[0]+l[0],h[1]+l[1]): caps.append((h,l,d,r))
        if r.weak and getattr(r,"weak_type",None)=="beta_neg" and len(rea)==1 and len(pro)==1:
            if rea[0][0]>=6 and pro[0][0]==rea[0][0] and pro[0][1]==rea[0][1]+1:
                betas.append((rea[0],pro[0],r))
    caps.sort(key=lambda x:(x[0],x[1],x[2],str(x[3])))
    betas.sort(key=lambda x:(x[0],x[1],str(x[2])))
    return caps,betas

def graph(native,maxA,caps,betas):
    src=[(h,l,d,r) for h,l,d,r in caps if h in native and d not in native and d[0]>=24 and d[0]<=maxA]
    seeds={d for h,l,d,r in src}
    cb=defaultdict(list); bb=defaultdict(list)
    for h,l,d,r in caps:
        if h[0]>=24: cb[h].append((d,l,r))
    for s,d,r in betas:
        if s[0]>=24: bb[s].append((d,r))
    seen=set(seeds); q=deque(sorted(seeds))
    while q:
        s=q.popleft()
        for d,l,r in cb.get(s,[]):
            if d[0]<=maxA and d not in seen:seen.add(d);q.append(d)
        for d,r in bb.get(s,[]):
            if d[0]<=maxA and d not in seen:seen.add(d);q.append(d)
    species=sorted(seen,key=lambda x:(x[0],x[1])); idx={s:i for i,s in enumerate(species)}
    inc=[];out=defaultdict(list)
    for s in species:
        for d,l,r in cb.get(s,[]):
            out[s].append(("capture",d,l,r))
            if d in idx:
                if idx[d]<=idx[s]:raise RuntimeError("non-forward capture")
                inc.append((idx[s],idx[d],"capture",l,r))
        for d,r in bb.get(s,[]):
            out[s].append(("beta",d,None,r))
            if d in idx:
                if idx[d]<=idx[s]:raise RuntimeError("non-forward beta")
                inc.append((idx[s],idx[d],"beta",None,r))
    inc.sort(key=lambda e:(e[1],e[0],str(e[4])))
    return src,species,idx,inc,out

def load_traj(eta):
    z=np.load(OUTPUT/f"NATIVE_TRAJECTORIES/PRIMAT_NATIVE_TRAJECTORY_ETA{eta_tag(eta)}.npz")
    names=[str(x) for x in z["species"]]; az=[parse_primat_name(n) for n in names]
    return np.asarray(z["t_s"],float),np.asarray(z["T_K"],float),np.asarray(z["rho_b_g_cm3"],float),az,np.asarray(z["Y"],float)

def precompute(eta,maxA,caps,betas):
    t,T,rho,naz,Y=load_traj(eta);native=set(naz);ix={a:i for i,a in enumerate(naz)}
    src,species,idx,inc,out=graph(native,maxA,caps,betas)
    ns=len(species);ntm=len(t);ne=len(inc)
    S=np.zeros((ns,ntm));L=np.zeros((ns,ntm));C=np.zeros((ne,ntm))
    for h,l,d,r in src:
        rv=np.array([float(r.eval(float(Tv))) for Tv in T]); c=np.maximum(rv,0.0)*rho*Y[ix[l],:]
        S[idx[d],:]+=c*Y[ix[h],:]
    for e,(si,di,kind,l,r) in enumerate(inc):
        rv=np.array([float(r.eval(float(Tv))) for Tv in T])
        C[e,:]=np.maximum(rv,0.0)*rho*Y[ix[l],:] if kind=="capture" else np.maximum(rv,0.0)
    for s in species:
        si=idx[s]
        for kind,d,l,r in out.get(s,[]):
            rv=np.array([float(r.eval(float(Tv))) for Tv in T])
            L[si,:]+=np.maximum(rv,0.0)*rho*Y[ix[l],:] if kind=="capture" else np.maximum(rv,0.0)
    counts=np.zeros(ns,dtype=np.int64)
    for si,di,kind,l,r in inc:counts[di]+=1
    starts=np.zeros(ns+1,dtype=np.int64);starts[1:]=np.cumsum(counts)
    return t,S,L,np.array([x[0] for x in inc],dtype=np.int64),starts,C,species,len(src)

def masses(species,y):
    d={A:0.0 for A in REGION}
    for s,v in zip(species,y):
        if s[0] in d:d[s[0]]+=float(v)
    return d

def maxrel(a,b):
    by={A:symmetric_rel(a[A],b[A]) for A in REGION}
    return max(by.values()),max(by,key=by.get),by

def rich(seq):
    out={};orders={};bad=[]
    for A in REGION:
        x0,x1,x2=(float(seq[k][A]) for k in LEVELS)
        d0=abs(x0-x1);d1=abs(x1-x2)
        if not all(math.isfinite(x) and x>0 for x in (x0,x1,x2)) or d0<=0 or d1<=0:
            bad.append(A);continue
        p=math.log(d0/d1,2); den=2.0**p-1.0
        if not math.isfinite(p) or abs(den)<1e-14:bad.append(A);continue
        lim=x2+(x2-x1)/den
        if not math.isfinite(lim) or lim<=0:bad.append(A);continue
        out[A]=lim;orders[A]=p
    return out,orders,bad

def dictrel(a,b):
    by={A:symmetric_rel(a[A],b[A]) for A in REGION}
    return max(by.values()),max(by,key=by.get),by

def main():
    if importlib.metadata.version("pynucastro")!="2.11.0":raise RuntimeError("pynucastro 2.11.0 required")
    if sha_file(OUTPUT/"NATIVE_TRAJECTORY_FREEZE.json")!="97fd7b4f4f4e7466be9e45be264e62faade5b55e80d415201ed4390405080f9a":
        raise RuntimeError("freeze mismatch")
    if load_json(EVIDENCE/"AUTHORITY_ADOPTION.json").get("pass") is not True:raise RuntimeError("adoption required")
    g=load_json(CONFIG/"FROZEN_R09_PREREGISTRATION.json")["hard_gates"]
    caps,betas=rates()
    anchors=[]
    GP01=GP12=GB01=GB12=GC=GPR=0.0
    for eta in ETA:
        print("R09_A120A160_START",eta,flush=True)
        t,S,L,ii,st,C,species,nsource=precompute(eta,200,caps,betas)
        structural={A for A,Z in species if A in REGION}; missing=sorted(set(REGION)-structural)
        integ=float(np.trapezoid(np.sum(S,axis=0),t))
        if not math.isfinite(integ) or integ<=0:raise RuntimeError("source integral")
        Sn=S/integ
        P={};B={}
        for N in LEVELS:
            y,mn=solve_positive_exponential_inflow(t,Sn,L,ii,st,C,N)
            if mn<0 or np.min(y)<0 or not np.all(np.isfinite(y)):raise RuntimeError("positive invalid")
            P[N]=masses(species,y)
            y,mn=solve_backward_euler(t,Sn,L,ii,st,C,N)
            if mn<0 or np.min(y)<0 or not np.all(np.isfinite(y)):raise RuntimeError("BE invalid")
            B[N]=masses(species,y)
        nonpos=sorted(A for A in REGION if P[512][A]<=0 or not math.isfinite(P[512][A]))
        p01,p01A,_=maxrel(P[128],P[256]);p12,p12A,_=maxrel(P[256],P[512])
        b01,b01A,_=maxrel(B[128],B[256]);b12,b12A,_=maxrel(B[256],B[512])
        po=math.log(p01/p12,2) if p01>0 and p12>0 else None
        bo=math.log(b01/b12,2) if b01>0 and b12>0 else None
        PR,PRo,PRbad=rich(P);BR,BRo,BRbad=rich(B)
        if PRbad or BRbad:raise RuntimeError(f"Richardson invalid P={PRbad} B={BRbad}")
        cross,crossA,_=dictrel(PR,BR); pres,presA,_=dictrel(P[512],PR)
        ya,_=solve_positive_exponential_inflow(t,S,L,ii,st,C,512)
        absrec,absA,_=dictrel(masses(species,ya),{A:P[512][A]*integ for A in REGION})
        z,_=solve_positive_exponential_inflow(t,S*0,L,ii,st,C,64)
        h,_=solve_positive_exponential_inflow(t,S*0.5,L,ii,st,C,64)
        d,_=solve_positive_exponential_inflow(t,S*2,L,ii,st,C,64)
        q,_=solve_positive_exponential_inflow(t,S,L,ii,st,C,64)
        zero=bool(np.array_equal(z,np.zeros_like(z)))
        lin=max(vector_max_rel(h*2,q),vector_max_rel(d/2,q))
        ok=(not missing and not nonpos and p12<=g["primary_256_512_fullregion_max_relative"] and
            po is not None and g["primary_effective_order_min"]<=po<=g["primary_effective_order_max"] and
            pres<=g["primary_512_to_Richardson_fullregion_max_relative"] and
            b12<=g["BE_256_512_fullregion_max_relative"] and
            bo is not None and g["BE_effective_order_min"]<=bo<=g["BE_effective_order_max"] and
            cross<=g["continuum_cross_scheme_fullregion_max_relative"] and zero and
            lin<=g["source_linearity_max_relative"] and absrec<=g["absolute_normalized_reconstruction_max_relative"])
        rec={"eta10":eta,"pass":ok,"source_edges":nsource,"species_Amax200":len(species),
             "structural_missing":missing,"nonpositive_A120_A160":nonpos,
             "P128_256_max":p01,"P128_256_worst_A":p01A,"P256_512_max":p12,"P256_512_worst_A":p12A,
             "P_effective_order":po,"BE128_256_max":b01,"BE128_256_worst_A":b01A,
             "BE256_512_max":b12,"BE256_512_worst_A":b12A,"BE_effective_order":bo,
             "continuum_cross_max":cross,"continuum_cross_worst_A":crossA,
             "P512_Richardson_max":pres,"P512_Richardson_worst_A":presA,
             "zero_source":zero,"linearity_max":lin,"absolute_reconstruction_max":absrec}
        anchors.append(rec)
        GP01=max(GP01,p01);GP12=max(GP12,p12);GB01=max(GB01,b01);GB12=max(GB12,b12);GC=max(GC,cross);GPR=max(GPR,pres)
        ddir=RESULTS/f"ETA{eta_tag(eta)}";ddir.mkdir(parents=True,exist_ok=True)
        with (ddir/"A120_A160_FINER_ENDPOINTS.csv").open("w",newline="",encoding="utf-8") as f:
            w=csv.writer(f);w.writerow(["A","P128","P256","P512","BE128","BE256","BE512","P_Richardson","BE_Richardson"])
            for A in REGION:w.writerow([A,P[128][A],P[256][A],P[512][A],B[128][A],B[256][A],B[512][A],PR[A],BR[A]])
        print("R09_A120A160_ANCHOR",eta,"PASS" if ok else "FAIL",
              "P256_512",p12,"P_ORDER",po,"BE256_512",b12,"BE_ORDER",bo,
              "CONTINUUM_CROSS",cross,"P512_RICH",pres,"WORST_A",crossA,flush=True)
    overall=all(a["pass"] for a in anchors)
    out={"schema":"cptg-r09-a120a160-finer-continuum-result-v1","decision":"PASS" if overall else "NOT_QUALIFIED",
         "anchors":anchors,"global_P128_256_max":GP01,"global_P256_512_max":GP12,
         "global_BE128_256_max":GB01,"global_BE256_512_max":GB12,
         "global_continuum_cross_max":GC,"global_P512_Richardson_max":GPR,
         "all_41_mass_sectors_all_six":overall}
    atomic_json(EVIDENCE/"R09_A120_A160_FINER_CONTINUUM_QUALIFICATION.json",out)
    print("R09_GLOBAL_P256_512",GP12)
    print("R09_GLOBAL_BE256_512",GB12)
    print("R09_GLOBAL_CONTINUUM_CROSS",GC)
    print("R09_GLOBAL_P512_RICHARDSON",GPR)
    print("R09_A120_A160_FINER_CONTINUUM_QUALIFICATION","PASS" if overall else "NOT_QUALIFIED")
    if not overall:raise SystemExit(5)
if __name__=="__main__":main()
