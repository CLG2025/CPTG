from __future__ import annotations
import json,hashlib,py_compile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def ck(n,c):
    if not c:raise RuntimeError(n+" FAIL")
    print(n,"PASS")
def main():
    p=json.loads((ROOT/"CONFIG/FROZEN_R09_PREREGISTRATION.json").read_text())
    ck("R09_SCOPE",p["graph"]["region_under_test"]==[120,160])
    ck("R07_DECISION_PRESERVED",p["prior_status"]["prior_decision_not_reclassified"] is True)
    ck("NO_R07_ENDPOINT_IMPORT",p["authority"]["no_r07_endpoint_import"] is True)
    ck("UNCHANGED_STRICT_PRIMARY_GATE",p["hard_gates"]["primary_256_512_fullregion_max_relative"]==0.005)
    ck("UNCHANGED_STRICT_RESIDUAL_GATE",p["hard_gates"]["primary_512_to_Richardson_fullregion_max_relative"]==0.0025)
    ck("UNCHANGED_CROSS_GATE",p["hard_gates"]["continuum_cross_scheme_fullregion_max_relative"]==0.005)
    ck("FINER_LEVELS",p["numerics"]["fresh_refinement_levels"]==[128,256,512])
    ck("CANDIDATE_PRODUCTION_512",p["numerics"]["candidate_production_refinement"]==512)
    ck("FRESH_REACLIB",p["graph"]["fresh_reaclib_each_run"] is True)
    ck("NO_SEED_FLOOR",p["graph"]["artificial_seed_or_floor"] is False)
    ck("SOURCE_TAIL_QUEUED","tail truncation" in p["future_required_diagnostic"].lower())
    s=(ROOT/"SOURCE/run_a120_a160_finer.py").read_text()
    ck("ALL_41_SECTORS","REGION=list(range(120,161))" in s)
    ck("GRAPH_A200","precompute(eta,200" in s)
    ck("TWO_SCHEMES","solve_positive_exponential_inflow" in s and "solve_backward_euler" in s)
    ck("FRESH_512","P[512]" in s and "B[512]" in s)
    ck("CSV_LADDER_128_256_512","P[128][A],P[256][A],P[512][A],B[128][A],B[256][A],B[512][A]" in s)
    ck("NO_STALE_64_CONTINUUM_TABLE","P[64][A]" not in s and "B[64][A]" not in s)
    ck("EVIDENCE_LABELS_MATCH_LADDER",all(x in s for x in ["P128_256_max","BE128_256_max","P512_Richardson_max","global_P128_256_max","global_BE128_256_max","global_P512_Richardson_max"]))
    ck("FINAL_TOKEN_MATCHES_README","R09_A120_A160_FINER_CONTINUUM_QUALIFICATION" in s)
    pys=sorted((ROOT/"SOURCE").glob("*.py"))
    for q in pys:py_compile.compile(str(q),doraise=True)
    print("PYTHON_COMPILE",f"{len(pys)}/{len(pys)}","PASS")
    bad=[];n=0
    for line in (ROOT/"MANIFEST.sha256").read_text().splitlines():
        if line.strip():
            h,rel=line.split("  ",1);n+=1;q=ROOT/rel
            if not q.is_file() or sha(q)!=h:bad.append(rel)
    ck(f"PACKAGE_MANIFEST {n-len(bad)}/{n}",not bad)
    print("R09_A120_A160_FINER_STATIC_VERIFY PASS")
if __name__=="__main__":main()
