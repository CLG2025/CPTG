# r09 HOTFIX r01 provenance

Original package SHA-256: `a31457c83eee685f5a0b5a0ba3e446f40e64036201b986415261061604f76bfe`

Frozen preregistration SHA-256 (unchanged): `f3b9c52f714b5195cc1ccc68e87f7b326452b5289cb95c72b5b35541eb602b40`

## Defect repaired

The r09 solver correctly constructed only the preregistered continuum levels `128`, `256`, and `512` in dictionaries `P` and `B`, but the endpoint CSV writer incorrectly referenced nonexistent `P[64]` and `B[64]` entries. This caused `KeyError: 64` after the first anchor calculation.

## Code-only repairs

- endpoint CSV columns now map exactly to P128/P256/P512 and BE128/BE256/BE512;
- stale `64_128` evidence labels are corrected to `128_256`;
- stale `P256_Richardson` labels are corrected to `P512_Richardson`;
- final evidence filename and terminal decision token now identify the finer-continuum qualification explicitly;
- static verification now fails if the stale continuum-table indexing or labels reappear;
- the inherited transport self-test terminal token is relabeled from R04 to R09 for unambiguous package provenance.

The 64-substep zero/half/double/full source-control calculations are intentionally retained. They are implementation-linearity controls and are not part of the preregistered 128/256/512 continuum ladder.

No scientific acceptance threshold, PRIMAT native trajectory, ReacLib graph rule, eta10 anchor, region under test, or numerical method was changed.
