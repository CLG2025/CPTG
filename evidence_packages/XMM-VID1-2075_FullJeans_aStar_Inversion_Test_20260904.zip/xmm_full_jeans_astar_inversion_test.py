#!/usr/bin/env python3
"""XMM-VID1-2075 CPTG full-Jeans a_star inversion test.

Purpose: test the existing CPTG equations without defining a new relation.
The observed stellar source is held fixed. The already-existing object parameter
`a_star` is varied inside the locked radial CPTG + spherical Jeans calculation
until the projected aperture dispersion matches a specified observed value.

This is not a fit to the unpublished/missing machine-readable Voronoi-bin table.
The source-paper central ~500 km/s resolved dispersion is used only as a secondary
resolved-gradient diagnostic.
"""
import math
import hashlib
from pathlib import Path
import numpy as np
from numpy.polynomial.legendre import leggauss
from scipy.integrate import cumulative_trapezoid
from scipy.interpolate import PchipInterpolator
from scipy.optimize import brentq
from scipy.special import gammaincinv

G = 6.67430e-11
C = 299792458.0
MSUN = 1.98847e30
KPC = 3.085677581491367e19
A_PI0 = math.pi**1.5 * 1e-10
B_PI = 1.0 - 1.0/math.pi
T_PI = 1.0/math.pi

# Locked/current XMM inputs after the manuscript's source-distance bookkeeping.
Z = 3.44927
MSTAR_C = 3.23454e11              # Msun
MSTAR_LO = 2.94054e11             # Msun (distance-converted lower source sensitivity)
MSTAR_HI = 3.33254e11             # Msun (distance-converted upper source sensitivity)
RE_SERSIC_C = 1.93056             # kpc
RE_SERSIC_ERR = 0.14850           # kpc
N_SERSIC_C = 3.97
N_SERSIC_ERR = 0.06
RE_AP = 1.98007                   # kpc, converted IFU circularized aperture
SIGMA_AP_OBS = 387.0              # km/s
SIGMA_AP_ERR = 22.0               # km/s
ASTAR_ONE_RADIUS = 2.45127e-9     # m/s^2, manuscript one-radius estimator
LOCKED_SIGMA_BETA0 = 394.158421   # km/s
LOCKED_SIGMA_BETA022 = 401.341868 # km/s
R95 = 16.535323012                # kpc, registered outer structural radius

class XMMModel:
    def __init__(self, mstar_msun=MSTAR_C, re_sersic_kpc=RE_SERSIC_C,
                 n_sersic=N_SERSIC_C, nr=3500, ntheta_deproj=160):
        self.mstar = mstar_msun * MSUN
        self.re_s = re_sersic_kpc * KPC
        self.n = n_sersic
        self.re_ap = RE_AP * KPC
        self.bn = float(gammaincinv(2*self.n, 0.5))
        self.r = np.geomspace(self.re_s*1e-5, self.re_s*1e4, nr)
        x,w = leggauss(ntheta_deproj)
        th = (x+1)*math.pi/4
        wt = w*math.pi/4
        ct = np.cos(th)
        Rm = self.r[:,None]/ct[None,:]
        Sigma = np.exp(-self.bn*((Rm/self.re_s)**(1/self.n)-1))
        dSdR = Sigma*(-self.bn/self.n)*(Rm/self.re_s)**(1/self.n-1)/self.re_s
        rho_shape = -(1/math.pi)*np.sum(dSdR*(1/ct)[None,:]*wt[None,:],axis=1)
        m_shape = 4*math.pi*np.trapezoid(rho_shape*self.r*self.r,self.r)
        self.rho = rho_shape*(self.mstar/m_shape)
        mcum = 4*math.pi*np.concatenate([[0], cumulative_trapezoid(self.rho*self.r*self.r,self.r)])
        self.gstar = G*mcum/self.r**2

    def field(self, astar):
        r=self.r; gsarr=self.gstar
        Rc=48*math.pi*C*C/astar
        ggeom=0.5*astar*(r/Rc)**(7/5)/(1+(r/Rc)**(12/5))
        out=np.empty_like(r)
        p=123/50; q=11/50
        for i,(gs,gg) in enumerate(zip(gsarr,ggeom)):
            if gs <= 0:
                out[i]=gg
                continue
            def f(g):
                return g-gs-(math.sqrt(astar*gs)+gg)/(1+(g/astar)**p)**q
            lo=gs
            hi=gs+math.sqrt(astar*gs)+gg+astar
            out[i]=brentq(f,lo,hi,xtol=1e-20,rtol=1e-12)
        return out

    def _radial_sigma2(self, gfield, beta):
        Fpow=self.r**(2*beta)
        integ=self.rho*Fpow*gfield
        jrev=np.concatenate([[0], cumulative_trapezoid(integ[::-1],self.r[::-1])])
        J=(-jrev)[::-1]
        return J/(self.rho*Fpow)

    def projected(self, gfield, beta, rmax_kpc, nrproj=650, ntheta=180):
        sr2=self._radial_sigma2(gfield,beta)
        Rmax=rmax_kpc*KPC
        Rg=np.geomspace(Rmax*1e-5,Rmax,nrproj)
        x,w=leggauss(ntheta)
        th=(x+1)*math.pi/4
        wt=w*math.pi/4
        ct=np.cos(th)
        lr=np.log(self.r)
        lrho=np.log(np.maximum(self.rho,1e-300))
        lrhos2=np.log(np.maximum(self.rho*sr2,1e-300))
        Sig=np.empty_like(Rg); Q=np.empty_like(Rg)
        for j,R in enumerate(Rg):
            lrr=np.log(R/ct)
            rv=np.exp(np.interp(lrr,lr,lrho,left=lrho[0],right=-745))
            rsv=np.exp(np.interp(lrr,lr,lrhos2,left=lrhos2[0],right=-745))
            fac=R/ct**2
            Sig[j]=2*np.sum(rv*fac*wt)
            Q[j]=2*np.sum((1-beta*ct**2)*rsv*fac*wt)
        siglos=np.sqrt(Q/Sig)/1000
        sigap=math.sqrt(np.trapezoid(Q*2*math.pi*Rg,Rg)/np.trapezoid(Sig*2*math.pi*Rg,Rg))/1000
        return sigap,Rg/KPC,siglos

    def sigma_ap(self, astar, beta, nrproj=650, ntheta=180):
        gf=self.field(astar)
        sig,_,_=self.projected(gf,beta,RE_AP,nrproj,nthta:=ntheta)
        return sig,gf

    def invert_astar(self,target_kms,beta,nrproj=650,ntheta=180):
        def f(loga):
            a=math.exp(loga)
            sig,_=self.sigma_ap(a,beta,nrproj,ntheta)
            return sig-target_kms
        root=brentq(f,math.log(1e-11),math.log(1e-8),xtol=1e-11)
        a=math.exp(root)
        sig,gf=self.sigma_ap(a,beta,nrproj,ntheta)
        return a,sig,gf

    def structural_N(self,gfield,npts=20000):
        r95=R95*KPC; kappa=KPC
        p=PchipInterpolator(np.log(self.r),np.log(gfield))
        rr=np.linspace(r95/5,r95,npts)
        xx=np.log(rr)
        gg=np.exp(p(xx))
        dg=gg*p.derivative()(xx)/rr
        Cg=gg**2+(kappa*dg)**2
        dC=np.gradient(Cg,rr,edge_order=2)
        w=np.abs(dC)
        lam=np.trapezoid(rr*w,rr)/np.trapezoid(w,rr)
        return r95/lam,lam/KPC


def native_values():
    a=1/(1+Z)
    Npi=math.log(a)
    E=math.sqrt(B_PI+T_PI*a**(-math.pi))
    api=A_PI0*E
    return a,Npi,E,api


def fmt(x):
    return f"{x:.12e}"


def main():
    print("XMM_FULL_JEANS_ASTAR_INVERSION_TEST")
    print("STATUS: measurement/inversion test only; no new CPTG relation is defined")
    print()
    model=XMMModel()

    # Reproduction gate at the locked manuscript a_star.
    print("[A] LOCKED RADIAL-JEANS REPRODUCTION")
    for beta,authority in [(0.0,LOCKED_SIGMA_BETA0),(0.22,LOCKED_SIGMA_BETA022)]:
        sig,gf=model.sigma_ap(ASTAR_ONE_RADIUS,beta,nrproj=850,ntheta=220)
        delta=sig-authority
        print(f"beta={beta:.2f} sigma_model={sig:.6f} km/s authority={authority:.6f} delta={delta:+.6f}")
        assert abs(delta)<0.05
    print("LOCKED_REPRODUCTION PASS")
    print()

    print("[B] FULL-JEANS INVERSION OF EXISTING a_star")
    central={}
    for beta in (0.0,0.22):
        ast,sig,gf=model.invert_astar(SIGMA_AP_OBS,beta,nrproj=850,ntheta=220)
        N,lam=model.structural_N(gf)
        central[beta]=(ast,gf)
        print(f"beta={beta:.2f} target={SIGMA_AP_OBS:.1f} astar_Jeans={fmt(ast)} sigma_return={sig:.9f} N_sph={N:.9f} lambda_kpc={lam:.9f} ratio_to_one_radius={ast/ASTAR_ONE_RADIUS:.9f}")
        assert abs(sig-SIGMA_AP_OBS)<1e-5
    print("FULL_JEANS_INVERSION PASS")
    print()

    print("[C] OBSERVED DISPERSION +/-1SIGMA RESPONSE")
    for beta in (0.0,0.22):
        vals=[]
        for target in (SIGMA_AP_OBS-SIGMA_AP_ERR,SIGMA_AP_OBS,SIGMA_AP_OBS+SIGMA_AP_ERR):
            ast,sig,_=model.invert_astar(target,beta,nrproj=500,ntheta=140)
            vals.append(ast)
            print(f"beta={beta:.2f} sigma_target={target:.1f} astar={fmt(ast)}")
        assert vals[0]<vals[1]<vals[2]
    print("SIGMA_SENSITIVITY PASS")
    print()

    print("[D] ONE-AT-A-TIME SOURCE SENSITIVITY AT sigma_ap=387 km/s")
    cases=[
        ("central",MSTAR_C,RE_SERSIC_C,N_SERSIC_C),
        ("Mstar_low",MSTAR_LO,RE_SERSIC_C,N_SERSIC_C),
        ("Mstar_high",MSTAR_HI,RE_SERSIC_C,N_SERSIC_C),
        ("ReS_low",MSTAR_C,RE_SERSIC_C-RE_SERSIC_ERR,N_SERSIC_C),
        ("ReS_high",MSTAR_C,RE_SERSIC_C+RE_SERSIC_ERR,N_SERSIC_C),
        ("n_low",MSTAR_C,RE_SERSIC_C,N_SERSIC_C-N_SERSIC_ERR),
        ("n_high",MSTAR_C,RE_SERSIC_C,N_SERSIC_C+N_SERSIC_ERR),
    ]
    for name,M,ReS,ns in cases:
        m=XMMModel(M,ReS,ns,nr=2800,ntheta_deproj=120)
        row=[]
        for beta in (0.0,0.22):
            ast,sig,_=m.invert_astar(SIGMA_AP_OBS,beta,nrproj=420,ntheta=120)
            row.append(ast)
        print(f"{name:11s} Mstar={M:.6e} ReS={ReS:.6f} n={ns:.4f} astar_beta0={fmt(row[0])} astar_beta022={fmt(row[1])}")
    print("SOURCE_SENSITIVITY PASS")
    print()

    print("[E] RESOLVED-CENTRAL GRADIENT DIAGNOSTIC")
    # One 0.1 x 0.1 arcsec NIRSpec spaxel is ~0.73 kpc square in the source paper.
    # Circular equal-area radius: 0.73/sqrt(pi) kpc. This is only a scale diagnostic,
    # not a reconstruction of the actual Voronoi/PSF response.
    req=0.73/math.sqrt(math.pi)
    print(f"equal_area_radius_for_0p73kpc_square={req:.9f} kpc")
    for beta in (0.0,0.22):
        ast,gf=central[beta]
        cap,RR,slos=model.projected(gf,beta,req,nrproj=700,ntheta=180)
        print(f"beta={beta:.2f} astar={fmt(ast)} central_equal_area_sigma_ap={cap:.6f} km/s sigma_los_at_Rmax={slos[-1]:.6f} km/s")
    # Exploratory constant-beta diagnostic: what beta would be needed for the same
    # spherical model to retain the 387-km/s global aperture and reach an approximate
    # 500-km/s equal-area central aperture? Not an accepted fit; exact bins/PSF absent.
    def central_resid(beta):
        ast,_,gf=model.invert_astar(SIGMA_AP_OBS,beta,nrproj=420,ntheta=120)
        cap,_,_=model.projected(gf,beta,req,nrproj=420,ntheta=120)
        return cap-500.0
    beta_req=brentq(central_resid,0.75,0.90,xtol=2e-4)
    ast_req,_,gf_req=model.invert_astar(SIGMA_AP_OBS,beta_req,nrproj=650,ntheta=180)
    cap_req,_,_=model.projected(gf_req,beta_req,req,nrproj=650,ntheta=180)
    print(f"exploratory_beta_for_global387_and_central500={beta_req:.6f} astar={fmt(ast_req)} central_equal_area_sigma_ap={cap_req:.6f}")
    print("CENTRAL_GRADIENT_DIAGNOSTIC COMPLETE (non-archive-grade: no machine-readable Voronoi table/PSF operator)")
    print()

    print("[F] NATIVE-PHASE DESCRIPTORS FOR THE MEASURED XMM EPOCH")
    a,Npi,E,api=native_values()
    print(f"a={a:.12f} N_pi={Npi:.12f} E_pi={E:.12f} a_pi={fmt(api)}")
    for beta in (0.0,0.22):
        ast,_=central[beta]
        print(f"beta={beta:.2f} eta_descriptor=astar/a_pi={ast/api:.12f}")
    print("NATIVE_DESCRIPTOR PASS")
    print()
    print("FINAL_STATUS PASS")

if __name__ == '__main__':
    main()
