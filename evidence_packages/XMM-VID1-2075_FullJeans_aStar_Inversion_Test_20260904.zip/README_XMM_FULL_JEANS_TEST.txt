XMM-VID1-2075 CPTG Full-Jeans a_star Inversion Test
Date: 2026-09-04

Purpose
-------
Run a measurement test using the existing CPTG radial field and spherical Jeans equations.
No new CPTG relation, branch, invariant, or preferred a_star/a_pi value is defined.

Test architecture
-----------------
1. Reproduce the locked XMM radial-Jeans aperture results at the manuscript's one-radius
   a_star = 2.45127e-9 m s^-2.
2. Hold the observed stellar source fixed and vary only the already-existing object parameter
   a_star until the full projected CPTG+Jeans aperture dispersion equals 387 km/s.
3. Repeat for beta_J = 0 and beta_J = 11/50.
4. Propagate the published +/-22 km/s aperture-dispersion bracket.
5. Run one-at-a-time source sensitivities in stellar mass, Sersic effective radius, and Sersic n.
6. Compare the global-aperture-matched solutions with the source paper's approximate central
   sigma ~ 500 km/s using a 0.73-kpc-square equal-area scale only as a diagnostic.

Authority inputs
----------------
Current locked CPTG manuscript values:
- z = 3.44927
- converted Mstar = 3.23454e11 Msun
- converted NIRCam Sersic Re = 1.93056 kpc
- n = 3.97
- converted IFU circularized aperture Re = 1.98007 kpc
- sigma_ap(<Re) = 387 +/- 22 km/s
- one-radius a_star = 2.45127e-9 m/s^2
- locked full-Jeans sigma values: 394.158421 km/s (beta=0), 401.341868 km/s (beta=0.22)

Public-source resolved constraints used only as secondary checks:
- central stellar dispersion approximately 500 km/s
- all resolved velocity offsets |V_star| < 100 km/s in the source analysis
- one 0.1 arcsec NIRSpec spaxel corresponds to about 730 pc per side

Important limitation
--------------------
The machine-readable Voronoi-bin table and an exact bin/PSF response operator are not present in
this evidence set. Therefore the central-gradient section is not an archive-grade bin-by-bin fit.
The full-aperture inversion is numerical and reproducible from the locked manuscript equations.

Files
-----
xmm_full_jeans_astar_inversion_test.py
xmm_full_jeans_astar_inversion_test.out
SHA256SUMS.txt
