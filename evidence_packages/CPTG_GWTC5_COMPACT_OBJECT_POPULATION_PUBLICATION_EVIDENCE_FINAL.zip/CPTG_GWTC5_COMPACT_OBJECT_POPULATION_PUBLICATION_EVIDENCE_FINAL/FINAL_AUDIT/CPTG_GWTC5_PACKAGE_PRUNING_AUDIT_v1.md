# CPTG GWTC-5 Package Pruning Audit v1

**Status: PASS**

Protected scientific/manuscript files checked: **160**. Changed: **0**.

## Removed redundant material

- `FIGURES_PDF_REFERENCE/` — 15 file(s), 758,982 bytes — obsolete PDF renderings; final TeX references PNG assets only.
- `FIGURES_PNG/` — 14 file(s), 1,865,004 bytes — exact duplicate mirror of the 14 PNG files already colocated with the final TeX in MANUSCRIPT/.
- `SOURCE_ARCHIVES/` — 1 file(s), 8,319,512 bytes — nested predecessor publication archive; all 129 files are present at top level, 119 byte-identical and 10 replaced by current control/manuscript files.
- `FINAL_AUDIT/FINAL_PUBLICATION_EVIDENCE_VALIDATION.log` — 1 file(s), 395 bytes — byte-identical duplicate of root PUBLICATION_VALIDATION.log.
- `SYNTHESIS/CPTG_GWTC5_ROTATION_SYNTHESIS_v1.tex` — 1 file(s), 12,583 bytes — section-development narrative/build artifact; final manuscript is authoritative and numerical synthesis CSVs are retained.
- `SYNTHESIS/CPTG_GWTC5_STRUCTURAL_MODE_SYNTHESIS_v1.tex` — 1 file(s), 11,664 bytes — section-development narrative/build artifact; final manuscript is authoritative and numerical synthesis CSVs are retained.
- `SYNTHESIS/CPTG_GWTC5_CORE_TIME_SYNTHESIS_v1_AUDIT.json` — 1 file(s), 3,221 bytes — section-development narrative/build artifact; final manuscript is authoritative and numerical synthesis CSVs are retained.
- `SYNTHESIS/SUPERSEDED_WORKING_OUTPUTS.md` — 1 file(s), 588 bytes — section-development narrative/build artifact; final manuscript is authoritative and numerical synthesis CSVs are retained.
- `SYNTHESIS/CPTG_GWTC5_ROTATION_SYNTHESIS_v1_AUDIT.json` — 1 file(s), 5,029 bytes — section-development narrative/build artifact; final manuscript is authoritative and numerical synthesis CSVs are retained.
- `SYNTHESIS/CPTG_GWTC5_MASS_STRUCTURE_SYNTHESIS_v1.tex` — 1 file(s), 11,771 bytes — section-development narrative/build artifact; final manuscript is authoritative and numerical synthesis CSVs are retained.
- `SYNTHESIS/CPTG_GWTC5_STRUCTURAL_MODE_SYNTHESIS_v1_AUDIT.json` — 1 file(s), 2,958 bytes — section-development narrative/build artifact; final manuscript is authoritative and numerical synthesis CSVs are retained.
- `SYNTHESIS/CPTG_GWTC5_MASS_STRUCTURE_SYNTHESIS_v1_AUDIT.json` — 1 file(s), 2,506 bytes — section-development narrative/build artifact; final manuscript is authoritative and numerical synthesis CSVs are retained.
- `SYNTHESIS/CPTG_GWTC5_MASS_STRUCTURE_SYNTHESIS_v1_README.md` — 1 file(s), 849 bytes — section-development narrative/build artifact; final manuscript is authoritative and numerical synthesis CSVs are retained.
- `SYNTHESIS/CPTG_GWTC5_CONCLUSION_REWRITE_v1_AUDIT.json` — 1 file(s), 1,567 bytes — section-development narrative/build artifact; final manuscript is authoritative and numerical synthesis CSVs are retained.
- `SYNTHESIS/CPTG_GWTC5_GR_CPTG_BOUNDARY_SYNTHESIS_v1.tex` — 1 file(s), 10,278 bytes — section-development narrative/build artifact; final manuscript is authoritative and numerical synthesis CSVs are retained.
- `SYNTHESIS/CPTG_GWTC5_INTERPRETATION_DISCUSSION_REWRITE_v1_README.md` — 1 file(s), 726 bytes — section-development narrative/build artifact; final manuscript is authoritative and numerical synthesis CSVs are retained.
- `SYNTHESIS/CPTG_GWTC5_CORE_TIME_SYNTHESIS_v1_README.md` — 1 file(s), 1,126 bytes — section-development narrative/build artifact; final manuscript is authoritative and numerical synthesis CSVs are retained.
- `SYNTHESIS/CPTG_GWTC5_POPULATION_NATIVE_REWRITE_v1_README.md` — 1 file(s), 1,412 bytes — section-development narrative/build artifact; final manuscript is authoritative and numerical synthesis CSVs are retained.
- `SYNTHESIS/CPTG_GWTC5_CONCLUSION_REWRITE_v1.tex` — 1 file(s), 5,494 bytes — section-development narrative/build artifact; final manuscript is authoritative and numerical synthesis CSVs are retained.
- `SYNTHESIS/CPTG_GWTC5_CORE_TIME_SYNTHESIS_v1.tex` — 1 file(s), 12,660 bytes — section-development narrative/build artifact; final manuscript is authoritative and numerical synthesis CSVs are retained.
- `SYNTHESIS/CPTG_GWTC5_STRUCTURAL_MODE_SYNTHESIS_v1_README.md` — 1 file(s), 1,227 bytes — section-development narrative/build artifact; final manuscript is authoritative and numerical synthesis CSVs are retained.
- `SYNTHESIS/CPTG_GWTC5_INTERPRETATION_DISCUSSION_REWRITE_v1_AUDIT.json` — 1 file(s), 1,285 bytes — section-development narrative/build artifact; final manuscript is authoritative and numerical synthesis CSVs are retained.
- `SYNTHESIS/CPTG_GWTC5_INTERPRETATION_DISCUSSION_REWRITE_v1.tex` — 1 file(s), 18,524 bytes — section-development narrative/build artifact; final manuscript is authoritative and numerical synthesis CSVs are retained.
- `SYNTHESIS/CPTG_GWTC5_POPULATION_NATIVE_REWRITE_v1.tex` — 1 file(s), 12,803 bytes — section-development narrative/build artifact; final manuscript is authoritative and numerical synthesis CSVs are retained.
- `SYNTHESIS/CPTG_GWTC5_GR_CPTG_BOUNDARY_SYNTHESIS_v1_AUDIT.json` — 1 file(s), 2,428 bytes — section-development narrative/build artifact; final manuscript is authoritative and numerical synthesis CSVs are retained.
- `SYNTHESIS/CPTG_GWTC5_CONCLUSION_REWRITE_v1_README.md` — 1 file(s), 940 bytes — section-development narrative/build artifact; final manuscript is authoritative and numerical synthesis CSVs are retained.
- `SYNTHESIS/CPTG_GWTC5_ROTATION_SYNTHESIS_v1_README.md` — 1 file(s), 1,317 bytes — section-development narrative/build artifact; final manuscript is authoritative and numerical synthesis CSVs are retained.
- `SYNTHESIS/CPTG_GWTC5_POPULATION_NATIVE_REWRITE_v1_AUDIT.json` — 1 file(s), 3,634 bytes — section-development narrative/build artifact; final manuscript is authoritative and numerical synthesis CSVs are retained.
- `SYNTHESIS/CPTG_GWTC5_GR_CPTG_BOUNDARY_SYNTHESIS_v1_README.md` — 1 file(s), 1,100 bytes — section-development narrative/build artifact; final manuscript is authoritative and numerical synthesis CSVs are retained.
- `FINAL_AUDIT/CPTG_GWTC5_DEEP_EVIDENCE_AUDIT_v2.json` — 1 file(s), 8,521 bytes — superseded packaging audit referencing removed mirrors/reference figures/predecessor archive.
- `FINAL_AUDIT/CPTG_GWTC5_DEEP_EVIDENCE_AUDIT_v2.md` — 1 file(s), 6,249 bytes — superseded packaging audit referencing removed mirrors/reference figures/predecessor archive.
- `FINAL_AUDIT/CPTG_GWTC5_EVIDENCE_SYNCHRONIZATION_AUDIT_v1.json` — 1 file(s), 1,354 bytes — superseded packaging audit referencing removed mirrors/reference figures/predecessor archive.
- `FINAL_AUDIT/CPTG_GWTC5_EVIDENCE_SYNCHRONIZATION_AUDIT_v1.md` — 1 file(s), 1,375 bytes — superseded packaging audit referencing removed mirrors/reference figures/predecessor archive.

## Remaining exact duplicate groups

- `INTERNAL_ROTATION/GWTC5_FULL_BRANCH_SELECTION.csv` = `CORE_TIME/GWTC5_FULL_BRANCH_SELECTION.csv`
- `INTERNAL_ROTATION/GWTC5_ROTATION_SOURCE_AUDIT.csv` = `CORE_TIME/GWTC5_SOURCE_AUDIT.csv`
- `INTERNAL_ROTATION/GWTC5_FULL_BRANCH_AUTHORITY.csv` = `CORE_TIME/GWTC5_FULL_BRANCH_AUTHORITY.csv`
- `INTERNAL_ROTATION/cptg_core_time_common.py` = `CORE_TIME/cptg_core_time_common.py`
- `INTERNAL_ROTATION/GWTC5_ROTATION_AUTHORITY_CLOSURE.csv` = `CORE_TIME/GWTC5_AUTHORITY_CLOSURE.csv`
- `INTERNAL_ROTATION/GWTC5_ROTATION_REORDER_AUDIT.csv` = `CORE_TIME/GWTC5_REORDER_AUDIT.csv`
- `INTERNAL_ROTATION/run_logged.py` = `CORE_TIME/run_logged.py`
- `INTERNAL_ROTATION/GWTC5_FULL_SOURCE_INPUTS.csv` = `CORE_TIME/GWTC5_FULL_SOURCE_INPUTS.csv`

These remaining duplicates are intentional because the CORE_TIME and INTERNAL_ROTATION reproduction lanes are independently runnable and carry separate internal manifests.
