# CPTG GWTC-5 Final Scientific Audit v1

**Status: PASS**

The manuscript was audited against the frozen event, compact-state, Structural-Mode, finite-core time, geometric-rotation, and r19 native-population evidence. **No scientific equation or numerical-result correction was required.**

## Identity and sample closure

- 259 astrophysical events.
- 288 retained release-label realizations.
- 260 unique within-event numerical streams.
- 520 solved compact components.
- 7,626,239 retained event-level posterior draws.
- Candidate subsections cover all 259 events exactly once.
- Stream counts remain M1=82, M2=94, M3=47, M4=30, M5=7; M5 represents six events because GW231123_135430 retains two distinct streams.

## Compact-state closure

The nonlinear compact identities were audited from the sample-wise event diagnostics rather than by adding separately reported marginal medians.

- Maximum compact-cubic residual: `1.332e-15`.
- Maximum mass-decomposition relative residual: `0.000e+00`.
- Maximum detector/source identity residual: `1.010e-15`.
- Stored-median geometric-share consistency residual: `3.807e-08`.
- Stored-median compact-cubic consistency residual: `1.669e-07`.
- All retained median `A_pol` values remain in `[1,2]`.

## Structural Mode

- Component-median `N_BH` range: `1.473147738840` to `1.898389091913`.
- Minimum sample-wise `x_- - x_N`: `0.049408417286901`.
- All reported median trapping surfaces remain inside `x=1`.
- Structural Mode remains an individual post-solution fingerprint; the manuscript does not assign a physical catalog-average mode.

## Finite-core clock

- Maximum stored-median `T24 - 24 alpha` residual: `3.553e-15 h`.
- All 520 median radial clock profiles decrease toward the zero-lapse trapping-surface limit.
- Independent 1 cm-10 cm-1 m fitted exponent range: `0.49999464` to `0.50001636`, consistent with the registered square-root boundary law.

## Geometric rotation

- Sample-wise angular-ordering violations: `0`.
- Nonfinite angular-speed samples: `0`.
- Maximum period-identity residual: `0.000e+00 ms`.
- Shallow radial turnovers remain allowed and are not promoted into a validation failure.
- ZAMO frame dragging is kept distinct from material rotation.

## Finite-to-Kerr boundary

Independent symbolic re-evaluation reproduces:

- `F(1)=1`
- `F'(1)=0`
- `F''(1)=0`
- `delta_int(1,q)=q^2-1`
- `delta'_int(1,q)=0`
- `delta''_int(1,q)=2`

The matching statement remains limited to the registered finite compact realization and is not presented as a unique parent-action derivation.

## Native population lane

The active route remains:

`released GWTC z -> GWTC luminosity-distance decoder -> fixed observation-coordinate D_L -> CPTG z_pi -> native mass coordinate -> compact handoff`

The frozen audit confirms 8200 hyperposterior rows, 512 realizations per row, the double-projection guard, no use of the retired r18 scaled lane, no event-side change, and passing r19-v2a regression. The equivalent-standard H0-like value remains downstream reporting only.

## Claim-boundary audit

No prohibited or superseded project terminology was reintroduced. The final manuscript preserves the distinctions among `r_N`, `r_-`, and `r_m`; treats fixed offsets as Boyer-Lindquist coordinate offsets; does not substitute a whole-core average or mass ratio for the lapse; keeps GW231123_135430 branches separate; and does not infer a material rotation law.

## Remaining disclosed scope limits

1. Event inference begins from released parameter-estimation posteriors rather than a native CPTG detector-strain likelihood.
2. A parent-action derivation of the rotating finite interior remains a future theoretical test.
3. A matter-rotation law is not inferred from the geometric ZAMO frame-dragging field.
4. Rare population tails retain finite-draw and GWTC sample-selection cautions.

**Scientific audit conclusion:** PASS. The equations, numerical results, coordinate path, component-identity policy, and interpretation boundaries are internally consistent with the frozen evidence.
