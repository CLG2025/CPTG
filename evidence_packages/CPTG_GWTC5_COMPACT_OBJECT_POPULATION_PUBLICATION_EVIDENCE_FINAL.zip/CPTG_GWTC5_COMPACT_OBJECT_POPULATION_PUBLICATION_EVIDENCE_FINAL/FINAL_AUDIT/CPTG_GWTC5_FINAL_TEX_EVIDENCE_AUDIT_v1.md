# CPTG GWTC-5 Final TeX and Evidence Audit v1

**Status: PASS**

## Final manuscript identity

- TeX SHA-256: `b2eed525664c65d591b64264773a1cdd5d8c422a2e404fdf71682f634e4d1217`
- PDF SHA-256: `25c72bef33631aff69bf7a03a91e9cc93c0dc26d40dc8707012274bcaa92c3a5`
- Compiled length: **301 pages**.
- Abstract: **288 words**, below the 300-word limit.

## TeX integrity

- 1255 labels, all unique.
- All `ref` / `eqref` / `pageref` targets exist.
- All 9 citation keys are defined and every bibliography item is used.
- The HDF5 methodology citation and Folk et al. bibliography entry are present.
- 14 PNG figures are referenced directly and all exact assets are present.
- 790 ordinary tables and 0 longtables.
- 259 event subsections.
- The M4 sentence reads `1 system falls`.
- Internal development identifiers `r19`, `r18`, and `v2a` are absent from the manuscript narrative.
- Three-pass `pdflatex` build: no LaTeX warnings, unresolved references/citations, overfull boxes, or underfull boxes.

## Candidate-content integrity

The final paper contains 259 event subsections and covers the complete taxonomy event set without omission or duplication. The two distinct GW231123_135430 branches remain within one event subsection and are never averaged. No numerical event, Structural-Mode, finite-core time, rotation, population, candidate-catalog, or synthesis evidence was changed during synchronization.

## Evidence integrity

The final publication archive now binds the exact synchronized manuscript source/PDF and the exact 14 PNG assets used by that source. The former PDF figure renderings are preserved only as secondary reference assets. The fail-closed root validator locks the distributed file set through the global SHA-256 manifest and checks manuscript identity, page count, figure contract, HDF5 citation, manuscript cleanup, and all frozen numerical evidence lanes.
