# CPTG GWTC-5 Deep Evidence Audit v3

**Status: PASS**

This audit covers the lean final publication package after removal of redundant figure/rendering mirrors, a nested predecessor package, and section-development manuscript artifacts. Frozen scientific result files were not changed.

## Checks

- **events**: PASS - 259
- **release labels**: PASS - 288
- **unique candidate streams**: PASS - 260
- **component rows**: PASS - 520
- **radial profile rows**: PASS - 4160
- **posterior draws**: PASS - 7626239
- **release-label accounting**: PASS - 288
- **distinct multi-stream event**: PASS - ['GW231123_135430']
- **branch alias provenance**: PASS - 0 issues
- **observational taxonomy reconstruction**: PASS - {'M2': 94, 'M1': 82, 'M3': 47, 'M4': 30, 'M5': 7}
- **M1 order file stream set**: PASS - 82 rows
- **M2 order file stream set**: PASS - 94 rows
- **M3 order file stream set**: PASS - 47 rows
- **M4 order file stream set**: PASS - 30 rows
- **M5 order file stream set**: PASS - 7 rows
- **candidate compact-state values match frozen compact evidence**: PASS - {"M_inf": 0, "M_c": 0, "M_geom": 0, "f_geom": 0, "a_inf": 0, "A_pol": 0, "a_c": 0, "r_match_km": 0}
- **candidate structural/time values match frozen core-time evidence**: PASS - {"M_inf": 6.711076139254146e-09, "r_match_km": 9.909740583680104e-09, "N_BH": 0, "x_minus": 0, "r_minus_km": 0, "x_N": 0, "r_N_km": 0, "alpha_N": 0, "T24_N_hours": 0}
- **candidate rotation values match frozen rotation evidence**: PASS - {"omega_N_axis_rad_s": 0, "omega_N_detavg_rad_s": 0, "omega_N_equator_rad_s": 0, "period_N_detavg_ms": 0, "omega_surface_rad_s": 0, "period_surface_ms": 0}
- **candidate radial profiles match frozen time/rotation evidence**: PASS - {"time": 0.0, "rotation": 0.0}
- **sample-wise x_N<x_-**: PASS - 0.0494084172869013
- **rotation angular ordering**: PASS - 0
- **rotation finite samples**: PASS - 0
- **T24=24 alpha median identity**: PASS - 3.552713678800501e-15
- **r19 status**: PASS - PASS_NATIVE_COORDINATE_POPULATION_CORRECTION
- **r19 decoder role**: PASS - external GWTC reporting-coordinate decoder only
- **r19 guards**: PASS - {'double_projection_guard': True, 'draws_per_row': 512, 'event_side_changed': False, 'population_sha256': 'aa159c4259ccdbb9140d4ab65382095f4744ef42d7531dc727f19e75d19ef048', 'propagated_realizations': 4198400, 'r18_scaled': False, 'rows': 8200, 'status': 'PASS_NATIVE_COORDINATE_POPULATION_CORRECTION', 'v2a_regression_pass': True}
- **CPTG_GWTC5_CANDIDATE_MASTER_ANALYSIS_v1.xlsx identity**: PASS - f09aa55c596fbb2c378fced03fef14fedce4c76ebdffe533edb9863ea0c5b01e
- **CPTG_GWTC5_CANDIDATE_TAXONOMY_v1.xlsx identity**: PASS - 339d7cb830bed5899ccf17552d93b1a498ec7083f04a49dcb1beb19ac20fd291
- **CPTG_GWTC5_CANDIDATE_TAXONOMY_v1_README.md identity**: PASS - 05be2c421e3e245ea27c1f56f4ee8e67d43f696eb0543b15ca6bf9d2a67e65bb
- **14 manuscript figure references**: PASS - 14 PNG references; authoritative files stored once in MANUSCRIPT/
- **final TeX synchronized**: PASS - b2eed525664c65d591b64264773a1cdd5d8c422a2e404fdf71682f634e4d1217
- **final PDF synchronized**: PASS - 25c72bef33631aff69bf7a03a91e9cc93c0dc26d40dc8707012274bcaa92c3a5
- **final PDF page count**: PASS - 301
- **HDF5 citation synchronized**: PASS - Folk et al. DOI 10.1145/1966895.1966900 present
- **internal run identifiers removed from manuscript narrative**: PASS - r19/r18/v2a absent
- **M4 grammar synchronized**: PASS - 1 system falls
- **authoritative manuscript PNG figures present once**: PASS - 14/14 present in MANUSCRIPT; no duplicate FIGURES_PNG directory
- **obsolete PDF figure renderings absent**: PASS - no figure PDFs; only the final manuscript PDF is distributed
- **nested predecessor publication archive absent**: PASS - SOURCE_ARCHIVES removed; it contained no unique scientific files
- **section-development manuscript fragments absent**: PASS - SYNTHESIS contains numerical CSV registries plus one current synthesis audit/README only
- **synthesis numerical audit**: PASS - CPTG_GWTC5_SYNTHESIS_AUDIT_v2.json

## Redundancy cleanup

- Removed all 14 obsolete PDF figure renderings because the final TeX references PNG assets only.
- Removed the duplicate FIGURES_PNG mirror; the exact 14 manuscript PNGs are stored once beside the final TeX.
- Removed the nested predecessor publication-evidence ZIP after verifying that all 129 of its files already existed at top level; 119 were byte-identical and the remaining 10 were superseded control/manuscript files.
- Removed the duplicate publication-validation log copy.
- Removed section-development TeX fragments, rewrite notes, intermediate build audits, and superseded-output notes from SYNTHESIS while retaining all numerical synthesis CSV registries.
- Replaced the removed synthesis build audits with one current numerical synthesis audit.
- Preserved the exact final manuscript TeX/PDF/14 PNGs and all frozen scientific result directories unchanged.

## Intentional retained duplication

- The frozen native-coordinate result ZIP and the frozen decoder-based baseline ZIP remain in COMPACT_POPULATION because they are source-authority/regression-control archives, not publication-package mirrors.
- A small set of byte-identical source/control files remains in CORE_TIME and INTERNAL_ROTATION so each numerical reproduction lane stays independently runnable and its internal manifest remains closed.
- The two candidate XLSX workbooks remain as consolidated human-readable catalog views; the CSV registries remain the machine-readable evidence authority.
