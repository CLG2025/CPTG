@echo off
setlocal
echo ============================================================
echo CPTG GWTC-5 CORE-TIME FULL POPULATION REPRODUCTION
echo ============================================================
if not exist .venv (
  py -3.11 -m venv .venv
  if errorlevel 1 exit /b 1
)
call .venv\Scripts\activate.bat
python -m pip install --disable-pip-version-check -r requirements.txt
if errorlevel 1 exit /b 1
python run_logged.py SELF_TEST.log selftest_population_method.py
if errorlevel 1 exit /b 1
python run_full_population_core_time.py --preflight-only
if errorlevel 1 exit /b 1
python run_logged.py ANALYSIS.log run_full_population_core_time.py
if errorlevel 1 exit /b 1
python run_logged.py VALIDATION.log validate_full_population_results.py
if errorlevel 1 exit /b 1
echo STATUS=PASS_FULL_POPULATION_REPRODUCTION
endlocal
