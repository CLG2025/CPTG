from pathlib import Path
import subprocess
import sys


def main():
    if len(sys.argv) < 3:
        raise SystemExit('usage: python run_logged.py LOGFILE SCRIPT [ARG ...]')
    log_path = Path(sys.argv[1])
    command = [sys.executable, *sys.argv[2:]]
    log_path.parent.mkdir(parents=True, exist_ok=True)
    with log_path.open('w', encoding='utf-8', newline='') as log:
        process = subprocess.Popen(
            command,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding='utf-8',
            errors='replace',
            bufsize=1,
        )
        assert process.stdout is not None
        for line in process.stdout:
            sys.stdout.write(line)
            sys.stdout.flush()
            log.write(line)
            log.flush()
        return_code = process.wait()
    raise SystemExit(return_code)


if __name__ == '__main__':
    main()
