# CPTG GWTC-5 Core-Time Full-Population Independent Audit

## Result

**PASS — full catalog closed.**

The archive records 288 retained posterior labels across 259 events and 259 verified PE source files. A total of 7,626,239 posterior draws were evaluated sample by sample.

## Integrity and authority

- ZIP integrity: PASS
- internal source audit rows: 259 / 259 PASS
- branch authority rows: 288 / 288 PASS
- sample-wise audit rows: 288 / 288 PASS
- accepted transfer controls: 10 / 10 PASS
- unique within-event derived sample streams: 260
- cross-event digest collisions: 0
- maximum compact-transform authority discrepancy: 6.7110761392541463e-09
- maximum reorder-fraction discrepancy: 9.714451465470121e-17
- maximum primary Structural-N authority discrepancy: 5.1092463593249696e-12
- maximum secondary Structural-N authority discrepancy: 6.1948224328034493e-12
- maximum detector/source identity relative residual: 1.0101651302487457e-15
- accepted transfer-control maximum discrepancy: 0

## Sample-wise and deterministic-audit closure

The full-run sample-wise audit records:

- maximum inner-root residual: 5.5511151231257827e-15
- maximum Structural-N shell residual: 3.3306690738754696e-16
- minimum x_minus - x_N: 0.049408417286901297
- maximum T24 - 24 alpha residual: 0 h
- Item-5 monotonicity violations: 0

An independent recalculation over all 1,440 deterministic audit rows gives:

- maximum inner-root residual: 2.9976021664879227e-15
- maximum Structural-N shell residual: 5.5511151231257827e-16
- maximum r_g identity discrepancy: 2.8421709430404007e-14 km
- maximum r_minus identity discrepancy: 1.4210854715202004e-14 km
- maximum r_N identity discrepancy: 1.4210854715202004e-14 km
- maximum Structural-N clock identity discrepancy: 3.5527136788005009e-15 h

The publication summary tables independently satisfy T24 = 24 alpha to:

- Structural-N summary: 7.1054273576010019e-15 h
- Item-5 summary: 5.3290705182007514e-15 h

The trapping-surface rows are identically zero, and the Item-5 offset sequence is monotonic in every branch/component/quantile summary.

## Duplicate-label handling

There are 29 events with two retained labels. Twenty-eight pairs carry identical derived sample-stream digests. `GW231123_135430` carries two genuinely distinct retained sample streams. No sample digest is shared across different events.

For catalog-level descriptive central values, `GWTC5_UNIQUE_WITHIN_EVENT_DESCRIPTIVE_RANGES.csv` therefore removes only exact duplicate within-event streams and preserves both genuinely distinct `GW231123_135430` branches. It contains 260 unique within-event realizations. The original 288-label descriptive table remains in the archive as the release-label view.

## Evidence boundary

The time reference is 24 hours of source-local asymptotic exterior Kerr time. Item-5 offsets are Boyer-Lindquist radial-coordinate offsets inward from the calculated CPTG inner trapping surface. Structural Mode remains a post-solution readout.
