from pathlib import Path
import csv, json, math
import numpy as np

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'RESULTS'

def rows(name):
    with open(OUT/name,newline='',encoding='utf-8') as f:
        return list(csv.DictReader(f))

status=json.loads((OUT/'GWTC5_CORE_TIME_STATUS.json').read_text(encoding='utf-8'))
if status.get('status')!='PASS_FULL_POPULATION':
    raise SystemExit('FAIL: population status is not PASS')

summary=rows('GWTC5_CORE_TIME_SUMMARY.csv')
item=rows('GWTC5_ITEM5_TIME.csv')
nrows=rows('GWTC5_STRUCTURAL_N_TIME.csv')
closure=rows('GWTC5_AUTHORITY_CLOSURE.csv')
source=rows('GWTC5_SOURCE_AUDIT.csv')
reorder=rows('GWTC5_REORDER_AUDIT.csv')
sampleaudit=rows('GWTC5_SAMPLEWISE_AUDIT.csv')
auditsample=rows('GWTC5_POSTERIOR_AUDIT_SAMPLE.csv')
control=rows('GWTC5_TRANSFER_CONTROL_CLOSURE.csv')
authority=rows('../GWTC5_FULL_BRANCH_AUTHORITY.csv') if False else None

expected={'summary':576,'item':4608,'nrows':576,'closure':288,'source':259,'reorder':288,'sampleaudit':288,'auditsample':1440,'control':10}
actual={'summary':len(summary),'item':len(item),'nrows':len(nrows),'closure':len(closure),'source':len(source),'reorder':len(reorder),'sampleaudit':len(sampleaudit),'auditsample':len(auditsample),'control':len(control)}
for k,v in expected.items():
    if actual[k]!=v: raise SystemExit(f'FAIL: {k} rows {actual[k]} != {v}')
if any(r['status']!='PASS' for r in closure): raise SystemExit('FAIL: authority closure')
if any(r['status']!='PASS' for r in source): raise SystemExit('FAIL: source audit')
if any(r['status']!='PASS' for r in sampleaudit): raise SystemExit('FAIL: samplewise audit')
if any(r['status']!='PASS' for r in control): raise SystemExit('FAIL: accepted transfer control')
if len({r['event'] for r in source})!=259 or len({(r['filename'],r['sha256']) for r in source})!=259:
    raise SystemExit('FAIL: source identities are not 259 unique event/file/SHA rows')
keys={(r['event'],r['posterior_branch']) for r in closure}
if len(keys)!=288: raise SystemExit('FAIL: closure keys are not 288 unique branches')
for table,name in [(reorder,'reorder'),(sampleaudit,'sampleaudit')]:
    if {(r['event'],r['posterior_branch']) for r in table} != keys: raise SystemExit(f'FAIL: {name} key mismatch')
if status['posterior_draws']!=7626239: raise SystemExit('FAIL: posterior draw total')

max_time=0.0
for r in item:
    for tag in ('p05','p50','p95'):
        a=float(r[f'alpha_{tag}']); h=float(r[f'core_hours_per_24h_{tag}'])
        max_time=max(max_time,abs(h-24*a))
        if not (0<=a<=1.0000000001): raise SystemExit('FAIL: Item-5 lapse outside [0,1]')
        if r['coordinate_offset_inside_rminus']=='trapping surface' and (abs(a)>1e-14 or abs(h)>1e-13):
            raise SystemExit('FAIL: trapping-surface zero')
for r in nrows:
    for tag in ('p05','p50','p95'):
        a=float(r[f'alpha_N_{tag}']); h=float(r[f'core_hours_per_24h_{tag}'])
        max_time=max(max_time,abs(h-24*a))
        if not (0<a<1): raise SystemExit('FAIL: Structural-N lapse outside (0,1)')
if max_time>2e-10: raise SystemExit(f'FAIL: summary T24=24alpha identity {max_time}')

# Item-5 branch/component quantiles must decrease toward the trapping surface.
order=['1 km','500 m','100 m','10 m','1 m','10 cm','1 cm','trapping surface']
by={}
for r in item: by[(r['event'],r['posterior_branch'],r['component'],r['coordinate_offset_inside_rminus'])]=r
for e,b in keys:
    for c in ('primary','secondary'):
        for tag in ('p05','p50','p95'):
            vals=[float(by[(e,b,c,o)][f'alpha_{tag}']) for o in order]
            if any(vals[j+1] > vals[j] + 5e-12 for j in range(len(vals)-1)):
                raise SystemExit(f'FAIL: Item-5 summary monotonicity {e} {b} {c} {tag}')

max_inner=max(float(r['max_inner_root_abs_residual']) for r in sampleaudit)
max_nshell=max(float(r['max_structural_N_shell_abs_residual']) for r in sampleaudit)
min_gap=min(float(r['minimum_xminus_minus_xN']) for r in sampleaudit)
max_sample_time=max(float(r['max_T24_minus_24alpha_abs_hours']) for r in sampleaudit)
viol=sum(int(r['item5_monotonicity_violations']) for r in sampleaudit)
if max_inner>5e-13: raise SystemExit(f'FAIL: inner root residual {max_inner}')
if max_nshell>2e-12: raise SystemExit(f'FAIL: Structural-N shell residual {max_nshell}')
if not min_gap>0: raise SystemExit('FAIL: nonpositive Structural-N shell gap')
if max_sample_time>2e-9: raise SystemExit(f'FAIL: sample time identity {max_sample_time}')
if viol!=0: raise SystemExit(f'FAIL: Item-5 sample monotonicity violations {viol}')
# Cryptographic digest identity follows the frozen branch authority.  The catalog
# contains 29 two-label events.  Twenty-eight paired labels are exact numerical
# identities of the same retained posterior realization; GW231123_135430 carries
# two genuinely distinct retained branches.  Therefore digest uniqueness is not
# one-per-label.  Validate the exact within-event identity structure instead.
authority_rows=[]
with open(ROOT/'GWTC5_FULL_BRANCH_AUTHORITY.csv', newline='', encoding='utf-8') as f:
    authority_rows=list(csv.DictReader(f))
if len(authority_rows)!=288:
    raise SystemExit(f'FAIL: authority rows {len(authority_rows)} != 288')
auth_keys={(r['event'],r['posterior_branch']) for r in authority_rows}
if auth_keys != keys:
    raise SystemExit('FAIL: authority key mismatch')

digest_by={(r['event'],r['posterior_branch']):r['sample_digest_sha256'] for r in sampleaudit}
import re
if any(re.fullmatch(r'[0-9a-f]{64}', d) is None for d in digest_by.values()):
    raise SystemExit('FAIL: malformed sample digest')

from collections import defaultdict
auth_by_event=defaultdict(list)
for r in authority_rows:
    auth_by_event[r['event']].append(r)

sig_cols=[c for c in authority_rows[0].keys() if c not in {'catalog_branch_index','event','posterior_branch'}]
expected_unique_digests=0
for event, ars in auth_by_event.items():
    sig_groups=defaultdict(list)
    for r in ars:
        sig=tuple(r[c] for c in sig_cols)
        sig_groups[sig].append(r['posterior_branch'])
    expected_unique_digests += len(sig_groups)
    group_digests=[]
    for branches in sig_groups.values():
        ds={digest_by[(event,b)] for b in branches}
        if len(ds)!=1:
            raise SystemExit(f'FAIL: authority-identical branch digest mismatch {event}')
        group_digests.append(next(iter(ds)))
    if len(set(group_digests)) != len(group_digests):
        raise SystemExit(f'FAIL: authority-distinct branch digest collision {event}')

if expected_unique_digests != 260:
    raise SystemExit(f'FAIL: frozen authority implies {expected_unique_digests} unique within-event realizations, expected 260')

digest_events=defaultdict(set)
for (event,branch), digest in digest_by.items():
    digest_events[digest].add(event)
if any(len(events)>1 for events in digest_events.values()):
    raise SystemExit('FAIL: sample digest shared across different events')
if len(digest_events) != expected_unique_digests:
    raise SystemExit(f'FAIL: unique sample digests {len(digest_events)} != frozen within-event realization count {expected_unique_digests}')

ctrl=max(float(r['core_time_summary_max_abs']) for r in control)
ctrl=max(ctrl,max(float(r['item5_time_max_abs']) for r in control),max(float(r['structural_N_time_max_abs']) for r in control),max(float(r['reorder_max_abs']) for r in control))
if ctrl>1e-7: raise SystemExit(f'FAIL: accepted transfer regression {ctrl}')

print('CPTG GWTC-5 CORE-TIME FULL POPULATION RESULT VALIDATION')
print('retained branches',len(keys))
print('unique sources',len(source))
print('posterior draws',status['posterior_draws'])
print('summary rows',len(summary))
print('Item-5 rows',len(item))
print('Structural-N rows',len(nrows))
print('samplewise audit rows',len(sampleaudit))
print('deterministic audit sample rows',len(auditsample))
print('unique within-event sample digests',len(digest_events))
print('max summary T24 identity abs',repr(max_time))
print('max sample inner-root residual',repr(max_inner))
print('max sample Structural-N shell residual',repr(max_nshell))
print('minimum xminus-xN',repr(min_gap))
print('max sample T24 identity abs',repr(max_sample_time))
print('accepted transfer control max abs',repr(ctrl))
print('STATUS=PASS_FULL_POPULATION_RESULT_VALIDATION')
