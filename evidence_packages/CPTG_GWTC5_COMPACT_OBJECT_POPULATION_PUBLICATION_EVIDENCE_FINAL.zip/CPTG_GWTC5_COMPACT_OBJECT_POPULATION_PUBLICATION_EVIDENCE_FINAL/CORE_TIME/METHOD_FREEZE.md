# Method Freeze

The r03 population run uses the same registered calculation validated by the GW230627 commissioning result and the 10-branch transfer closure.

For every posterior draw, the observed luminosity-distance coordinate is inverted through the registered CPTG luminosity map. Detector-frame component masses are placed in the CPTG exterior source coordinate, the compact mass-spin handoff is solved separately for both raw components, and only then are the complete attached component states reordered by CPTG physical compact-source mass.

The finite rotating core uses the locked mass function

`F(x) = (63 x^5 - 90 x^7 + 35 x^9) / 8`,

with inner trapping surface defined by

`x^2 - 2 x F(x) + q^2 = 0`.

The determinant-measure angularly averaged ZAMO lapse is evaluated at the declared Item-5 Boyer-Lindquist coordinate offsets and at the Structural-N organization shell. The rotating Structural Mode is calculated from the registered equal-measure shell map and inherited compact structural weight. All new time quantities are evaluated draw by draw before posterior quantiles are taken.

The 24-hour reference is source-local asymptotic exterior Kerr time. No whole-core average and no geometric-mass fraction is used as a clock ratio.

Independent retained posterior branches remain separate throughout the calculation and reporting. Structural Mode values are never averaged across branches or objects.
