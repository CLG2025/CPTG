# LOCKED GWTC CORE-TIME REPORTING METHOD

This file records the exact time-reporting method to be used for every GWTC
candidate/component in the CPTG compact-population paper unless explicitly reopened.

## Clock authority

Use the minimum CPTG Kerr-compatible rotating mass-function realization:

\[
F(x)=\frac18(63x^5-90x^7+35x^9),\qquad x=r/r_g,
\]

\[
\delta(x,q)=x^2-2xF(x)+q^2,\qquad q=|\hat a_\infty|,
\]

\[
\sigma(x,\theta,q)=x^2+q^2\cos^2\theta,
\]

\[
{\cal A}_d(x,\theta,q)
=(x^2+q^2)^2-q^2\delta(x,q)\sin^2\theta.
\]

The locally nonrotating/ZAMO lapse is

\[
\alpha(x,\theta;q)
=\sqrt{\frac{\delta\,\sigma}{{\cal A}_d}}.
\]

The time comparison is always source-local asymptotic exterior time:
\[
T_{\rm core}=\alpha T_\infty.
\]
`T_infty = 24 h` means 24 hours on the local asymptotic Kerr clock of the
candidate, not 24 detector/Earth hours.

At a fixed shell use the determinant-measure angular average
\[
\bar\alpha(x;q)
=
\frac{\int_0^\pi \alpha(x,\theta;q)\,
       \sigma(x,\theta,q)\sin\theta\,d\theta}
     {\int_0^\pi \sigma(x,\theta,q)\sin\theta\,d\theta}.
\]

No mass-ratio clock approximation is permitted.

## Inner CPTG trapping surface

For each posterior draw and component solve
\[
\delta(x_-,q)=0,\qquad 0<x_-<1,
\]
equivalently
\[
35y^5-90y^4+63y^3-4y-4q^2=0,\qquad y=x^2.
\]

The physical inner radius is
\[
r_-^{\rm CPTG}=x_-r_g,\qquad
r_g=\frac{GM_\infty}{c^2}.
\]

## REQUIRED TIME READOUT 1 — Item 5 near-boundary time accumulation

For every candidate/component, report exactly these coordinate offsets inward from
the inner CPTG trapping surface:

- 1 km
- 500 m
- 100 m
- 10 m
- 1 m
- 10 cm
- 1 cm
- trapping surface

For each nonzero offset \(d\),
\[
r_d=r_-^{\rm CPTG}-d,\qquad x_d=r_d/r_g,
\]
then report
\[
\bar\alpha_d=\bar\alpha(x_d;q)
\]
and
\[
T_{24,d}=24\,\bar\alpha_d\ {\rm h}.
\]

At the trapping surface set
\[
\bar\alpha=0,\qquad T_{24}=0.
\]

The listed distances are Boyer-Lindquist radial-coordinate offsets in the registered
minimum rotating realization; they are not relabeled as proper radial distances.

Posterior reporting: calculate this on every retained posterior draw first, then report
5th/50th/95th percentiles. Never construct uncertainties by combining separately
printed marginal medians.

## REQUIRED TIME READOUT 2 — Structural N-mode time

Use the already registered rotating Structural Mode:

\[
\xi(x,q)=
\left[
\frac{x(x^2+q^2)}{1+q^2}
\right]^{1/3},
\]

\[
N_{\rm BH}(q)
=
\frac{\int_0^1 w(x)\,dx}
     {\int_0^1 \xi(x,q)w(x)\,dx}.
\]

The Structural-Mode organization shell is the unique radius whose equal-measure
coordinate equals the weighted mean:
\[
\xi_N=\frac1{N_{\rm BH}}.
\]

Thus \(x_N\) is the unique root on \(0<x_N<1\) of
\[
x_N(x_N^2+q^2)
=
\frac{1+q^2}{N_{\rm BH}^3}.
\]

Report
\[
r_N=x_Nr_g,
\]
\[
\bar\alpha_N=\bar\alpha(x_N;q),
\]
and
\[
T_{24,N}=24\,\bar\alpha_N\ {\rm h}.
\]

Posterior reporting: evaluate every quantity on every retained posterior draw first,
then quote the 5th/50th/95th percentiles.

## Required candidate presentation

For every GWTC candidate/component, the time discussion is restricted to:

1. Item 5 near-inner-boundary table.
2. Structural N-mode time.

A whole-core average, \(M_c/M_\infty\), geometric mass fraction, Schwarzschild
one-function clock substitution, or any other scalar clock definition must not replace
these two readouts.

## Claim boundary

These are time readouts of the registered **minimum CPTG Kerr-compatible rotating
mass-function realization**. They are not promoted to a unique parent-action theorem
unless the compact action later selects this realization uniquely.
