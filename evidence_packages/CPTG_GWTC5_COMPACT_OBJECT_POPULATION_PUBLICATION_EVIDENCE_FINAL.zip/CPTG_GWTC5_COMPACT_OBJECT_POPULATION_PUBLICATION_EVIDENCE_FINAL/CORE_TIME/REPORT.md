# CPTG GWTC-5 Core-Time Population r03

- Retained branch realizations: 288
- Unique events/source files: 259
- Posterior draws evaluated sample by sample: 7,626,239
- Source identity closure: PASS
- Compact-transform authority closure: PASS
- Structural-Mode authority closure: PASS
- Sample-wise trapping-surface / Structural-N / clock closure: PASS
- Accepted 10-branch transfer regression: PASS (max abs 0.000e+00)

## Catalog descriptive ranges

Independent retained branches remain separate. The following quantities summarize branch-level medians and are not pooled object fingerprints.

| Quantity | Count | Minimum | Median | Maximum |
|---|---:|---:|---:|---:|
| primary_branch_median_structural_N_hours_per_24h | 288 | 12.439672 | 17.2415567 | 19.9856155 |
| secondary_branch_median_structural_N_hours_per_24h | 288 | 11.8526222 | 14.9741804 | 19.4551331 |
| reorder_fraction | 288 | 0 | 0.162701369 | 0.413592005 |

Item-5 offsets are Boyer-Lindquist radial-coordinate offsets inward from the calculated inner CPTG trapping surface. The 24-hour reference is source-local asymptotic exterior Kerr time.
