from pathlib import Path
import math
import csv
import numpy as np

from cptg_core_time_common import (
    STRUCT_ROOTS, W0, W1, REGISTERED_N0, Nbh_vec, xminus_vec, xN_vec,
    shell_alpha_vec, RG_PER_MSUN_KM, OFFSETS
)

ROOT=Path(__file__).resolve().parent

# Registered compact Structural-Mode authority.
assert np.max(np.abs(STRUCT_ROOTS-np.array([0.56519964,0.83262028,0.95519955]))) < 2e-8
assert abs(W0-22.311398744512) < 5e-10
assert abs(W1-11.667718705918) < 5e-10
assert abs(W0/W1-REGISTERED_N0) < 5e-10

# Deterministic commissioning point.
q=np.array([0.147634065418])
N=Nbh_vec(q)[0]
xm=xminus_vec(q)[0]
xN=xN_vec(q,np.array([N]))[0]
aN=shell_alpha_vec(np.array([xN]),q)[0]
h24=24*aN
assert abs(N-1.8685541423212226) < 5e-12
assert abs(xm-0.585167729480677) < 5e-12
assert abs(xN-0.5255579589653346) < 5e-12
assert abs(aN-0.5183196659262973) < 5e-12
assert abs(h24-12.439671982231136) < 5e-11


# Full registered spin-domain geometry sanity check.
qgrid=np.linspace(0.0,0.999999,2001)
Ngrid=Nbh_vec(qgrid)
xmgrid=xminus_vec(qgrid)
xNgrid=xN_vec(qgrid,Ngrid)
agrid=shell_alpha_vec(xNgrid,qgrid)
if np.any(~np.isfinite(Ngrid)) or np.any(~np.isfinite(agrid)):
    raise SystemExit('FAIL non-finite registered spin-domain geometry')
if np.any(xNgrid <= 0) or np.any(xNgrid >= xmgrid) or np.any(xmgrid >= 1):
    raise SystemExit('FAIL registered spin-domain shell ordering')
if np.any(agrid <= 0) or np.any(agrid >= 1):
    raise SystemExit('FAIL registered spin-domain lapse bounds')
spin_domain_min_gap=float(np.min(xmgrid-xNgrid))

# Regression against a 128-draw fixture frozen from the commissioning posterior.
with open(ROOT/'GW230627_TIME_REGRESSION_FIXTURE.csv', newline='', encoding='utf-8') as fh:
    fx=list(csv.DictReader(fh))

def column(name):
    return np.asarray([float(r[name]) for r in fx], dtype=float)

maxerr=0.0
for prefix in ('primary','secondary'):
    qq=column(f'{prefix}_q')
    mm=column(f'{prefix}_M_inf')
    rg=RG_PER_MSUN_KM*mm
    NN=Nbh_vec(qq)
    xxm=xminus_vec(qq)
    xxN=xN_vec(qq,NN)
    aaN=shell_alpha_vec(xxN,qq)
    pairs={
        f'{prefix}_r_g_km':rg,
        f'{prefix}_x_minus':xxm,
        f'{prefix}_r_minus_km':xxm*rg,
        f'{prefix}_N_BH':NN,
        f'{prefix}_x_N':xxN,
        f'{prefix}_r_N_km':xxN*rg,
        f'{prefix}_alpha_N':aaN,
        f'{prefix}_N_mode_hours24':24*aaN,
    }
    for col,calc in pairs.items():
        err=float(np.max(np.abs(calc-column(col))))
        maxerr=max(maxerr,err)
        if err>5e-10:
            raise SystemExit(f'FAIL {col} regression error {err}')
    for name,d in OFFSETS:
        key=name.replace(' ','_')
        if d==0:
            aa=np.zeros_like(qq)
        else:
            aa=shell_alpha_vec(xxm-d/rg,qq)
        for suffix,calc in [('alpha',aa),('hours24',24*aa)]:
            col=f'{prefix}_item5_{key}_{suffix}'
            err=float(np.max(np.abs(calc-column(col))))
            maxerr=max(maxerr,err)
            if err>5e-10:
                raise SystemExit(f'FAIL {col} regression error {err}')

print('CPTG GWTC-5 CORE-TIME POPULATION METHOD SELF-TEST')
print('Structural roots',repr(STRUCT_ROOTS))
print('W0',repr(W0))
print('W1',repr(W1))
print('N0',repr(W0/W1))
print('commissioning q',q[0])
print('commissioning x_minus',xm)
print('commissioning N_BH',N)
print('commissioning x_N',xN)
print('commissioning alpha_N',aN)
print('commissioning hours24_N',h24)
print('registered spin-domain minimum xminus-xN',spin_domain_min_gap)
print('fixture rows',len(fx))
print('maximum regression absolute error',repr(maxerr))
print('STATUS=PASS_POPULATION_METHOD_SELFTEST')
