from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import shutil
from pathlib import Path

import numpy as np

from cptg_core_time_common import (
    F,
    Nbh_vec,
    component_time_calc,
    qtile,
    read_csv_dicts,
    read_event_branch,
    sanitize_branch,
    sha256_file,
    transform_event,
)

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'RESULTS'
WORK = ROOT / 'WORK'
CHECKPOINTS = WORK / 'CHECKPOINTS'
SELECTION = ROOT / 'GWTC5_FULL_BRANCH_SELECTION.csv'
SOURCES = ROOT / 'GWTC5_FULL_SOURCE_INPUTS.csv'
AUTHORITY = ROOT / 'GWTC5_FULL_BRANCH_AUTHORITY.csv'

TRANSFORM_TOL = 2e-6
SPIN_TOL = 5e-7
N_AUTH_TOL = 5e-9
TRANSFER_CONTROL_TOL = 1e-7
EXPECTED_BRANCHES = 288
EXPECTED_EVENTS = 259
EXPECTED_POSTERIOR_DRAWS = 7_626_239


def write_csv(path, rows, fields=None):
    path.parent.mkdir(parents=True, exist_ok=True)
    rows = list(rows)
    if fields is None:
        fields = []
        for r in rows:
            for k in r:
                if k not in fields:
                    fields.append(k)
    with open(path, 'w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        if rows:
            w.writerows(rows)


def f(x): return float(x)
def i(x): return int(float(x))


def jsonable(obj):
    if isinstance(obj, dict):
        return {str(k): jsonable(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [jsonable(v) for v in obj]
    if isinstance(obj, np.ndarray):
        return [jsonable(v) for v in obj.tolist()]
    if isinstance(obj, (np.floating, float)):
        return float(obj)
    if isinstance(obj, (np.integer, int)):
        return int(obj)
    if isinstance(obj, (np.bool_, bool)):
        return bool(obj)
    return obj


def file_contract_sha256():
    h = hashlib.sha256()
    for name in [
        'cptg_core_time_common.py',
        'run_full_population_core_time.py',
        'GWTC5_FULL_BRANCH_SELECTION.csv',
        'GWTC5_FULL_BRANCH_AUTHORITY.csv',
        'GWTC5_FULL_SOURCE_INPUTS.csv',
        'LOCKED_GWTC_CORE_TIME_REPORTING_METHOD.md',
    ]:
        h.update(name.encode('utf-8') + b'\0')
        h.update(bytes.fromhex(sha256_file(ROOT / name)))
    return h.hexdigest()


def gate_quantiles(name, got, expected, tol):
    got = np.asarray(got, float)
    expected = np.asarray(expected, float)
    err = float(np.max(np.abs(got - expected)))
    if err > tol:
        raise RuntimeError(f'{name} authority mismatch: max_abs={err} got={got} expected={expected}')
    return err


def package_preflight(verbose=True):
    selection = read_csv_dicts(SELECTION)
    authority = read_csv_dicts(AUTHORITY)
    sources = read_csv_dicts(SOURCES)
    skeys = [(r['event'], r['posterior_branch']) for r in selection]
    akeys = [(r['event'], r['posterior_branch']) for r in authority]
    if len(selection) != EXPECTED_BRANCHES or len(set(skeys)) != EXPECTED_BRANCHES:
        raise RuntimeError(f'branch selection must contain {EXPECTED_BRANCHES} unique keys')
    if len(authority) != EXPECTED_BRANCHES or set(akeys) != set(skeys):
        raise RuntimeError('full branch authority does not exactly match selection')
    events = {r['event'] for r in selection}
    if len(events) != EXPECTED_EVENTS:
        raise RuntimeError(f'expected {EXPECTED_EVENTS} unique events, got {len(events)}')
    if len(sources) != EXPECTED_EVENTS or len({r['event'] for r in sources}) != EXPECTED_EVENTS:
        raise RuntimeError('source registry must contain exactly one row per event')
    source_events = {r['event'] for r in sources}
    if events != source_events:
        raise RuntimeError('source-event set does not equal selected event set')
    total = sum(i(r['posterior_samples_finite']) for r in selection)
    if total != EXPECTED_POSTERIOR_DRAWS:
        raise RuntimeError(f'posterior sample authority total {total} != {EXPECTED_POSTERIOR_DRAWS}')

    # Reconstruct all frozen Structural-Mode authorities directly from the frozen spin quantiles.
    max_n = 0.0
    for r in authority:
        q1 = np.array([f(r['a_inf_1_p95']), f(r['a_inf_1_p50']), f(r['a_inf_1_p05'])])
        q2 = np.array([f(r['a_inf_2_p95']), f(r['a_inf_2_p50']), f(r['a_inf_2_p05'])])
        e1 = np.array([f(r['N_BH_1_p05']), f(r['N_BH_1_p50']), f(r['N_BH_1_p95'])])
        e2 = np.array([f(r['N_BH_2_p05']), f(r['N_BH_2_p50']), f(r['N_BH_2_p95'])])
        max_n = max(max_n, float(np.max(np.abs(Nbh_vec(q1) - e1))), float(np.max(np.abs(Nbh_vec(q2) - e2))))
    if max_n > N_AUTH_TOL:
        raise RuntimeError(f'catalog Structural-Mode authority preflight failed: {max_n}')

    # Accepted transfer controls must all be present in the full selection.
    ctrl = read_csv_dicts(ROOT / 'R02_CONTROL_SUBSET_SELECTION.csv')
    ckeys = {(r['event'], r['posterior_branch']) for r in ctrl}
    if len(ctrl) != 10 or not ckeys.issubset(set(skeys)):
        raise RuntimeError('accepted transfer control set is not a 10-branch subset of the catalog selection')

    if verbose:
        print('FULL POPULATION STATIC PREFLIGHT')
        print('branch realizations', len(selection))
        print('unique events', len(events))
        print('posterior draw authority', total)
        print('source identities', len(sources))
        print('max reconstructed Structural-N authority abs', repr(max_n))
        print('accepted transfer controls', len(ctrl))
        print('STATUS=PASS_FULL_POPULATION_STATIC_PREFLIGHT')
    return max_n


def source_preflight(sources):
    audit = []
    print('Verifying 259 source-file identities before posterior calculation...')
    for pos, r in enumerate(sources, 1):
        event = r['event']
        path = Path(r['local_path'])
        if not path.exists():
            raise RuntimeError(f'{event}: source file not found: {path}')
        actual_size = path.stat().st_size
        expected_size = i(r['size_bytes'])
        if actual_size != expected_size:
            raise RuntimeError(f'{event}: source size mismatch {actual_size} != {expected_size}')
        actual_sha = sha256_file(path)
        if actual_sha.lower() != r['local_sha256'].lower():
            raise RuntimeError(f'{event}: source SHA256 mismatch')
        audit.append({
            'population_row': r['population_row'], 'event': event,
            'filename': r['filename'], 'path': str(path), 'size_bytes': actual_size,
            'official_md5': r['official_md5'], 'sha256': actual_sha,
            'acquisition_status': r['acquisition_status'], 'status': 'PASS'
        })
        if pos % 20 == 0 or pos == len(sources):
            print(f'  source identities verified {pos}/{len(sources)}')
    return audit


def canonical_sample_digest(tr, p1, p2):
    h = hashlib.sha256()
    fields = [
        ('z_CPTG', tr['z']), ('m_inf_1', tr['m1']), ('m_inf_2', tr['m2']),
        ('a_inf_1', tr['q1']), ('a_inf_2', tr['q2']),
        ('A_pol_1', tr['A1']), ('A_pol_2', tr['A2']),
        ('m_c_1', tr['mc1']), ('m_c_2', tr['mc2']),
        ('m_geom_1', tr['mg1']), ('m_geom_2', tr['mg2']),
    ]
    for prefix, p in [('primary', p1), ('secondary', p2)]:
        for k, v in p.items():
            fields.append((prefix + '_' + k, v))
    for name, arr in fields:
        h.update(name.encode('utf-8') + b'\0')
        a = np.asarray(arr, dtype='<f8')
        h.update(a.tobytes(order='C'))
    h.update(b'swap\0')
    h.update(np.asarray(tr['swap'], dtype=np.uint8).tobytes(order='C'))
    return h.hexdigest()


def samplewise_audit(event, branch, tr, p1, p2, digest):
    max_inner = 0.0
    max_nshell = 0.0
    min_gap = float('inf')
    max_time = 0.0
    monotonic_violations = 0
    min_alpha = float('inf')
    max_alpha = 0.0
    for p in (p1, p2):
        q = np.asarray(p['q'], float)
        xm = np.asarray(p['x_minus'], float)
        N = np.asarray(p['N_BH'], float)
        xn = np.asarray(p['x_N'], float)
        max_inner = max(max_inner, float(np.max(np.abs(xm*xm - 2*xm*F(xm) + q*q))))
        rhs = (1 + q*q) / (N**3)
        max_nshell = max(max_nshell, float(np.max(np.abs(xn*(xn*xn + q*q) - rhs))))
        min_gap = min(min_gap, float(np.min(xm - xn)))
        aN = np.asarray(p['alpha_N'], float)
        hN = np.asarray(p['N_mode_hours24'], float)
        max_time = max(max_time, float(np.max(np.abs(hN - 24*aN))))
        min_alpha = min(min_alpha, float(np.min(aN)))
        max_alpha = max(max_alpha, float(np.max(aN)))
        seq = []
        for key in ('1_km','500_m','100_m','10_m','1_m','10_cm','1_cm'):
            a = np.asarray(p[f'item5_{key}_alpha'], float)
            h = np.asarray(p[f'item5_{key}_hours24'], float)
            max_time = max(max_time, float(np.max(np.abs(h - 24*a))))
            min_alpha = min(min_alpha, float(np.min(a)))
            max_alpha = max(max_alpha, float(np.max(a)))
            seq.append(a)
        seq = np.vstack(seq)
        # As offset shrinks toward the trapping surface, lapse must not increase.
        monotonic_violations += int(np.sum(np.any(np.diff(seq, axis=0) > 5e-13, axis=0)))
        surf = np.asarray(p['item5_trapping_surface_alpha'], float)
        if float(np.max(np.abs(surf))) > 1e-14:
            raise RuntimeError(f'{event} {branch}: trapping-surface lapse is not zero')
    if not (min_gap > 0):
        raise RuntimeError(f'{event} {branch}: Structural-N shell ordering failed')
    if monotonic_violations:
        raise RuntimeError(f'{event} {branch}: Item-5 sample monotonicity violations {monotonic_violations}')
    return {
        'event': event, 'posterior_branch': branch, 'samples': len(tr['z']),
        'sample_digest_sha256': digest,
        'max_inner_root_abs_residual': max_inner,
        'max_structural_N_shell_abs_residual': max_nshell,
        'minimum_xminus_minus_xN': min_gap,
        'max_T24_minus_24alpha_abs_hours': max_time,
        'item5_monotonicity_violations': monotonic_violations,
        'minimum_nonzero_lapse': min_alpha,
        'maximum_lapse': max_alpha,
        'status': 'PASS',
    }


def deterministic_audit_rows(event, branch, tr, p1, p2):
    n = len(tr['z'])
    idxs = sorted(set([0, n//4, n//2, (3*n)//4, n-1]))
    out = []
    for idx in idxs:
        r = {
            'event': event, 'posterior_branch': branch, 'sample_index': idx,
            'z_CPTG': float(tr['z'][idx]), 'reordered': int(tr['swap'][idx]),
            'm_inf_1': float(tr['m1'][idx]), 'm_inf_2': float(tr['m2'][idx]),
            'a_inf_1': float(tr['q1'][idx]), 'a_inf_2': float(tr['q2'][idx]),
            'A_pol_1': float(tr['A1'][idx]), 'A_pol_2': float(tr['A2'][idx]),
            'm_c_1': float(tr['mc1'][idx]), 'm_c_2': float(tr['mc2'][idx]),
            'm_geom_1': float(tr['mg1'][idx]), 'm_geom_2': float(tr['mg2'][idx]),
        }
        for prefix, p in [('primary', p1), ('secondary', p2)]:
            for k, v in p.items():
                r[prefix + '_' + k] = float(np.asarray(v)[idx])
        out.append(r)
    return out


def write_full_samples(path, event, branch, tr, p1, p2):
    import gzip
    audit = deterministic_audit_rows(event, branch, tr, p1, p2)
    # Use the same field order as the audit rows, but emit every draw.
    fields = list(audit[0].keys())
    with gzip.open(path, 'wt', newline='', encoding='utf-8') as fh:
        w = csv.DictWriter(fh, fieldnames=fields)
        w.writeheader()
        n = len(tr['z'])
        for idx in range(n):
            r = {
                'event': event, 'posterior_branch': branch, 'sample_index': idx,
                'z_CPTG': float(tr['z'][idx]), 'reordered': int(tr['swap'][idx]),
                'm_inf_1': float(tr['m1'][idx]), 'm_inf_2': float(tr['m2'][idx]),
                'a_inf_1': float(tr['q1'][idx]), 'a_inf_2': float(tr['q2'][idx]),
                'A_pol_1': float(tr['A1'][idx]), 'A_pol_2': float(tr['A2'][idx]),
                'm_c_1': float(tr['mc1'][idx]), 'm_c_2': float(tr['mc2'][idx]),
                'm_geom_1': float(tr['mg1'][idx]), 'm_geom_2': float(tr['mg2'][idx]),
            }
            for prefix, p in [('primary', p1), ('secondary', p2)]:
                for k, v in p.items():
                    r[prefix + '_' + k] = float(np.asarray(v)[idx])
            w.writerow(r)


def process_branch(sel, ar, sr, source_sha, write_samples=False):
    event, branch = sel['event'], sel['posterior_branch']
    src = Path(sr['local_path'])
    dspath, data = read_event_branch(src, branch)
    tr = transform_event(data)
    n = len(tr['z'])
    if n != i(ar['posterior_samples_finite']):
        raise RuntimeError(f'{event} {branch}: finite sample count {n} != {ar["posterior_samples_finite"]}')

    max_transform = 0.0
    checks = [
        ('z', qtile(tr['z']), [f(ar['cptg_z_p05']), f(ar['cptg_z_p50']), f(ar['cptg_z_p95'])], TRANSFORM_TOL),
        ('m_inf_1', qtile(tr['m1']), [f(ar['m_inf_1_p05']), f(ar['m_inf_1_p50']), f(ar['m_inf_1_p95'])], TRANSFORM_TOL),
        ('m_inf_2', qtile(tr['m2']), [f(ar['m_inf_2_p05']), f(ar['m_inf_2_p50']), f(ar['m_inf_2_p95'])], TRANSFORM_TOL),
        ('m_c_1', qtile(tr['mc1']), [f(ar['m_c_1_p05']), f(ar['m_c_1_p50']), f(ar['m_c_1_p95'])], TRANSFORM_TOL),
        ('m_c_2', qtile(tr['mc2']), [f(ar['m_c_2_p05']), f(ar['m_c_2_p50']), f(ar['m_c_2_p95'])], TRANSFORM_TOL),
        ('a_inf_1', qtile(tr['q1']), [f(ar['a_inf_1_p05']), f(ar['a_inf_1_p50']), f(ar['a_inf_1_p95'])], SPIN_TOL),
        ('a_inf_2', qtile(tr['q2']), [f(ar['a_inf_2_p05']), f(ar['a_inf_2_p50']), f(ar['a_inf_2_p95'])], SPIN_TOL),
    ]
    for cname, got, exp, tol in checks:
        max_transform = max(max_transform, gate_quantiles(f'{event} {branch} {cname}', got, exp, tol))
    reorder_err = abs(tr['reorder_fraction'] - f(ar['reorder_fraction']))
    if reorder_err > 2e-12:
        raise RuntimeError(f'{event} {branch}: reorder fraction mismatch {reorder_err}')

    s1, i1, p1 = component_time_calc('primary', tr['q1'], tr['m1'])
    s2, i2, p2 = component_time_calc('secondary', tr['q2'], tr['m2'])

    n1auth = Nbh_vec(qtile(tr['q1'])[::-1])
    n2auth = Nbh_vec(qtile(tr['q2'])[::-1])
    n1exp = np.array([f(ar['N_BH_1_p05']), f(ar['N_BH_1_p50']), f(ar['N_BH_1_p95'])])
    n2exp = np.array([f(ar['N_BH_2_p05']), f(ar['N_BH_2_p50']), f(ar['N_BH_2_p95'])])
    n1err = gate_quantiles(f'{event} {branch} N1', n1auth, n1exp, N_AUTH_TOL)
    n2err = gate_quantiles(f'{event} {branch} N2', n2auth, n2exp, N_AUTH_TOL)

    summary = [{'event': event, 'posterior_branch': branch, **s} for s in (s1, s2)]
    item = [{'event': event, 'posterior_branch': branch, **r} for r in (i1 + i2)]
    nrows = []
    for s in (s1, s2):
        nrows.append({
            'event': event, 'posterior_branch': branch, 'component': s['component'],
            'N_BH_p05': s['N_BH_p05'], 'N_BH_p50': s['N_BH_p50'], 'N_BH_p95': s['N_BH_p95'],
            'r_N_km_p05': s['r_N_km_p05'], 'r_N_km_p50': s['r_N_km_p50'], 'r_N_km_p95': s['r_N_km_p95'],
            'alpha_N_p05': s['alpha_N_p05'], 'alpha_N_p50': s['alpha_N_p50'], 'alpha_N_p95': s['alpha_N_p95'],
            'core_hours_per_24h_p05': s['N_mode_core_hours_per_24h_p05'],
            'core_hours_per_24h_p50': s['N_mode_core_hours_per_24h_p50'],
            'core_hours_per_24h_p95': s['N_mode_core_hours_per_24h_p95'],
        })

    digest = canonical_sample_digest(tr, p1, p2)
    sample_audit = samplewise_audit(event, branch, tr, p1, p2, digest)
    audit_rows = deterministic_audit_rows(event, branch, tr, p1, p2)

    if write_samples:
        sample_dir = OUT / 'FULL_SAMPLES'
        sample_dir.mkdir(parents=True, exist_ok=True)
        slug = f'{event}__{sanitize_branch(branch)}'
        write_full_samples(sample_dir / f'{slug}_SAMPLES.csv.gz', event, branch, tr, p1, p2)

    reorder = {
        'event': event, 'posterior_branch': branch, 'samples': n,
        'reordered_draws': int(np.sum(tr['swap'])), 'reorder_fraction': tr['reorder_fraction'],
        'reference_reorder_fraction': f(ar['reorder_fraction'])
    }
    closure = {
        'event': event, 'posterior_branch': branch, 'posterior_dataset': dspath,
        'samples': n, 'source_sha256': source_sha,
        'max_transform_authority_abs': max_transform,
        'reorder_fraction_abs': reorder_err,
        'N1_authority_max_abs': n1err, 'N2_authority_max_abs': n2err,
        'detector_source_identity_max_rel': tr['detector_source_identity_max_rel'],
        'status': 'PASS'
    }
    return {
        'summary': summary, 'item': item, 'nrows': nrows, 'reorder': reorder,
        'closure': closure, 'sample_audit': sample_audit, 'audit_samples': audit_rows,
    }


def compare_rows(got_rows, ref_rows, keys, ignore=()):
    gm = {tuple(str(r[k]) for k in keys): r for r in got_rows}
    rm = {tuple(str(r[k]) for k in keys): r for r in ref_rows}
    if set(gm) != set(rm):
        raise RuntimeError(f'control key mismatch for keys {keys}')
    mx = 0.0
    for key in rm:
        got, ref = gm[key], rm[key]
        for k, v in ref.items():
            if k in keys or k in ignore or k not in got or v in ('', None):
                continue
            try:
                e = abs(float(got[k]) - float(v))
            except (ValueError, TypeError):
                continue
            mx = max(mx, e)
    return mx


def transfer_control_closure(summary, item, nrows, reorder):
    ctrl_select = read_csv_dicts(ROOT / 'R02_CONTROL_SUBSET_SELECTION.csv')
    keys = {(r['event'], r['posterior_branch']) for r in ctrl_select}
    filt = lambda rows: [r for r in rows if (r['event'], r['posterior_branch']) in keys]
    errs = {
        'core_time_summary_max_abs': compare_rows(filt(summary), read_csv_dicts(ROOT/'R02_CONTROL_CORE_TIME_SUMMARY.csv'), ['event','posterior_branch','component']),
        'item5_time_max_abs': compare_rows(filt(item), read_csv_dicts(ROOT/'R02_CONTROL_ITEM5_TIME.csv'), ['event','posterior_branch','component','coordinate_offset_inside_rminus']),
        'structural_N_time_max_abs': compare_rows(filt(nrows), read_csv_dicts(ROOT/'R02_CONTROL_STRUCTURAL_N_TIME.csv'), ['event','posterior_branch','component']),
        'reorder_max_abs': compare_rows(filt(reorder), read_csv_dicts(ROOT/'R02_CONTROL_REORDER_AUDIT.csv'), ['event','posterior_branch'], ignore=('samples','reordered_draws')),
    }
    mx = max(errs.values())
    if mx > TRANSFER_CONTROL_TOL:
        raise RuntimeError(f'accepted transfer control regression failed: {errs}')
    rows = []
    # one concise row per accepted transfer branch with the global control errors duplicated for easy filtering
    for r in ctrl_select:
        rows.append({'event': r['event'], 'posterior_branch': r['posterior_branch'], **errs, 'status': 'PASS'})
    return rows, mx


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument('--preflight-only', action='store_true')
    ap.add_argument('--fresh', action='store_true', help='discard branch checkpoints and recompute all 288 branches')
    ap.add_argument('--write-full-samples', action='store_true', help='also retain all derived per-draw rows; multi-gigabyte output')
    args = ap.parse_args(argv)

    package_preflight(verbose=True)
    if args.preflight_only:
        return

    selection = read_csv_dicts(SELECTION)
    authority = {(r['event'], r['posterior_branch']): r for r in read_csv_dicts(AUTHORITY)}
    sources_list = read_csv_dicts(SOURCES)
    sources = {r['event']: r for r in sources_list}

    if args.fresh and WORK.exists():
        shutil.rmtree(WORK)
    CHECKPOINTS.mkdir(parents=True, exist_ok=True)
    if OUT.exists():
        shutil.rmtree(OUT)
    OUT.mkdir(parents=True)

    contract = file_contract_sha256()
    source_audit = source_preflight(sources_list)
    source_sha = {r['event']: r['sha256'] for r in source_audit}

    all_summary, all_item, all_n = [], [], []
    all_reorder, all_closure, all_sample_audit, all_audit_samples = [], [], [], []

    print('============================================================')
    print('CPTG GWTC-5 CORE-TIME POPULATION r03')
    print('Frozen full catalog:', len(selection), 'retained branch realizations /', EXPECTED_EVENTS, 'events')
    print('============================================================')

    for pos, sel in enumerate(selection, 1):
        event, branch = sel['event'], sel['posterior_branch']
        key = (event, branch)
        cp = CHECKPOINTS / f'{i(sel["catalog_branch_index"]):03d}__{event}__{sanitize_branch(branch)}.json'
        result = None
        if cp.exists() and not args.write_full_samples:
            try:
                saved = json.loads(cp.read_text(encoding='utf-8'))
                if saved.get('contract_sha256') == contract and saved.get('source_sha256') == source_sha[event]:
                    result = saved['result']
                    print(f'[{pos}/{len(selection)}] {event}  {branch}  CHECKPOINT=PASS')
            except Exception:
                result = None
        if result is None:
            print(f'[{pos}/{len(selection)}] {event}  {branch}')
            result = process_branch(sel, authority[key], sources[event], source_sha[event], write_samples=args.write_full_samples)
            cp.write_text(json.dumps(jsonable({
                'contract_sha256': contract,
                'source_sha256': source_sha[event],
                'result': result,
            }), separators=(',', ':')), encoding='utf-8')
            p = result['summary'][0]; s = result['summary'][1]
            print('  samples', result['reorder']['samples'])
            print('  reorder fraction', result['reorder']['reorder_fraction'])
            print('  primary N-mode hours p05/p50/p95', p['N_mode_core_hours_per_24h_p05'], p['N_mode_core_hours_per_24h_p50'], p['N_mode_core_hours_per_24h_p95'])
            print('  secondary N-mode hours p05/p50/p95', s['N_mode_core_hours_per_24h_p05'], s['N_mode_core_hours_per_24h_p50'], s['N_mode_core_hours_per_24h_p95'])

        all_summary.extend(result['summary'])
        all_item.extend(result['item'])
        all_n.extend(result['nrows'])
        all_reorder.append(result['reorder'])
        all_closure.append(result['closure'])
        all_sample_audit.append(result['sample_audit'])
        all_audit_samples.extend(result['audit_samples'])

    control_rows, control_max = transfer_control_closure(all_summary, all_item, all_n, all_reorder)

    write_csv(OUT/'GWTC5_CORE_TIME_SUMMARY.csv', all_summary)
    write_csv(OUT/'GWTC5_ITEM5_TIME.csv', all_item)
    write_csv(OUT/'GWTC5_STRUCTURAL_N_TIME.csv', all_n)
    write_csv(OUT/'GWTC5_REORDER_AUDIT.csv', all_reorder)
    write_csv(OUT/'GWTC5_AUTHORITY_CLOSURE.csv', all_closure)
    write_csv(OUT/'GWTC5_SOURCE_AUDIT.csv', source_audit)
    write_csv(OUT/'GWTC5_SAMPLEWISE_AUDIT.csv', all_sample_audit)
    write_csv(OUT/'GWTC5_POSTERIOR_AUDIT_SAMPLE.csv', all_audit_samples)
    write_csv(OUT/'GWTC5_TRANSFER_CONTROL_CLOSURE.csv', control_rows)

    # Catalog-wide descriptive ranges keep retained branches separate; no independent reconstructions are averaged.
    med_primary = [float(r['N_mode_core_hours_per_24h_p50']) for r in all_summary if r['component']=='primary']
    med_secondary = [float(r['N_mode_core_hours_per_24h_p50']) for r in all_summary if r['component']=='secondary']
    aggs = [
        {'quantity':'primary_branch_median_structural_N_hours_per_24h','count':len(med_primary),'minimum':min(med_primary),'median':float(np.median(med_primary)),'maximum':max(med_primary)},
        {'quantity':'secondary_branch_median_structural_N_hours_per_24h','count':len(med_secondary),'minimum':min(med_secondary),'median':float(np.median(med_secondary)),'maximum':max(med_secondary)},
        {'quantity':'reorder_fraction','count':len(all_reorder),'minimum':min(float(r['reorder_fraction']) for r in all_reorder),'median':float(np.median([float(r['reorder_fraction']) for r in all_reorder])),'maximum':max(float(r['reorder_fraction']) for r in all_reorder)},
    ]
    write_csv(OUT/'GWTC5_POPULATION_DESCRIPTIVE_RANGES.csv', aggs)

    status = {
        'stage':'CPTG_GWTC5_CORE_TIME_POPULATION_r03',
        'retained_branch_realizations': len(selection),
        'unique_events': len({r['event'] for r in selection}),
        'unique_source_files': len(source_audit),
        'posterior_draws': sum(i(r['samples']) for r in all_reorder),
        'all_source_identity_gates_passed': True,
        'all_authority_gates_passed': True,
        'all_samplewise_audits_passed': True,
        'accepted_transfer_control_branches': 10,
        'accepted_transfer_control_max_abs': control_max,
        'full_sample_registries_written': bool(args.write_full_samples),
        'samplewise_cryptographic_digests': True,
        'deterministic_audit_draws_per_branch': 5,
        'time_reference':'24 h source-local asymptotic exterior Kerr time',
        'item5_offsets':['1 km','500 m','100 m','10 m','1 m','10 cm','1 cm','trapping surface'],
        'status':'PASS_FULL_POPULATION',
    }
    (OUT/'GWTC5_CORE_TIME_STATUS.json').write_text(json.dumps(status, indent=2), encoding='utf-8')

    lines = [
        '# CPTG GWTC-5 Core-Time Population r03', '',
        f'- Retained branch realizations: {len(selection)}',
        f'- Unique events/source files: {EXPECTED_EVENTS}',
        f'- Posterior draws evaluated sample by sample: {status["posterior_draws"]:,}',
        '- Source identity closure: PASS',
        '- Compact-transform authority closure: PASS',
        '- Structural-Mode authority closure: PASS',
        '- Sample-wise trapping-surface / Structural-N / clock closure: PASS',
        f'- Accepted 10-branch transfer regression: PASS (max abs {control_max:.3e})', '',
        '## Catalog descriptive ranges', '',
        'Independent retained branches remain separate. The following quantities summarize branch-level medians and are not pooled object fingerprints.', '',
        '| Quantity | Count | Minimum | Median | Maximum |', '|---|---:|---:|---:|---:|',
    ]
    for r in aggs:
        lines.append(f'| {r["quantity"]} | {r["count"]} | {r["minimum"]:.9g} | {r["median"]:.9g} | {r["maximum"]:.9g} |')
    lines += ['', 'Item-5 offsets are Boyer-Lindquist radial-coordinate offsets inward from the calculated inner CPTG trapping surface. The 24-hour reference is source-local asymptotic exterior Kerr time.']
    (OUT/'REPORT.md').write_text('\n'.join(lines)+'\n', encoding='utf-8')

    print('============================================================')
    print('STATUS=PASS_FULL_POPULATION')
    print('RESULTS=', OUT)


if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        print('STATUS=FAIL_FULL_POPULATION')
        print(type(exc).__name__ + ':', exc)
        raise
