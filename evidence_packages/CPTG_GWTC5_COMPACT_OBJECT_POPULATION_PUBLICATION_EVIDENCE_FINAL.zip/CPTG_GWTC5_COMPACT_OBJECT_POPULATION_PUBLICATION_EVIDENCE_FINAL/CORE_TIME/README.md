# CPTG GWTC-5 Core-Time Full-Population Evidence

This archive contains the standalone evidence for applying the frozen GW230627_015337 core-time method to the complete retained GWTC-5 compact-object catalog.

## Catalog scope

- 259 events
- 288 retained posterior labels
- 259 verified PE source files
- 7,626,239 posterior draws evaluated sample by sample
- 260 unique within-event derived sample streams

Twenty-eight two-label events contain numerically identical paired posterior realizations. GW231123_135430 contains two genuinely distinct retained realizations. Both views are preserved: the original 288-label tables and a separate 260-realization unique-within-event descriptive table.

## Principal outputs

- `GWTC5_CORE_TIME_SUMMARY.csv`
- `GWTC5_ITEM5_TIME.csv`
- `GWTC5_STRUCTURAL_N_TIME.csv`
- `GWTC5_UNIQUE_WITHIN_EVENT_DESCRIPTIVE_RANGES.csv`
- `GWTC5_REORDER_AUDIT.csv`
- `GWTC5_AUTHORITY_CLOSURE.csv`
- `GWTC5_SOURCE_AUDIT.csv`
- `GWTC5_SAMPLEWISE_AUDIT.csv`
- `GWTC5_POSTERIOR_AUDIT_SAMPLE.csv`
- `GWTC5_TRANSFER_CONTROL_CLOSURE.csv`
- `GWTC5_CORE_TIME_STATUS.json`
- `EXECUTION_LOG.txt`
- `SELF_TEST.log`
- `VALIDATION.log`
- `AUDIT_REPORT.md`

## Reporting definitions

The clock reference is 24 hours of source-local asymptotic exterior Kerr time.

Item-5 offsets are Boyer-Lindquist radial-coordinate offsets inward from the calculated inner CPTG trapping surface. They are not proper-distance offsets.

Structural Mode N is evaluated only after compact closure. Independent retained reconstructions remain separate; exact duplicate retained-label streams are identified cryptographically rather than averaged.

## Reproduction

The exact local PE source identities are frozen in `GWTC5_FULL_SOURCE_INPUTS.csv`. On the corresponding Windows PE archive:

```bat
call RUN_REPRODUCE_FULL_POPULATION.cmd
```

The reproduction performs the locked method self-test, full-catalog static preflight, source verification, all retained-label calculations, and full result validation.
