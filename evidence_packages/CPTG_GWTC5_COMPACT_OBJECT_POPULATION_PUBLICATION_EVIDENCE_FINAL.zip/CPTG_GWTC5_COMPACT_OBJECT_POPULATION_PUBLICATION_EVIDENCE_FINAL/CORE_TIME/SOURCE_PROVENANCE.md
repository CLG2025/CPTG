# Source Provenance

`GWTC5_FULL_SOURCE_INPUTS.csv` freezes the 259 local GWTC PE source identities used by this run, including official filename, release record, official MD5 where registered, locally verified SHA-256, byte size, and exact local path.

`GWTC5_FULL_BRANCH_SELECTION.csv` freezes the 288 retained posterior branch realizations and their finite sample counts.

`GWTC5_FULL_BRANCH_AUTHORITY.csv` freezes the established CPTG event-level compact-state authorities and the registered rotating Structural-Mode authorities for the same event/branch keys. It is used only as a fail-closed reproduction gate; it is not used to choose or tune any new time result.

The accepted 10-branch transfer outputs are retained as regression controls. r03 must reproduce those time summaries, Item-5 tables, Structural-N tables, and component-reorder fractions before the full population result can close.
