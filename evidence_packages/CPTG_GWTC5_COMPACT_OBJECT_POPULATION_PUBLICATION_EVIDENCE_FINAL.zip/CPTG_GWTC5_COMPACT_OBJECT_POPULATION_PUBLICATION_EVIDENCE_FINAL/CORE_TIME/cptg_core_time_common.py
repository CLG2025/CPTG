from __future__ import annotations

import csv
import hashlib
import math
import re
from pathlib import Path

import h5py
import numpy as np
from numpy.polynomial.legendre import leggauss
from scipy.integrate import solve_ivp
from scipy.interpolate import PchipInterpolator
from scipy.optimize import brentq

C_KM_S = 299792.458
H0_L = 73.1711530416
BPI = 1.0 - 1.0 / math.pi
TPI = 1.0 / math.pi
RG_PER_MSUN_KM = 1.4766250385

OFFSETS = [
    ("1 km", 1.0),
    ("500 m", 0.5),
    ("100 m", 0.1),
    ("10 m", 0.01),
    ("1 m", 0.001),
    ("10 cm", 0.0001),
    ("1 cm", 0.00001),
    ("trapping surface", 0.0),
]

EVENT_FIELDS = {
    "mass_1_source",
    "mass_ratio",
    "redshift",
    "luminosity_distance",
    "mass_1",
    "mass_2",
    "a_1",
    "a_2",
}


def sha256_file(path: Path, chunk: int = 8 * 1024 * 1024) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(chunk), b""):
            h.update(block)
    return h.hexdigest()


def qtile(a):
    return np.quantile(np.asarray(a, float), [0.05, 0.50, 0.95])


def F(x):
    return (63 * x**5 - 90 * x**7 + 35 * x**9) / 8.0


def Fp(x):
    return (315 * x**4 - 630 * x**6 + 315 * x**8) / 8.0


def U(x):
    return (63 * x**3 - 90 * x**5 + 35 * x**7) / 8.0


def Up(x):
    return (189 * x**2 - 450 * x**4 + 245 * x**6) / 8.0


def Upp(x):
    return (378 * x - 1800 * x**3 + 1470 * x**5) / 8.0


def Cprime(x):
    u = U(x)
    up = Up(x)
    upp = Upp(x)
    return 2 * u * up + 2 * up * upp + 4 * (u / x) * ((up * x - u) / x**2)


# Registered compact Structural-Mode quadrature.  The weight has three cusps,
# so the integral is split at the exact sign-change roots before applying the
# Gaussian rule on each smooth interval.
STRUCT_ROOTS = np.array(
    [
        brentq(lambda xx: Cprime(xx), 0.50, 0.65, xtol=2e-15, rtol=2e-15),
        brentq(lambda xx: Cprime(xx), 0.75, 0.90, xtol=2e-15, rtol=2e-15),
        brentq(lambda xx: Cprime(xx), 0.90, 0.99, xtol=2e-15, rtol=2e-15),
    ],
    dtype=float,
)

_ng, _wg = leggauss(64)
_xparts, _wparts = [], []
_edges = np.concatenate(([0.0], STRUCT_ROOTS, [1.0]))
for _a, _b in zip(_edges[:-1], _edges[1:]):
    _xparts.append((_ng + 1.0) * (_b - _a) / 2.0 + _a)
    _wparts.append(_wg * (_b - _a) / 2.0)
XG = np.concatenate(_xparts)
XW = np.concatenate(_wparts)
WSTR = np.abs(Cprime(XG))
W0 = float(np.sum(XW * WSTR))
W1 = float(np.sum(XW * XG * WSTR))
REGISTERED_W0 = 22.311398744512
REGISTERED_W1 = 11.667718705918
REGISTERED_N0 = 1.912233171442

if abs(W0 - REGISTERED_W0) > 5e-10:
    raise RuntimeError(f"Structural-mode W0 authority mismatch: {W0}")
if abs(W1 - REGISTERED_W1) > 5e-10:
    raise RuntimeError(f"Structural-mode W1 authority mismatch: {W1}")
if abs(W0 / W1 - REGISTERED_N0) > 5e-10:
    raise RuntimeError(f"Structural-mode spherical-limit authority mismatch: {W0/W1}")

_ugl, _ugw = leggauss(96)


def Nbh_vec(q, batch=2048):
    q = np.asarray(q, float)
    out = np.empty_like(q)
    for s in range(0, len(q), batch):
        qq = q[s : s + batch, None]
        xi = (XG[None, :] * (XG[None, :] ** 2 + qq**2) / (1 + qq**2)) ** (1 / 3)
        den = np.sum(XW[None, :] * WSTR[None, :] * xi, axis=1)
        out[s : s + batch] = W0 / den
    return out


def xminus_vec(q):
    """Physical positive inner trapping root on 0<x<1, vectorized bisection."""
    q = np.asarray(q, float)
    if np.any(~np.isfinite(q)) or np.any(q < 0) or np.any(q >= 1):
        raise RuntimeError("exterior spin magnitude must satisfy 0<=q<1")
    lo = np.full_like(q, 0.55)
    hi = np.full_like(q, 1.0 - 2e-15)
    flo = lo * lo - 2 * lo * F(lo) + q * q
    fhi = hi * hi - 2 * hi * F(hi) + q * q
    if np.any(flo <= 0) or np.any(fhi >= 0):
        raise RuntimeError("inner trapping root bracket failed")
    for _ in range(64):
        mid = 0.5 * (lo + hi)
        fm = mid * mid - 2 * mid * F(mid) + q * q
        lo = np.where(fm > 0, mid, lo)
        hi = np.where(fm <= 0, mid, hi)
    x = 0.5 * (lo + hi)
    resid = np.max(np.abs(x * x - 2 * x * F(x) + q * q))
    if resid > 5e-13:
        raise RuntimeError(f"inner trapping root residual too large: {resid}")
    return x


def xN_vec(q, N):
    q = np.asarray(q, float)
    N = np.asarray(N, float)
    C = (1 + q * q) / (N**3)
    x = np.cbrt(C)
    for _ in range(14):
        x -= (x**3 + q * q * x - C) / (3 * x * x + q * q)
    resid = np.max(np.abs(x * (x * x + q * q) - C))
    if resid > 2e-12:
        raise RuntimeError(f"Structural-N shell residual too large: {resid}")
    return x


def shell_alpha_vec(x, q, batch=2048):
    x = np.asarray(x, float)
    q = np.asarray(q, float)
    out = np.full_like(x, np.nan)
    good = (x > 0) & (x < 1) & np.isfinite(x) & np.isfinite(q)
    ids = np.where(good)[0]
    for s in range(0, len(ids), batch):
        ii = ids[s : s + batch]
        xx = x[ii, None]
        qq = q[ii, None]
        u = _ugl[None, :]
        ff = F(xx)
        d = xx**2 - 2 * xx * ff + qq**2
        sig = xx**2 + qq**2 * u**2
        A = (xx**2 + qq**2) ** 2 - qq**2 * d * (1 - u**2)
        rad = d * sig / A
        if np.any(rad < -1e-10):
            raise RuntimeError("negative ZAMO lapse radicand inside declared core")
        a = np.sqrt(np.maximum(rad, 0))
        num = np.sum(_ugw[None, :] * sig * a, axis=1)
        den = np.sum(_ugw[None, :] * sig, axis=1)
        out[ii] = num / den
    return out


def Epi(z):
    return np.sqrt(BPI + TPI * (1 + z) ** math.pi)


def make_z_inverter(max_dl):
    zmax = 0.5
    while True:
        sol = solve_ivp(
            lambda z, y: [1.0 / Epi(z)],
            (0, zmax),
            [0.0],
            rtol=2e-12,
            atol=2e-14,
            dense_output=True,
            max_step=0.002,
        )
        I = float(sol.sol(zmax)[0])
        D = (1 + zmax) * C_KM_S / H0_L * I
        if D >= max_dl * 1.02:
            break
        zmax *= 2
        if zmax > 20:
            raise RuntimeError("could not bracket CPTG luminosity distance")
    zg = np.linspace(0, zmax, 50001)
    Ig = sol.sol(zg)[0]
    Dg = (1 + zg) * C_KM_S / H0_L * Ig
    inv = PchipInterpolator(Dg, zg, extrapolate=False)

    def invert(dl):
        dl = np.asarray(dl, float)
        z = np.asarray(inv(dl), float)
        for _ in range(4):
            I = sol.sol(z)[0]
            D = (1 + z) * C_KM_S / H0_L * I
            dD = C_KM_S / H0_L * (
                I + (1 + z) / np.sqrt(BPI + TPI * (1 + z) ** math.pi)
            )
            z = z - (D - dl) / dD
        return z

    return invert


def Apol_vec(q):
    q = np.asarray(q, float)
    A = 2.0 / (1.0 + q * q)
    A = np.clip(A, 1.0, 2.0)
    for _ in range(16):
        f = q * q * A**3 + A - 2.0
        fp = 3.0 * q * q * A**2 + 1.0
        A = np.clip(A - f / fp, 1.0, 2.0)
    resid = np.max(np.abs(q * q * A**3 + A - 2.0))
    if resid > 2e-12:
        raise RuntimeError(f"compact cubic residual too large: {resid}")
    return A


def exact_branch_dataset(hf: h5py.File, branch: str):
    direct = f"{branch}/posterior_samples"
    if direct in hf:
        ds = hf[direct]
        if isinstance(ds, h5py.Dataset) and EVENT_FIELDS.issubset(set(ds.dtype.names or ())):
            return direct, ds

    candidates = []

    def visitor(name, obj):
        if isinstance(obj, h5py.Dataset) and name.endswith("posterior_samples"):
            names = set(obj.dtype.names or ())
            if EVENT_FIELDS.issubset(names):
                label = name.rsplit("/posterior_samples", 1)[0].split("/")[-1]
                if label == branch:
                    candidates.append((name, obj))

    hf.visititems(visitor)
    if len(candidates) != 1:
        raise RuntimeError(
            f"exact posterior branch {branch!r} resolved to {len(candidates)} datasets"
        )
    return candidates[0]


def read_event_branch(path: Path, branch: str):
    with h5py.File(path, "r") as hf:
        dspath, ds = exact_branch_dataset(hf, branch)
        arr = ds.fields(sorted(EVENT_FIELDS))[:]
    data = {k: np.asarray(arr[k], float) for k in EVENT_FIELDS}
    return dspath, data


def transform_event(data):
    m1s = data["mass_1_source"]
    qrel = data["mass_ratio"]
    zrel = data["redshift"]
    dl = data["luminosity_distance"]
    m1d = data["mass_1"]
    m2d = data["mass_2"]
    a1 = data["a_1"]
    a2 = data["a_2"]
    m2s = m1s * qrel

    finite = (
        np.isfinite(m1s)
        & np.isfinite(qrel)
        & np.isfinite(zrel)
        & np.isfinite(dl)
        & np.isfinite(m1d)
        & np.isfinite(m2d)
        & np.isfinite(a1)
        & np.isfinite(a2)
    )
    if not np.any(finite):
        raise RuntimeError("no finite posterior samples")

    m1s = m1s[finite]
    m2s = m2s[finite]
    zrel = zrel[finite]
    dl = dl[finite]
    m1d = m1d[finite]
    m2d = m2d[finite]
    a1 = a1[finite]
    a2 = a2[finite]

    if np.any(m1d <= 0) or np.any(m2d <= 0) or np.any(dl <= 0):
        raise RuntimeError("nonphysical mass/distance samples")
    if np.any(a1 < 0) or np.any(a1 >= 1) or np.any(a2 < 0) or np.any(a2 >= 1):
        raise RuntimeError("spin magnitude outside [0,1)")

    rel1 = np.abs(m1d - m1s * (1 + zrel)) / np.maximum(m1d, 1.0)
    rel2 = np.abs(m2d - m2s * (1 + zrel)) / np.maximum(m2d, 1.0)
    detector_source_identity_max_rel = max(float(np.max(rel1)), float(np.max(rel2)))
    if detector_source_identity_max_rel > 1e-4:
        raise RuntimeError(
            f"detector/source mass identity residual too large: {detector_source_identity_max_rel}"
        )

    zinv = make_z_inverter(float(np.max(dl)))
    z = zinv(dl)
    m1_raw = m1d / (1 + z)
    m2_raw = m2d / (1 + z)

    A1_raw = Apol_vec(a1)
    A2_raw = Apol_vec(a2)
    mc1_raw = m1_raw / A1_raw
    mc2_raw = m2_raw / A2_raw
    mg1_raw = m1_raw - mc1_raw
    mg2_raw = m2_raw - mc2_raw

    swap = mc2_raw > mc1_raw

    def order(v1, v2):
        return np.where(swap, v2, v1), np.where(swap, v1, v2)

    m1, m2 = order(m1_raw, m2_raw)
    q1, q2 = order(a1, a2)
    A1, A2 = order(A1_raw, A2_raw)
    mc1, mc2 = order(mc1_raw, mc2_raw)
    mg1, mg2 = order(mg1_raw, mg2_raw)

    return {
        "z": z,
        "m1": m1,
        "m2": m2,
        "q1": q1,
        "q2": q2,
        "A1": A1,
        "A2": A2,
        "mc1": mc1,
        "mc2": mc2,
        "mg1": mg1,
        "mg2": mg2,
        "swap": swap,
        "reorder_fraction": float(np.mean(swap)),
        "detector_source_identity_max_rel": detector_source_identity_max_rel,
    }


def component_time_calc(label, q, m):
    q = np.asarray(q, float)
    m = np.asarray(m, float)
    rg = RG_PER_MSUN_KM * m
    N = Nbh_vec(q)
    xm = xminus_vec(q)
    rminus = xm * rg
    xN = xN_vec(q, N)
    if np.any(xN >= xm):
        raise RuntimeError(f"{label}: Structural-N shell is not inside trapping surface")
    rN = xN * rg
    alphaN = shell_alpha_vec(xN, q)
    tN = 24 * alphaN

    item_rows = []
    per_sample = {}
    for name, d_km in OFFSETS:
        if d_km == 0:
            a = np.zeros_like(q)
        else:
            x = xm - d_km / rg
            if np.any(x <= 0):
                bad = int(np.sum(x <= 0))
                raise RuntimeError(f"{label} {name}: {bad} draws do not contain the offset inside the core")
            a = shell_alpha_vec(x, q)
            if np.any(~np.isfinite(a)):
                raise RuntimeError(f"{label} {name}: non-finite lapse")
        h = 24 * a
        aq, hq = qtile(a), qtile(h)
        item_rows.append(
            {
                "component": label,
                "coordinate_offset_inside_rminus": name,
                "offset_km": d_km,
                "alpha_p05": aq[0],
                "alpha_p50": aq[1],
                "alpha_p95": aq[2],
                "core_hours_per_24h_p05": hq[0],
                "core_hours_per_24h_p50": hq[1],
                "core_hours_per_24h_p95": hq[2],
            }
        )
        key = name.replace(" ", "_")
        per_sample[f"item5_{key}_alpha"] = a
        per_sample[f"item5_{key}_hours24"] = h

    summary = {
        "component": label,
        "samples": len(q),
        "q_p05": qtile(q)[0],
        "q_p50": qtile(q)[1],
        "q_p95": qtile(q)[2],
        "M_inf_p05": qtile(m)[0],
        "M_inf_p50": qtile(m)[1],
        "M_inf_p95": qtile(m)[2],
        "r_g_km_p05": qtile(rg)[0],
        "r_g_km_p50": qtile(rg)[1],
        "r_g_km_p95": qtile(rg)[2],
        "x_minus_p05": qtile(xm)[0],
        "x_minus_p50": qtile(xm)[1],
        "x_minus_p95": qtile(xm)[2],
        "r_minus_km_p05": qtile(rminus)[0],
        "r_minus_km_p50": qtile(rminus)[1],
        "r_minus_km_p95": qtile(rminus)[2],
        "N_BH_p05": qtile(N)[0],
        "N_BH_p50": qtile(N)[1],
        "N_BH_p95": qtile(N)[2],
        "x_N_p05": qtile(xN)[0],
        "x_N_p50": qtile(xN)[1],
        "x_N_p95": qtile(xN)[2],
        "r_N_km_p05": qtile(rN)[0],
        "r_N_km_p50": qtile(rN)[1],
        "r_N_km_p95": qtile(rN)[2],
        "alpha_N_p05": qtile(alphaN)[0],
        "alpha_N_p50": qtile(alphaN)[1],
        "alpha_N_p95": qtile(alphaN)[2],
        "N_mode_core_hours_per_24h_p05": qtile(tN)[0],
        "N_mode_core_hours_per_24h_p50": qtile(tN)[1],
        "N_mode_core_hours_per_24h_p95": qtile(tN)[2],
    }
    samples = {
        "q": q,
        "M_inf": m,
        "r_g_km": rg,
        "x_minus": xm,
        "r_minus_km": rminus,
        "N_BH": N,
        "x_N": xN,
        "r_N_km": rN,
        "alpha_N": alphaN,
        "N_mode_hours24": tN,
        **per_sample,
    }
    return summary, item_rows, samples


def sanitize_branch(branch: str) -> str:
    return re.sub(r"[^A-Za-z0-9._-]+", "_", branch)


def read_csv_dicts(path: Path):
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))
