# Catalog-wide synthesis evidence

This directory contains only the numerical synthesis registries and compact summary tables used to support the catalog-wide statements in the final manuscript. Section-development TeX fragments, intermediate build audits, and rewrite notes have been removed because the integrated manuscript under `MANUSCRIPT/` is the sole publication source.

`CPTG_GWTC5_SYNTHESIS_AUDIT_v2.json` verifies the retained row counts, the common 520-component key set across Structural-Mode, core-time, and rotation registries, the population summary against the authoritative population result, and SHA-256 identities for every retained synthesis CSV.
