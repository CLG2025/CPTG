# CPTG GWTC-5 Candidate Taxonomy v1

This is Step 2 of the manuscript reorganization.

## Primary manuscript organization

The 260 unique numerical candidate streams are divided into five empirical observational mass regimes using Jenks natural breaks (k=5) on detector-frame total mass constructed from the released component marginal medians.

- M1 — Lower observed-mass regime: 82 streams / 82 events; 13.911–55.527 M_sun
- M2 — Intermediate observed-mass regime: 94 streams / 94 events; 57.388–105.052 M_sun
- M3 — Upper observed-mass regime: 47 streams / 47 events; 107.782–148.961 M_sun
- M4 — High observed-mass regime: 30 streams / 30 events; 153.138–198.821 M_sun
- M5 — Extreme observed-mass regime: 7 streams / 6 events; 242.018–327.048 M_sun

These are observational classes. No CPTG output is used to assign them.

## Cross-cutting descriptors

- mass ratio: three Jenks regimes;
- luminosity distance: three Jenks regimes for observational context;
- broad-posterior flag: top 10% of the maximum fractional 5th–95th half-width across D_L, detector m1, and detector m2;
- branch-provenance flag for the two distinct GW231123_135430 numerical streams.

Attached exterior-spin medians are placed in screening bands only. They are not used for taxonomy because the frozen evidence preserves them attached to post-handoff compact identities rather than as release-order spin marginal summaries.

## Extreme observed-mass section

- GW190521_030229: 242.018 M_sun
- GW230922_040658: 249.638 M_sun
- GW231005_021030: 259.443 M_sun
- GW231028_153006: 260.645 M_sun
- GW230704_212616: 289.343 M_sun
- GW231123_135430 :: C00:Mixed+XO4a: 325.204 M_sun
- GW231123_135430 :: C00:Mixed: 327.048 M_sun

## Recommended manuscript use

Use M1 through M5 as the primary candidate sections. Within each section, write one candidate subsection using the existing component-detail and radial-profile datasets. Use asymmetry, distance, uncertainty, and eventually raw release-order spin as cross-cutting synthesis topics rather than allowing downstream CPTG quantities to define the classes.
