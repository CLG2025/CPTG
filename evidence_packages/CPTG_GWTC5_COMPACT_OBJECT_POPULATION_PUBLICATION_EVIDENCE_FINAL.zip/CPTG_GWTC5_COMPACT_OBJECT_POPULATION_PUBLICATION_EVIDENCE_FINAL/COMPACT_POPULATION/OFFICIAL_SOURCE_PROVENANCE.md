# Official GWTC-5 Authorities and Source Provenance

1. **GWTC-5.0: Population Properties of Merging Compact Binaries** — arXiv:2605.27226; LIGO document P2600045-v7. This defines the 259-event BBH analysis set and the published low-mass selection caution.

2. **GWTC-5.0 population data release** — Zenodo DOI 10.5281/zenodo.20292639. The exact `default_mmax` popsummary input used here has SHA-256 `aa159c4259ccdbb9140d4ab65382095f4744ef42d7531dc727f19e75d19ef048`.

3. **Event parameter-estimation releases** — the 259 event files are identified individually in `EVENT_SOURCE_IDENTITIES.csv`. The source records used are Zenodo 6513631, 22685054, 20275769, 20348005, and 20348006; the table records the exact event-to-record assignment, official MD5, local SHA-256, size, and acquisition status.

## Coordinate provenance

Event luminosity-distance posteriors are direct observational inputs to the CPTG observation map. The population redshift grid is a released model-dependent coordinate and is decoded back to luminosity distance with the documented GWTC reference convention before the CPTG map is applied. The frozen r19 result ZIP is the population authority for this publication.
