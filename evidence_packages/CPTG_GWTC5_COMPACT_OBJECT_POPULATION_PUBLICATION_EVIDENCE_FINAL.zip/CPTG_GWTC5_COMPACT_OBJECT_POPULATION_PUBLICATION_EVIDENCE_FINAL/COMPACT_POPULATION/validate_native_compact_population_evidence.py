from pathlib import Path
import csv, json, hashlib, io, zipfile, math, re
import numpy as np
from numpy.polynomial import Polynomial
from numpy.polynomial.legendre import leggauss

ROOT=Path(__file__).resolve().parent
V2A_SHA="4e18154d11dd3e03ddbf64de7eae98a4d04d35efdd5c85737bd72a9eb0cf3555"
R19_SHA="0666efe47a039e9e809df434b46f126424b82970eb20c82ce5041b6e90af5567"
POP_SHA="aa159c4259ccdbb9140d4ab65382095f4744ef42d7531dc727f19e75d19ef048"

def sha(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        for b in iter(lambda:f.read(8*1024*1024),b''): h.update(b)
    return h.hexdigest()
def rows(p):
    with open(p,newline='',encoding='utf-8-sig') as f: return list(csv.DictReader(f))
def q(a,p): return float(np.quantile(np.asarray(a,float),p))
def check(cond,msg):
    if not cond: raise RuntimeError('FAIL-CLOSED: '+msg)

v2a=ROOT/'FROZEN_EVENT_POPULATION_BASELINE_v2a_RESULTS.zip'
r19=ROOT/'FROZEN_NATIVE_COORDINATE_POPULATION_r19_RESULTS.zip'
check(sha(v2a)==V2A_SHA,'frozen v2a identity')
check(sha(r19)==R19_SHA,'frozen r19 identity')

with zipfile.ZipFile(r19) as z:
    check(z.testzip() is None,'r19 ZIP integrity')
    for line in z.read('MANIFEST_SHA256.txt').decode().splitlines():
        if not line.strip(): continue
        parts=line.split('  ')
        d,n=parts[0],parts[1]
        check(hashlib.sha256(z.read(n)).hexdigest()==d,'r19 manifest '+n)
with zipfile.ZipFile(v2a) as z:
    check(z.testzip() is None,'v2a ZIP integrity')
    for line in z.read('RESULTS_SHA256.txt').decode().splitlines():
        if not line.strip(): continue
        d,n,_=line.split('  ')
        check(hashlib.sha256(z.read(n)).hexdigest()==d,'v2a manifest '+n)

# Event authority.
ev=rows(ROOT/'EVENT_BRANCH_CPTG_SUMMARY.csv')
us=rows(ROOT/'EVENT_CPTG_USABILITY.csv')
rej=rows(ROOT/'EVENT_BRANCH_REJECTIONS.csv')
struct=rows(ROOT/'EVENT_BRANCH_STRUCTURAL_MODE_N.csv')
check(len(ev)==288 and len({r['event'] for r in ev})==259,'event branch counts')
check(len(us)==259 and all(r['event_status']=='USABLE' for r in us),'259/259 event usability')
check(len(rej)==0,'no branch rejections')
check(len(struct)==288,'Structural Mode row count')

# Paired-label topology.
g={}
for r in ev: g.setdefault(r['event'],[]).append(r)
pairs=[k for k,v in g.items() if len(v)==2]
check(len(pairs)==29,'two-label event count')
idcols={'event','file','branch_mode','posterior_branch'}
numcols=[c for c in ev[0] if c not in idcols]
ident=0; distinct=[]
for k in pairs:
    v=g[k]
    same=all(v[0][c]==v[1][c] for c in numcols)
    if same: ident+=1
    else: distinct.append(k)
check(ident==28 and distinct==['GW231123_135430'],'paired-label identity topology')

# Recompute Structural N with split Gauss-Legendre quadrature.
U=Polynomial([0,0,0,63/8,0,-90/8,0,35/8])
UP=U.deriv(); UOX=Polynomial([0,0,63/8,0,-90/8,0,35/8])
C=U*U+UP*UP+2*(UOX*UOX); CP=C.deriv()
breaks=[0.0,0.5651996425788532,0.8326202762571817,0.9551995472802848,1.0]
gl_x,gl_w=leggauss(96)
def integ(fun):
    s=0.0
    for lo,hi in zip(breaks[:-1],breaks[1:]):
        x=.5*(hi-lo)*gl_x+.5*(hi+lo)
        s += .5*(hi-lo)*np.sum(gl_w*fun(x))
    return float(s)
W0=integ(lambda x: np.abs(CP(x)))
def nbh(a):
    a=abs(float(a))
    den=integ(lambda x: (x*(x*x+a*a)/(1+a*a))**(1/3)*np.abs(CP(x)))
    return W0/den
bykey={(r['event'],r['posterior_branch']):r for r in struct}
max_n=0.0
for r in ev:
    s=bykey[(r['event'],r['posterior_branch'])]
    for comp in (1,2):
        for nq,aq in [('05','95'),('50','50'),('95','05')]:
            max_n=max(max_n,abs(float(s[f'N_BH_{comp}_p{nq}'])-nbh(float(r[f'a_inf_{comp}_p{aq}']))))
check(max_n<2e-9,f'Structural Mode recomputation {max_n}')
check(abs(nbh(0.0)-1.912233171442)<2e-12,'Structural Mode spherical limit')

# Native population authority.
pop=rows(ROOT/'POPULATION_HYPERPOSTERIOR_NATIVE_CPTG.csv')
th=rows(ROOT/'POPULATION_THRESHOLD_POSTERIOR_NATIVE_CPTG.csv')
coord=rows(ROOT/'POPULATION_COORDINATE_DIAGNOSTIC.csv')
summ=json.loads((ROOT/'POPULATION_NATIVE_CPTG_SUMMARY.json').read_text())
fa=json.loads((ROOT/'NATIVE_COORDINATE_FINAL_AUDIT.json').read_text())
check(fa['status']=='PASS_NATIVE_COORDINATE_POPULATION_CORRECTION','r19 status')
check(fa['population_sha256']==POP_SHA,'population HDF identity')
check(fa['rows']==8200 and fa['draws_per_row']==512 and fa['propagated_realizations']==4198400,'population counts')
check(fa['event_side_changed'] is False and fa['double_projection_guard'] is True and fa['v2a_regression_pass'] is True,'r19 guards')
check(len(pop)==len(th)==len(coord)==8200,'native population table counts')
ids=list(range(8200))
check([int(r['hyperposterior_row']) for r in pop]==ids,'population row IDs')
check([int(r['hyperposterior_row']) for r in th]==ids,'threshold row IDs')
check([int(r['hyperposterior_row']) for r in coord]==ids,'coordinate row IDs')

# Recompute r19 summary values from distributed CSVs.
for key,stat in summ['quantities'].items():
    vals=[float(r[key]) for r in pop]
    got={'mean':float(np.mean(vals)),'p05':q(vals,.05),'p50':q(vals,.5),'p95':q(vals,.95)}
    for k,v in got.items(): check(abs(v-float(stat[k]))<2e-12,f'population summary {key} {k}')
for key,stat in summ['coordinate_readouts'].items():
    vals=[float(r[key]) for r in coord]
    got={'mean':float(np.mean(vals)),'p05':q(vals,.05),'p50':q(vals,.5),'p95':q(vals,.95)}
    for k,v in got.items(): check(abs(v-float(stat[k]))<2e-12,f'coordinate summary {key} {k}')
for tag,block in summ['anchors'].items():
    for key,stat in block.items():
        vals=[float(r[key]) for r in th]
        got={'mean':float(np.mean(vals)),'p05':q(vals,.05),'p50':q(vals,.5),'p95':q(vals,.95)}
        for k,v in got.items(): check(abs(v-float(stat[k]))<2e-12,f'anchor {tag} {key} {k}')

# Regression to exact frozen v2a decoder-based physical population outputs.
with zipfile.ZipFile(v2a) as z:
    vpop=list(csv.DictReader(io.StringIO(z.read('POPULATION_HYPERPOSTERIOR_CPTG.csv').decode())))
    vth=list(csv.DictReader(io.StringIO(z.read('POPULATION_THRESHOLD_POSTERIOR.csv').decode())))
shared=['release_m1_median','release_m2_median','cptg_m_inf_1_median','cptg_m_inf_2_median','cptg_m_c_1_median','cptg_m_c_2_median','cptg_f_geom_1_median','cptg_f_geom_2_median','cptg_A_pol_1_median','cptg_A_pol_2_median','reorder_fraction']
mx=0.0
for a,b in zip(pop,vpop):
    for k in shared: mx=max(mx,abs(float(a[k])-float(b[k])))
    mx=max(mx,abs(float(a['cptg_z_pi_median'])-float(b['cptg_z_median'])))
check(mx<5e-9,f'r19/v2a population regression {mx}')
mxth=0.0
for a,b in zip(th,vth):
    for k in a:
        if k!='hyperposterior_row': mxth=max(mxth,abs(float(a[k])-float(b[k])))
check(mxth<5e-12,f'r19/v2a threshold regression {mxth}')

# Source registry identity structure.
src=rows(ROOT/'EVENT_SOURCE_IDENTITIES.csv')
loc=rows(ROOT/'LOCAL_259_PE_ARCHIVE.csv')
check(len(src)==len(loc)==259,'source registry row count')
sm={r['event']:r for r in src}; lm={r['event']:r for r in loc}
check(set(sm)==set(lm),'source registry event set')
for e in sm:
    a,b=sm[e],lm[e]
    check(a['official_filename']==b['filename'] and a['local_sha256']==b['local_sha256'] and a['official_md5']==b['official_md5'],'source identity '+e)

print('CPTG GWTC-5 NATIVE COMPACT/POPULATION EVIDENCE VALIDATION')
print('events',len({r['event'] for r in ev}))
print('release-label rows',len(ev))
print('native population rows',len(pop))
print('propagated realizations',8200*512)
print('max Structural-N recomputation abs',repr(max_n))
print('max r19-v2a physical population abs',repr(mx))
print('max r19-v2a threshold abs',repr(mxth))
print('STATUS=PASS_NATIVE_COMPACT_POPULATION_EVIDENCE')
