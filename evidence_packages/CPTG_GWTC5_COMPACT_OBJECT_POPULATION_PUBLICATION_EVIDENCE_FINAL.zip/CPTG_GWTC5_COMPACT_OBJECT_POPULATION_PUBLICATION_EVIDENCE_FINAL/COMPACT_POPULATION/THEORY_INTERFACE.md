# Theory Interface

The observational and theory-side coordinates are kept separate.

Event lane:
`observed D_L + detector-frame masses/spin magnitudes -> CPTG affine luminosity observation map -> native z_pi -> M_inf -> compact handoff -> M_c + M_geom`.

Population lane:
`released GWTC z -> documented GWTC coordinate decoder -> recovered D_L -> CPTG affine luminosity observation map -> native z_pi -> M_inf -> compact handoff -> M_c + M_geom`.

The external GWTC $H_0$ and $\Omega_m$ values are decoder parameters for the released population coordinate only; they are not CPTG-native inputs. The phase-dependent equivalent-standard native coordinate is a downstream comparison readout only.

Structural Mode $N_{\rm BH}$ is evaluated after compact closure and is never used as a fit parameter, branch selector, or gravity-strength parameter.
