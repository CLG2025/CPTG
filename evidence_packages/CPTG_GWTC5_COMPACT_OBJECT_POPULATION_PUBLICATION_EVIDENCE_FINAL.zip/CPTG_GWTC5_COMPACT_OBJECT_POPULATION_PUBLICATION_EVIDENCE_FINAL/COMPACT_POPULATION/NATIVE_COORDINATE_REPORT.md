# CPTG GWTC-5 Native-Coordinate Population Correction r19

Status: **PASS_NATIVE_COORDINATE_POPULATION_CORRECTION**

This stage corrects the 8,200-row official `default_mmax` population push-forward. The released population redshift is first decoded to luminosity distance using its documented GWTC reference coordinate (H0=67.9, Omega_m=0.3065). That external cosmology is used only as a decoder of the released coordinate. The fixed luminosity distance is then inverted through the registered CPTG affine luminosity observation map to recover the native phase z_pi. Detector-frame mass is reconstructed implicitly through the exact scale (1+z_release)/(1+z_pi), after which the existing compact mass-spin handoff is applied unchanged.

The native GWTC comparison coordinate is calculated afterward as a reporting diagnostic only. It never feeds back into z_pi, masses, spins, or the compact solve. This is the explicit guard against the r18 double projection.

## Population medians across hyperposterior-row medians

- released primary mass: 10.243071105 Msun
- CPTG exterior component 1: 9.623446302 Msun
- CPTG physical component 1: 6.506707228 Msun
- released secondary mass: 8.507142097 Msun
- CPTG exterior component 2: 8.406749977 Msun
- CPTG physical component 2: 4.837247973 Msun
- CPTG native phase z_pi: 1.528041386

## Native GWTC comparison readout

Median of the 8,200 row-median equivalent-standard native coordinates: **71.741361056 km s^-1 Mpc^-1**. This is a comparison coordinate, not a fitted CPTG H0.

## Regression

The active population transform reproduces the original v2a external-coordinate decoder medians to <= 5e-10. The later acoustic->luminosity population remap is therefore retired for this data product.
