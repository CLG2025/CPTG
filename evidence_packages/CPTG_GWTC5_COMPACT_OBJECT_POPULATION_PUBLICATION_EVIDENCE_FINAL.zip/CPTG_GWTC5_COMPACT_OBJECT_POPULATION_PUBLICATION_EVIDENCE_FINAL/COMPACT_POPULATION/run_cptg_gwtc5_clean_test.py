#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import re
import shutil
import sys
import zipfile
from pathlib import Path

import h5py
import numpy as np

ROOT=Path(__file__).resolve().parent
STAGE="CPTG_GWTC5_COMPACT_POPULATION_CLEAN_TEST_v2a"

# ---------------------------------------------------------------------------
# Official local inputs
# ---------------------------------------------------------------------------

PE_ROOT=Path(r"F:\CPTG-GWTC5\pe\full_259")
POPULATION_HDF=Path(
    r"E:\CPTG-GWTC5\popsummary_files\gwtc5_updated_default_mmax_mass_"
    r"TwoPeakBrokenPowerLawSmoothedMassDistribution_redshift_PowerLawRedshift_"
    r"magnitude_iid_spin_magnitude_gaussian_tilt_iid_spin_orientation_"
    r"popsummary_result.h5"
)
EXPECTED_POPULATION_SHA256=(
    "aa159c4259ccdbb9140d4ab65382095f4744ef42d7531dc727f19e75d19ef048"
)

EXPECTED_EVENT_COUNT=259

# Published GWTC-5 population-feature anchors. They are diagnostics only;
# they do not enter the CPTG solve.
ANCHORS=np.asarray([10.0,35.0,40.0,45.0],float)
ANCHOR_RESOLUTION_PROB=0.95

# Efficient population push-forward: deterministic stratification for m1,z,
# fixed-seed conditional q/spin draws. No row search or row ranking.
DRAWS_PER_HYPERROW=512
POPULATION_SEED=520259
HIST_EDGES=np.arange(0.0,152.0,2.0)

# Released GWTC population redshift convention used only to reconstruct
# luminosity distance from the official population z grid.
H0_RELEASE=67.9
OMEGA_M_RELEASE=0.3065

# Registered CPTG luminosity comparison coordinate.
C_KM_S=299792.458
B_PI=1.0-1.0/math.pi
T_PI=1.0/math.pi
H0_PI=69.4162507897
GAMMA_L_AFF=math.sqrt(10.0/9.0)
H0_CPTG_AFF=H0_PI*GAMMA_L_AFF

# Solar gravitational radius GM_sun/c^2 in km.
GM_SUN_C2_KM=1.4766250385

# Numerical closure only. These are not scientific-fit tolerances.
MAX_CUBIC_ABS=2e-12
MAX_MASS_DECOMP_REL=2e-12
MAX_DETECTOR_SOURCE_IDENTITY_REL=1e-4
MAX_STRATIFIED_M1_ANCHOR_ERROR=1.1/DRAWS_PER_HYPERROW

EVENT_RE=re.compile(r"(GW\d{6}_\d{6})")
EVENT_FIELDS={
    "mass_1_source","mass_ratio","redshift","luminosity_distance",
    "mass_1","mass_2","a_1","a_2"
}

# ---------------------------------------------------------------------------
# Generic utilities
# ---------------------------------------------------------------------------

def fail(msg):
    raise RuntimeError("FAIL-CLOSED: "+msg)

def sha256(path,chunk=8*1024*1024):
    h=hashlib.sha256()
    with open(path,"rb") as f:
        for b in iter(lambda:f.read(chunk),b""):
            h.update(b)
    return h.hexdigest()

def decode_list(v):
    out=[]
    for x in list(v):
        out.append(x.decode() if isinstance(x,(bytes,np.bytes_)) else str(x))
    return out

def write_csv(path,records,fields=None):
    path.parent.mkdir(parents=True,exist_ok=True)
    if fields is None:
        fields=[]
        for r in records:
            for k in r:
                if k not in fields:
                    fields.append(k)
    with path.open("w",newline="",encoding="utf-8") as f:
        w=csv.DictWriter(f,fieldnames=fields)
        w.writeheader()
        if records:
            w.writerows(records)

def q90(x):
    x=np.asarray(x,float)
    return {
        "p05":float(np.quantile(x,.05)),
        "p50":float(np.quantile(x,.50)),
        "p95":float(np.quantile(x,.95)),
    }

def summarize(x):
    a=np.asarray(x,float)
    return {
        "p05":float(np.quantile(a,.05)),
        "p50":float(np.quantile(a,.50)),
        "p95":float(np.quantile(a,.95)),
        "mean":float(np.mean(a)),
    }

# ---------------------------------------------------------------------------
# Distance coordinates
# ---------------------------------------------------------------------------

def cumulative_trapz(y,x):
    y=np.asarray(y,float); x=np.asarray(x,float)
    seg=.5*(y[:-1]+y[1:])*np.diff(x)
    return np.concatenate(([0.0],np.cumsum(seg)))

def cptg_E(z):
    z=np.asarray(z,float)
    return np.sqrt(B_PI+T_PI*(1.0+z)**math.pi)

def release_E(z):
    z=np.asarray(z,float)
    return np.sqrt(OMEGA_M_RELEASE*(1.0+z)**3+(1.0-OMEGA_M_RELEASE))

def luminosity_distance_grid(zmax,h0,efunc,n=180001):
    z=np.linspace(0.0,float(zmax),int(n))
    integ=cumulative_trapz(1.0/efunc(z),z)
    dl=(1.0+z)*(C_KM_S/h0)*integ
    return z,dl

class CPTGDistanceInverter:
    """
    Dynamic D_L -> z_CPTG inverter.

    The inversion domain is an implementation cache, not a physical or
    population-model boundary. It automatically expands to the largest
    finite observed luminosity distance actually encountered.
    """
    def __init__(self):
        self.zmax=0.0
        self.z=np.asarray([0.0,1.0])
        self.dl=np.asarray([0.0,1.0])
        self.expansions=0
        self.ensure_dl(1.0)

    def ensure_dl(self,max_dl):
        max_dl=float(max_dl)
        if not math.isfinite(max_dl) or max_dl<0:
            fail(f"invalid luminosity-distance maximum {max_dl}")
        if self.dl[-1] >= max_dl*1.000001+1e-10:
            return
        zmax=max(2.0,self.zmax if self.zmax>0 else 2.0)
        while True:
            z,dl=luminosity_distance_grid(zmax,H0_CPTG_AFF,cptg_E)
            if dl[-1] >= max_dl*1.000001+1e-10:
                self.zmax=zmax
                self.z=z
                self.dl=dl
                self.expansions+=1
                return
            zmax*=1.8
            if zmax>100:
                fail("unable to bracket observed luminosity distance in CPTG")

    def invert(self,dl):
        x=np.asarray(dl,float)
        if np.any(~np.isfinite(x)) or np.any(x<0):
            fail("invalid luminosity distance")
        self.ensure_dl(float(np.max(x)))
        return np.interp(x,self.dl,self.z)

def release_dl_from_z(z):
    z=np.asarray(z,float)
    if np.any(~np.isfinite(z)) or np.any(z<0):
        fail("invalid release redshift")
    zmax=max(float(np.max(z))*1.001+1e-8,.1)
    zg,dg=luminosity_distance_grid(zmax,H0_RELEASE,release_E)
    return np.interp(z,zg,dg)

# ---------------------------------------------------------------------------
# CPTG minimum compact mass-spin handoff
# ---------------------------------------------------------------------------

def polarization_factor(a_inf):
    a=np.asarray(a_inf,float)
    if np.any(~np.isfinite(a)) or np.any(a<0) or np.any(a>1):
        fail("exterior spin magnitude outside [0,1]")

    lo=np.ones_like(a)
    hi=np.full_like(a,2.0)
    for _ in range(80):
        mid=.5*(lo+hi)
        f=a*a*mid**3+mid-2.0
        hi=np.where(f>0,mid,hi)
        lo=np.where(f<=0,mid,lo)
    A=.5*(lo+hi)
    residual=a*a*A**3+A-2.0
    if float(np.max(np.abs(residual)))>MAX_CUBIC_ABS:
        fail("compact mass-spin cubic closure failed")
    return A

def map_compact_pair(m1_inf,m2_inf,a1_inf,a2_inf):
    m1=np.asarray(m1_inf,float); m2=np.asarray(m2_inf,float)
    a1=np.asarray(a1_inf,float); a2=np.asarray(a2_inf,float)

    A1=polarization_factor(a1)
    A2=polarization_factor(a2)

    c1=m1/A1
    c2=m2/A2
    ac1=a1*A1*A1
    ac2=a2*A2*A2
    g1=m1-c1
    g2=m2-c2
    f1=g1/m1
    f2=g2/m2

    e1=np.abs((c1+g1)-m1)/np.maximum(m1,1.0)
    e2=np.abs((c2+g2)-m2)/np.maximum(m2,1.0)
    decomp=max(float(np.max(e1)),float(np.max(e2)))
    if decomp>MAX_MASS_DECOMP_REL:
        fail("compact mass decomposition closure failed")
    if np.any(ac1>1+2e-11) or np.any(ac2>1+2e-11):
        fail("compact source spin exceeded unity")

    # Preserve component identity through the handoff, then order source mass,
    # carrying its corresponding exterior/source spin and decomposition.
    swap=c2>c1
    def order(x1,x2):
        return np.where(swap,x2,x1),np.where(swap,x1,x2)

    mc1,mc2=order(c1,c2)
    mi1,mi2=order(m1,m2)
    ain1,ain2=order(a1,a2)
    ac_1,ac_2=order(ac1,ac2)
    Ap1,Ap2=order(A1,A2)
    mg1,mg2=order(g1,g2)
    fg1,fg2=order(f1,f2)

    return {
        "m_inf_1":mi1,"m_inf_2":mi2,
        "m_c_1":mc1,"m_c_2":mc2,
        "m_geom_1":mg1,"m_geom_2":mg2,
        "f_geom_1":fg1,"f_geom_2":fg2,
        "A_pol_1":Ap1,"A_pol_2":Ap2,
        "a_inf_1":ain1,"a_inf_2":ain2,
        "a_c_1":ac_1,"a_c_2":ac_2,
        "r_match_1_km":GM_SUN_C2_KM*mi1,
        "r_match_2_km":GM_SUN_C2_KM*mi2,
        "q_inf":mi2/mi1,
        "q_c":mc2/mc1,
        "reordered":swap,
        "max_cubic_abs":max(
            float(np.max(np.abs(a1*a1*A1**3+A1-2.0))),
            float(np.max(np.abs(a2*a2*A2**3+A2-2.0))),
        ),
        "max_decomp_rel":decomp,
    }

# ---------------------------------------------------------------------------
# Event posteriors: retain objects, reject only unusable branches
# ---------------------------------------------------------------------------

def posterior_candidates(h):
    found=[]
    def visitor(name,obj):
        if isinstance(obj,h5py.Dataset) and name.endswith("posterior_samples"):
            names=set(obj.dtype.names or ())
            if EVENT_FIELDS.issubset(names):
                parent=name.rsplit("/posterior_samples",1)[0]
                label=parent.split("/")[-1]
                found.append((name,label,len(obj)))
    h.visititems(visitor)
    return found

def choose_branch_ensemble(h):
    """
    Prefer official waveform-marginalized Mixed branches. If none are present,
    retain all branches in the best available XPHM family. Equal branches are
    kept separately; they are never pooled as independent observations.
    """
    c=posterior_candidates(h)
    if not c:
        return [],"NO_USABLE_POSTERIOR_BRANCH"

    mixed=sorted([x for x in c if "mixed" in x[1].lower()],key=lambda x:x[1])
    if mixed:
        return mixed,"MIXED_WAVEFORM_ENSEMBLE"

    st=sorted(
        [x for x in c if "imrphenomxphm-spintaylor" in x[1].lower()],
        key=lambda x:x[1]
    )
    if st:
        return st,"XPHM_SPINTAYLOR_ENSEMBLE"

    xp=sorted(
        [x for x in c if "imrphenomxphm" in x[1].lower()],
        key=lambda x:x[1]
    )
    if xp:
        return xp,"XPHM_ENSEMBLE"

    # Last resort: all schema-compatible released branches.
    return sorted(c,key=lambda x:x[1]),"SCHEMA_COMPATIBLE_FALLBACK"

def event_file_map():
    if not PE_ROOT.is_dir():
        fail(f"PE root missing: {PE_ROOT}")
    files=[]
    for ext in ("*.h5","*.hdf5"):
        files.extend(PE_ROOT.rglob(ext))
    by={}
    for p in files:
        m=EVENT_RE.search(p.name)
        if m:
            by.setdefault(m.group(1),[]).append(p)
    if len(by)!=EXPECTED_EVENT_COUNT:
        fail(f"expected {EXPECTED_EVENT_COUNT} event files, found {len(by)} events")
    dup={k:v for k,v in by.items() if len(v)!=1}
    if dup:
        fail(f"duplicate local PE files for {len(dup)} events")
    return {k:v[0] for k,v in by.items()}

def branch_transform(event,path,dspath,label,branch_mode,inverter):
    with h5py.File(path,"r") as h:
        ds=h[dspath]
        arr=ds.fields(sorted(EVENT_FIELDS))[:]

    m1s=np.asarray(arr["mass_1_source"],float)
    q=np.asarray(arr["mass_ratio"],float)
    zrel=np.asarray(arr["redshift"],float)
    dl=np.asarray(arr["luminosity_distance"],float)
    m1d=np.asarray(arr["mass_1"],float)
    m2d=np.asarray(arr["mass_2"],float)
    a1=np.asarray(arr["a_1"],float)
    a2=np.asarray(arr["a_2"],float)
    m2s=m1s*q

    finite=(
        np.isfinite(m1s)&np.isfinite(q)&np.isfinite(zrel)&np.isfinite(dl)&
        np.isfinite(m1d)&np.isfinite(m2d)&np.isfinite(a1)&np.isfinite(a2)
    )
    if not np.any(finite):
        raise RuntimeError("no finite posterior samples")

    m1s=m1s[finite]; m2s=m2s[finite]; zrel=zrel[finite]; dl=dl[finite]
    m1d=m1d[finite]; m2d=m2d[finite]; a1=a1[finite]; a2=a2[finite]

    if np.any(m1d<=0) or np.any(m2d<=0) or np.any(dl<0):
        raise RuntimeError("nonphysical mass/distance samples")
    if np.any(a1<0) or np.any(a1>1) or np.any(a2<0) or np.any(a2>1):
        raise RuntimeError("spin magnitude outside [0,1]")

    rel1=np.abs(m1d-m1s*(1+zrel))/np.maximum(m1d,1.0)
    rel2=np.abs(m2d-m2s*(1+zrel))/np.maximum(m2d,1.0)
    idres=max(float(np.max(rel1)),float(np.max(rel2)))
    if idres>MAX_DETECTOR_SOURCE_IDENTITY_REL:
        raise RuntimeError(
            f"detector/source mass identity residual {idres:.6g} exceeds "
            f"{MAX_DETECTOR_SOURCE_IDENTITY_REL}"
        )

    # Observed luminosity distance is the observational input. Inversion is
    # dynamically extended to the full posterior support.
    zc=inverter.invert(dl)
    m1inf=m1d/(1.0+zc)
    m2inf=m2d/(1.0+zc)
    mapped=map_compact_pair(m1inf,m2inf,a1,a2)

    rec={
        "event":event,
        "file":str(path),
        "branch_mode":branch_mode,
        "posterior_branch":label,
        "posterior_samples_total":len(arr),
        "posterior_samples_finite":len(dl),
        "finite_fraction":len(dl)/len(arr),
        "detector_source_identity_max_rel":idres,
        "cptg_cubic_max_abs":mapped["max_cubic_abs"],
        "cptg_mass_decomposition_max_rel":mapped["max_decomp_rel"],
        "reorder_fraction":float(np.mean(mapped["reordered"])),
    }

    quantities={
        "release_z":zrel,
        "observed_dl_Mpc":dl,
        "detector_m1":m1d,
        "detector_m2":m2d,
        "cptg_z":zc,
        "m_inf_1":mapped["m_inf_1"],
        "m_inf_2":mapped["m_inf_2"],
        "m_c_1":mapped["m_c_1"],
        "m_c_2":mapped["m_c_2"],
        "m_geom_1":mapped["m_geom_1"],
        "m_geom_2":mapped["m_geom_2"],
        "f_geom_1":mapped["f_geom_1"],
        "f_geom_2":mapped["f_geom_2"],
        "A_pol_1":mapped["A_pol_1"],
        "A_pol_2":mapped["A_pol_2"],
        "a_inf_1":mapped["a_inf_1"],
        "a_inf_2":mapped["a_inf_2"],
        "a_c_1":mapped["a_c_1"],
        "a_c_2":mapped["a_c_2"],
        "r_match_1_km":mapped["r_match_1_km"],
        "r_match_2_km":mapped["r_match_2_km"],
        "q_inf":mapped["q_inf"],
        "q_c":mapped["q_c"],
    }
    for name,x in quantities.items():
        s=q90(x)
        for k,v in s.items():
            rec[f"{name}_{k}"]=v

    diagnostics=[]
    for t in ANCHORS:
        for comp,key in (("m1","m_c_1"),("m2","m_c_2")):
            x=mapped[key]
            pabove=float(np.mean(x>=t))
            if pabove>=ANCHOR_RESOLUTION_PROB:
                status="RESOLVED_ABOVE"
            elif pabove<=1.0-ANCHOR_RESOLUTION_PROB:
                status="RESOLVED_BELOW"
            else:
                status="UNRESOLVED_NOISE"
            diagnostics.append({
                "event":event,
                "posterior_branch":label,
                "branch_mode":branch_mode,
                "component":comp,
                "anchor_Msun":float(t),
                "p_above":pabove,
                "status":status,
            })

    return rec,diagnostics

def process_events(inverter):
    fmap=event_file_map()
    branch_rows=[]
    diag_rows=[]
    reject_rows=[]
    event_rows=[]

    for k,event in enumerate(sorted(fmap)):
        path=fmap[event]
        with h5py.File(path,"r") as h:
            branches,mode=choose_branch_ensemble(h)

        good=[]
        event_diags=[]
        if not branches:
            reject_rows.append({
                "event":event,"file":str(path),
                "posterior_branch":"",
                "reason":"NO_SCHEMA_COMPATIBLE_POSTERIOR_BRANCH",
            })
        else:
            for dspath,label,n in branches:
                try:
                    rec,dg=branch_transform(
                        event,path,dspath,label,mode,inverter
                    )
                    good.append(rec)
                    event_diags.extend(dg)
                    branch_rows.append(rec)
                    diag_rows.extend(dg)
                except Exception as exc:
                    reject_rows.append({
                        "event":event,"file":str(path),
                        "posterior_branch":label,
                        "reason":str(exc),
                    })

        if good:
            # Event is retained if at least one official branch supports the
            # compact-state calculation. Alternate branches remain separate
            # sensitivity reconstructions.
            row={
                "event":event,
                "file":str(path),
                "event_status":"USABLE",
                "branch_mode":good[0]["branch_mode"],
                "usable_branch_count":len(good),
                "usable_branches":";".join(r["posterior_branch"] for r in good),
                "rejected_branch_count":sum(
                    r["event"]==event for r in reject_rows
                ),
            }
            for qname in (
                "m_c_1_p50","m_c_2_p50","m_geom_1_p50","m_geom_2_p50",
                "f_geom_1_p50","f_geom_2_p50","A_pol_1_p50","A_pol_2_p50",
                "a_c_1_p50","a_c_2_p50","cptg_z_p50"
            ):
                vals=[float(r[qname]) for r in good]
                row[qname+"_branch_min"]=min(vals)
                row[qname+"_branch_max"]=max(vals)

            # Diagnostic noise affects only that diagnostic, not event retention.
            row["resolved_anchor_branch_tests"]=sum(
                d["status"]!="UNRESOLVED_NOISE" for d in event_diags
            )
            row["unresolved_anchor_branch_tests"]=sum(
                d["status"]=="UNRESOLVED_NOISE" for d in event_diags
            )
            event_rows.append(row)
        else:
            event_rows.append({
                "event":event,
                "file":str(path),
                "event_status":"HARD_REJECT_NO_USABLE_BRANCH",
                "branch_mode":mode,
                "usable_branch_count":0,
                "usable_branches":"",
                "rejected_branch_count":sum(
                    r["event"]==event for r in reject_rows
                ),
                "resolved_anchor_branch_tests":0,
                "unresolved_anchor_branch_tests":0,
            })

        if k==0 or (k+1)%25==0 or k+1==EXPECTED_EVENT_COUNT:
            usable=sum(r["event_status"]=="USABLE" for r in event_rows)
            print(
                f"EVENTS {k+1}/{EXPECTED_EVENT_COUNT} usable={usable}",
                flush=True
            )

    # Cross-branch diagnostic agreement is reported, never used to erase
    # a generally usable compact-state event.
    agreement=[]
    for event in sorted(fmap):
        ed=[d for d in diag_rows if d["event"]==event]
        for t in ANCHORS:
            for comp in ("m1","m2"):
                rr=[
                    d for d in ed
                    if d["anchor_Msun"]==float(t) and d["component"]==comp
                ]
                if not rr:
                    state="NO_USABLE_BRANCH"
                else:
                    states={d["status"] for d in rr}
                    if len(states)==1:
                        state=next(iter(states))
                    elif "UNRESOLVED_NOISE" in states:
                        state="BRANCH_SENSITIVE_OR_UNRESOLVED"
                    else:
                        state="BRANCH_DISAGREEMENT"
                agreement.append({
                    "event":event,"component":comp,"anchor_Msun":float(t),
                    "event_diagnostic_state":state,
                    "usable_branch_count":len(rr),
                })

    return event_rows,branch_rows,diag_rows,agreement,reject_rows

# ---------------------------------------------------------------------------
# Efficient push-forward of the official selection-corrected population
# ---------------------------------------------------------------------------

def planck_taper(m,mlow,delta):
    m=np.asarray(m,float)
    out=np.zeros_like(m)
    if delta<=0:
        out[m>=mlow]=1.0
        return out
    hi=m>=mlow+delta
    mid=(m>=mlow)&(m<mlow+delta)
    out[hi]=1.0
    if np.any(mid):
        xp=m[mid]-mlow
        with np.errstate(divide="ignore",invalid="ignore",over="ignore"):
            A=delta/xp+delta/(xp-delta)
        s=np.empty_like(A)
        pos=A>=0
        s[pos]=np.exp(-A[pos])/(1+np.exp(-A[pos]))
        s[~pos]=1/(1+np.exp(A[~pos]))
        out[mid]=s
    return out

def grid_xy(group,row):
    x=np.asarray(group["positions"],float)
    if x.ndim>1:
        x=x[0]
    y=np.asarray(group["rates"],float)[row]
    y=np.maximum(np.where(np.isfinite(y),y,0.0),0.0)
    return x,y

def grid_cdf(x,y):
    seg=.5*(y[:-1]+y[1:])*np.diff(x)
    c=np.concatenate(([0.0],np.cumsum(seg)))
    if not np.isfinite(c[-1]) or c[-1]<=0:
        fail("invalid population rate-grid normalization")
    return c/c[-1]

def sample_grid_stratified(rng,x,y,n):
    c=grid_cdf(x,y)
    u=(np.arange(n,dtype=float)+.5)/n
    rng.shuffle(u)
    return np.interp(u,c,x)

def exact_grid_fraction_above(x,y,t):
    c=grid_cdf(x,y)
    return 1.0-float(np.interp(float(t),x,c,left=0.0,right=1.0))

def sample_truncated_normal(rng,mu,sigma,lo,hi,n):
    if sigma<=0 or hi<=lo:
        fail("invalid truncated-normal population spin law")
    out=np.empty(n,float); filled=0
    while filled<n:
        x=rng.normal(mu,sigma,max(64,(n-filled)*3))
        x=x[(x>=lo)&(x<=hi)]
        take=min(n-filled,len(x))
        if take:
            out[filled:filled+take]=x[:take]
            filled+=take
    return out

def ensure_primary_support(rng,m1,x,y,mlow):
    m=np.asarray(m1,float).copy()
    c=grid_cdf(x,y)
    bad=m<=mlow
    loops=0
    while np.any(bad):
        loops+=1
        if loops>100:
            fail("could not resample primary masses onto q support")
        m[bad]=np.interp(rng.random(int(np.sum(bad))),c,x)
        bad=m<=mlow
    return m

def power_integral(beta,lo,hi):
    hi=np.asarray(hi,float)
    bp1=float(beta)+1.0
    if abs(bp1)<1e-10:
        return np.log(hi/lo)
    return (np.power(hi,bp1)-lo**bp1)/bp1

def inverse_power_integral(beta,lo,target):
    target=np.asarray(target,float)
    bp1=float(beta)+1.0
    if abs(bp1)<1e-10:
        return lo*np.exp(target)
    base=lo**bp1+bp1*target
    if np.any(base<=0):
        fail("invalid inverse power-integral base")
    return np.power(base,1.0/bp1)

def unique_cdf_for_inverse(x,cdf):
    x=np.asarray(x,float)
    cdf=np.asarray(cdf,float)
    if x.ndim!=1 or cdf.ndim!=1 or len(x)!=len(cdf):
        fail("invalid conditional-mass taper CDF")
    if np.any(~np.isfinite(x)) or np.any(~np.isfinite(cdf)):
        fail("nonfinite conditional-mass taper CDF")
    if np.any(np.diff(cdf)<0):
        fail("nonmonotone conditional-mass taper CDF")

    # Numerical Planck-taper underflow produces repeated zero-CDF values at
    # the lower endpoint. For inversion, retain the last x on each plateau.
    vals,rev_idx=np.unique(cdf[::-1],return_index=True)
    idx=len(cdf)-1-rev_idx
    order=np.argsort(vals)
    cu=vals[order]
    xu=x[idx[order]]
    if len(cu)<2 or cu[0]!=0.0 or cu[-1]<=0:
        fail("degenerate conditional-mass taper CDF")
    return xu,cu

class ConditionalM2Law:
    """
    Numerical conditional law used by the released default mass model:

        p(m2 | m1) ∝ m2^beta S(m2 | mlow, delta),
        mlow < m2 <= m1.

    This is the same QNorm construction used in the earlier registered
    population-density code, but sampled by inverse CDF instead of rejection.
    It cannot stall when m1 lies inside the Planck taper.
    """
    def __init__(self,beta,mlow,delta,max_mass):
        self.beta=float(beta)
        self.mlow=float(mlow)
        self.delta=float(delta)
        self.taper_hi=min(
            self.mlow+max(self.delta,0.0),
            float(max_mass)
        )
        self.tg=None
        self.tcdf=None
        self.Itaper=0.0
        if self.delta>0 and self.taper_hi>self.mlow:
            self.tg=np.linspace(self.mlow,self.taper_hi,4097)
            taper=planck_taper(self.tg,self.mlow,self.delta)
            shape=np.power(self.tg,self.beta)*taper
            shape=np.maximum(
                np.where(np.isfinite(shape),shape,0.0),0.0
            )
            seg=.5*(shape[:-1]+shape[1:])*np.diff(self.tg)
            self.tcdf=np.concatenate(([0.0],np.cumsum(seg)))
            self.Itaper=float(self.tcdf[-1])

    def I(self,m1):
        m1=np.asarray(m1,float)
        out=np.zeros_like(m1)
        valid=m1>self.mlow
        if not np.any(valid):
            return out
        x=m1[valid]
        if self.tg is None:
            out[valid]=power_integral(
                self.beta,self.mlow,x
            )
            return out

        low=x<=self.taper_hi
        vals=np.empty_like(x)
        if np.any(low):
            vals[low]=np.interp(
                x[low],self.tg,self.tcdf
            )
        if np.any(~low):
            vals[~low]=(
                self.Itaper+
                power_integral(
                    self.beta,self.taper_hi,x[~low]
                )
            )
        out[valid]=vals
        return out

    def sample_m2(self,rng,m1):
        m1=np.asarray(m1,float)
        I=np.asarray(self.I(m1),float)
        valid=(m1>self.mlow)&np.isfinite(I)&(I>0)
        if not np.all(valid):
            bad=np.where(~valid)[0]
            fail(
                f"conditional m2 inverse sampler received {len(bad)} "
                "primary masses outside numerical conditional support"
            )

        u=rng.random(len(m1))
        target=u*I
        out=np.empty_like(m1)

        if self.tg is None:
            out[:]=inverse_power_integral(
                self.beta,self.mlow,target
            )
        else:
            xu,cu=unique_cdf_for_inverse(
                self.tg,self.tcdf
            )
            in_taper=target<=self.Itaper

            if np.any(in_taper):
                out[in_taper]=np.interp(
                    target[in_taper],cu,xu
                )

            if np.any(~in_taper):
                out[~in_taper]=inverse_power_integral(
                    self.beta,
                    float(self.taper_hi),
                    target[~in_taper]-self.Itaper
                )

        out=np.minimum(out,m1)
        out=np.maximum(
            out,np.nextafter(self.mlow,np.inf)
        )

        # Exact numerical CDF regression against the same conditional law.
        frac=np.asarray(self.I(out),float)/I
        err=float(np.max(np.abs(frac-u)))
        if not math.isfinite(err) or err>2e-7:
            fail(
                "conditional m2 inverse-CDF regression failed: "
                f"max |F-u|={err}"
            )
        return out

def ensure_joint_mass_support(rng,m1,x,y,law):
    """
    The official primary-mass grid can numerically reach the lower edge where
    the tabulated conditional normalization underflows to zero. Those points
    have no finite numerical QNorm support. Resample only those numerical-zero
    support points from the same official m1 grid.
    """
    m=np.asarray(m1,float).copy()
    c=grid_cdf(x,y)
    bad=(m<=law.mlow)|(law.I(m)<=0)|(~np.isfinite(law.I(m)))
    loops=0
    while np.any(bad):
        loops+=1
        if loops>100:
            fail("could not obtain finite joint mass support")
        m[bad]=np.interp(
            rng.random(int(np.sum(bad))),c,x
        )
        I=law.I(m)
        bad=(m<=law.mlow)|(I<=0)|(~np.isfinite(I))
    return m

def hparam_map(h):
    return {k:i for i,k in enumerate(decode_list(h.attrs["hyperparameters"]))}

def population_pushforward(inverter,out):
    if not POPULATION_HDF.is_file():
        fail(f"population HDF missing: {POPULATION_HDF}")
    print("VERIFY population HDF SHA256...",flush=True)
    if sha256(POPULATION_HDF)!=EXPECTED_POPULATION_SHA256:
        fail("population HDF SHA mismatch")

    rng=np.random.default_rng(POPULATION_SEED)
    hyper_rows=[]
    threshold_rows=[]
    hist_release=[]
    hist_cptg=[]
    anchor_closure=[]

    with h5py.File(POPULATION_HDF,"r") as h:
        H=np.asarray(h["posterior/hyperparameter_samples"],float)
        pmap=hparam_map(h)
        grids=h["posterior/rates_on_grids"]
        required=["beta","mlow_2","delta_m_2","mu_chi","sigma_chi","amax"]
        miss=[x for x in required if x not in pmap]
        if miss:
            fail(f"population hyperparameters missing {miss}")

        for r in range(H.shape[0]):
            xm,ym=grid_xy(grids["mass_1"],r)
            xz,yz=grid_xy(grids["redshift"],r)

            m1raw=sample_grid_stratified(
                rng,xm,ym,DRAWS_PER_HYPERROW
            )
            zrel=sample_grid_stratified(
                rng,xz,yz,DRAWS_PER_HYPERROW
            )

            errs=[]
            for t in ANCHORS:
                errs.append(abs(
                    float(np.mean(m1raw>=t))-
                    exact_grid_fraction_above(xm,ym,t)
                ))
            anchor_closure.append(max(errs))

            beta=float(H[r,pmap["beta"]])
            mlow=float(H[r,pmap["mlow_2"]])
            delta=float(H[r,pmap["delta_m_2"]])
            mu=float(H[r,pmap["mu_chi"]])
            sig=float(H[r,pmap["sigma_chi"]])
            amax=min(float(H[r,pmap["amax"]]),1.0)

            qlaw=ConditionalM2Law(
                beta,mlow,delta,float(np.max(xm))
            )
            m1rel=ensure_joint_mass_support(
                rng,m1raw,xm,ym,qlaw
            )
            m2rel=qlaw.sample_m2(rng,m1rel)
            q=m2rel/m1rel
            a1=sample_truncated_normal(
                rng,mu,sig,0.0,amax,DRAWS_PER_HYPERROW
            )
            a2=sample_truncated_normal(
                rng,mu,sig,0.0,amax,DRAWS_PER_HYPERROW
            )

            dl=release_dl_from_z(zrel)
            zc=inverter.invert(dl)
            scale=(1.0+zrel)/(1.0+zc)
            mapped=map_compact_pair(
                m1rel*scale,m2rel*scale,a1,a2
            )

            row={
                "hyperposterior_row":r,
                "release_m1_median":float(np.median(m1rel)),
                "release_m2_median":float(np.median(m2rel)),
                "cptg_m_inf_1_median":float(np.median(mapped["m_inf_1"])),
                "cptg_m_inf_2_median":float(np.median(mapped["m_inf_2"])),
                "cptg_m_c_1_median":float(np.median(mapped["m_c_1"])),
                "cptg_m_c_2_median":float(np.median(mapped["m_c_2"])),
                "cptg_f_geom_1_median":float(np.median(mapped["f_geom_1"])),
                "cptg_f_geom_2_median":float(np.median(mapped["f_geom_2"])),
                "cptg_A_pol_1_median":float(np.median(mapped["A_pol_1"])),
                "cptg_A_pol_2_median":float(np.median(mapped["A_pol_2"])),
                "cptg_z_median":float(np.median(zc)),
                "reorder_fraction":float(np.mean(mapped["reordered"])),
            }
            hyper_rows.append(row)

            tr={"hyperposterior_row":r}
            for t in ANCHORS:
                tag=str(int(t))
                tr[f"release_m1_ge_{tag}"]=float(np.mean(m1rel>=t))
                tr[f"release_m2_ge_{tag}"]=float(np.mean(m2rel>=t))
                tr[f"cptg_source_m1_ge_{tag}"]=float(
                    np.mean(mapped["m_c_1"]>=t)
                )
                tr[f"cptg_source_m2_ge_{tag}"]=float(
                    np.mean(mapped["m_c_2"]>=t)
                )
            threshold_rows.append(tr)

            hr,_=np.histogram(m1rel,bins=HIST_EDGES,density=True)
            hc,_=np.histogram(mapped["m_c_1"],bins=HIST_EDGES,density=True)
            hist_release.append(hr)
            hist_cptg.append(hc)

            if r==0 or (r+1)%500==0 or r+1==H.shape[0]:
                print(
                    f"POPULATION {r+1}/{H.shape[0]}",
                    flush=True
                )

    closure=float(np.max(anchor_closure))
    if closure>MAX_STRATIFIED_M1_ANCHOR_ERROR+1e-12:
        fail(
            f"population stratified anchor closure {closure} exceeds "
            f"{MAX_STRATIFIED_M1_ANCHOR_ERROR}"
        )

    write_csv(out/"POPULATION_HYPERPOSTERIOR_CPTG.csv",hyper_rows)
    write_csv(out/"POPULATION_THRESHOLD_POSTERIOR.csv",threshold_rows)

    hr=np.asarray(hist_release,float)
    hc=np.asarray(hist_cptg,float)
    bands=[]
    for i in range(len(HIST_EDGES)-1):
        bands.append({
            "bin_lo":HIST_EDGES[i],
            "bin_hi":HIST_EDGES[i+1],
            "bin_center":.5*(HIST_EDGES[i]+HIST_EDGES[i+1]),
            "release_density_p05":float(np.quantile(hr[:,i],.05)),
            "release_density_p50":float(np.quantile(hr[:,i],.50)),
            "release_density_p95":float(np.quantile(hr[:,i],.95)),
            "cptg_source_density_p05":float(np.quantile(hc[:,i],.05)),
            "cptg_source_density_p50":float(np.quantile(hc[:,i],.50)),
            "cptg_source_density_p95":float(np.quantile(hc[:,i],.95)),
        })
    write_csv(out/"POPULATION_PRIMARY_MASS_DENSITY_BANDS.csv",bands)

    summary={
        "population_file":str(POPULATION_HDF),
        "population_sha256":EXPECTED_POPULATION_SHA256,
        "hyperposterior_rows":len(hyper_rows),
        "draws_per_hyperposterior_row":DRAWS_PER_HYPERROW,
        "selection_status":(
            "uses the official selection-corrected GWTC-5 popsummary posterior; "
            "no new selection fit or candidate-bank search is performed"
        ),
        "m1_stratified_anchor_closure_max_abs":closure,
        "quantities":{
            k:summarize([r[k] for r in hyper_rows])
            for k in [
                "release_m1_median","release_m2_median",
                "cptg_m_inf_1_median","cptg_m_inf_2_median",
                "cptg_m_c_1_median","cptg_m_c_2_median",
                "cptg_f_geom_1_median","cptg_f_geom_2_median",
                "cptg_A_pol_1_median","cptg_A_pol_2_median",
                "cptg_z_median","reorder_fraction"
            ]
        },
        "anchors":{},
    }
    for t in ANCHORS:
        tag=str(int(t))
        summary["anchors"][tag]={}
        for key in (
            f"release_m1_ge_{tag}",f"release_m2_ge_{tag}",
            f"cptg_source_m1_ge_{tag}",f"cptg_source_m2_ge_{tag}"
        ):
            summary["anchors"][tag][key]=summarize(
                [r[key] for r in threshold_rows]
            )

    (out/"POPULATION_CPTG_SUMMARY.json").write_text(
        json.dumps(summary,indent=2,sort_keys=True)+"\n",
        encoding="utf-8"
    )
    return summary

# ---------------------------------------------------------------------------
# Audit and packaging
# ---------------------------------------------------------------------------

def self_test():
    a=np.linspace(0,1,1001)
    A=polarization_factor(a)
    if np.max(np.abs(a*a*A**3+A-2.0))>MAX_CUBIC_ABS:
        fail("compact cubic self-test")

    m=np.linspace(3,200,1001)
    mp=map_compact_pair(m,.7*m,a,a[::-1])
    if np.any(mp["m_c_1"]<mp["m_c_2"]):
        fail("component ordering self-test")
    if np.max(np.abs(
        mp["m_inf_1"]-(mp["m_c_1"]+mp["m_geom_1"])
    ))>1e-10:
        fail("mass decomposition self-test")

    inv=CPTGDistanceInverter()
    dl=np.asarray([0.0,1e3,1e4,5e4])
    z=inv.invert(dl)
    if z[0]!=0 or np.any(np.diff(z)<=0):
        fail("dynamic CPTG distance inversion self-test")

    # Verify the published central benchmark from the gravitational-law paper.
    aa=np.asarray([.84])
    AP=polarization_factor(aa)[0]
    mc=15.65/AP
    ac=.84*AP*AP
    if abs(AP-1.088925987)>2e-9:
        fail("M33 X-7 A_pol benchmark regression")
    if abs(mc-14.3719593)>3e-7:
        fail("M33 X-7 source-mass benchmark regression")
    if abs(ac-.996038237)>3e-7:
        fail("M33 X-7 source-spin benchmark regression")

    # Conditional-mass sampler regression inside the low-mass Planck taper.
    # This is the regime where the v2 rejection sampler could run 10,000
    # iterations without accepting and falsely report a data failure.
    rng_q=np.random.default_rng(520260)
    law=ConditionalM2Law(
        beta=1.5,mlow=5.0,delta=4.0,max_mass=100.0
    )
    probe_m1=np.asarray(
        [5.05,5.10,5.25,5.50,6.0,7.0,8.5,9.0,12.0,30.0]*200,
        float
    )
    probe_m2=law.sample_m2(rng_q,probe_m1)
    if np.any(probe_m2<=5.0) or np.any(probe_m2>probe_m1):
        fail("conditional m2 support self-test")
    print("Conditional m2 inverse-CDF taper regression PASS")

    # Stratified population-grid resolution.
    rng=np.random.default_rng(1)
    x=np.linspace(3,100,1000)
    y=np.exp(-x/20)
    s=sample_grid_stratified(rng,x,y,DRAWS_PER_HYPERROW)
    for t in ANCHORS:
        err=abs(
            float(np.mean(s>=t))-exact_grid_fraction_above(x,y,t)
        )
        if err>MAX_STRATIFIED_M1_ANCHOR_ERROR+1e-12:
            fail("stratified population self-test")

    print("SELF-TEST PASS")
    print("CPTG minimum compact mass-spin closure PASS")
    print("M33 X-7 published compact benchmark regression PASS")
    print("Dynamic luminosity-distance inversion PASS")
    print("No global event noise cut; noise is diagnostic-specific.")
    print("No candidate bank, row ranking, covariance escalation, or new injections.")
    print(f"Population push-forward resolution = {DRAWS_PER_HYPERROW} draws/hyperrow.")

def package_results(out):
    manifest=[]
    for p in sorted(out.rglob("*")):
        if p.is_file() and p.name!="RESULTS_SHA256.txt":
            b=p.read_bytes()
            manifest.append(
                f"{hashlib.sha256(b).hexdigest()}  "
                f"{p.relative_to(out).as_posix()}  {len(b)}"
            )
    (out/"RESULTS_SHA256.txt").write_text(
        "\n".join(manifest)+"\n",encoding="utf-8"
    )

    rz=ROOT/f"{STAGE}_RESULTS.zip"
    if rz.exists():
        rz.unlink()
    with zipfile.ZipFile(
        rz,"w",compression=zipfile.ZIP_DEFLATED,compresslevel=9
    ) as z:
        for p in sorted(out.rglob("*")):
            if p.is_file():
                z.write(p,p.relative_to(out).as_posix())
    return rz,sha256(rz)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--self-test",action="store_true")
    args=ap.parse_args()
    if args.self_test:
        self_test(); return

    self_test()
    out=ROOT/"RESULTS"
    if out.exists():
        shutil.rmtree(out)
    out.mkdir()

    inverter=CPTGDistanceInverter()

    event_rows,branch_rows,diag_rows,agreement,reject_rows=process_events(
        inverter
    )
    write_csv(out/"EVENT_CPTG_USABILITY.csv",event_rows)
    write_csv(out/"EVENT_BRANCH_CPTG_SUMMARY.csv",branch_rows)
    write_csv(out/"EVENT_BRANCH_DIAGNOSTICS.csv",diag_rows)
    write_csv(out/"EVENT_DIAGNOSTIC_AGREEMENT.csv",agreement)
    write_csv(out/"EVENT_BRANCH_REJECTIONS.csv",reject_rows)

    population=population_pushforward(inverter,out)

    usable=[r for r in event_rows if r["event_status"]=="USABLE"]
    hard=[r for r in event_rows if r["event_status"]!="USABLE"]
    resolved=sum(
        r["event_diagnostic_state"] in ("RESOLVED_ABOVE","RESOLVED_BELOW")
        for r in agreement
    )
    unresolved=sum(
        r["event_diagnostic_state"] not in ("RESOLVED_ABOVE","RESOLVED_BELOW")
        for r in agreement
    )

    status=(
        "PASS_CLEAN_CPTG_GWTC5_COMPACT_POPULATION_TRANSFORM"
        if len(usable)>0 else
        "FAIL_NO_USABLE_GWTC5_EVENTS"
    )
    result={
        "status":status,
        "stage":STAGE,
        "event_program":{
            "expected_events":EXPECTED_EVENT_COUNT,
            "usable_events":len(usable),
            "hard_rejected_events":len(hard),
            "usable_branch_rows":len(branch_rows),
            "rejected_branch_rows":len(reject_rows),
            "resolved_event_anchor_diagnostics":resolved,
            "unresolved_or_branch_sensitive_event_anchor_diagnostics":unresolved,
            "noise_policy":(
                "The compact-state transformation retains an event whenever at "
                "least one official released posterior branch is usable. Posterior "
                "width does not erase an otherwise valid object. Noise rejection is "
                "applied only to the specific threshold diagnostic: a 10/35/40/45 "
                "Msun classification is unresolved unless >=95% of the branch "
                "posterior lies on one side. Alternate waveform reconstructions are "
                "kept as separate sensitivity rows, not pooled as independent events."
            ),
        },
        "population_program":population,
        "distance_inverter":{
            "dynamic_support":True,
            "final_cptg_zmax":inverter.zmax,
            "final_cptg_dlmax_Mpc":float(inverter.dl[-1]),
            "cache_expansions":inverter.expansions,
            "support_rule":(
                "CPTG inversion support follows the actual finite luminosity "
                "distance required by the data and is never clipped to a population "
                "grid boundary."
            ),
        },
        "theory_interface":{
            "compact_handoff":"a_inf^2 A_pol^3 + A_pol - 2 = 0",
            "source_mass":"M_c = M_inf/A_pol",
            "geometric_mass":"M_geom = M_inf - M_c",
            "source_spin":"a_c = A_pol^2 a_inf",
            "matching_radius":"r_m = G M_inf/c^2",
            "claim_boundary":(
                "Minimum conditional compact mass-spin handoff only. This test does "
                "not claim a full rotating interior. The measured exterior mass-spin "
                "state remains the observational input; CPTG changes its finite "
                "source/geometric decomposition."
            ),
        },
        "stop_rule":(
            "On successful transformation of every usable event branch and the "
            "official selection-corrected default_mmax population posterior, stop. "
            "Unresolved object diagnostics remain unresolved; they do not spawn "
            "candidate-bank, covariance, or new-injection tests."
        ),
    }
    (out/"FINAL_AUDIT.json").write_text(
        json.dumps(result,indent=2,sort_keys=True)+"\n",
        encoding="utf-8"
    )
    (out/"FINAL_AUDIT.txt").write_text(
        "\n".join([
            "CPTG GWTC-5.0 COMPACT + POPULATION CLEAN TEST v2a",
            "="*78,
            f"STATUS = {status}",
            f"usable events = {len(usable)} / {EXPECTED_EVENT_COUNT}",
            f"hard-rejected events = {len(hard)}",
            f"usable posterior branches = {len(branch_rows)}",
            f"rejected posterior branches = {len(reject_rows)}",
            f"resolved event-anchor diagnostics = {resolved}",
            f"unresolved/branch-sensitive diagnostics = {unresolved}",
            f"population hyperposterior rows = {population['hyperposterior_rows']}",
            f"population draws per row = {DRAWS_PER_HYPERROW}",
            f"dynamic CPTG inversion zmax = {inverter.zmax:.12g}",
            "candidate bank = NO",
            "hyperposterior row ranking = NO",
            "new injections = NO",
            "test stops here on completed clean transform.",
        ])+"\n",
        encoding="utf-8"
    )

    shutil.copyfile(Path(__file__),out/Path(__file__).name)
    shutil.copyfile(ROOT/"README.md",out/"README.md")
    shutil.copyfile(ROOT/"METHOD_NOTE.md",out/"METHOD_NOTE.md")
    shutil.copyfile(ROOT/"THEORY_INTERFACE.md",out/"THEORY_INTERFACE.md")
    shutil.copyfile(ROOT/"FROZEN_PROTOCOL.json",out/"FROZEN_PROTOCOL.json")

    rz,rsha=package_results(out)

    print("="*78)
    print(f"STATUS = {status}")
    print(f"USABLE EVENTS = {len(usable)} / {EXPECTED_EVENT_COUNT}")
    print(f"HARD REJECTED EVENTS = {len(hard)}")
    print(f"USABLE BRANCHES = {len(branch_rows)}")
    print(
        f"POPULATION HYPERPOSTERIOR ROWS = "
        f"{population['hyperposterior_rows']}"
    )
    print("NO CANDIDATE BANK. NO ROW RANKING. NO NEW INJECTIONS.")
    print(f"RESULT ZIP = {rz.name}")
    print(f"RESULT ZIP SHA256 = {rsha}")
    print("="*78)

if __name__=="__main__":
    try:
        main()
    except Exception as exc:
        print(str(exc),file=sys.stderr,flush=True)
        sys.exit(1)
