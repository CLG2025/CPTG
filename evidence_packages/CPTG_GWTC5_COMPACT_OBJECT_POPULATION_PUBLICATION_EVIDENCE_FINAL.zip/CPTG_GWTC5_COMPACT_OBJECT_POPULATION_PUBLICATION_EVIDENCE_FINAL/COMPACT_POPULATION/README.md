# CPTG GWTC-5 Native-Coordinate Compact/Population Evidence

This lane contains the exact event-side compact-state products and the frozen native-coordinate population correction used by the publication.

The event authority is the frozen v2a result. The population authority is the frozen r19 result. r19 keeps the v2a external-coordinate decoder physical transform and adds the explicit native-coordinate audit and post-solve comparison readout; its physical population medians regress to v2a within numerical tolerance.

Run `RUN_VALIDATE_NATIVE_EVIDENCE.cmd` for a fail-closed audit of the distributed evidence. `RUN_FULL_NUMERICAL_REPRODUCTION.cmd` reruns the original decoder-based event/population transform against the local PE and population HDF archives; the distributed r19 files remain the publication authority for the added native-coordinate diagnostic.
