@echo off
setlocal EnableExtensions
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" py -3.11 -m venv .venv
if errorlevel 1 exit /b 1
set "PY=.venv\Scripts\python.exe"
"%PY%" -m pip install --disable-pip-version-check -r requirements.txt
if errorlevel 1 exit /b 1
"%PY%" verify_event_source_identities.py
if errorlevel 1 exit /b 1
"%PY%" run_cptg_gwtc5_clean_test.py --self-test
if errorlevel 1 exit /b 1
"%PY%" run_cptg_gwtc5_clean_test.py
if errorlevel 1 exit /b 1
"%PY%" validate_native_compact_population_evidence.py
if errorlevel 1 exit /b 1
echo STATUS=PASS_NATIVE_COMPACT_POPULATION_NUMERICAL_REPRODUCTION
