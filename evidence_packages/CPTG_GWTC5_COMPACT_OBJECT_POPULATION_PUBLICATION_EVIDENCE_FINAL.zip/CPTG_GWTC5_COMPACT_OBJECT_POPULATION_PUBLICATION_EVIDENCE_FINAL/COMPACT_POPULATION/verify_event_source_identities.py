#!/usr/bin/env python3
from pathlib import Path
import argparse,csv,hashlib,sys
ROOT=Path(__file__).resolve().parent

def digest(path,name,chunk=8*1024*1024):
    h=hashlib.new(name)
    with open(path,'rb') as f:
        for b in iter(lambda:f.read(chunk),b''):
            h.update(b)
    return h.hexdigest()

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--pe-root',default=r'F:\CPTG-GWTC5\pe\full_259')
    ap.add_argument('--sha256',action='store_true',help='also compute full local SHA-256; slower for 69.7 GiB')
    args=ap.parse_args()
    rows=list(csv.DictReader(open(ROOT/'EVENT_SOURCE_IDENTITIES.csv',newline='',encoding='utf-8')))
    base=Path(args.pe_root)
    files={p.name:p for p in base.rglob('*') if p.is_file()}
    bad=[]
    for i,r in enumerate(rows,1):
        p=files.get(r['official_filename'])
        if p is None:
            bad.append((r['event'],'MISSING')); continue
        if p.stat().st_size!=int(r['size_bytes']):
            bad.append((r['event'],'SIZE')); continue
        md5=digest(p,'md5')
        if md5.lower()!=r['official_md5'].lower():
            bad.append((r['event'],'MD5')); continue
        if args.sha256:
            s=digest(p,'sha256')
            if s.lower()!=r['local_sha256'].lower():
                bad.append((r['event'],'SHA256')); continue
        if i==1 or i%25==0 or i==len(rows):
            print(f'VERIFIED {i}/{len(rows)}',flush=True)
    if bad:
        for x in bad: print('FAIL',*x,file=sys.stderr)
        raise SystemExit(1)
    print(f'PASS: {len(rows)} event files match filename/size/official MD5'+(' and local SHA-256' if args.sha256 else ''))

if __name__=='__main__': main()
