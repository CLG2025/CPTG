@echo off
setlocal EnableExtensions
cd /d "%~dp0"
if not exist ".venv_publication\Scripts\python.exe" py -3.11 -m venv .venv_publication
if errorlevel 1 exit /b 1
set "PY=.venv_publication\Scripts\python.exe"
"%PY%" -m pip install --disable-pip-version-check -r requirements.txt
if errorlevel 1 exit /b 1
"%PY%" validate_publication_evidence.py
if errorlevel 1 exit /b 1
echo STATUS=PASS_COMBINED_NATIVE_PUBLICATION_EVIDENCE
