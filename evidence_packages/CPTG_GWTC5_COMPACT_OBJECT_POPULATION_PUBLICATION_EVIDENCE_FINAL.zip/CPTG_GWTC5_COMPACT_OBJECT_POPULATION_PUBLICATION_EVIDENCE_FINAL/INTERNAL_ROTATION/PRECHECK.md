# r04 Precheck

The internal-rotation method self-test and full-catalog static preflight pass before any local HDF5 execution.

```text
CPTG INTERNAL-ROTATION METHOD SELF-TEST
N 1.8685541423212226
x_minus 0.585167729480677
x_N 0.5255579589653346
omega_N_axis 8662.986294255805 rad/s
omega_N_detavg 8781.354720384405 rad/s
omega_N_equator 8843.133755992498 rad/s
omega_surface 9824.642008406352 rad/s
period_N_detavg 0.7155143491236327 ms
period_surface 0.6395332574768062 ms
analytic_vs_192_abs_rad_s 3.637978807091713e-12
surface_theta_spread_rad_s 0.0
STATUS=PASS_INTERNAL_ROTATION_METHOD_SELFTEST
```

```text
CPTG INTERNAL-ROTATION STATIC PREFLIGHT
branch realizations 288
unique events 259
posterior draw authority 7626239
source identities 259
max reconstructed Structural-N authority abs 6.1950444774083735e-12
transfer-control branches 10
STATUS=PASS_INTERNAL_ROTATION_STATIC_PREFLIGHT
```

The accepted ten-branch transfer data provide 356,213 posterior rows (712,426 component states). The rotation operator has zero angular-ordering violations, zero trapping-surface angular spread, and a maximum independent 192-point determinant-average relative discrepancy of approximately `9.22e-15` on the deterministic audit sample.
