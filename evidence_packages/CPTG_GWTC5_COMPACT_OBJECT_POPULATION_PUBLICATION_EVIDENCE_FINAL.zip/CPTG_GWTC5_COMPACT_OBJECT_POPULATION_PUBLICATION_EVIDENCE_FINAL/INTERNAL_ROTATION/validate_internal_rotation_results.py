from __future__ import annotations

import csv, json, math
from pathlib import Path
import numpy as np

from cptg_internal_rotation_common import omega_triplet_vec

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'RESULTS'

def read_csv(name):
    with open(OUT/name,newline='',encoding='utf-8') as f:
        return list(csv.DictReader(f))

def fv(x): return float(x)
def rel(a,b): return abs(a-b)/max(abs(b),1.0)

status=json.loads((OUT/'GWTC5_INTERNAL_ROTATION_STATUS.json').read_text())
if status.get('status')!='PASS_INTERNAL_ROTATION_POPULATION':
    raise RuntimeError('population status is not PASS')
if int(status['retained_branch_realizations'])!=288 or int(status['unique_events'])!=259 or int(status['posterior_draws'])!=7626239:
    raise RuntimeError('catalog count mismatch')
if int(status['unique_within_event_rotation_streams'])!=260:
    raise RuntimeError('unique stream count mismatch')
if status.get('matter_rotation_inferred') is not False:
    raise RuntimeError('matter-rotation boundary lost')

summary=read_csv('GWTC5_INTERNAL_ROTATION_SUMMARY.csv')
item=read_csv('GWTC5_ITEM5_ROTATION.csv')
audit=read_csv('GWTC5_ROTATION_SAMPLEWISE_AUDIT.csv')
det=read_csv('GWTC5_ROTATION_POSTERIOR_AUDIT_SAMPLE.csv')
closure=read_csv('GWTC5_ROTATION_AUTHORITY_CLOSURE.csv')
sources=read_csv('GWTC5_ROTATION_SOURCE_AUDIT.csv')
controls=read_csv('GWTC5_ROTATION_TRANSFER_CONTROL_CLOSURE.csv')

if len(summary)!=576: raise RuntimeError(f'summary rows {len(summary)} != 576')
if len(item)!=4608: raise RuntimeError(f'item rows {len(item)} != 4608')
if len(audit)!=288 or len(closure)!=288: raise RuntimeError('branch audit/closure count mismatch')
if len(det)!=1440: raise RuntimeError('deterministic audit row count mismatch')
if len(sources)!=259 or any(r['status']!='PASS' for r in sources): raise RuntimeError('source audit failed')
if len(controls)!=10 or any(r['status']!='PASS' for r in controls): raise RuntimeError('transfer control failed')
if any(r['status']!='PASS' for r in audit) or any(r['status']!='PASS' for r in closure):
    raise RuntimeError('branch-level validation failed')

dig={}
within=set()
for r in audit:
    d=r['rotation_digest_sha256']; ev=r['event']
    within.add((ev,d)); dig.setdefault(d,set()).add(ev)
if len(within)!=260:
    raise RuntimeError(f'unique within-event digest count {len(within)} != 260')
if any(len(v)>1 for v in dig.values()):
    raise RuntimeError('rotation digest shared across distinct events')

if max(fv(r['max_inner_root_abs_residual']) for r in audit)>5e-12:
    raise RuntimeError('inner-root residual too large')
if max(fv(r['max_structural_N_shell_abs_residual']) for r in audit)>5e-12:
    raise RuntimeError('Structural-N shell residual too large')
if min(fv(r['minimum_xminus_minus_xN']) for r in audit)<=0:
    raise RuntimeError('N shell not strictly internal')
if sum(int(float(r['angular_ordering_violations'])) for r in audit)!=0:
    raise RuntimeError('angular ordering violations present')
if sum(int(float(r['nonfinite_angular_speed_samples'])) for r in audit)!=0:
    raise RuntimeError('nonfinite angular speeds present')

# Authoritative period identity: enforced sample by sample by the population runner.
max_pointwise_period_abs=max(fv(r['max_period_identity_abs_ms']) for r in audit)
if max_pointwise_period_abs>5e-9:
    raise RuntimeError(f'pointwise period identity failed: {max_pointwise_period_abs} ms')

# Independent period identity on all deterministic audit rows.
max_det_period_rel=0.0
for r in det:
    for pref in ('primary','secondary'):
        for om_key,p_key in (
            (pref+'_omega_N_detavg_rad_s', pref+'_period_N_detavg_ms'),
            (pref+'_omega_surface_rad_s', pref+'_period_surface_ms'),
        ):
            om=fv(r[om_key]); pp=fv(r[p_key])
            expected=2*math.pi/om*1000.0
            max_det_period_rel=max(max_det_period_rel,rel(pp,expected))
if max_det_period_rel>5e-12:
    raise RuntimeError(f'deterministic-row period identity failed: {max_det_period_rel}')

# Posterior-summary consistency only.
# Period and omega quantiles are each computed directly from posterior samples.
# Since P=2*pi/omega is nonlinear, NumPy's linearly interpolated finite-sample
# quantiles do not satisfy Q_p(P)=2*pi/Q_(1-p)(omega) exactly.
max_quantile_interp_rel=0.0
for r in summary:
    for loc in ('N','surface'):
        if loc=='N':
            for ang in ('axis','detavg','equator'):
                op=f'omega_N_{ang}_rad_s'; pp=f'period_N_{ang}_ms'
                for pq,oq in (('p05','p95'),('p50','p50'),('p95','p05')):
                    expected=2*math.pi/fv(r[f'{op}_{oq}'])*1000.0
                    max_quantile_interp_rel=max(max_quantile_interp_rel,rel(fv(r[f'{pp}_{pq}']),expected))
        else:
            op='omega_surface_rad_s'; pp='period_surface_ms'
            for pq,oq in (('p05','p95'),('p50','p50'),('p95','p05')):
                expected=2*math.pi/fv(r[f'{op}_{oq}'])*1000.0
                max_quantile_interp_rel=max(max_quantile_interp_rel,rel(fv(r[f'{pp}_{pq}']),expected))

for r in item:
    for ang in ('axis','detavg','equator'):
        op=f'omega_{ang}_rad_s'; pp=f'period_{ang}_ms'
        for pq,oq in (('p05','p95'),('p50','p50'),('p95','p05')):
            expected=2*math.pi/fv(r[f'{op}_{oq}'])*1000.0
            max_quantile_interp_rel=max(max_quantile_interp_rel,rel(fv(r[f'{pp}_{pq}']),expected))
    for q in ('p05','p50','p95'):
        if not (fv(r[f'omega_axis_rad_s_{q}']) <= fv(r[f'omega_detavg_rad_s_{q}'])+1e-8
                <= fv(r[f'omega_equator_rad_s_{q}'])+2e-8):
            raise RuntimeError('summary angular ordering failure')
    if r['coordinate_offset_inside_rminus']=='trapping surface':
        for q in ('p05','p50','p95'):
            a=fv(r[f'omega_axis_rad_s_{q}'])
            m=fv(r[f'omega_detavg_rad_s_{q}'])
            e=fv(r[f'omega_equator_rad_s_{q}'])
            if max(abs(a-m),abs(m-e))>2e-8:
                raise RuntimeError('surface angular dependence detected')

if max_quantile_interp_rel>1e-3:
    raise RuntimeError(f'period/omega posterior quantile consistency failed: {max_quantile_interp_rel}')

max_quad_rel=0.0
for r in det:
    for pref,qkey in [('primary','a_inf_1'),('secondary','a_inf_2')]:
        x=np.array([fv(r[pref+'_x_N'])])
        q=np.array([fv(r[qkey])])
        rg=np.array([fv(r[pref+'_r_g_km'])])
        _,om,_=omega_triplet_vec(x,q,rg,order=192)
        stored=fv(r[pref+'_omega_N_detavg_rad_s'])
        max_quad_rel=max(max_quad_rel,rel(float(om[0]),stored))
if max_quad_rel>5e-12:
    raise RuntimeError(f'independent 192-point rotation check failed: {max_quad_rel}')

print('CPTG INTERNAL-ROTATION FULL RESULT VALIDATION')
print('summary rows',len(summary))
print('item5 rows',len(item))
print('branch audits',len(audit))
print('posterior draws',status['posterior_draws'])
print('unique within-event rotation streams',len(within))
print('max pointwise period identity abs ms',repr(max_pointwise_period_abs))
print('max deterministic-row period identity relative error',repr(max_det_period_rel))
print('max finite-sample quantile interpolation relative difference',repr(max_quantile_interp_rel))
print('max independent 192-point determinant-average relative error',repr(max_quad_rel))
print('transfer control max relative discrepancy',status['transfer_control_max_relative_discrepancy'])
print('STATUS=PASS_INTERNAL_ROTATION_RESULT_VALIDATION')
