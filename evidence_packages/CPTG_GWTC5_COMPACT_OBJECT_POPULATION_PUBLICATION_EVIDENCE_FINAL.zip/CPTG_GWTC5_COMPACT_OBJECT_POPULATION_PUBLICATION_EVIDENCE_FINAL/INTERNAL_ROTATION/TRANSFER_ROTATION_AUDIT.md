# CPTG GWTC-5 Internal-Rotation Transfer Audit

## Result

**PASS — the geometric rotation operator closes on the accepted ten-branch transfer sample.**

- retained branch realizations: 10
- unique events: 9
- posterior rows: 356213
- component posterior states: 712426
- angular-ordering violations: 0
- maximum trapping-surface angular spread: 0 rad/s
- maximum period identity residual: 0 ms
- maximum independent 192-point determinant-average relative discrepancy: 9.2135612328278411e-15
- maximum inner-root residual: 4.2188474935755949e-15
- maximum Structural-N shell residual: 2.2204460492503131e-16
- minimum `x_minus-x_N`: 0.049408417288174911

The determinant-average result uses the same `sigma sin(theta)` geometric measure as the accepted core-time readout. Axis, determinant-average, and equatorial rates remain explicitly separate.

## Transfer-sample branch-median ranges

- primary `omega_N_detavg_rad_s_p50`: 389.688082 / 2349.69343 / 11006.958 (min / median / max)
- primary `period_N_detavg_ms_p50`: 0.570837585 / 2.67405532 / 16.1236271 (min / median / max)
- primary `omega_surface_rad_s_p50`: 893.801282 / 3660.03868 / 15631.8248 (min / median / max)
- primary `period_surface_ms_p50`: 0.401948297 / 1.71948634 / 7.02973405 (min / median / max)
- secondary `omega_N_detavg_rad_s_p50`: 578.265328 / 2561.76149 / 15550.6634 (min / median / max)
- secondary `period_N_detavg_ms_p50`: 0.404046127 / 2.47877745 / 10.865575 (min / median / max)
- secondary `omega_surface_rad_s_p50`: 1191.27012 / 3411.54284 / 21918.8831 (min / median / max)
- secondary `period_surface_ms_p50`: 0.286656272 / 1.88818443 / 5.27435821 (min / median / max)

## Interpretation boundary

These values are geometric ZAMO frame-dragging rates. They do not specify the angular velocity of compact-source matter. The retained spin inputs are magnitudes, so this calculation reports angular-speed magnitude and does not assign a rotation direction.
