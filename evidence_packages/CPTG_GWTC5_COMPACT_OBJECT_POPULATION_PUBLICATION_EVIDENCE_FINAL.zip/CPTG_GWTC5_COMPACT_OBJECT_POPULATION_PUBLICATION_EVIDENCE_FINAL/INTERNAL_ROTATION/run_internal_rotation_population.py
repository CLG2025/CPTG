from __future__ import annotations

import argparse
import csv
import hashlib
import json
import shutil
from pathlib import Path

import numpy as np

from cptg_core_time_common import (
    F, Nbh_vec, qtile, read_csv_dicts, read_event_branch, sanitize_branch,
    sha256_file, transform_event,
)
from cptg_internal_rotation_common import component_rotation_calc, omega_triplet_vec, period_ms

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'RESULTS'
WORK = ROOT / 'WORK'
CHECKPOINTS = WORK / 'CHECKPOINTS'
SELECTION = ROOT / 'GWTC5_FULL_BRANCH_SELECTION.csv'
SOURCES = ROOT / 'GWTC5_FULL_SOURCE_INPUTS.csv'
AUTHORITY = ROOT / 'GWTC5_FULL_BRANCH_AUTHORITY.csv'
CTRL_SUMMARY = ROOT / 'R02_ROTATION_TRANSFER_CONTROL_SUMMARY.csv'
CTRL_ITEM = ROOT / 'R02_ROTATION_TRANSFER_CONTROL_ITEM5.csv'

TRANSFORM_TOL = 2e-6
SPIN_TOL = 5e-7
N_AUTH_TOL = 5e-9
ROTATION_CONTROL_REL_TOL = 8e-7
EXPECTED_BRANCHES = 288
EXPECTED_EVENTS = 259
EXPECTED_POSTERIOR_DRAWS = 7_626_239
EXPECTED_UNIQUE_WITHIN_EVENT_STREAMS = 260


def f(x): return float(x)
def i(x): return int(float(x))


def jsonable(obj):
    if isinstance(obj, dict): return {str(k): jsonable(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)): return [jsonable(v) for v in obj]
    if isinstance(obj, np.ndarray): return [jsonable(v) for v in obj.tolist()]
    if isinstance(obj, (np.floating, float)): return float(obj)
    if isinstance(obj, (np.integer, int)): return int(obj)
    if isinstance(obj, (np.bool_, bool)): return bool(obj)
    return obj


def write_csv(path, rows, fields=None):
    rows = list(rows)
    path.parent.mkdir(parents=True, exist_ok=True)
    if fields is None:
        fields=[]
        for r in rows:
            for k in r:
                if k not in fields: fields.append(k)
    with open(path,'w',newline='',encoding='utf-8') as fh:
        w=csv.DictWriter(fh,fieldnames=fields)
        w.writeheader()
        if rows: w.writerows(rows)


def file_contract_sha256():
    h=hashlib.sha256()
    for name in [
        'cptg_core_time_common.py','cptg_internal_rotation_common.py',
        'run_internal_rotation_population.py','GWTC5_FULL_BRANCH_SELECTION.csv',
        'GWTC5_FULL_BRANCH_AUTHORITY.csv','GWTC5_FULL_SOURCE_INPUTS.csv',
        'R02_ROTATION_TRANSFER_CONTROL_SUMMARY.csv','R02_ROTATION_TRANSFER_CONTROL_ITEM5.csv',
        'LOCKED_INTERNAL_ROTATION_METHOD.md',
    ]:
        h.update(name.encode()+b'\0')
        h.update(bytes.fromhex(sha256_file(ROOT/name)))
    return h.hexdigest()


def gate_quantiles(name, got, expected, tol):
    got=np.asarray(got,float); exp=np.asarray(expected,float)
    err=float(np.max(np.abs(got-exp)))
    if err>tol:
        raise RuntimeError(f'{name} authority mismatch: max_abs={err} got={got} expected={exp}')
    return err


def package_preflight(verbose=True):
    sel=read_csv_dicts(SELECTION); auth=read_csv_dicts(AUTHORITY); src=read_csv_dicts(SOURCES)
    sk=[(r['event'],r['posterior_branch']) for r in sel]
    ak=[(r['event'],r['posterior_branch']) for r in auth]
    if len(sel)!=EXPECTED_BRANCHES or len(set(sk))!=EXPECTED_BRANCHES:
        raise RuntimeError('branch selection authority mismatch')
    if len(auth)!=EXPECTED_BRANCHES or set(ak)!=set(sk):
        raise RuntimeError('branch authority does not exactly match selection')
    events={r['event'] for r in sel}
    if len(events)!=EXPECTED_EVENTS:
        raise RuntimeError(f'expected {EXPECTED_EVENTS} unique events')
    if len(src)!=EXPECTED_EVENTS or {r['event'] for r in src}!=events:
        raise RuntimeError('source registry does not exactly match event set')
    total=sum(i(r['posterior_samples_finite']) for r in sel)
    if total!=EXPECTED_POSTERIOR_DRAWS:
        raise RuntimeError(f'posterior draw authority {total} != {EXPECTED_POSTERIOR_DRAWS}')

    max_n=0.0
    for r in auth:
        q1=np.array([f(r['a_inf_1_p95']),f(r['a_inf_1_p50']),f(r['a_inf_1_p05'])])
        q2=np.array([f(r['a_inf_2_p95']),f(r['a_inf_2_p50']),f(r['a_inf_2_p05'])])
        e1=np.array([f(r['N_BH_1_p05']),f(r['N_BH_1_p50']),f(r['N_BH_1_p95'])])
        e2=np.array([f(r['N_BH_2_p05']),f(r['N_BH_2_p50']),f(r['N_BH_2_p95'])])
        max_n=max(max_n,float(np.max(np.abs(Nbh_vec(q1)-e1))),float(np.max(np.abs(Nbh_vec(q2)-e2))))
    if max_n>N_AUTH_TOL:
        raise RuntimeError(f'Structural-N authority preflight failed: {max_n}')

    cs=read_csv_dicts(CTRL_SUMMARY); ci=read_csv_dicts(CTRL_ITEM)
    ckeys={(r['event'],r['posterior_branch']) for r in cs}
    if len(ckeys)!=10 or not ckeys.issubset(set(sk)):
        raise RuntimeError('rotation transfer control is not the accepted 10-branch subset')
    if len(cs)!=20 or len(ci)!=160:
        raise RuntimeError('rotation transfer control row count mismatch')

    if verbose:
        print('CPTG INTERNAL-ROTATION STATIC PREFLIGHT')
        print('branch realizations',len(sel))
        print('unique events',len(events))
        print('posterior draw authority',total)
        print('source identities',len(src))
        print('max reconstructed Structural-N authority abs',repr(max_n))
        print('transfer-control branches',len(ckeys))
        print('STATUS=PASS_INTERNAL_ROTATION_STATIC_PREFLIGHT')
    return max_n


def source_preflight(rows):
    audit=[]
    print('Verifying 259 source-file identities before rotation calculation...')
    for pos,r in enumerate(rows,1):
        path=Path(r['local_path']); event=r['event']
        if not path.exists(): raise RuntimeError(f'{event}: source file not found: {path}')
        size=path.stat().st_size
        if size!=i(r['size_bytes']): raise RuntimeError(f'{event}: source size mismatch')
        sh=sha256_file(path)
        if sh.lower()!=r['local_sha256'].lower(): raise RuntimeError(f'{event}: source SHA256 mismatch')
        audit.append({'population_row':r['population_row'],'event':event,'filename':r['filename'],
                      'path':str(path),'size_bytes':size,'official_md5':r['official_md5'],
                      'sha256':sh,'acquisition_status':r['acquisition_status'],'status':'PASS'})
        if pos%20==0 or pos==len(rows): print(f'  source identities verified {pos}/{len(rows)}')
    return audit


def rotation_digest(tr,p1,p2):
    h=hashlib.sha256()
    fields=[('z_CPTG',tr['z']),('m_inf_1',tr['m1']),('m_inf_2',tr['m2']),
            ('a_inf_1',tr['q1']),('a_inf_2',tr['q2'])]
    for pref,p in [('primary',p1),('secondary',p2)]:
        for k in sorted(p):
            if k.endswith('_x'): continue
            fields.append((pref+'_'+k,p[k]))
    for name,arr in fields:
        h.update(name.encode()+b'\0')
        h.update(np.asarray(arr,dtype='<f8').tobytes(order='C'))
    h.update(b'swap\0'); h.update(np.asarray(tr['swap'],dtype=np.uint8).tobytes(order='C'))
    return h.hexdigest()


def samplewise_audit(event,branch,tr,p1,p2,digest):
    max_inner=max_shell=max_period=0.0
    min_gap=float('inf'); angular_viol=0; nonfinite=0
    for p in (p1,p2):
        q=np.asarray(p['q'],float); xm=np.asarray(p['x_minus'],float); N=np.asarray(p['N_BH'],float); xn=np.asarray(p['x_N'],float)
        max_inner=max(max_inner,float(np.max(np.abs(xm*xm-2*xm*F(xm)+q*q))))
        rhs=(1+q*q)/(N**3)
        max_shell=max(max_shell,float(np.max(np.abs(xn*(xn*xn+q*q)-rhs))))
        min_gap=min(min_gap,float(np.min(xm-xn)))
        locs=[('N',p['omega_N_axis_rad_s'],p['omega_N_detavg_rad_s'],p['omega_N_equator_rad_s'],p['period_N_detavg_ms'])]
        for key in ('1_km','500_m','100_m','10_m','1_m','10_cm','1_cm','trapping_surface'):
            locs.append((key,p[f'item5_{key}_omega_axis_rad_s'],p[f'item5_{key}_omega_detavg_rad_s'],p[f'item5_{key}_omega_equator_rad_s'],p[f'item5_{key}_period_detavg_ms']))
        for lname,oa,om,oe,pm in locs:
            oa=np.asarray(oa,float);om=np.asarray(om,float);oe=np.asarray(oe,float);pm=np.asarray(pm,float)
            nonfinite += int(np.sum(~np.isfinite(oa)|~np.isfinite(om)|~np.isfinite(oe)))
            angular_viol += int(np.sum((oa>om+1e-8)|(om>oe+1e-8)))
            good=om>0
            if np.any(good):
                max_period=max(max_period,float(np.max(np.abs(pm[good]-(2*np.pi/om[good]*1000.0)))))
        # Exact surface must be theta-independent.
        sa=np.asarray(p['item5_trapping_surface_omega_axis_rad_s'],float)
        sm=np.asarray(p['item5_trapping_surface_omega_detavg_rad_s'],float)
        se=np.asarray(p['item5_trapping_surface_omega_equator_rad_s'],float)
        if max(float(np.max(np.abs(sa-sm))),float(np.max(np.abs(sm-se))))>1e-10:
            raise RuntimeError(f'{event} {branch}: trapping-surface angular rate not theta-independent')
    if min_gap<=0: raise RuntimeError(f'{event} {branch}: Structural-N shell ordering failed')
    if nonfinite: raise RuntimeError(f'{event} {branch}: non-finite angular-speed samples {nonfinite}')
    if angular_viol: raise RuntimeError(f'{event} {branch}: angular ordering violations {angular_viol}')
    return {'event':event,'posterior_branch':branch,'samples':len(tr['z']),
            'rotation_digest_sha256':digest,'max_inner_root_abs_residual':max_inner,
            'max_structural_N_shell_abs_residual':max_shell,'minimum_xminus_minus_xN':min_gap,
            'angular_ordering_violations':angular_viol,'nonfinite_angular_speed_samples':nonfinite,
            'max_period_identity_abs_ms':max_period,'status':'PASS'}


def deterministic_audit_rows(event,branch,tr,p1,p2):
    n=len(tr['z']); idxs=sorted(set([0,n//4,n//2,(3*n)//4,n-1])); out=[]
    for idx in idxs:
        r={'event':event,'posterior_branch':branch,'sample_index':idx,'z_CPTG':float(tr['z'][idx]),
           'reordered':int(tr['swap'][idx]),'m_inf_1':float(tr['m1'][idx]),'m_inf_2':float(tr['m2'][idx]),
           'a_inf_1':float(tr['q1'][idx]),'a_inf_2':float(tr['q2'][idx])}
        for pref,p in [('primary',p1),('secondary',p2)]:
            for k in ['r_g_km','x_minus','N_BH','x_N','omega_N_axis_rad_s','omega_N_detavg_rad_s','omega_N_equator_rad_s','period_N_detavg_ms','omega_surface_rad_s','period_surface_ms']:
                r[pref+'_'+k]=float(np.asarray(p[k])[idx])
            for key in ('1_km','500_m','100_m','10_m','1_m','10_cm','1_cm'):
                r[pref+f'_item5_{key}_omega_detavg_rad_s']=float(np.asarray(p[f'item5_{key}_omega_detavg_rad_s'])[idx])
        out.append(r)
    return out


def relerr(got,ref):
    return abs(float(got)-float(ref))/max(abs(float(ref)),1.0)


def transfer_control_closure(summary,item):
    ref_s=read_csv_dicts(CTRL_SUMMARY); ref_i=read_csv_dicts(CTRL_ITEM)
    got_s={(r['event'],r['posterior_branch'],r['component']):r for r in summary}
    got_i={(r['event'],r['posterior_branch'],r['component'],r['coordinate_offset_inside_rminus']):r for r in item}
    maxrel=0.0; perbranch={}
    for ref in ref_s:
        key=(ref['event'],ref['posterior_branch'],ref['component']); got=got_s[key]
        for col,val in ref.items():
            if col in {'event','posterior_branch','component','samples'} or val in ('',None): continue
            try: e=relerr(got[col],val)
            except Exception: continue
            maxrel=max(maxrel,e); perbranch[(ref['event'],ref['posterior_branch'])]=max(perbranch.get((ref['event'],ref['posterior_branch']),0.0),e)
    for ref in ref_i:
        key=(ref['event'],ref['posterior_branch'],ref['component'],ref['coordinate_offset_inside_rminus']); got=got_i[key]
        for col,val in ref.items():
            if col in {'event','posterior_branch','component','coordinate_offset_inside_rminus','offset_km'} or val in ('',None): continue
            try: e=relerr(got[col],val)
            except Exception: continue
            maxrel=max(maxrel,e); perbranch[(ref['event'],ref['posterior_branch'])]=max(perbranch.get((ref['event'],ref['posterior_branch']),0.0),e)
    if maxrel>ROTATION_CONTROL_REL_TOL:
        raise RuntimeError(f'rotation transfer regression failed: max relative {maxrel}')
    rows=[{'event':e,'posterior_branch':b,'max_relative_discrepancy':v,'status':'PASS'} for (e,b),v in sorted(perbranch.items())]
    return rows,maxrel


def process_branch(sel,ar,sr,source_sha):
    event,branch=sel['event'],sel['posterior_branch']
    dspath,data=read_event_branch(Path(sr['local_path']),branch)
    tr=transform_event(data); n=len(tr['z'])
    if n!=i(ar['posterior_samples_finite']): raise RuntimeError(f'{event} {branch}: sample count mismatch')
    max_transform=0.0
    checks=[
        ('z',qtile(tr['z']),[f(ar['cptg_z_p05']),f(ar['cptg_z_p50']),f(ar['cptg_z_p95'])],TRANSFORM_TOL),
        ('m_inf_1',qtile(tr['m1']),[f(ar['m_inf_1_p05']),f(ar['m_inf_1_p50']),f(ar['m_inf_1_p95'])],TRANSFORM_TOL),
        ('m_inf_2',qtile(tr['m2']),[f(ar['m_inf_2_p05']),f(ar['m_inf_2_p50']),f(ar['m_inf_2_p95'])],TRANSFORM_TOL),
        ('m_c_1',qtile(tr['mc1']),[f(ar['m_c_1_p05']),f(ar['m_c_1_p50']),f(ar['m_c_1_p95'])],TRANSFORM_TOL),
        ('m_c_2',qtile(tr['mc2']),[f(ar['m_c_2_p05']),f(ar['m_c_2_p50']),f(ar['m_c_2_p95'])],TRANSFORM_TOL),
        ('a_inf_1',qtile(tr['q1']),[f(ar['a_inf_1_p05']),f(ar['a_inf_1_p50']),f(ar['a_inf_1_p95'])],SPIN_TOL),
        ('a_inf_2',qtile(tr['q2']),[f(ar['a_inf_2_p05']),f(ar['a_inf_2_p50']),f(ar['a_inf_2_p95'])],SPIN_TOL),
    ]
    for nm,got,exp,tol in checks: max_transform=max(max_transform,gate_quantiles(f'{event} {branch} {nm}',got,exp,tol))
    reorder_err=abs(tr['reorder_fraction']-f(ar['reorder_fraction']))
    if reorder_err>2e-12: raise RuntimeError(f'{event} {branch}: reorder authority mismatch')

    s1,i1,p1=component_rotation_calc('primary',tr['q1'],tr['m1'])
    s2,i2,p2=component_rotation_calc('secondary',tr['q2'],tr['m2'])
    n1auth=Nbh_vec(qtile(tr['q1'])[::-1]); n2auth=Nbh_vec(qtile(tr['q2'])[::-1])
    n1exp=[f(ar['N_BH_1_p05']),f(ar['N_BH_1_p50']),f(ar['N_BH_1_p95'])]
    n2exp=[f(ar['N_BH_2_p05']),f(ar['N_BH_2_p50']),f(ar['N_BH_2_p95'])]
    n1err=gate_quantiles(f'{event} {branch} N1',n1auth,n1exp,N_AUTH_TOL)
    n2err=gate_quantiles(f'{event} {branch} N2',n2auth,n2exp,N_AUTH_TOL)

    summary=[{'event':event,'posterior_branch':branch,**s} for s in (s1,s2)]
    item=[{'event':event,'posterior_branch':branch,**r} for r in (i1+i2)]
    digest=rotation_digest(tr,p1,p2)
    audit=samplewise_audit(event,branch,tr,p1,p2,digest)
    det=deterministic_audit_rows(event,branch,tr,p1,p2)
    closure={'event':event,'posterior_branch':branch,'posterior_dataset':dspath,'samples':n,
             'source_sha256':source_sha,'max_transform_authority_abs':max_transform,
             'reorder_fraction_abs':reorder_err,'N1_authority_max_abs':n1err,'N2_authority_max_abs':n2err,
             'detector_source_identity_max_rel':tr['detector_source_identity_max_rel'],'status':'PASS'}
    reorder={'event':event,'posterior_branch':branch,'samples':n,'reordered_draws':int(np.sum(tr['swap'])),
             'reorder_fraction':tr['reorder_fraction'],'reference_reorder_fraction':f(ar['reorder_fraction'])}
    return {'summary':summary,'item':item,'sample_audit':audit,'audit_samples':det,'closure':closure,'reorder':reorder}


def main(argv=None):
    ap=argparse.ArgumentParser()
    ap.add_argument('--preflight-only',action='store_true')
    ap.add_argument('--fresh',action='store_true')
    args=ap.parse_args(argv)
    package_preflight(True)
    if args.preflight_only: return

    sel=read_csv_dicts(SELECTION); auth={(r['event'],r['posterior_branch']):r for r in read_csv_dicts(AUTHORITY)}
    src_rows=read_csv_dicts(SOURCES); src={r['event']:r for r in src_rows}
    if args.fresh and WORK.exists(): shutil.rmtree(WORK)
    CHECKPOINTS.mkdir(parents=True,exist_ok=True)
    if OUT.exists(): shutil.rmtree(OUT)
    OUT.mkdir(parents=True)
    contract=file_contract_sha256(); source_audit=source_preflight(src_rows); sh={r['event']:r['sha256'] for r in source_audit}

    all_s=[]; all_i=[]; all_a=[]; all_d=[]; all_c=[]; all_r=[]
    print('============================================================')
    print('CPTG GWTC-5 INTERNAL ROTATION POPULATION r04')
    print('Geometric frame-dragging readout; no matter-rotation law assumed')
    print('============================================================')
    for pos,row in enumerate(sel,1):
        event,branch=row['event'],row['posterior_branch']; key=(event,branch)
        cp=CHECKPOINTS/f'{i(row["catalog_branch_index"]):03d}__{event}__{sanitize_branch(branch)}.json'
        result=None
        if cp.exists():
            try:
                saved=json.loads(cp.read_text())
                if saved.get('contract_sha256')==contract and saved.get('source_sha256')==sh[event]:
                    result=saved['result']; print(f'[{pos}/{len(sel)}] {event}  {branch}  CHECKPOINT=PASS')
            except Exception: result=None
        if result is None:
            print(f'[{pos}/{len(sel)}] {event}  {branch}')
            result=process_branch(row,auth[key],src[event],sh[event])
            cp.write_text(json.dumps(jsonable({'contract_sha256':contract,'source_sha256':sh[event],'result':result}),separators=(',',':')),encoding='utf-8')
            a=result['summary'][0]; b=result['summary'][1]
            print('  samples',a['samples'])
            print('  primary N-shell omega_detavg p50',a['omega_N_detavg_rad_s_p50'],'rad/s ; period',a['period_N_detavg_ms_p50'],'ms')
            print('  secondary N-shell omega_detavg p50',b['omega_N_detavg_rad_s_p50'],'rad/s ; period',b['period_N_detavg_ms_p50'],'ms')
        all_s.extend(result['summary']); all_i.extend(result['item']); all_a.append(result['sample_audit']); all_d.extend(result['audit_samples']); all_c.append(result['closure']); all_r.append(result['reorder'])

    ctrl_rows,ctrl_max=transfer_control_closure(all_s,all_i)
    write_csv(OUT/'GWTC5_INTERNAL_ROTATION_SUMMARY.csv',all_s)
    write_csv(OUT/'GWTC5_ITEM5_ROTATION.csv',all_i)
    write_csv(OUT/'GWTC5_ROTATION_SAMPLEWISE_AUDIT.csv',all_a)
    write_csv(OUT/'GWTC5_ROTATION_POSTERIOR_AUDIT_SAMPLE.csv',all_d)
    write_csv(OUT/'GWTC5_ROTATION_AUTHORITY_CLOSURE.csv',all_c)
    write_csv(OUT/'GWTC5_ROTATION_REORDER_AUDIT.csv',all_r)
    write_csv(OUT/'GWTC5_ROTATION_SOURCE_AUDIT.csv',source_audit)
    write_csv(OUT/'GWTC5_ROTATION_TRANSFER_CONTROL_CLOSURE.csv',ctrl_rows)

    # Unique-within-event stream audit: identical release labels are deduplicated only here.
    digest_rows={(r['event'],r['posterior_branch']):r for r in all_a}
    seen=set(); unique_summary=[]; unique_reorder=[]
    for r in all_s:
        d=digest_rows[(r['event'],r['posterior_branch'])]['rotation_digest_sha256']
        k=(r['event'],d,r['component'])
        if k not in seen:
            seen.add(k); unique_summary.append(r)
    seen_r=set()
    for r in all_r:
        d=digest_rows[(r['event'],r['posterior_branch'])]['rotation_digest_sha256']; k=(r['event'],d)
        if k not in seen_r: seen_r.add(k); unique_reorder.append(r)
    unique_streams=len(seen_r)
    if unique_streams!=EXPECTED_UNIQUE_WITHIN_EVENT_STREAMS:
        raise RuntimeError(f'unique within-event rotation streams {unique_streams} != {EXPECTED_UNIQUE_WITHIN_EVENT_STREAMS}')
    # No digest can be shared across different events.
    d_events={}
    for r in all_a: d_events.setdefault(r['rotation_digest_sha256'],set()).add(r['event'])
    cross=sum(1 for evs in d_events.values() if len(evs)>1)
    if cross: raise RuntimeError(f'cross-event rotation digest collisions: {cross}')

    ranges=[]
    for comp in ('primary','secondary'):
        rr=[r for r in unique_summary if r['component']==comp]
        for col in ('omega_N_detavg_rad_s_p50','period_N_detavg_ms_p50','omega_surface_rad_s_p50','period_surface_ms_p50'):
            vals=np.array([float(r[col]) for r in rr])
            ranges.append({'component':comp,'quantity':col,'count':len(vals),'minimum':float(np.min(vals)),'median':float(np.median(vals)),'maximum':float(np.max(vals))})
    vals=np.array([float(r['reorder_fraction']) for r in unique_reorder])
    ranges.append({'component':'catalog','quantity':'reorder_fraction','count':len(vals),'minimum':float(np.min(vals)),'median':float(np.median(vals)),'maximum':float(np.max(vals))})
    write_csv(OUT/'GWTC5_UNIQUE_WITHIN_EVENT_ROTATION_RANGES.csv',ranges)

    status={'stage':'CPTG_GWTC5_INTERNAL_ROTATION_POPULATION_r04','status':'PASS_INTERNAL_ROTATION_POPULATION',
            'observable':'ZAMO geometric frame-dragging angular-speed magnitude',
            'matter_rotation_inferred':False,'rotation_direction_inferred':False,
            'time_reference':'source-local asymptotic exterior Kerr coordinate time',
            'angular_readouts':['axis','determinant-measure average','equator'],
            'retained_branch_realizations':len(sel),'unique_events':len({r['event'] for r in sel}),
            'unique_source_files':len(source_audit),'posterior_draws':sum(i(r['samples']) for r in all_r),
            'unique_within_event_rotation_streams':unique_streams,
            'transfer_control_max_relative_discrepancy':ctrl_max,
            'all_source_identity_gates_passed':True,'all_authority_gates_passed':True,'all_samplewise_rotation_audits_passed':True}
    (OUT/'GWTC5_INTERNAL_ROTATION_STATUS.json').write_text(json.dumps(status,indent=2)+'\n',encoding='utf-8')
    print('============================================================')
    print('STATUS=PASS_INTERNAL_ROTATION_POPULATION')
    print('RESULTS=',OUT)

if __name__=='__main__': main()
