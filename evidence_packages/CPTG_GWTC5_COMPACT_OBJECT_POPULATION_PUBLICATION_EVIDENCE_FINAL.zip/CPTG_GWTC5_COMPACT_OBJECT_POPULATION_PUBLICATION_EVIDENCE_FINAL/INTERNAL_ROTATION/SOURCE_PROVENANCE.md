# Source Provenance

`GWTC5_FULL_SOURCE_INPUTS.csv` freezes the 259 local GWTC PE source identities used by this calculation, including official filename, release record, official MD5 where registered, locally verified SHA-256, byte size, and exact local path.

`GWTC5_FULL_BRANCH_SELECTION.csv` freezes the 288 retained posterior branch realizations and their finite sample counts.

`GWTC5_FULL_BRANCH_AUTHORITY.csv` freezes the established CPTG event-level compact-state and Structural-Mode authorities for the same event/branch keys. These values are used only as fail-closed reproduction gates. They do not tune the internal-rotation result.

`R02_ROTATION_TRANSFER_CONTROL_SUMMARY.csv` and `R02_ROTATION_TRANSFER_CONTROL_ITEM5.csv` are new rotation readouts calculated from the complete per-draw registries in the accepted ten-branch core-time transfer evidence. Their provenance is documented separately in `TRANSFER_ROTATION_PROVENANCE.md`.
