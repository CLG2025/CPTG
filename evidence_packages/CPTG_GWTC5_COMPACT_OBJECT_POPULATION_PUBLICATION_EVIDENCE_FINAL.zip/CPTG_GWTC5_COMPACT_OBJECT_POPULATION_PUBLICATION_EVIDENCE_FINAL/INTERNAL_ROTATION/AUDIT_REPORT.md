# CPTG GWTC-5 Internal Rotation Population — Independent Final Audit

## Decision

**PASS — the geometric internal frame-dragging calculation closes across the complete retained catalog.**

The result contains 288 retained release-label realizations across 259 events and 259 verified PE source files. The calculation evaluates 7,626,239 posterior draws. Numerical identity auditing leaves 260 unique within-event rotation streams for descriptive catalog statistics.

## Independent integrity checks

- ZIP extraction and table structure: PASS
- 259/259 source-audit rows: PASS
- 288/288 compact/Structural-N authority rows: PASS
- 288/288 sample-wise rotation audits: PASS
- 10/10 frozen transfer controls: PASS
- source-registry SHA-256 identities agree across source input, source audit, and branch closure tables: PASS
- posterior sample counts agree with the frozen branch-selection authority: PASS
- 28 paired release labels are exact duplicate rotation streams; `GW231123_135430` retains two genuinely distinct streams
- no rotation digest is shared by different events

Maximum recorded closure residuals are:

- compact-transform authority: 6.7110761392541463e-09
- reorder fraction: 9.714451465470121e-17
- primary Structural-N authority: 5.1092463593249696e-12
- secondary Structural-N authority: 6.1948224328034493e-12
- detector/source identity: 1.0101651302487457e-15
- inner trapping-root equation: 5.5511151231257827e-15
- Structural-N shell equation: 3.3306690738754696e-16
- accepted transfer control: 8.914964521926915e-15

The minimum posterior `x_minus-x_N` separation is 0.049408417286901297; all Structural-N shells remain strictly inside the trapping surface. Angular-ordering violations and nonfinite angular-speed samples are both zero. The sample-wise `P=2*pi/omega` identity residual is identically zero in the complete-run audit.

An independent 256-point Gauss-Legendre reconstruction over all 1,440 deterministic audit rows reproduces the stored axis, determinant-average, equatorial, and trapping-surface angular speeds with maximum relative discrepancy 1.1897817037569934e-13. The independently reconstructed period values agree to 1.1895058662757977e-13 relative discrepancy. The exact trapping-surface angular spread is 0 rad/s.

## Catalog-level branch-median ranges

Across the 260 unique within-event rotation streams:

| Component | Structural-N det.-avg. omega (rad/s) | Structural-N period (ms) | Surface omega (rad/s) | Surface period (ms) |
|---|---:|---:|---:|---:|
| 1 | 389.688–11006.958; median 2377.014 | 0.570838–16.123627; median 2.643329 | 893.801–15631.825; median 3794.429 | 0.401948–7.029734; median 1.655900 |
| 2 | 578.265–16330.834; median 3228.678 | 0.384744–10.865575; median 1.946077 | 1191.270–23276.013; median 4771.501 | 0.269943–5.274358; median 1.316818 |

The fastest branch-median Structural-N component-1 readout is `GW241109_115924` at 11006.958 rad/s; the slowest is the `GW231123_135430` `Mixed+XO4a` branch at 389.688 rad/s. For component 2, the fastest is `GW190924_021846` at 16330.834 rad/s and the slowest is the `GW231123_135430` `Mixed` branch at 578.265 rad/s.

## Interpretation boundary

These are geometric ZAMO frame-dragging rates of the declared finite-core realization. They are not a material or fluid angular velocity, rigid-body spin law, differential-rotation law, or tangential matter speed. The retained spin inputs are magnitudes, so no rotation direction is assigned.

The radial frame-dragging profile is not universally monotonic immediately inside the trapping surface. The deterministic audit sample contains 183 component/sample profiles with at least one near-boundary turnover across the registered Item-5 locations. This is a geometric feature of the evaluated omega profile, not a validation failure; no radial monotonicity condition was imposed or required.
