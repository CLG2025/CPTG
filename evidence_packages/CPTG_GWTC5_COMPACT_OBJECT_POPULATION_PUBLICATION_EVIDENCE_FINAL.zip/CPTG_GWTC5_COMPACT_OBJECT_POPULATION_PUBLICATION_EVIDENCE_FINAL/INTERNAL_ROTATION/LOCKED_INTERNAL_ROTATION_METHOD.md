# CPTG GWTC-5 Internal Rotation Readout — Locked Method

## Scope

This extension evaluates the geometric rotation already implied by the finite Kerr-compatible CPTG core used in the core-time calculation. It introduces no fitted coefficient, no new compact handoff, and no material rotation law.

The reported observable is the magnitude of the local zero-angular-momentum-observer (ZAMO) frame-dragging angular velocity relative to source-local asymptotic exterior Kerr coordinate time. Because the retained GWTC parameter-estimation fields provide spin magnitudes, the calculation does not assign a rotation sign or direction.

It must not be described as a solved matter or fluid angular velocity. A matter law would require an independently registered source four-velocity or stress-energy rotation model.

## Finite rotating core

Use the same minimum finite-core realization as the accepted core-time calculation,

```text
F(x) = (63 x^5 - 90 x^7 + 35 x^9)/8
Delta = x^2 - 2 x F(x) + q^2
sigma = x^2 + q^2 cos^2(theta)
A_d = (x^2+q^2)^2 - q^2 Delta sin^2(theta)
q = |a_hat_inf|
r_g = G M_inf/c^2
```

The geometric frame-dragging rate is

```text
omega(x,theta) = (c/r_g) [2 q x F(x) / A_d(x,theta)].
```

Units are rad/s; radians are dimensionless. The associated coordinate-time rotation period is

```text
P = 2 pi / omega.
```

## Angular reporting

Three angular readouts are retained rather than silently selecting the equator:

```text
axis:     theta = 0
detavg:   integral omega sigma sin(theta) dtheta / integral sigma sin(theta) dtheta
equator:  theta = pi/2
```

The determinant-measure average uses the same `sigma sin(theta)` measure already registered for the core-time angular average. It is a reporting operator, not a matter-rotation law. The angular integral is evaluated in closed form with a stable small-epsilon series and independently checked against 96- and 192-point Gauss-Legendre quadrature.

## Locations

The rotation readout is evaluated sample by sample at the same locations used by the core-time test:

```text
Structural-N organization shell
1 km inward from r_minus
500 m
100 m
10 m
1 m
10 cm
1 cm
exact r = r_minus
```

Offsets are exact Boyer-Lindquist radial-coordinate offsets, not proper distances.

At the exact inner trapping surface, `Delta=0`, so the angular dependence disappears and

```text
Omega_minus = (c/r_g) q/(x_minus^2 + q^2).
```

The axis, determinant-average, and equatorial values must therefore agree at the surface.

## Structural-N shell

Structural Mode remains downstream of compact closure. Use the already registered shell

```text
x_N (x_N^2+q^2) = (1+q^2)/N_BH^3.
```

No `N_BH` value is used to fit the gravitational state or choose a branch.

## Posterior rule

All quantities are evaluated on each retained posterior draw after the CPTG physical-source ordering is complete. Only then are 5th, 50th, and 95th percentiles reported. Marginal medians are never assembled into a synthetic joint posterior sample.

## Interpretation boundary

This calculation determines internal geometric frame dragging for the declared finite CPTG core. It does not determine rigid-body rotation, differential matter rotation, local material tangential speed, or a source equation of state.
