@echo off
setlocal EnableExtensions
cd /d "%~dp0"

echo ============================================================
echo CPTG GWTC-5 INTERNAL ROTATION FULL REPRODUCTION
echo ============================================================

if exist .venv rmdir /s /q .venv
py -3.11 -m venv .venv
if errorlevel 1 exit /b 1
set "PY=.venv\Scripts\python.exe"

"%PY%" -m pip install --disable-pip-version-check -r requirements.txt
if errorlevel 1 exit /b 1

echo.
echo [1/4] Locked method self-test...
"%PY%" selftest_internal_rotation.py
if errorlevel 1 exit /b 1

echo.
echo [2/4] Static full-catalog preflight...
"%PY%" run_internal_rotation_population.py --preflight-only
if errorlevel 1 exit /b 1

echo.
echo [3/4] Full posterior rotation calculation...
"%PY%" run_internal_rotation_population.py --fresh
if errorlevel 1 exit /b 1

echo.
echo [4/4] Full result validation...
"%PY%" validate_internal_rotation_results.py
if errorlevel 1 exit /b 1

echo.
echo STATUS=PASS_INTERNAL_ROTATION_FULL_REPRODUCTION
endlocal
