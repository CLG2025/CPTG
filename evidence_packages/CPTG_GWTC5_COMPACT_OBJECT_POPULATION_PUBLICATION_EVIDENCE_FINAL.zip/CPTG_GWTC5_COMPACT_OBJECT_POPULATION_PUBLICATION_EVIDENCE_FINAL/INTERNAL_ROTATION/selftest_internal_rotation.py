import math
import numpy as np

from cptg_core_time_common import Nbh_vec, xminus_vec, xN_vec, RG_PER_MSUN_KM
from cptg_internal_rotation_common import omega_triplet_vec, omega_surface_vec, period_ms

q=np.array([0.147634065418],float)
m=np.array([8.37645],float)
rg=RG_PER_MSUN_KM*m
N=Nbh_vec(q); xm=xminus_vec(q); xN=xN_vec(q,N)
oa,om,oe=omega_triplet_vec(xN,q,rg)
os=omega_surface_vec(xm,q,rg)

expected={
 'rg':12.368875803743325,
 'N':1.8685541423212226,
 'xm':0.585167729480677,
 'xN':0.5255579589653346,
 'oa':8662.986294255805,
 'om':8781.354720384405,
 'oe':8843.133755992498,
 'os':9824.642008406352,
 'pN':0.7155143491236327,
 'ps':0.6395332574768062,
}
got={'rg':rg[0],'N':N[0],'xm':xm[0],'xN':xN[0],'oa':oa[0],'om':om[0],'oe':oe[0],'os':os[0],
     'pN':period_ms(om)[0],'ps':period_ms(os)[0]}
for k,v in expected.items():
    err=abs(float(got[k])-v)
    tol=2e-11*max(abs(v),1.0)
    if err>tol: raise RuntimeError(f'deterministic sanity mismatch {k}: {got[k]} vs {v}')

# Independent high-order quadrature check of the closed angular average.
_,o96,_=omega_triplet_vec(xN,q,rg,order=96)
_,o192,_=omega_triplet_vec(xN,q,rg,order=192)
if abs(float(om[0]-o192[0]))>2e-9: raise RuntimeError('analytic/192-point determinant average mismatch')
if abs(float(o96[0]-o192[0]))>2e-9: raise RuntimeError('96/192-point determinant average mismatch')

# Exact trapping-surface theta independence.
sa,sm,se=omega_triplet_vec(xm,q,rg)
if max(abs(sa[0]-os[0]),abs(sm[0]-os[0]),abs(se[0]-os[0]))>2e-9:
    raise RuntimeError('surface theta-independence check failed')

# Nonrotating limit: frame-dragging rate must vanish.
q0=np.array([0.0]); x0=np.array([0.6]); rg0=np.array([10.0])
a0,m0,e0=omega_triplet_vec(x0,q0,rg0)
if max(abs(a0[0]),abs(m0[0]),abs(e0[0]))>1e-14:
    raise RuntimeError('q=0 frame-dragging limit failed')

print('CPTG INTERNAL-ROTATION METHOD SELF-TEST')
for k in ('N','xm','xN','oa','om','oe','os','pN','ps'):
    print(k,repr(float(got[k])))
print('analytic_vs_192_abs_rad_s',repr(abs(float(om[0]-o192[0]))))
print('surface_theta_spread_rad_s',repr(float(max(sa[0],sm[0],se[0])-min(sa[0],sm[0],se[0]))))
print('STATUS=PASS_INTERNAL_ROTATION_METHOD_SELFTEST')
