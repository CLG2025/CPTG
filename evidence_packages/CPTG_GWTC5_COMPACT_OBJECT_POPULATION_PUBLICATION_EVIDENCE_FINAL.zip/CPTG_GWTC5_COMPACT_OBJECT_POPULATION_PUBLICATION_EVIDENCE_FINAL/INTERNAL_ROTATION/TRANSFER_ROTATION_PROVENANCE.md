# Internal-Rotation Transfer-Control Provenance

The rotation transfer controls in this package were evaluated directly from the complete per-draw sample registries in the accepted ten-branch core-time transfer evidence archive:

`CPTG_GWTC5_CORE_TIME_POPULATION_TRANSFER_EVIDENCE_FINAL.zip`

Those registries preserve the post-handoff CPTG-ordered `q`, `M_inf`, `r_g`, `x_minus`, `N_BH`, and `x_N` values for every retained draw. The internal-rotation operator was applied to those frozen states without refitting or changing the compact transformation.

The controls cover 10 retained branch realizations across 9 events, including both distinct retained branches of `GW231123_135430`. They are used only as regression authorities for the new geometric rotation readout.

The accepted transfer evidence archive used to construct these controls has SHA-256:

`c7b674cf61ddfc7b1a0047dbce22952c62f1ae45de8efca55f936e85b1c0592c`
