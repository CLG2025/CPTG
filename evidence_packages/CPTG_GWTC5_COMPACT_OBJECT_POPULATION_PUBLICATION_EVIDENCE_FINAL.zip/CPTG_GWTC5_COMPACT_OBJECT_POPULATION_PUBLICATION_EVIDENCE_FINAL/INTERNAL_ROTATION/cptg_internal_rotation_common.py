from __future__ import annotations

import math
import numpy as np
from numpy.polynomial.legendre import leggauss

from cptg_core_time_common import (
    C_KM_S, RG_PER_MSUN_KM, OFFSETS, F, Nbh_vec, xminus_vec, xN_vec, qtile
)

# Same determinant measure used by the locked core-time angular average:
# sigma(x,q,u) du, where u=cos(theta). This is a reporting operator only.
_UGL96, _UGW96 = leggauss(96)
_UGL192, _UGW192 = leggauss(192)


def _omega_dimless(x, q, u):
    """Dimensionless ZAMO frame-dragging rate: (r_g/c) * omega."""
    x = np.asarray(x, float)
    q = np.asarray(q, float)
    u = np.asarray(u, float)
    d = x*x - 2.0*x*F(x) + q*q
    A = (x*x + q*q)**2 - q*q*d*(1.0-u*u)
    return 2.0*q*x*F(x) / A


def _determinant_average_factor(x, q):
    """Exact determinant-measure angular factor with a stable small-epsilon series."""
    x = np.asarray(x, float)
    q = np.asarray(q, float)
    delta = x*x - 2.0*x*F(x) + q*q
    B = (x*x + q*q)**2
    eps = q*q*delta/B
    if np.any(eps < -5e-14) or np.any(eps >= 1.0):
        raise RuntimeError('determinant-average epsilon outside inner-core domain')
    eps = np.maximum(eps, 0.0)

    j = np.empty_like(eps)
    k = np.empty_like(eps)
    small = eps < 1e-2
    if np.any(small):
        e = eps[small]
        js = np.zeros_like(e)
        ks = np.zeros_like(e)
        c = 1.0       # integral_0^1 (1-u^2)^0 du
        d = 1.0/3.0   # integral_0^1 u^2(1-u^2)^0 du
        ep = np.ones_like(e)
        for n in range(13):
            if n > 0:
                c *= (2.0*n)/(2.0*n + 1.0)
                d *= (2.0*n)/(2.0*n + 3.0)
                ep *= e
            js += c*ep
            ks += d*ep
        j[small] = js
        k[small] = ks

    idx = ~small
    if np.any(idx):
        e = eps[idx]
        jj = np.arctan(np.sqrt(e/(1.0-e))) / np.sqrt(e*(1.0-e))
        kk = (1.0 - (1.0-e)*jj) / e
        j[idx] = jj
        k[idx] = kk

    return (x*x*j + q*q*k) / (x*x + q*q/3.0)


def omega_triplet_vec(x, q, rg_km, order='analytic', batch=2048):
    """
    Return ZAMO frame-dragging angular-speed magnitudes in rad/s:
      axis (theta=0), determinant-measure average, equator (theta=pi/2).

    The sign/direction is not reconstructed because the PE fields used by the
    catalog calculation supply spin magnitudes. The returned values are rates
    relative to source-local asymptotic exterior Kerr coordinate time.

    `order='analytic'` uses the exact closed angular integral with a stable
    small-epsilon series. Integer orders are retained only for independent
    Gaussian-quadrature verification.
    """
    x = np.asarray(x, float)
    q = np.asarray(q, float)
    rg = np.asarray(rg_km, float)
    if x.shape != q.shape or x.shape != rg.shape:
        raise RuntimeError('x, q, and r_g must have identical shapes')
    if np.any(~np.isfinite(x)) or np.any(~np.isfinite(q)) or np.any(~np.isfinite(rg)):
        raise RuntimeError('non-finite internal-rotation input')
    if np.any(x <= 0) or np.any(x >= 1) or np.any(q < 0) or np.any(q >= 1) or np.any(rg <= 0):
        raise RuntimeError('internal-rotation input outside declared domain')

    delta = x*x - 2.0*x*F(x) + q*q
    base = (x*x + q*q)**2
    num = 2.0*q*x*F(x)
    A_axis = base
    A_eq = base - q*q*delta
    scale = C_KM_S / rg
    omega_axis = scale * (num / A_axis)
    omega_eq = scale * (num / A_eq)

    if order == 'analytic':
        R = _determinant_average_factor(x, q)
        omega_avg = scale * (num/base) * R
    else:
        if int(order) == 96:
            u, w = _UGL96, _UGW96
        elif int(order) == 192:
            u, w = _UGL192, _UGW192
        else:
            u, w = leggauss(int(order))
        omega_avg = np.empty_like(x)
        for s in range(0, len(x), batch):
            xx = x[s:s+batch, None]
            qq = q[s:s+batch, None]
            rr = rg[s:s+batch]
            uu = u[None, :]
            dd = xx*xx - 2.0*xx*F(xx) + qq*qq
            sigma = xx*xx + qq*qq*uu*uu
            A = (xx*xx + qq*qq)**2 - qq*qq*dd*(1.0-uu*uu)
            od = 2.0*qq*xx*F(xx) / A
            n = np.sum(w[None, :] * sigma * od, axis=1)
            den = np.sum(w[None, :] * sigma, axis=1)
            omega_avg[s:s+batch] = (C_KM_S / rr) * (n / den)

    if np.any(omega_axis > omega_avg + 1e-8) or np.any(omega_avg > omega_eq + 1e-8):
        raise RuntimeError('angular frame-dragging ordering failed')
    return omega_axis, omega_avg, omega_eq

def omega_surface_vec(xminus, q, rg_km):
    """Inner-trapping-surface angular-speed magnitude in rad/s.

    Delta=0 makes the ZAMO frame-dragging rate theta-independent:
      Omega_- = (c/r_g) q/(x_-^2+q^2).
    """
    xm = np.asarray(xminus, float)
    q = np.asarray(q, float)
    rg = np.asarray(rg_km, float)
    return (C_KM_S / rg) * q / (xm*xm + q*q)


def period_ms(omega):
    omega = np.asarray(omega, float)
    out = np.full_like(omega, np.inf)
    good = omega > 0
    out[good] = 2.0*math.pi / omega[good] * 1000.0
    return out


def _quantile_fields(prefix, arr):
    qq = qtile(arr)
    return {f'{prefix}_p05': qq[0], f'{prefix}_p50': qq[1], f'{prefix}_p95': qq[2]}


def component_rotation_calc(label, q, m):
    q = np.asarray(q, float)
    m = np.asarray(m, float)
    rg = RG_PER_MSUN_KM * m
    N = Nbh_vec(q)
    xm = xminus_vec(q)
    rminus = xm * rg
    xN = xN_vec(q, N)
    if np.any(xN >= xm):
        raise RuntimeError(f'{label}: Structural-N shell is not inside trapping surface')
    rN = xN * rg

    oNa, oNm, oNe = omega_triplet_vec(xN, q, rg)
    pNa, pNm, pNe = period_ms(oNa), period_ms(oNm), period_ms(oNe)
    oSurf = omega_surface_vec(xm, q, rg)
    pSurf = period_ms(oSurf)

    item_rows = []
    per_sample = {
        'q': q, 'M_inf': m, 'r_g_km': rg,
        'N_BH': N, 'x_minus': xm, 'r_minus_km': rminus,
        'x_N': xN, 'r_N_km': rN,
        'omega_N_axis_rad_s': oNa,
        'omega_N_detavg_rad_s': oNm,
        'omega_N_equator_rad_s': oNe,
        'period_N_axis_ms': pNa,
        'period_N_detavg_ms': pNm,
        'period_N_equator_ms': pNe,
        'omega_surface_rad_s': oSurf,
        'period_surface_ms': pSurf,
    }

    for name, d_km in OFFSETS:
        key = name.replace(' ', '_')
        if d_km == 0:
            oa = om = oe = oSurf
            pa = pm = pe = pSurf
            x = xm
        else:
            x = xm - d_km / rg
            if np.any(x <= 0):
                bad = int(np.sum(x <= 0))
                raise RuntimeError(f'{label} {name}: {bad} draws do not contain the offset inside the core')
            oa, om, oe = omega_triplet_vec(x, q, rg)
            pa, pm, pe = period_ms(oa), period_ms(om), period_ms(oe)

        row = {
            'component': label,
            'coordinate_offset_inside_rminus': name,
            'offset_km': d_km,
        }
        for nm, arr in [
            ('omega_axis_rad_s', oa), ('omega_detavg_rad_s', om), ('omega_equator_rad_s', oe),
            ('period_axis_ms', pa), ('period_detavg_ms', pm), ('period_equator_ms', pe),
        ]:
            row.update(_quantile_fields(nm, arr))
        item_rows.append(row)
        per_sample[f'item5_{key}_x'] = x
        per_sample[f'item5_{key}_omega_axis_rad_s'] = oa
        per_sample[f'item5_{key}_omega_detavg_rad_s'] = om
        per_sample[f'item5_{key}_omega_equator_rad_s'] = oe
        per_sample[f'item5_{key}_period_detavg_ms'] = pm

    summary = {
        'component': label,
        'samples': len(q),
        **_quantile_fields('q', q),
        **_quantile_fields('M_inf', m),
        **_quantile_fields('r_g_km', rg),
        **_quantile_fields('x_minus', xm),
        **_quantile_fields('r_minus_km', rminus),
        **_quantile_fields('N_BH', N),
        **_quantile_fields('x_N', xN),
        **_quantile_fields('r_N_km', rN),
        **_quantile_fields('omega_N_axis_rad_s', oNa),
        **_quantile_fields('omega_N_detavg_rad_s', oNm),
        **_quantile_fields('omega_N_equator_rad_s', oNe),
        **_quantile_fields('period_N_axis_ms', pNa),
        **_quantile_fields('period_N_detavg_ms', pNm),
        **_quantile_fields('period_N_equator_ms', pNe),
        **_quantile_fields('omega_surface_rad_s', oSurf),
        **_quantile_fields('period_surface_ms', pSurf),
    }
    return summary, item_rows, per_sample
