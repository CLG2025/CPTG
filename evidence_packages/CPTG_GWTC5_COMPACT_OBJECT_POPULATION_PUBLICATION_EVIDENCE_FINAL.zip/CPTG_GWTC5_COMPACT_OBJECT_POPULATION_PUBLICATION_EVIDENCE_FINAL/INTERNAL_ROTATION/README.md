# CPTG GWTC-5 Internal Rotation Population — Final Evidence

This standalone archive records the full-catalog geometric internal frame-dragging readout of the finite Kerr-compatible CPTG core used by the accepted compact core-time calculation.

The reported observable is the magnitude of the local ZAMO frame-dragging angular velocity relative to source-local asymptotic exterior Kerr coordinate time. It is not a material/fluid angular velocity and does not assign a rotation direction.

The archive contains the frozen 259-source / 288-branch authority, the complete result tables, sample-wise and deterministic audits, the accepted ten-branch transfer controls, execution logs, locked method, implementation source, independent audit report, and SHA-256 manifest.

For full local reproduction against the frozen PE archive, run:

```bat
call RUN_REPRODUCE_INTERNAL_ROTATION.cmd
```

The reproduction performs the locked self-test, static catalog preflight, complete posterior calculation, and final validation.
