from pathlib import Path
import csv, hashlib, json, subprocess, sys, re
ROOT=Path(__file__).resolve().parent

def sha(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        for b in iter(lambda:f.read(8*1024*1024),b''): h.update(b)
    return h.hexdigest()

def check(cond,msg):
    if not cond: raise RuntimeError('FAIL-CLOSED: '+msg)

runtime_parts={'.venv_publication','.venv','.venv_pub','__pycache__','WORK','RESULTS','FINAL_EVIDENCE','FINAL_EVIDENCE_r04a'}
def is_runtime_path(p,base):
    rel=p.relative_to(base)
    return any(part in runtime_parts for part in rel.parts)

manifest=ROOT/'MANIFEST_SHA256.txt'; check(manifest.exists(),'global manifest missing')
listed={}
for line in manifest.read_text(encoding='utf-8').splitlines():
    if not line.strip(): continue
    d,n=line.split('  ',1); p=ROOT/n
    check(p.is_file(),'manifest file missing: '+n)
    check(sha(p)==d,'global manifest mismatch: '+n)
    listed[n]=d
actual={p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file() and p!=manifest and not is_runtime_path(p,ROOT)}
check(set(listed)==actual,'global manifest file-set mismatch')

idx=ROOT/'EVIDENCE_INDEX.csv'; check(idx.exists(),'evidence index missing')
with open(idx,newline='',encoding='utf-8') as f: rows=list(csv.DictReader(f))
indexed={r['path'] for r in rows}
all_files={p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file() and not is_runtime_path(p,ROOT)}
check(indexed==all_files,'evidence index file-set mismatch')

ms={}
for line in (ROOT/'MANUSCRIPT_SHA256.txt').read_text().splitlines():
    d,n=line.split('  ',1); ms[n]=d
for n,d in ms.items(): check(sha(ROOT/n)==d,'manuscript identity: '+n)
tex_path=ROOT/'MANUSCRIPT/CPTG_GWTC5_Compact_Object_and_Population_Validation.tex'
pdf_path=ROOT/'MANUSCRIPT/CPTG_GWTC5_Compact_Object_and_Population_Validation.pdf'
tex=tex_path.read_text(encoding='utf-8')
figs=[]
for n in re.findall(r'\\includegraphics(?:\[[^\]]*\])?\{([^}]+)\}',tex):
    if n not in figs: figs.append(n)
check(len(figs)==14,'manuscript figure count')
check(all(Path(n).suffix.lower()=='.png' for n in figs),'final TeX must reference PNG figure assets')
for n in figs:
    mp=ROOT/'MANUSCRIPT'/n
    check(mp.is_file(),'missing manuscript PNG figure '+n)
check(not (ROOT/'FIGURES_PNG').exists(),'redundant FIGURES_PNG mirror directory present')
check(not (ROOT/'FIGURES_PDF_REFERENCE').exists(),'obsolete PDF figure reference directory present')
check(not (ROOT/'SOURCE_ARCHIVES').exists(),'nested predecessor publication archive present')
all_pdfs=[p for p in ROOT.rglob('*.pdf') if not is_runtime_path(p,ROOT)]
check(all_pdfs==[pdf_path],'unexpected PDF asset outside final manuscript')
all_tex=[p for p in ROOT.rglob('*.tex') if not is_runtime_path(p,ROOT)]
check(all_tex==[tex_path],'section-development TeX fragment remains in final evidence package')
check('\\cite{HDF5}' in tex and '\\bibitem{HDF5}' in tex,'HDF5 citation contract')
check(re.search(r'Within M4, 1 system falls\b',tex) is not None,'M4 singular grammar')
check(re.search(r'\b(?:r19|r18|v2a)\b',tex,re.I) is None,'internal run identifier remains in final manuscript narrative')

pi=subprocess.run(['pdfinfo',str(pdf_path)],text=True,capture_output=True)
check(pi.returncode==0,'pdfinfo final manuscript')
m=re.search(r'^Pages:\s+(\d+)',pi.stdout,re.M); check(m is not None,'PDF page count unavailable')
check(int(m.group(1))==301,'current manuscript page count')

p=subprocess.run([sys.executable,'validate_native_compact_population_evidence.py'],cwd=ROOT/'COMPACT_POPULATION',text=True,capture_output=True)
print(p.stdout,end='')
if p.stderr: print(p.stderr,end='',file=sys.stderr)
check(p.returncode==0,'compact/population validator')

def verify_nested(name):
    d=ROOT/name; rows=[]
    for line in (d/'MANIFEST_SHA256.txt').read_text().splitlines():
        if not line.strip(): continue
        h,n=line.split('  ',1); rows.append(n); check(sha(d/n)==h,f'{name} manifest: {n}')
    actual={p.relative_to(d).as_posix() for p in d.rglob('*') if p.is_file() and p!=d/'MANIFEST_SHA256.txt' and not is_runtime_path(p,d)}
    check(set(rows)==actual,f'{name} manifest file-set mismatch')
    return json.loads((d/'PACKAGE.json').read_text())
core=verify_nested('CORE_TIME'); rot=verify_nested('INTERNAL_ROTATION')
check(core['status']=='PASS_FULL_POPULATION_RESULT_VALIDATION','core-time status')
check(int(core['unique_events'])==259 and int(core['retained_labels'])==288 and int(core['posterior_draws'])==7626239,'core-time counts')
check(rot['status']=='PASS_INTERNAL_ROTATION_RESULT_VALIDATION','rotation status')
check(int(rot['unique_events'])==259 and int(rot['retained_branch_realizations'])==288 and int(rot['posterior_draws'])==7626239,'rotation counts')
check(rot.get('matter_rotation_inferred') is False,'rotation interpretation boundary')

audit=json.loads((ROOT/'AUDIT_REPORT.json').read_text())
check(audit['status']=='PASS_COMBINED_NATIVE_PUBLICATION_EVIDENCE','publication audit status')
check(audit['compact_population']['coordinate_path'].startswith('released GWTC z -> GWTC D_L decoder'),'native population coordinate path')
check(audit['manuscript']['pages']==301,'audit manuscript page count')
check(audit['manuscript']['tex_sha256']==ms['MANUSCRIPT/CPTG_GWTC5_Compact_Object_and_Population_Validation.tex'],'current manuscript tex identity')
check(audit['manuscript']['pdf_sha256']==ms['MANUSCRIPT/CPTG_GWTC5_Compact_Object_and_Population_Validation.pdf'],'current manuscript pdf identity')
check(audit['manuscript']['figure_pngs']==14,'audit PNG figure count')
check(audit['manuscript']['hdf5_citation_present'] is True,'audit HDF5 citation')
check(audit['manuscript']['internal_run_ids_in_narrative'] is False,'audit narrative cleanup')
deep=json.loads((ROOT/'FINAL_AUDIT/CPTG_GWTC5_DEEP_EVIDENCE_AUDIT_v3.json').read_text())
check(deep['status']=='PASS','deep evidence audit status')
syn=json.loads((ROOT/'SYNTHESIS/CPTG_GWTC5_SYNTHESIS_AUDIT_v2.json').read_text())
check(syn['status']=='PASS','synthesis audit status')
prune=json.loads((ROOT/'FINAL_AUDIT/CPTG_GWTC5_PACKAGE_PRUNING_AUDIT_v1.json').read_text())
check(prune['status']=='PASS' and prune['protected_files_changed']==[],'package pruning audit')
check(not (ROOT/'COMPACT_POPULATION/POPULATION_ACOUSTIC_COORDINATE_AUDIT.json').exists(),'retired acoustic audit present')
print('STATUS=PASS_COMBINED_NATIVE_PUBLICATION_EVIDENCE')
