# Publication Summary

This archive supports the final **301-page** GWTC-5 CPTG compact-state, finite-core time, geometric-rotation, and population manuscript.

## Event and compact-state scope

- 259 astrophysical events.
- 288 retained release-label realizations.
- 260 unique within-event numerical streams after exact duplicate identification.
- 520 compact components.
- 7,626,239 retained event-level posterior draws.

The candidate catalog cross-checks to the frozen compact-state evidence, core-time geometry, and rotation/radial-profile tables.

## Native-coordinate population

All 8,200 hyperposterior rows are propagated with 512 joint realizations each. The final population calculation decodes the released GWTC comparison redshift to luminosity distance, holds that observation-coordinate distance fixed, solves the CPTG native phase, and then applies the compact handoff. At the median of the row medians, component 1 follows 10.243 -> 9.623 -> 6.507 Msun from released source coordinate to CPTG exterior mass to CPTG physical compact-source mass.

## Finite-core time and geometric rotation

The core-time and rotation lanes evaluate the same 7,626,239 event-level draws over the same 288 retained release labels. The clock reference is 24 hours of source-local asymptotic exterior Kerr time. Rotation is the geometric ZAMO frame-dragging rate and is not a material rotation law.

## Figure assets

The final TeX references **14 PNG figures directly**. Each authoritative PNG is stored exactly once in `MANUSCRIPT/`, beside the TeX. No secondary PDF figure renderings or duplicate PNG mirror directory are included. `MANUSCRIPT/FIGURE_FILE_MAP.csv` records the exact PNG hashes.

## Package pruning

The final archive excludes the redundant predecessor publication ZIP, the obsolete PDF figure set, the duplicate PNG mirror, duplicate validation-log copy, and section-development TeX/rewrite/build artifacts. Frozen scientific result directories and retained numerical synthesis CSVs are byte-identical to the pre-pruning package.

The final manuscript is synchronized at TeX SHA-256 `b2eed525664c65d591b64264773a1cdd5d8c422a2e404fdf71682f634e4d1217` and PDF SHA-256 `25c72bef33631aff69bf7a03a91e9cc93c0dc26d40dc8707012274bcaa92c3a5`.
