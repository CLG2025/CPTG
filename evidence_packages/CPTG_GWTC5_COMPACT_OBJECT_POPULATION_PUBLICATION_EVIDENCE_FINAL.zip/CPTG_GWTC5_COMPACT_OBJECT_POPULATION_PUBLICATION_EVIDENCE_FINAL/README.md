# CPTG GWTC-5 Compact-Object and Population Publication Evidence

This is the final publication evidence archive for `GWTC-5 Compact Objects in CPTG: A 259-Event Compact-State, Core-Time, Geometric-Rotation, and Population Validation`.

## Included

- exact final manuscript source, compiled 301-page PDF, and the 14 PNG figures referenced directly by the TeX;
- frozen native event/population compact-state evidence;
- complete finite-core time and geometric ZAMO frame-dragging result evidence;
- the 259-event / 260-stream candidate master, 520-component registries, 4,160-row radial profiles, observational taxonomy, and class-order tables;
- catalog-wide mass, Structural-Mode, clock, rotation, boundary, and population synthesis registries;
- final scientific, TeX, deep-evidence, synthesis, and package-pruning audits;
- source provenance, execution logs, validation/reproduction scripts, and SHA-256 manifests.

The retained topology is 259 astrophysical events, 288 retained release-label realizations, 260 unique within-event numerical streams, 520 compact components, and 7,626,239 event-level posterior draws. The population calculation propagates all 8,200 official hyperposterior rows with 512 joint realizations each, for 4,198,400 population realizations.

The final population calculation decodes the released GWTC redshift coordinate to its documented luminosity-distance coordinate, holds that observation-coordinate distance fixed, solves the CPTG native phase, and then applies the compact-state handoff. The GWTC decoder values are used only to unpack the released comparison coordinate; they are not CPTG-native parameters. Internal run identifiers remain only in frozen evidence/provenance artifacts where they identify source calculations or regression controls.

Structural Mode remains object-specific and post-solution. The rotation observable is geometric ZAMO frame dragging, not material rotation.

## Manuscript identity

- TeX SHA-256: `b2eed525664c65d591b64264773a1cdd5d8c422a2e404fdf71682f634e4d1217`
- PDF SHA-256: `25c72bef33631aff69bf7a03a91e9cc93c0dc26d40dc8707012274bcaa92c3a5`
- compiled pages: **301**
- figure contract: **14 PNG files stored once, beside the final TeX in `MANUSCRIPT/`**

## Raw-data boundary

The archive is complete for the derived publication evidence and reproducibility metadata, but it does not duplicate approximately 69.7 GiB of released PE HDF5 files or the official population HDF. Their identities, sizes, release IDs, and cryptographic hashes are frozen under `COMPACT_POPULATION/`. Full numerical reruns require those external observational source files. Static validation of the distributed evidence does not require them.

Run `validate_publication_evidence.py` at the archive root for fail-closed validation of the distributed package.
