#!/usr/bin/env python3
"""Reproduce and audit the numerical results used in the NMBS-C7447 CPTG native-locking structural test.

This revision adds explicit verification of the monotonic-C_g condition used by the
endpoint Structural Mode evaluation and direct |dC_g/dr| cross-checks.
"""
import math
import numpy as np
from scipy.integrate import quad, cumulative_trapezoid
from scipy.optimize import brentq
from scipy.special import gamma, gammaincinv
from numpy.polynomial.legendre import leggauss

PI = math.pi
C = 299792458.0
KPC_M = 3.0856775814913673e19
MPC_KM = 3.085677581491367e19
SEC_PER_GYR = 365.25 * 24 * 3600 * 1e9
G_KPC = 4.30091727003628e-6  # kpc (km/s)^2 Msun^-1
ACC_CONV = 1e6 / KPC_M       # (km/s)^2/kpc -> m/s^2

# Observational anchors from van de Sande et al. (2011)
Z = 1.80
SIGMA = 294.0
SIGMA_ERR = 51.0
RE_CIRC = 1.64
RE_CIRC_ERR = 0.15
N_SERSIC = 5.3
N_SERSIC_ERR = 0.4
Q_PROJ = 0.71
Q_PROJ_ERR = 0.01
MSTAR = 1.5e11
LOGM_ERR = 0.2

# Current CPTG native branch
BPI = 1.0 - 1.0 / PI
TPI = 1.0 / PI
H0_PI = 69.4162507897
A_PI0 = PI ** 1.5 * 1e-10
P_AC = 3.0 - PI / 100.0
OM_AC = P_AC / (3.0 * PI)
OL_AC = 1.0 - OM_AC
H0_AC = 67.4777967351
H0_LUM = 73.17


def E_pi(z):
    a = 1.0 / (1.0 + z)
    return math.sqrt(BPI + TPI * a ** (-PI))


def E_ac(z):
    a = 1.0 / (1.0 + z)
    return math.sqrt(BPI + TPI * a ** (-P_AC))


def E_lum(z):
    a = 1.0 / (1.0 + z)
    return math.sqrt(OL_AC + OM_AC * a ** (-P_AC))


def E_lcdm70(z):
    return math.sqrt(0.3 * (1.0 + z) ** 3 + 0.7)


def D_A(z, H0, E):
    integral = quad(lambda zz: 1.0 / E(zz), 0.0, z, epsabs=1e-12, epsrel=1e-12)[0]
    return (299792.458 / H0) * integral / (1.0 + z)


def b_n(n):
    return float(gammaincinv(2.0 * n, 0.5))


def rfrac_over_re(n, frac):
    return (float(gammaincinv(2.0 * n, frac)) / b_n(n)) ** n


def sersic_S(s, re, n):
    return np.exp(-b_n(n) * ((np.asarray(s) / re) ** (1.0 / n) - 1.0))


def sersic_dSds(s, re, n):
    s = np.asarray(s)
    return sersic_S(s, re, n) * (-b_n(n) / n) * (s / re) ** (1.0 / n - 1.0) / re


def sersic_LS(re, n):
    b = b_n(n)
    return 2.0 * PI * n * math.exp(b) * re ** 2 * b ** (-2.0 * n) * gamma(2.0 * n)


def rho_abel_grid(rgrid, re, n, mstar, q=1.0, nquad=480):
    x, w = leggauss(nquad)
    theta = (x + 1.0) * PI / 4.0
    wt = w * PI / 4.0
    sec = 1.0 / np.cos(theta)
    out = np.empty_like(rgrid)
    fac = -mstar / (PI * q * sersic_LS(re, n))
    for i in range(0, len(rgrid), 500):
        rr = rgrid[i:i+500, None]
        s = rr * sec[None, :]
        integ = np.sum(sersic_dSds(s, re, n) * sec[None, :] * wt[None, :], axis=1)
        out[i:i+500] = fac * integ
    return out


def solve_cptg(gbar, astar, r_kpc):
    rc_m = 48.0 * PI * C ** 2 / astar
    r_m = np.asarray(r_kpc) * KPC_M
    ggeom = 0.5 * astar * (r_m / rc_m) ** (7.0 / 5.0) / (1.0 + (r_m / rc_m) ** (12.0 / 5.0))
    result = np.empty_like(gbar)
    for i, (gb, gg) in enumerate(zip(gbar, ggeom)):
        def f(g):
            return g - gb - (math.sqrt(astar * gb) + gg) / (1.0 + (g / astar) ** (123.0 / 50.0)) ** (11.0 / 50.0)
        result[i] = brentq(f, gb, gb + math.sqrt(astar * gb) + gg + 10.0 * astar,
                            xtol=1e-18, rtol=1e-12, maxiter=100)
    return result


def endpoint_mode(r, cstruct):
    r_outer = r[-1]
    r_inner = r_outer / 5.0
    denom = cstruct[0] - cstruct[-1]
    numer = r_inner * cstruct[0] - r_outer * cstruct[-1] + np.trapezoid(cstruct, r)
    lam = numer / denom
    return lam, r_outer / lam


def direct_abs_mode(r, cstruct):
    """Evaluate Structural Mode directly from w=|dC_g/dr|."""
    dcdr = np.gradient(cstruct, r, edge_order=2)
    weight = np.abs(dcdr)
    denom = np.trapezoid(weight, r)
    numer = np.trapezoid(r * weight, r)
    lam = numer / denom
    return lam, r[-1] / lam


def cstruct_diagnostics(r, cstruct):
    diffs = np.diff(cstruct)
    lam_abs, mode_abs = direct_abs_mode(r, cstruct)
    return {
        "monotonic_decreasing": bool(np.all(diffs < 0.0)),
        "max_delta_Cg": float(np.max(diffs)),
        "lambda_abs": float(lam_abs),
        "mode_abs": float(mode_abs),
    }


def structural_mode_spherical(re, n, mstar, astar, nr=6000, frac=0.95, nquad=480):
    r95 = rfrac_over_re(n, frac) * re
    rg = np.geomspace(re * 1e-6, r95, nr)
    rho = rho_abel_grid(rg, re, n, mstar, q=1.0, nquad=nquad)
    menc = cumulative_trapezoid(4.0 * PI * rho * rg ** 2, rg, initial=0.0)
    r = np.linspace(r95 / 5.0, r95, nr)
    mr = np.interp(r, rg, menc)
    gbar = G_KPC * mr / r ** 2 * ACC_CONV
    g = solve_cptg(gbar, astar, r)
    dgdr = np.gradient(g, r, edge_order=2)
    cstruct = g ** 2 + dgdr ** 2  # kappa_struct = 1 kpc
    lam, mode = endpoint_mode(r, cstruct)
    return r95, lam, mode


def structural_mode_oblate(re_major, n, mstar, astar, q, nr=5000, nfield=240, frac=0.95, nquad=480, return_diagnostics=False):
    r95 = rfrac_over_re(n, frac) * re_major
    rg = np.geomspace(re_major * 1e-6, r95, max(nr, 6000))
    rho = rho_abel_grid(rg, re_major, n, mstar, q=q, nquad=nquad)
    r = np.linspace(r95 / 5.0, r95, nr)
    xx, ww = leggauss(nfield)
    x = (xx + 1.0) / 2.0
    wt = ww / 2.0
    denom = np.sqrt(1.0 - (1.0 - q * q) * x * x)
    gbar = np.empty_like(r)
    logrho = np.log(rho)
    logrg = np.log(rg)
    for i in range(0, len(r), 200):
        rr = r[i:i+200, None]
        m = rr * x[None, :]
        rhom = np.exp(np.interp(np.log(m.ravel()), logrg, logrho)).reshape(m.shape)
        integ = np.sum(rhom * x[None, :] ** 2 / denom[None, :] * wt[None, :], axis=1)
        gbar[i:i+200] = 4.0 * PI * G_KPC * q * r[i:i+200] * integ * ACC_CONV
    g = solve_cptg(gbar, astar, r)
    dgdr = np.gradient(g, r, edge_order=2)
    cstruct = g ** 2 + dgdr ** 2
    lam, mode = endpoint_mode(r, cstruct)
    if return_diagnostics:
        return r95, lam, mode, cstruct_diagnostics(r, cstruct)
    return r95, lam, mode


def astar_from(sig, re):
    return (sig * 1000.0) ** 2 / (re * KPC_M)


def main():
    a = 1.0 / (1.0 + Z)
    npi = math.log(a)
    epi = E_pi(Z)
    api = A_PI0 * epi
    astar = astar_from(SIGMA, RE_CIRC)
    ahat = astar / epi
    eta = astar / api
    frac_astar = math.sqrt((2.0 * SIGMA_ERR / SIGMA) ** 2 + (RE_CIRC_ERR / RE_CIRC) ** 2)
    sig_astar = astar * frac_astar
    sig_eta = eta * frac_astar
    sig_ahat = ahat * frac_astar
    rc_local_gpc = (48.0 * PI * C ** 2 / astar) / KPC_M / 1e6
    rc_native_gpc = (48.0 * PI * C ** 2 / api) / KPC_M / 1e6
    rc_lock0_gpc = (48.0 * PI * C ** 2 / ahat) / KPC_M / 1e6
    sig_rc_local = rc_local_gpc * frac_astar
    sig_rc_lock0 = rc_lock0_gpc * frac_astar

    h0pi_s = H0_PI / MPC_KM
    tpi = (2.0 / (PI * h0pi_s * math.sqrt(BPI)) *
           math.asinh(math.sqrt(BPI / TPI) * a ** (PI / 2.0))) / SEC_PER_GYR
    tpi0 = (2.0 / (PI * h0pi_s * math.sqrt(BPI)) *
            math.asinh(math.sqrt(BPI / TPI))) / SEC_PER_GYR
    hstruct_over_hpi = (16.0 * PI / 3.0) * math.sqrt(BPI) * eta
    sig_hstruct_over_hpi = (16.0 * PI / 3.0) * math.sqrt(BPI) * sig_eta

    da_l70 = D_A(Z, 70.0, E_lcdm70)
    da_ac = D_A(Z, H0_AC, E_ac)
    da_lum = D_A(Z, H0_LUM, E_lum)
    da_mid = 0.5 * (da_ac + da_lum)

    distance_rows = []
    for label, da in [('acoustic', da_ac), ('midpoint', da_mid), ('luminosity', da_lum)]:
        sd = da / da_l70
        re = RE_CIRC * sd
        mstar = MSTAR * sd ** 2
        ast = astar_from(SIGMA, re)
        et = ast / api
        sig_et = et * frac_astar
        distance_rows.append((label, da, sd, re, mstar, et, sig_et, (et - 1.0) / sig_et))

    re_major = RE_CIRC / math.sqrt(Q_PROJ)
    sph95, sphlam, sphn = structural_mode_spherical(RE_CIRC, N_SERSIC, MSTAR, astar, nr=20000, nquad=480)
    maj95, majlam, majn = structural_mode_spherical(re_major, N_SERSIC, MSTAR, astar, nr=16000, nquad=480)
    obl95, obllam, obln, obl_diag = structural_mode_oblate(
        re_major, N_SERSIC, MSTAR, astar, Q_PROJ, nr=12000, nfield=400, nquad=480,
        return_diagnostics=True)
    thin00595, thin005lam, thin005n = structural_mode_oblate(re_major, N_SERSIC, MSTAR, astar, 0.005, nr=5000, nfield=260)
    thin000295, thin0002lam, thin0002n, thin_diag = structural_mode_oblate(
        re_major, N_SERSIC, MSTAR, astar, 0.0002, nr=16000, nfield=800, nquad=600,
        return_diagnostics=True)

    # Outer-registration sensitivity: R = R90, R95, R99 for the same central edge-on source.
    reg_rows = []
    for frac in [0.90, 0.95, 0.99]:
        rr, ll, nn = structural_mode_oblate(re_major, N_SERSIC, MSTAR, astar, Q_PROJ,
                                             nr=5000, nfield=240, frac=frac)
        reg_rows.append((frac, rr, ll, nn))

    # One-at-a-time edge-on source sensitivities.
    def edge(sig=SIGMA, re=RE_CIRC, ns=N_SERSIC, logm=math.log10(MSTAR), qp=Q_PROJ,
             qint=None, nr=2600, nfield=140, nquad=180, return_diagnostics=False):
        ast = astar_from(sig, re)
        remaj = re / math.sqrt(qp)
        if qint is None:
            qint = qp
        result = structural_mode_oblate(remaj, ns, 10.0 ** logm, ast, qint,
                                        nr=nr, nfield=nfield, nquad=nquad,
                                        return_diagnostics=return_diagnostics)
        if return_diagnostics:
            return result[2], result[3]
        return result[2]

    sens_specs = {
        'sigma_low': {'sig': SIGMA-SIGMA_ERR},
        'sigma_high': {'sig': SIGMA+SIGMA_ERR},
        'Re_low': {'re': RE_CIRC-RE_CIRC_ERR},
        'Re_high': {'re': RE_CIRC+RE_CIRC_ERR},
        'n_low': {'ns': N_SERSIC-N_SERSIC_ERR},
        'n_high': {'ns': N_SERSIC+N_SERSIC_ERR},
        'M_low': {'logm': math.log10(MSTAR)-LOGM_ERR},
        'M_high': {'logm': math.log10(MSTAR)+LOGM_ERR},
        'q_low': {'qp': Q_PROJ-Q_PROJ_ERR},
        'q_high': {'qp': Q_PROJ+Q_PROJ_ERR},
    }
    sens = {}
    sens_monotonic = {}
    for key, kwargs in sens_specs.items():
        val, diag = edge(return_diagnostics=True, **kwargs)
        sens[key] = val
        sens_monotonic[key] = diag['monotonic_decreasing']

    # Full deterministic signed-corner scan over quoted source extrema.
    import itertools
    corner_axes = [
        [SIGMA-SIGMA_ERR, SIGMA+SIGMA_ERR],
        [RE_CIRC-RE_CIRC_ERR, RE_CIRC+RE_CIRC_ERR],
        [N_SERSIC-N_SERSIC_ERR, N_SERSIC+N_SERSIC_ERR],
        [math.log10(MSTAR)-LOGM_ERR, math.log10(MSTAR)+LOGM_ERR],
        [Q_PROJ-Q_PROJ_ERR, Q_PROJ+Q_PROJ_ERR],
    ]
    edge_corner = []
    thin_corner = []
    edge_corner_monotonic = []
    thin_corner_monotonic = []
    for combo in itertools.product(*corner_axes):
        edge_val, edge_diag = edge(*combo, nr=1200, nfield=80, nquad=100, return_diagnostics=True)
        thin_val, thin_cdiag = edge(*combo, qint=0.0002, nr=1200, nfield=80, nquad=100, return_diagnostics=True)
        edge_corner.append((edge_val, combo))
        thin_corner.append((thin_val, combo))
        edge_corner_monotonic.append(edge_diag['monotonic_decreasing'])
        thin_corner_monotonic.append(thin_cdiag['monotonic_decreasing'])
    edge_min = min(edge_corner, key=lambda x: x[0])
    edge_max = max(edge_corner, key=lambda x: x[0])
    thin_min = min(thin_corner, key=lambda x: x[0])
    thin_max = max(thin_corner, key=lambda x: x[0])

    # High-resolution refinement of the extremal source corners identified above.
    def refine_corner(item, qint=None):
        combo = item[1]
        sig, re, ns, logm, qp = combo
        ast = astar_from(sig, re)
        remaj = re / math.sqrt(qp)
        qq = qp if qint is None else qint
        nf = 400 if qq > 0.01 else 800
        return structural_mode_oblate(remaj, ns, 10.0 ** logm, ast, qq,
                                      nr=12000, nfield=nf, nquad=600)[2]
    edge_min_ref = refine_corner(edge_min)
    edge_max_ref = refine_corner(edge_max)
    thin_min_ref = refine_corner(thin_min, qint=0.0002)
    thin_max_ref = refine_corner(thin_max, qint=0.0002)

    # Linearized shared-input covariance between eta_star and N at the edge-on central point.
    central = {'sig': SIGMA, 're': RE_CIRC, 'n': N_SERSIC,
               'logm': math.log10(MSTAR), 'q': Q_PROJ}
    errors = {'sig': SIGMA_ERR, 're': RE_CIRC_ERR, 'n': N_SERSIC_ERR,
              'logm': LOGM_ERR, 'q': Q_PROJ_ERR}
    def n_from_dict(d):
        return edge(d['sig'], d['re'], d['n'], d['logm'], d['q'], nr=1800, nfield=100, nquad=120)
    dn = {}
    for key in central:
        h = 0.1 * errors[key]
        plus = dict(central); plus[key] += h
        minus = dict(central); minus[key] -= h
        dn[key] = (n_from_dict(plus) - n_from_dict(minus)) / (2.0 * h)
    deta = {'sig': 2.0 * eta / SIGMA, 're': -eta / RE_CIRC,
            'n': 0.0, 'logm': 0.0, 'q': 0.0}
    var_eta = sum((deta[k] * errors[k]) ** 2 for k in central)
    var_n_obs = sum((dn[k] * errors[k]) ** 2 for k in ['sig', 're', 'n', 'q'])
    var_n_all = sum((dn[k] * errors[k]) ** 2 for k in central)
    cov_eta_n = sum(deta[k] * dn[k] * errors[k] ** 2 for k in central)
    rho_eta_n_all = cov_eta_n / math.sqrt(var_eta * var_n_all)

    print('NMBS-C7447 CPTG native-locking structural evidence r03')
    print(f'a={a:.12f}')
    print(f'N_pi={npi:.12f}')
    print(f'E_pi={epi:.12f}')
    print(f'a_pi0={A_PI0:.15e} m s^-2')
    print(f'a_pi(z)={api:.15e} m s^-2')
    print(f't_pi(z)={tpi:.9f} Gyr')
    print(f't_pi0={tpi0:.9f} Gyr')
    print(f'a_sigma=a_star_est={astar:.15e} m s^-2')
    print(f'sigma(a_sigma)={sig_astar:.15e} m s^-2')
    print(f'central_fractional_difference={(astar-api)/api:.12f}')
    print(f'central_pull_sigma={(astar-api)/sig_astar:.9f}')
    print(f'a_hat=a_star/E_pi={ahat:.15e} +/- {sig_ahat:.15e} m s^-2')
    print(f'eta_star=a_star/a_pi={eta:.12f} +/- {sig_eta:.12f}')
    print(f'eta_minus_one_sigma={(eta-1.0)/sig_eta:.6f}')
    print(f'R_c(local)={rc_local_gpc:.9f} +/- {sig_rc_local:.9f} Gpc linearized')
    print(f'R_C(native,z)={rc_native_gpc:.9f} Gpc')
    print(f'R_c(lock,z=0 coordinate)={rc_lock0_gpc:.9f} +/- {sig_rc_lock0:.9f} Gpc linearized')
    print(f'eta_corner_low={astar_from(SIGMA-SIGMA_ERR, RE_CIRC+RE_CIRC_ERR)/api:.12f}')
    print(f'eta_corner_high={astar_from(SIGMA+SIGMA_ERR, RE_CIRC-RE_CIRC_ERR)/api:.12f}')
    print(f'H_struct/H_pi={hstruct_over_hpi:.12f} +/- {sig_hstruct_over_hpi:.12f}')

    print('distance-coordinate sensitivity')
    print(f'D_A_LCDM70={da_l70:.9f} Mpc')
    for label, da, sd, re, ms, et, set_, pull_ in distance_rows:
        print(f'{label}: D_A={da:.9f} Mpc s_D={sd:.12f} R_e={re:.12f} kpc '
              f'Mstar={ms:.9e} Msun eta={et:.12f} +/- {set_:.12f} unit_pull={pull_:.6f}')

    print('Structural Mode')
    print(f'R_e_major={re_major:.12f} kpc')
    print(f'spherical_circularized: R95={sph95:.9f} lambda={sphlam:.9f} N={sphn:.9f}')
    print(f'spherical_same_major: R95={maj95:.9f} lambda={majlam:.9f} N={majn:.9f}')
    print(f'oblate_edge_on_q={Q_PROJ:.2f}: R95={obl95:.9f} lambda={obllam:.9f} N={obln:.9f}')
    obl_status = 'PASS' if obl_diag['monotonic_decreasing'] else 'FAIL'
    print(f"oblate_edge_on_q={Q_PROJ:.2f}_Cg_monotonic={obl_status} max_delta_Cg={obl_diag['max_delta_Cg']:.12e}")
    print(f"oblate_edge_on_q={Q_PROJ:.2f}_direct_abs: lambda={obl_diag['lambda_abs']:.9f} N={obl_diag['mode_abs']:.9f} delta_N={obl_diag['mode_abs']-obln:.12e}")
    print(f'oblate_q0.005: R95={thin00595:.9f} lambda={thin005lam:.9f} N={thin005n:.9f}')
    print(f'oblate_q0.0002_near_asymptote: R95={thin000295:.9f} lambda={thin0002lam:.9f} N={thin0002n:.9f}')
    thin_status = 'PASS' if thin_diag['monotonic_decreasing'] else 'FAIL'
    print(f"oblate_q0.0002_Cg_monotonic={thin_status} max_delta_Cg={thin_diag['max_delta_Cg']:.12e}")
    print(f"oblate_q0.0002_direct_abs: lambda={thin_diag['lambda_abs']:.9f} N={thin_diag['mode_abs']:.9f} delta_N={thin_diag['mode_abs']-thin0002n:.12e}")
    one_status = 'PASS' if all(sens_monotonic.values()) else 'FAIL'
    edge_status = 'PASS' if all(edge_corner_monotonic) else 'FAIL'
    thin_corner_status = 'PASS' if all(thin_corner_monotonic) else 'FAIL'
    print(f'one_at_a_time_Cg_monotonic={sum(sens_monotonic.values())}/{len(sens_monotonic)} {one_status}')
    print(f'edge_corner_Cg_monotonic={sum(edge_corner_monotonic)}/{len(edge_corner_monotonic)} {edge_status}')
    print(f'near_thin_corner_Cg_monotonic={sum(thin_corner_monotonic)}/{len(thin_corner_monotonic)} {thin_corner_status}')
    for frac_, rr, ll, nn in reg_rows:
        print(f'oblate_edge_on_R{int(round(frac_*100))}: R={rr:.9f} lambda={ll:.9f} N={nn:.9f}')
    for key, val in sens.items():
        print(f'N_{key}={val:.9f}')
    print(f'N_edge_compound_corner_low={edge_min_ref:.9f} inputs={edge_min[1]}')
    print(f'N_edge_compound_corner_high={edge_max_ref:.9f} inputs={edge_max[1]}')
    print(f'N_near_thin_compound_corner_low={thin_min_ref:.9f} inputs={thin_min[1]}')
    print(f'N_near_thin_compound_corner_high={thin_max_ref:.9f} inputs={thin_max[1]}')
    print(f'N_linearized_sigma_obs_only={math.sqrt(var_n_obs):.9f}  # sigma, Re, n, q only')
    print(f'N_linearized_sigma_including_0.2dex_mass={math.sqrt(var_n_all):.9f}  # illustrative, not CI')
    print(f'cov_eta_N_shared={cov_eta_n:.12e}')
    print(f'rho_eta_N_linearized_including_mass={rho_eta_n_all:.9f}')


if __name__ == '__main__':
    main()
