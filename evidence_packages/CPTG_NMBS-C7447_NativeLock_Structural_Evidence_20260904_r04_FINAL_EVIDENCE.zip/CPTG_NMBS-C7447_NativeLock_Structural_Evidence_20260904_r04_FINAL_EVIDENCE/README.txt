CPTG NMBS-C7447 Native-Locking and Structural-Mode Evidence Package

Scope
-----
This package contains the numerical evidence authority used to reproduce the
NMBS-C7447 native-phase, native-locking, distance-sensitivity, Sersic-source,
oblate-source, nonlinear-field, Structural Mode, source-sensitivity, geometry-
sensitivity, and shared-input covariance calculations cited by the manuscript.

The package also verifies the condition underlying the endpoint Structural Mode
evaluation. C_g(r) is checked for strict monotonic decrease over the registered
R/5 <= r <= R interval for the central solution, all ten one-at-a-time source
sensitivities, all 32 signed edge-on source corners, and all 32 signed near-thin
source corners. The central edge-on and near-thin results are independently
cross-checked by direct numerical integration of w(r)=|dC_g/dr|.

Authoritative numerical script
------------------------------
CPTG_NMBS-C7447_NativeLock_Structural_Evidence_20260904_r03.py

Authoritative expected output
-----------------------------
CPTG_NMBS-C7447_NativeLock_Structural_Evidence_20260904_r03.txt

Execution environment
---------------------
EXECUTION_ENVIRONMENT.txt records the Python, NumPy, SciPy, and platform versions
used for the clean verification run included with this archive.

Reproduction
------------
Run:

python CPTG_NMBS-C7447_NativeLock_Structural_Evidence_20260904_r03.py > rerun.txt

In the recorded execution environment, rerun.txt is verified when it is
byte-for-byte identical to the included authoritative output file. The package
verification record documents the clean rerun used when this archive was assembled.
