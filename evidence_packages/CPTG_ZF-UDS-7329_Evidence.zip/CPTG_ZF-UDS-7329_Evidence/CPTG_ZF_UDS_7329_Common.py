#!/usr/bin/env python3
"""Common observational inputs, constants, and CPTG comparison coordinates."""

import math
from scipy.integrate import quad

# Physical constants.
G = 6.67430e-11
C = 299792458.0
C_KM = C / 1000.0
M_SUN = 1.98847e30
KPC_M = 3.0856775814913673e19
MPC_KM = 3.0856775814913673e19
SEC_PER_GYR = 365.25 * 24 * 3600 * 1e9

# EXCELS population and phase authority: Leung et al. 2026, MNRAS 549, stag827.
Z_OBS = 3.1954
DZ_OBS = 0.0002
LOGM_TOTAL_SOURCE = 11.19
DLOGM_TOTAL = 0.02
SFR_UPPER = 1.13
LOGZ = 0.07
LOGZ_PLUS = 0.14
LOGZ_MINUS = 0.09
TFORM_SOURCE_GYR = 0.28
TFORM_PLUS = 0.17
TFORM_MINUS = 0.14
Z_FORM = 14.5
Z_FORM_PLUS = 8.9
Z_FORM_MINUS = 4.2
Z_QUENCH = 9.90
Z_QUENCH_PLUS = 7.79
Z_QUENCH_MINUS = 3.29
A_V = 0.26
DA_V = 0.06
TAU_10_90 = 262.0
TAU_10_90_PLUS = 287.0
TAU_10_90_MINUS = 200.0
MGFE = 0.24
DMGFE = 0.10

# EXCELS imaging and kinematic measurements used for the bound-system calculation.
Z_STRUCT_SOURCE = 3.1943
RE_SOURCE_KPC = 0.910
DRE_SOURCE_KPC = 0.010
SIGMA_KMS = 250.0
DSIGMA_KMS = 20.0
N_SERSIC = 2.5
DN_SERSIC = 0.1
ELLIPTICITY = 0.77
DELLIPTICITY = 0.01
LOGM_DYN_SOURCE = 10.94
DLOGM_DYN = 0.07

# CPTG branch coordinates.
PI = math.pi
B_PI = 1.0 - 1.0 / PI
T_PI = 1.0 / PI
P_AC = 3.0 - PI / 100.0
OMEGA_M_AC = P_AC / (3.0 * PI)
OMEGA_L_AC = 1.0 - OMEGA_M_AC
H0_PI = 69.4162507897
H0_AC = 67.4777967351
H0_LUM = 73.17


def E_pi_z(z):
    return math.sqrt(B_PI + T_PI * (1.0 + z) ** PI)


def E_ac_z(z):
    return math.sqrt(B_PI + T_PI * (1.0 + z) ** P_AC)


def E_lum_z(z):
    return math.sqrt(OMEGA_L_AC + OMEGA_M_AC * (1.0 + z) ** P_AC)


def E_lcdm_z(z):
    return math.sqrt(0.3 * (1.0 + z) ** 3 + 0.7)


def D_A(z, H0, Efunc):
    integ = quad(lambda zp: 1.0 / Efunc(zp), 0.0, z, epsabs=1e-12, epsrel=1e-12)[0]
    return (C_KM / H0) * integ / (1.0 + z)


def H0_gyr_inv(H0):
    return H0 / MPC_KM * SEC_PER_GYR


def branch_clock(a, H0, B, T, q):
    H = H0_gyr_inv(H0)
    return 2.0 / (q * H * math.sqrt(B)) * math.asinh(math.sqrt(B / T) * a ** (q / 2.0))


def coordinate_values():
    """Derive all source-to-CPTG distance scales from the stated branch equations."""
    da_lcdm_source = D_A(Z_OBS, 70.0, E_lcdm_z)
    da_lcdm_struct = D_A(Z_STRUCT_SOURCE, 70.0, E_lcdm_z)
    da_ac = D_A(Z_OBS, H0_AC, E_ac_z)
    da_lum = D_A(Z_OBS, H0_LUM, E_lum_z)
    da_mid = 0.5 * (da_ac + da_lum)
    pop_scale = da_mid / da_lcdm_source
    struct_scale = da_mid / da_lcdm_struct

    re = RE_SOURCE_KPC * struct_scale
    dre = DRE_SOURCE_KPC * struct_scale
    logMtotal = LOGM_TOTAL_SOURCE + 2.0 * math.log10(pop_scale)
    logMe_source = LOGM_TOTAL_SOURCE - math.log10(2.0)
    logMe = logMe_source + 2.0 * math.log10(pop_scale)
    logMdyn = LOGM_DYN_SOURCE + math.log10(struct_scale)

    return {
        'DA_Lambda70_source_phase_Mpc': da_lcdm_source,
        'DA_Lambda70_structural_measurement_phase_Mpc': da_lcdm_struct,
        'DA_ac_Mpc': da_ac,
        'DA_lum_Mpc': da_lum,
        'DA_mid_Mpc': da_mid,
        'population_distance_scale': pop_scale,
        'structural_distance_scale': struct_scale,
        'Re_mid_kpc': re,
        'dRe_mid_kpc': dre,
        'logM_total_mid': logMtotal,
        'logMstar_e_source_derived': logMe_source,
        'logMstar_e_mid': logMe,
        'logMdyn_mid': logMdyn,
    }
