#!/usr/bin/env python3
"""Fail-closed integrity and result verification for the evidence package."""

import argparse
import hashlib
import os
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
EXPECTED_RESULTS = ROOT / 'EXPECTED_RESULTS_SHA256.txt'
MANIFEST = ROOT / 'SHA256SUMS.txt'
FINAL_RESULTS = {
    'CLOSURE_RESULTS.txt': ROOT / 'CLOSURE_RESULTS.txt',
    'STRUCTURAL_MODE_RESULTS.txt': ROOT / 'STRUCTURAL_MODE_RESULTS.txt',
}


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def canonical_text_bytes(path: Path) -> bytes:
    data = path.read_bytes()
    return data.replace(b'\r\n', b'\n').replace(b'\r', b'\n')


def normalized_text_sha256(path: Path) -> str:
    return sha256_bytes(canonical_text_bytes(path))


def exact_file_sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def parse_hash_file(path: Path):
    entries = []
    for lineno, raw in enumerate(path.read_text(encoding='utf-8').splitlines(), 1):
        line = raw.strip()
        if not line or line.startswith('#'):
            continue
        parts = line.split(None, 1)
        if len(parts) != 2 or len(parts[0]) != 64:
            raise RuntimeError(f'{path.name}:{lineno}: invalid hash entry')
        entries.append((parts[0].lower(), parts[1].strip()))
    if not entries:
        raise RuntimeError(f'{path.name}: no hash entries')
    return entries


def verify_manifest():
    failures = []
    for expected, relname in parse_hash_file(MANIFEST):
        path = ROOT / relname
        if not path.is_file():
            failures.append(f'MISSING {relname}')
            continue
        actual = exact_file_sha256(path)
        if actual != expected:
            failures.append(f'HASH_MISMATCH {relname} expected={expected} actual={actual}')
    if failures:
        for item in failures:
            print(item, file=sys.stderr)
        raise SystemExit(1)
    print('PACKAGE_MANIFEST_VERIFY PASS')


def verify_results(closure_temp: Path, structural_temp: Path, promote: bool):
    supplied = {
        'CLOSURE_RESULTS.txt': closure_temp,
        'STRUCTURAL_MODE_RESULTS.txt': structural_temp,
    }
    expected_map = {name: digest for digest, name in parse_hash_file(EXPECTED_RESULTS)}
    failures = []
    for name, temp in supplied.items():
        if name not in expected_map:
            failures.append(f'NO_EXPECTED_HASH {name}')
            continue
        if not temp.is_file():
            failures.append(f'MISSING_GENERATED_RESULT {temp}')
            continue
        actual = normalized_text_sha256(temp)
        expected = expected_map[name]
        if actual != expected:
            failures.append(f'RESULT_MISMATCH {name} expected={expected} actual={actual}')
    if failures:
        for item in failures:
            print(item, file=sys.stderr)
        raise SystemExit(1)

    if promote:
        for name, temp in supplied.items():
            # Normalize text to LF before replacing the archived result so the
            # package manifest remains platform independent after a successful run.
            final = FINAL_RESULTS[name]
            data = canonical_text_bytes(temp)
            staging = final.with_name(final.name + '.verified_tmp')
            staging.write_bytes(data)
            os.replace(staging, final)
    print('EXPECTED_RESULTS_VERIFY PASS')


def main():
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest='command', required=True)
    sub.add_parser('manifest')
    r = sub.add_parser('results')
    r.add_argument('closure_temp')
    r.add_argument('structural_temp')
    r.add_argument('--promote', action='store_true')
    args = parser.parse_args()

    if args.command == 'manifest':
        verify_manifest()
    elif args.command == 'results':
        verify_results(Path(args.closure_temp), Path(args.structural_temp), args.promote)


if __name__ == '__main__':
    main()
