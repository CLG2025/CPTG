#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

CLOSURE_TMP=".CLOSURE_RESULTS.tmp"
STRUCTURAL_TMP=".STRUCTURAL_MODE_RESULTS.tmp"
cleanup() {
  rm -f "$CLOSURE_TMP" "$STRUCTURAL_TMP"
}
trap cleanup EXIT

python3 VERIFY_PACKAGE.py manifest
python3 -m py_compile \
  CPTG_ZF_UDS_7329_Common.py \
  CPTG_ZF_UDS_7329_Closure.py \
  CPTG_ZF_UDS_7329_StructuralMode.py \
  VERIFY_PACKAGE.py

python3 CPTG_ZF_UDS_7329_Closure.py > "$CLOSURE_TMP"
python3 CPTG_ZF_UDS_7329_StructuralMode.py > "$STRUCTURAL_TMP"
python3 VERIFY_PACKAGE.py results "$CLOSURE_TMP" "$STRUCTURAL_TMP" --promote
python3 VERIFY_PACKAGE.py manifest

echo "CPTG_ZF_UDS_7329_REPRODUCTION PASS"
