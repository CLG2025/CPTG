@echo off
setlocal
cd /d "%~dp0"
set "CLOSURE_TMP=.CLOSURE_RESULTS.tmp"
set "STRUCTURAL_TMP=.STRUCTURAL_MODE_RESULTS.tmp"

python VERIFY_PACKAGE.py manifest
if errorlevel 1 goto :fail

python -m py_compile CPTG_ZF_UDS_7329_Common.py CPTG_ZF_UDS_7329_Closure.py CPTG_ZF_UDS_7329_StructuralMode.py VERIFY_PACKAGE.py
if errorlevel 1 goto :fail

python CPTG_ZF_UDS_7329_Closure.py > "%CLOSURE_TMP%"
if errorlevel 1 goto :fail
python CPTG_ZF_UDS_7329_StructuralMode.py > "%STRUCTURAL_TMP%"
if errorlevel 1 goto :fail

python VERIFY_PACKAGE.py results "%CLOSURE_TMP%" "%STRUCTURAL_TMP%" --promote
if errorlevel 1 goto :fail
python VERIFY_PACKAGE.py manifest
if errorlevel 1 goto :fail

del /q "%CLOSURE_TMP%" "%STRUCTURAL_TMP%" 2>nul
echo CPTG_ZF_UDS_7329_REPRODUCTION PASS
endlocal
exit /b 0

:fail
del /q "%CLOSURE_TMP%" "%STRUCTURAL_TMP%" 2>nul
echo CPTG_ZF_UDS_7329_REPRODUCTION FAIL
endlocal
exit /b 1
