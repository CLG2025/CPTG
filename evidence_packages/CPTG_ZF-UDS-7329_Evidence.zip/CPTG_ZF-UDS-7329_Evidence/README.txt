CPTG ZF-UDS-7329 Evidence Package

Purpose
-------
Reproduce the numerical quantities used in the manuscript
"CPTG Native-Phase Structural Test: Effective-Radius Closure and Structural Mode N of ZF-UDS-7329".

Observational authority
-----------------------
Population and phase quantities:
Ho-Hin Leung et al., "The JWST EXCELS survey: the ages and abundances of 3 < z < 5 massive quiescent galaxies show that downsizing was already in place by z ≃ 4",
MNRAS 549, stag827 (2026), DOI: 10.1093/mnras/stag827.
Public source products: https://github.com/HinLeung622/EXCELS_massive_quiescent

Adopted source values:
  z = 3.1954 +/- 0.0002
  log10(M*/Msun) = 11.19 +/- 0.02
  SFR averaged over 10 Myr < 1.13 Msun/yr
  log10(Z*/Zsun) = 0.07 +0.14/-0.09
  t_form(source conventional coordinate) = 0.28 +0.17/-0.14 Gyr
  z_form = 14.5 +8.9/-4.2
  z_quench = 9.90 +7.79/-3.29
  A_V = 0.26 +/- 0.06 mag
  tau_10-90 = 262 +287/-200 Myr
  [Mg/Fe] = 0.24 +/- 0.10

EXCELS structural measurements for the same galaxy:
A. C. Carnall et al., MNRAS 534, 325–348 (2024), DOI: 10.1093/mnras/stae2092.
  structural measurement redshift = 3.1943
  F277W Re = 0.910 +/- 0.010 kpc
  intrinsic stellar dispersion = 250 +/- 20 km/s
  F277W Sersic n = 2.5 +/- 0.1
  F277W ellipticity = 0.77 +/- 0.01
  log10(Mdyn,e/Msun) = 10.94 +/- 0.07

The source paper's fitted spectral-broadening parameter is not substituted for the intrinsic stellar dispersion because that quantity does not separate the spectral resolution of model and data.

Files
-----
CPTG_ZF_UDS_7329_Common.py
  Single source for adopted observations, physical constants, CPTG branch constants,
  distance functions, and derived source-to-CPTG coordinate scales used by both calculations.

CPTG_ZF_UDS_7329_Closure.py
  Recomputes CPTG comparison distances, source-coordinate transformations,
  native/projection clocks, formation/quenching coordinates, the central and lower-1-sigma
  formation-marker cadence tests, pressure-support a_star, Rc, the implicit one-radius CPTG
  field, propagated input sensitivities, and nominal closure residuals.

CLOSURE_RESULTS.txt
  Frozen verified output from the closure script.

CPTG_ZF_UDS_7329_StructuralMode.py
  Recomputes the Sersic R95 registration, spherical Structural Mode, the spherical
  one-at-a-time sensitivity table and grid convergence, oblate-homoeoid source geometry,
  inclination/thickness family, oblate source sensitivities, deterministic corner stresses,
  and numerical convergence tests.

STRUCTURAL_MODE_RESULTS.txt
  Frozen verified output from the Structural Mode script.

SOURCE_VALUES.txt
  Compact observational source register and derived coordinate values.

VERIFY_PACKAGE.py
  Cross-platform fail-closed verifier for the full package manifest and generated results.

EXPECTED_RESULTS_SHA256.txt
  Frozen canonical SHA-256 hashes of the two expected result files.

RUN_ALL_WINDOWS.cmd / RUN_ALL.sh
  Verify package integrity, compile the Python sources, run both calculations to temporary
  files, require exact agreement with the frozen expected result hashes, promote verified
  outputs, verify package integrity again, and only then report PASS.

SHA256SUMS.txt
  SHA-256 integrity manifest for the evidence files.

requirements.txt / ENVIRONMENT.txt
  Pinned Python dependencies and the tested reproduction environment.

Execution
---------
Linux/macOS:
  ./RUN_ALL.sh

Windows:
  RUN_ALL_WINDOWS.cmd

A successful run ends with all of the following:
  PACKAGE_MANIFEST_VERIFY PASS
  EXPECTED_RESULTS_VERIFY PASS
  PACKAGE_MANIFEST_VERIFY PASS
  CPTG_ZF_UDS_7329_REPRODUCTION PASS

Any changed package file, script failure, or result mismatch returns a nonzero exit status and does not report reproduction PASS.

Scientific scope
----------------
The one-radius virial comparison is a shared-input closure test, not an independent prediction significance.
The radial source assumes constant stellar M/L. The oblate calculation changes source geometry without inventing a rotation velocity or fitting a Jeans model. Continuous Structural Mode N is the primary structural readout.
