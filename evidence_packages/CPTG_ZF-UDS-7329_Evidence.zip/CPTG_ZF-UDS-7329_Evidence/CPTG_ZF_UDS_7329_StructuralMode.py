#!/usr/bin/env python3
"""
ZF-UDS-7329 Structural Mode geometry reproduction using the adopted EXCELS source values.

Purpose
-------
Reproduce the spherical-equivalent Structural Mode calculation and the
non-fitted oblate-source stress test using the measured F277W ellipticity.
No rotation velocity is invented and the observed-epoch pressure-support
estimator a_star ~= sigma_star^2 / R_e is kept fixed.

The oblate calculation assumes a stellar density stratified on similar oblate
spheroids m^2 = R^2 + z^2/q_int^2, constant stellar M/L, and the same projected
Sersic semimajor-axis profile.  The exact equatorial Newtonian source field for
nested oblate homoeoids is used before solving the unchanged CPTG scalar response.
"""

import math
from functools import lru_cache
import numpy as np
from numpy.polynomial.legendre import leggauss
from scipy.integrate import quad, cumulative_trapezoid
from scipy.interpolate import PchipInterpolator, CubicSpline
from scipy.optimize import brentq
from scipy.special import gamma, gammaincinv
from CPTG_ZF_UDS_7329_Common import (
    G, C, M_SUN, KPC_M, RE_SOURCE_KPC, DRE_SOURCE_KPC, SIGMA_KMS, DSIGMA_KMS,
    LOGM_TOTAL_SOURCE, DLOGM_TOTAL, N_SERSIC, DN_SERSIC, ELLIPTICITY,
    DELLIPTICITY, coordinate_values,
)

COORD = coordinate_values()
POP_DISTANCE_SCALE = COORD['population_distance_scale']
STRUCT_DISTANCE_SCALE = COORD['structural_distance_scale']
RE_KPC = COORD['Re_mid_kpc']
LOGM_TOTAL = COORD['logM_total_mid']
Q_PROJ = 1.0 - ELLIPTICITY

KAPPA_STRUCT_KPC = 1.0


def csmi(N):
    intervals = [
        (None, 1.45, 'Dwarf Irregular'),
        (1.45, 1.75, 'Magellanic Irregular'),
        (1.75, 1.95, 'LSB Dwarf Disk'),
        (1.95, 2.15, 'Transition Dwarf'),
        (2.15, 2.35, 'LSB Spiral'),
        (2.35, 2.55, 'Very Late Spiral'),
        (2.55, 2.80, 'Late Spiral'),
        (2.80, 3.05, 'Intermediate Spiral'),
        (3.05, 3.30, 'Early Spiral'),
        (3.30, 3.55, 'Bulged Spiral'),
        (3.55, 3.72, 'Lenticular/Early Disk'),
        (3.72, None, 'High-Mode Outlier'),
    ]
    for lo, hi, label in intervals:
        if (lo is None or N > lo) and (hi is None or N <= hi):
            return label
    return 'Undefined'


def astar_from(sigma_kms, re_kpc):
    return (sigma_kms * 1e3) ** 2 / (re_kpc * KPC_M)


# -----------------------------------------------------------------------------
# Spherical-equivalent baseline calculation.
# -----------------------------------------------------------------------------
@lru_cache(maxsize=None)
def spherical_mass_fraction(n, re_kpc):
    n = float(n)
    re_kpc = float(re_kpc)
    b_n = float(gammaincinv(2.0 * n, 0.5))

    def intensity(R):
        return math.exp(-b_n * ((R / re_kpc) ** (1.0 / n) - 1.0))

    def dI_dR(R):
        return -intensity(R) * b_n / (n * re_kpc) * (R / re_kpc) ** (1.0 / n - 1.0)

    def rho(r):
        return quad(
            lambda u: -dI_dR(r * math.cosh(u)) / math.pi,
            0.0, 20.0, epsabs=1e-9, epsrel=2e-8, limit=150
        )[0]

    grid = np.geomspace(re_kpc * 1e-5, re_kpc * 200.0, 2500)
    rho_grid = np.array([rho(float(r)) for r in grid])
    m_grid = 4.0 * math.pi * cumulative_trapezoid(rho_grid * grid**2, grid, initial=0.0)
    total = 2.0 * math.pi * n * re_kpc**2 * math.exp(b_n) * b_n ** (-2.0 * n) * gamma(2.0 * n)
    fraction = np.maximum.accumulate(np.clip(m_grid / total, 0.0, 1.0))
    return PchipInterpolator(grid, fraction, extrapolate=True), b_n


def solve_cptg_scalar(gbar, r_kpc, a_star, rc_m):
    r_m = r_kpc * KPC_M
    y = r_m / rc_m
    ggeom = 0.5 * a_star * y ** (7.0 / 5.0) / (1.0 + y ** (12.0 / 5.0))
    A = math.sqrt(a_star * gbar) + ggeom

    def residual(g):
        suppression = (1.0 + (g / a_star) ** (123.0 / 50.0)) ** (11.0 / 50.0)
        return g - gbar - A / suppression

    return brentq(residual, 0.0, gbar + A + a_star, xtol=1e-30, rtol=1e-13)


def mode_from_field(r_kpc, g, lo, R):
    g_spline = CubicSpline(r_kpc, g)
    dg_dr_kpc = g_spline(r_kpc, 1)
    Cg = g**2 + (KAPPA_STRUCT_KPC * dg_dr_kpc) ** 2
    C_spline = CubicSpline(r_kpc, Cg)

    check_r = np.linspace(lo, R, 5000)
    max_dCg = float(np.max(C_spline(check_r, 1)))
    if max_dCg >= 0.0:
        raise RuntimeError(f'C_g is not strictly decreasing: max derivative={max_dCg}')

    C_lo = float(C_spline(lo))
    C_R = float(C_spline(R))
    int_C = float(C_spline.integrate(lo, R))
    denom = C_lo - C_R
    numer = lo * C_lo - R * C_R + int_C
    lam = numer / denom
    return lam, R / lam, max_dCg


def solve_mode_spherical(a_star, logmass_total, re_kpc, n, n_grid=16000):
    mass_fraction, b_n = spherical_mass_fraction(float(n), float(re_kpc))
    mass = 10.0**logmass_total * M_SUN
    rc = 48.0 * math.pi * C**2 / a_star
    R = re_kpc * (gammaincinv(2.0 * n, 0.95) / b_n) ** n
    lo = R / 5.0

    base = np.linspace(0.9 * lo, 1.02 * R, n_grid)
    r_kpc = np.unique(np.sort(np.r_[base, lo, R]))
    gbar = np.empty_like(r_kpc)
    g = np.empty_like(r_kpc)
    for j, r in enumerate(r_kpc):
        frac = float(np.clip(mass_fraction(float(r)), 0.0, 1.0))
        gbar[j] = G * mass * frac / (r * KPC_M) ** 2
        g[j] = solve_cptg_scalar(gbar[j], float(r), a_star, rc)

    lam, N, max_dCg = mode_from_field(r_kpc, g, lo, R)
    return dict(R95_kpc=R, lambda_kpc=lam, N=N, CSMI=csmi(N), max_dCg_dr=max_dCg)


# -----------------------------------------------------------------------------
# Oblate-source geometry stress test.
# -----------------------------------------------------------------------------
@lru_cache(maxsize=None)
def sersic_density_shape_hi(n, re_kpc):
    """Spherical Abel inverse used as the common shape function j(m).

    For an oblate system with constant intrinsic q and the same projected
    semimajor-axis Sersic profile, mass normalization supplies the required
    1/q factor.  The q prefactor in the homoeoid field then cancels that
    normalization, leaving q only in the geometric kernel.
    """
    n = float(n)
    re_kpc = float(re_kpc)
    b_n = float(gammaincinv(2.0 * n, 0.5))

    def intensity(R):
        return math.exp(-b_n * ((R / re_kpc) ** (1.0 / n) - 1.0))

    def dI_dR(R):
        return -intensity(R) * b_n / (n * re_kpc) * (R / re_kpc) ** (1.0 / n - 1.0)

    def rho_shape(r):
        return quad(
            lambda u: -dI_dR(r * math.cosh(u)) / math.pi,
            0.0, 25.0, epsabs=1e-10, epsrel=5e-10, limit=250
        )[0]

    # The x^2 field kernel suppresses the central integrable cusp, but the
    # dense lower extension prevents quadrature-order dependence from spline
    # extrapolation near x=0.
    grid = np.geomspace(re_kpc * 1e-9, re_kpc * 200.0, 6000)
    rho_grid = np.array([rho_shape(float(r)) for r in grid])
    # Interpolate log(rho) against log(r).  The deprojected Sersic density spans
    # many orders of magnitude; log-log interpolation avoids the relative-error
    # floor of direct interpolation on a logarithmic radial grid.
    log_rho_interp = PchipInterpolator(
        np.log(grid), np.log(rho_grid), extrapolate=True
    )

    def rho_interp(r):
        r = np.asarray(r, dtype=float)
        return np.exp(log_rho_interp(np.log(r)))

    total_circular = (
        2.0 * math.pi * n * re_kpc**2 * math.exp(b_n)
        * b_n ** (-2.0 * n) * gamma(2.0 * n)
    )
    return rho_interp, total_circular, b_n


def gbar_oblate_array(r_kpc, mass_kg, n, re_kpc, q_int, n_quad=480, chunk=1200):
    """Exact equatorial source acceleration for similar oblate homoeoids.

    v_c^2(R) = 4*pi*G*q int_0^R rho_q(m) m^2 dm /
               sqrt(R^2-(1-q^2)m^2)

    with rho_q normalized to the fixed total stellar mass.  Inserting
    rho_q = M*j(m)/(q*L_circ) cancels q outside the integral.
    """
    if not (0.0 < q_int <= 1.0):
        raise ValueError('q_int must satisfy 0 < q_int <= 1')

    rho_shape, L_circ, _ = sersic_density_shape_hi(float(n), float(re_kpc))
    nodes, weights = leggauss(n_quad)
    e2 = 1.0 - q_int**2

    # For flattened systems remove the integrable endpoint singularity with
    # x = sin(theta)/e, e=sqrt(1-q^2). Then
    # x^2 dx/sqrt(1-e^2 x^2) = sin^2(theta) dtheta/e^3.
    # The ordinary x quadrature is retained near the spherical limit.
    if q_int < 0.9:
        ecc = math.sqrt(e2)
        theta_max = math.asin(ecc)
        theta = 0.5 * (nodes + 1.0) * theta_max
        wtheta = 0.5 * theta_max * weights
        x = np.sin(theta) / ecc
        kernel = wtheta * np.sin(theta)**2 / ecc**3
    else:
        x = 0.5 * (nodes + 1.0)
        w = 0.5 * weights
        kernel = w * x**2 / np.sqrt(1.0 - e2 * x**2)

    r_kpc = np.asarray(r_kpc, dtype=float)
    out = np.empty_like(r_kpc)
    for start in range(0, len(r_kpc), chunk):
        rv = r_kpc[start:start + chunk]
        vals = np.asarray(rho_shape(rv[:, None] * x[None, :]))
        integ = np.sum(vals * kernel[None, :], axis=1)
        # 4*pi*R^2/L_circ * integral has units 1/kpc and equals 1/R
        # times the enclosed mass fraction in the spherical q=1 limit.
        factor_per_kpc = 4.0 * math.pi * rv**2 * integ / L_circ
        v2 = G * mass_kg * factor_per_kpc / KPC_M
        out[start:start + chunk] = v2 / (rv * KPC_M)
    return out


def solve_mode_oblate(sigma_kms=SIGMA_KMS, re_kpc=RE_KPC,
                       logmass=LOGM_TOTAL, n=N_SERSIC, q_int=Q_PROJ,
                       n_grid=8000, n_quad=480):
    a_star = astar_from(sigma_kms, re_kpc)
    mass = 10.0**logmass * M_SUN
    rc = 48.0 * math.pi * C**2 / a_star
    b_n = float(gammaincinv(2.0 * n, 0.5))
    R = re_kpc * (gammaincinv(2.0 * n, 0.95) / b_n) ** n
    lo = R / 5.0

    base = np.linspace(0.9 * lo, 1.02 * R, n_grid)
    r_kpc = np.unique(np.sort(np.r_[base, lo, R]))
    gbar = gbar_oblate_array(r_kpc, mass, n, re_kpc, q_int, n_quad=n_quad)
    g = np.array([
        solve_cptg_scalar(float(gb), float(r), a_star, rc)
        for gb, r in zip(gbar, r_kpc)
    ])

    lam, N, max_dCg = mode_from_field(r_kpc, g, lo, R)
    gbar_re = float(gbar_oblate_array(
        np.array([re_kpc]), mass, n, re_kpc, q_int, n_quad=max(480, n_quad)
    )[0])
    g_re = solve_cptg_scalar(gbar_re, re_kpc, a_star, rc)
    return dict(
        q_int=q_int,
        a_star=a_star,
        R95_kpc=R,
        lambda_kpc=lam,
        N=N,
        CSMI=csmi(N),
        max_dCg_dr=max_dCg,
        gbar_Re=gbar_re,
        g_CPTG_Re=g_re,
    )


def q_intrinsic_from_inclination(q_proj, inclination_deg):
    i = math.radians(inclination_deg)
    numerator = q_proj**2 - math.cos(i)**2
    denominator = math.sin(i)**2
    if numerator < 0.0:
        return None
    return math.sqrt(numerator / denominator)


def print_case(label, result):
    print(label)
    for key in ('q_int', 'a_star', 'R95_kpc', 'lambda_kpc', 'N', 'CSMI',
                'gbar_Re', 'g_CPTG_Re', 'max_dCg_dr'):
        if key in result:
            value = result[key]
            if isinstance(value, float):
                print(f'  {key}={value:.15g}')
            else:
                print(f'  {key}={value}')


def main():
    print('SOURCE_GEOMETRY')
    print(f'population_distance_scale={POP_DISTANCE_SCALE:.12f}')
    print(f'structural_distance_scale={STRUCT_DISTANCE_SCALE:.12f}')
    print(f'Re_mid_kpc={RE_KPC:.12f}')
    print(f'logM_total_mid={LOGM_TOTAL:.12f}')
    print(f'n_sersic={N_SERSIC:.12f}')
    print(f'ellipticity={ELLIPTICITY:.12f}')
    print(f'q_proj=1-e={Q_PROJ:.12f}')
    i_min = math.degrees(math.acos(Q_PROJ))
    print(f'oblate_i_min_deg={i_min:.12f}')

    print('\nSPHERICAL_BASELINE')
    a0 = astar_from(SIGMA_KMS, RE_KPC)
    spherical = solve_mode_spherical(a0, LOGM_TOTAL, RE_KPC, N_SERSIC, n_grid=16000)
    print_case('spherical_equivalent', spherical)

    print('\nSPHERICAL_ONE_AT_A_TIME_SENSITIVITY')
    re_low = (RE_SOURCE_KPC - DRE_SOURCE_KPC) * STRUCT_DISTANCE_SCALE
    re_high = (RE_SOURCE_KPC + DRE_SOURCE_KPC) * STRUCT_DISTANCE_SCALE
    spherical_cases = [
        ('sigma_230', astar_from(230.0, RE_KPC), LOGM_TOTAL, RE_KPC, N_SERSIC),
        ('sigma_270', astar_from(270.0, RE_KPC), LOGM_TOTAL, RE_KPC, N_SERSIC),
        ('n_2p4', a0, LOGM_TOTAL, RE_KPC, 2.4),
        ('n_2p6', a0, LOGM_TOTAL, RE_KPC, 2.6),
        ('mass_minus_0p02dex', a0, LOGM_TOTAL - DLOGM_TOTAL, RE_KPC, N_SERSIC),
        ('mass_plus_0p02dex', a0, LOGM_TOTAL + DLOGM_TOTAL, RE_KPC, N_SERSIC),
        ('Re_low', astar_from(SIGMA_KMS, re_low), LOGM_TOTAL, re_low, N_SERSIC),
        ('Re_high', astar_from(SIGMA_KMS, re_high), LOGM_TOTAL, re_high, N_SERSIC),
    ]
    for label, astar_case, logmass_case, re_case, n_case in spherical_cases:
        print_case(label, solve_mode_spherical(astar_case, logmass_case, re_case, n_case, n_grid=16000))

    print('\nNUMERICAL_CONVERGENCE_SPHERICAL')
    for ng in (4000, 8000, 16000, 32000):
        r = solve_mode_spherical(a0, LOGM_TOTAL, RE_KPC, N_SERSIC, n_grid=ng)
        print(f'n_grid={ng} N={r["N"]:.12f} lambda_kpc={r["lambda_kpc"]:.12f}')

    print('\nOBLATE_EDGE_ON_CENTRAL')
    central = solve_mode_oblate(q_int=Q_PROJ, n_grid=16000, n_quad=480)
    print_case('oblate_edge_on_q_equals_qproj', central)
    print(f'delta_N_oblate_minus_spherical={central["N"]-spherical["N"]:.12f}')

    print('\nOBLATE_ONE_AT_A_TIME_SENSITIVITY')
    cases = [
        ('sigma_230', dict(sigma_kms=230.0)),
        ('sigma_270', dict(sigma_kms=270.0)),
        ('n_2p4', dict(n=2.4)),
        ('n_2p6', dict(n=2.6)),
        ('mass_minus_0p02dex', dict(logmass=LOGM_TOTAL - DLOGM_TOTAL)),
        ('mass_plus_0p02dex', dict(logmass=LOGM_TOTAL + DLOGM_TOTAL)),
        ('Re_low', dict(re_kpc=(RE_SOURCE_KPC - DRE_SOURCE_KPC) * STRUCT_DISTANCE_SCALE)),
        ('Re_high', dict(re_kpc=(RE_SOURCE_KPC + DRE_SOURCE_KPC) * STRUCT_DISTANCE_SCALE)),
        ('ellip_0p76_q_0p24', dict(q_int=0.24)),
        ('ellip_0p78_q_0p22', dict(q_int=0.22)),
    ]
    for label, kwargs in cases:
        print_case(label, solve_mode_oblate(n_grid=8000, n_quad=480, **kwargs))

    print('\nSIMULTANEOUS_SIGNED_CORNERS_EDGE_ON')
    low = solve_mode_oblate(
        sigma_kms=270.0,
        re_kpc=(RE_SOURCE_KPC + DRE_SOURCE_KPC) * STRUCT_DISTANCE_SCALE,
        logmass=LOGM_TOTAL - DLOGM_TOTAL,
        n=N_SERSIC - DN_SERSIC,
        q_int=Q_PROJ + DELLIPTICITY,
        n_grid=8000, n_quad=480,
    )
    high = solve_mode_oblate(
        sigma_kms=230.0,
        re_kpc=(RE_SOURCE_KPC - DRE_SOURCE_KPC) * STRUCT_DISTANCE_SCALE,
        logmass=LOGM_TOTAL + DLOGM_TOTAL,
        n=N_SERSIC + DN_SERSIC,
        q_int=Q_PROJ - DELLIPTICITY,
        n_grid=8000, n_quad=480,
    )
    print_case('signed_corner_low_N', low)
    print_case('signed_corner_high_N', high)
    print('  NOTE=deterministic simultaneous quoted-error corners; not a statistical confidence interval')

    print('\nINCLINATION_THICKNESS_FAMILY_CENTRAL_INPUTS')
    for i_deg in (90.0, 88.0, 85.0, 82.0, 80.0, 78.0, 77.0, 76.8, 76.72):
        q_int = q_intrinsic_from_inclination(Q_PROJ, i_deg)
        if q_int is None:
            continue
        r = solve_mode_oblate(q_int=max(q_int, 1e-5), n_grid=6000, n_quad=480)
        print(f'i_deg={i_deg:.5f} q_int={q_int:.12f} N={r["N"]:.12f} CSMI={r["CSMI"]}')
    thin = solve_mode_oblate(q_int=1e-5, n_grid=8000, n_quad=800)
    print(f'razor_thin_numeric_limit_q1e-5_N={thin["N"]:.12f} CSMI={thin["CSMI"]}')

    print('\nCOMPOUND_HIGH_N_THIN_STRESS_POINT')
    high_thin = solve_mode_oblate(
        sigma_kms=230.0,
        re_kpc=(RE_SOURCE_KPC - DRE_SOURCE_KPC) * STRUCT_DISTANCE_SCALE,
        logmass=LOGM_TOTAL + DLOGM_TOTAL,
        n=N_SERSIC + DN_SERSIC,
        q_int=1e-5, n_grid=8000, n_quad=480,
    )
    print_case('high_N_quoted_input_corner_q1e-5', high_thin)
    print('  NOTE=compound geometry/source stress point; not a confidence bound or preferred deprojection')

    print('\nNUMERICAL_CONVERGENCE_EDGE_ON')
    for ng in (4000, 8000, 16000, 32000):
        r = solve_mode_oblate(q_int=Q_PROJ, n_grid=ng, n_quad=480)
        print(f'n_grid={ng} N={r["N"]:.12f} lambda_kpc={r["lambda_kpc"]:.12f}')
    for nq in (320, 480, 800):
        r = solve_mode_oblate(q_int=Q_PROJ, n_grid=16000, n_quad=nq)
        print(f'n_quad={nq} N={r["N"]:.12f} lambda_kpc={r["lambda_kpc"]:.12f}')

    print('\nINTERPRETATION')
    print('spherical_equivalent_is_baseline=True')
    print('axisymmetric_oblate_is_nonfitted_geometry_stress_test=True')
    print('rotation_velocity_invented=False')
    print('a_star_reestimated_from_rotation=False')
    print('inclination_and_intrinsic_thickness_not_uniquely_resolved=True')
    print('continuous_N_is_primary=True')


if __name__ == '__main__':
    main()
