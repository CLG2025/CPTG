#!/usr/bin/env python3
import math
from scipy.optimize import brentq
from CPTG_ZF_UDS_7329_Common import *


def solve_field(gstar, astar, r_m):
    rc = 48.0 * PI * C**2 / astar
    y = r_m / rc
    ggeom = 0.5 * astar * y ** (7.0 / 5.0) / (1.0 + y ** (12.0 / 5.0))
    A = math.sqrt(astar * gstar) + ggeom
    def residual(g):
        return g - gstar - A / (1.0 + (g / astar) ** (123.0 / 50.0)) ** (11.0 / 50.0)
    root = brentq(residual, 0.0, gstar + A + astar, xtol=1e-30, rtol=1e-14)
    return root, ggeom, rc


def outputs(logMe, sigma_kms, re_kpc):
    astar = (sigma_kms * 1e3) ** 2 / (re_kpc * KPC_M)
    gstar = G * (10.0 ** logMe * M_SUN) / (re_kpc * KPC_M) ** 2
    g, ggeom, rc = solve_field(gstar, astar, re_kpc * KPC_M)
    logMcptg = math.log10(g * (re_kpc * KPC_M) ** 2 / G / M_SUN)
    return g, logMcptg, astar, gstar, ggeom, rc


def half_range(lo, hi):
    return 0.5 * (hi - lo)


def main():
    coord = coordinate_values()
    da_lcdm_new = coord['DA_Lambda70_source_phase_Mpc']
    da_lcdm_struct = coord['DA_Lambda70_structural_measurement_phase_Mpc']
    da_ac = coord['DA_ac_Mpc']
    da_lum = coord['DA_lum_Mpc']
    da_mid = coord['DA_mid_Mpc']
    pop_scale = coord['population_distance_scale']
    struct_scale = coord['structural_distance_scale']
    re = coord['Re_mid_kpc']
    dre = coord['dRe_mid_kpc']
    logMtotal = coord['logM_total_mid']
    logMe_source = coord['logMstar_e_source_derived']
    logMe = coord['logMstar_e_mid']
    logMdyn = coord['logMdyn_mid']

    aobs = 1.0 / (1.0 + Z_OBS)
    nobs = math.log(aobs)
    tpi_obs = branch_clock(aobs, H0_PI, B_PI, T_PI, PI)
    tpi0 = branch_clock(1.0, H0_PI, B_PI, T_PI, PI)
    tac_obs = branch_clock(aobs, H0_AC, B_PI, T_PI, P_AC)
    tac0 = branch_clock(1.0, H0_AC, B_PI, T_PI, P_AC)
    tlum_obs = branch_clock(aobs, H0_LUM, OMEGA_L_AC, OMEGA_M_AC, P_AC)
    tlum0 = branch_clock(1.0, H0_LUM, OMEGA_L_AC, OMEGA_M_AC, P_AC)

    aform = 1.0 / (1.0 + Z_FORM)
    nform = math.log(aform)
    tform = branch_clock(aform, H0_PI, B_PI, T_PI, PI)
    aquench = 1.0 / (1.0 + Z_QUENCH)
    nquench = math.log(aquench)
    tquench = branch_clock(aquench, H0_PI, B_PI, T_PI, PI)
    d1t = tpi_obs - tform
    d1n = nobs - nform
    d2t = tpi0 - tpi_obs
    d2n = -nobs
    cad1 = d1n / d1t
    cad2 = d2n / d2t

    zform_low = Z_FORM - Z_FORM_MINUS
    aform_low = 1.0 / (1.0 + zform_low)
    nform_low = math.log(aform_low)
    tform_low = branch_clock(aform_low, H0_PI, B_PI, T_PI, PI)
    cad1_low = (nobs - nform_low) / (tpi_obs - tform_low)
    cadence_ratio_low = cad1_low / cad2

    g, logMcptg, astar, gstar, ggeom, rc = outputs(logMe, SIGMA_KMS, re)
    mdyn = 10.0 ** logMdyn * M_SUN
    gdyn = G * mdyn / (re * KPC_M) ** 2

    # a_star uncertainty from sigma and R_e.
    a_sig_lo = (230e3) ** 2 / (re * KPC_M)
    a_sig_hi = (270e3) ** 2 / (re * KPC_M)
    a_re_lo = (250e3) ** 2 / ((re - dre) * KPC_M)
    a_re_hi = (250e3) ** 2 / ((re + dre) * KPC_M)
    ua = math.sqrt(half_range(a_sig_lo, a_sig_hi)**2 + half_range(a_re_lo, a_re_hi)**2)

    # g_star uncertainty from total-mass error and R_e.
    gs_m_lo = G * (10.0 ** (logMe - DLOGM_TOTAL) * M_SUN) / (re * KPC_M) ** 2
    gs_m_hi = G * (10.0 ** (logMe + DLOGM_TOTAL) * M_SUN) / (re * KPC_M) ** 2
    gs_r_lo = G * (10.0 ** logMe * M_SUN) / ((re - dre) * KPC_M) ** 2
    gs_r_hi = G * (10.0 ** logMe * M_SUN) / ((re + dre) * KPC_M) ** 2
    ugstar = math.sqrt(half_range(gs_m_lo, gs_m_hi)**2 + half_range(gs_r_lo, gs_r_hi)**2)

    # CPTG field and mass uncertainty: one-at-a-time symmetric perturbations.
    pert = []
    for lo_args, hi_args in [
        ((logMe-DLOGM_TOTAL, SIGMA_KMS, re), (logMe+DLOGM_TOTAL, SIGMA_KMS, re)),
        ((logMe, SIGMA_KMS-DSIGMA_KMS, re), (logMe, SIGMA_KMS+DSIGMA_KMS, re)),
        ((logMe, SIGMA_KMS, re-dre), (logMe, SIGMA_KMS, re+dre)),
    ]:
        lo = outputs(*lo_args)
        hi = outputs(*hi_args)
        pert.append((half_range(lo[0], hi[0]), half_range(lo[1], hi[1])))
    ug = math.sqrt(sum(x[0]**2 for x in pert))
    ulogMcptg = math.sqrt(sum(x[1]**2 for x in pert))

    gd_m_lo = G * (10.0 ** (logMdyn-DLOGM_DYN) * M_SUN) / (re*KPC_M)**2
    gd_m_hi = G * (10.0 ** (logMdyn+DLOGM_DYN) * M_SUN) / (re*KPC_M)**2
    gd_r_lo = G * (10.0 ** logMdyn * M_SUN) / ((re-dre)*KPC_M)**2
    gd_r_hi = G * (10.0 ** logMdyn * M_SUN) / ((re+dre)*KPC_M)**2
    ugdyn = math.sqrt(half_range(gd_m_lo, gd_m_hi)**2 + half_range(gd_r_lo, gd_r_hi)**2)

    dfield = g-gdyn
    sigfield = dfield / math.sqrt(ug**2 + ugdyn**2)
    dmass = logMcptg-logMdyn
    sigmass = dmass / math.sqrt(ulogMcptg**2 + DLOGM_DYN**2)

    print('EXCELS_OBSERVATIONAL_SOURCE')
    print(f'z_obs={Z_OBS:.4f} +/- {DZ_OBS:.4f}')
    print(f'logM_total_source={LOGM_TOTAL_SOURCE:.2f} +/- {DLOGM_TOTAL:.2f}')
    print(f'SFR_10Myr_upper_Msun_per_yr={SFR_UPPER:.2f}')
    print(f'logZ_Zsun={LOGZ:.2f} +{LOGZ_PLUS:.2f} -{LOGZ_MINUS:.2f}')
    print(f't_form_source_Gyr={TFORM_SOURCE_GYR:.2f} +{TFORM_PLUS:.2f} -{TFORM_MINUS:.2f}')
    print(f'z_form={Z_FORM:.1f} +{Z_FORM_PLUS:.1f} -{Z_FORM_MINUS:.1f}')
    print(f'z_quench={Z_QUENCH:.2f} +{Z_QUENCH_PLUS:.2f} -{Z_QUENCH_MINUS:.2f}')
    print(f'A_V={A_V:.2f} +/- {DA_V:.2f}')
    print(f'tau_10_90_Myr={TAU_10_90:.0f} +{TAU_10_90_PLUS:.0f} -{TAU_10_90_MINUS:.0f}')
    print(f'MgFe={MGFE:.2f} +/- {DMGFE:.2f}')

    print('\nDISTANCE_COORDINATES')
    print(f'DA_Lambda70_source_phase_Mpc={da_lcdm_new:.10f}')
    print(f'DA_Lambda70_structural_measurement_phase_Mpc={da_lcdm_struct:.10f}')
    print(f'DA_ac_Mpc={da_ac:.10f}')
    print(f'DA_lum_Mpc={da_lum:.10f}')
    print(f'DA_mid_Mpc={da_mid:.10f}')
    print(f'population_distance_scale={pop_scale:.12f}')
    print(f'structural_distance_scale={struct_scale:.12f}')
    print(f'Re_mid_kpc={re:.12f} +/- {dre:.12f}')
    print(f'logM_total_mid={logMtotal:.12f}')
    print(f'logMstar_e_source_derived={logMe_source:.12f}')
    print(f'logMstar_e_mid={logMe:.12f}')
    print(f'logMdyn_mid={logMdyn:.12f}')

    print('\nNATIVE_AND_PROJECTION_COORDINATES')
    print(f'a_obs={aobs:.12f}')
    print(f'N_pi_obs={nobs:.12f}')
    print(f'E_pi_obs={E_pi_z(Z_OBS):.12f}')
    print(f'E_ac_obs={E_ac_z(Z_OBS):.12f}')
    print(f'E_lum_obs={E_lum_z(Z_OBS):.12f}')
    print(f't_pi_obs_Gyr={tpi_obs:.12f}')
    print(f't_pi_0_Gyr={tpi0:.12f}')
    print(f't_ac_obs_Gyr={tac_obs:.12f}')
    print(f't_ac_0_Gyr={tac0:.12f}')
    print(f't_lum_obs_Gyr={tlum_obs:.12f}')
    print(f't_lum_0_Gyr={tlum0:.12f}')
    print(f'a_form={aform:.12f}')
    print(f'N_pi_form={nform:.12f}')
    print(f't_pi_form_Gyr={tform:.12f}')
    print(f'Hpi_form_over_Hpi0={E_pi_z(Z_FORM):.12f}')
    print(f'a_quench={aquench:.12f}')
    print(f'N_pi_quench={nquench:.12f}')
    print(f't_pi_quench_Gyr={tquench:.12f}')
    print(f'Hpi_quench_over_Hpi0={E_pi_z(Z_QUENCH):.12f}')
    print(f'formation_to_obs_dt_Gyr={d1t:.12f}')
    print(f'formation_to_obs_dN={d1n:.12f}')
    print(f'formation_to_obs_cadence_Gyr^-1={cad1:.12f}')
    print(f'obs_to_present_dt_Gyr={d2t:.12f}')
    print(f'obs_to_present_dN={d2n:.12f}')
    print(f'obs_to_present_cadence_Gyr^-1={cad2:.12f}')
    print(f'cadence_ratio={cad1/cad2:.12f}')

    print('\nFORMATION_MARKER_ROBUSTNESS')
    print(f'z_form_lower_1sigma={zform_low:.1f}')
    print(f'N_pi_form_lower_1sigma={nform_low:.12f}')
    print(f't_pi_form_lower_1sigma_Gyr={tform_low:.12f}')
    print(f'cadence_ratio_lower_1sigma={cadence_ratio_low:.12f}')

    print('\nEFFECTIVE_RADIUS_CLOSURE')
    print(f'a_star={astar:.15e}')
    print(f'a_star_uncertainty={ua:.15e}')
    print(f'Rc_Gpc={rc/(KPC_M*1e6):.12f}')
    print(f'gstar_e={gstar:.15e}')
    print(f'gstar_e_uncertainty={ugstar:.15e}')
    print(f'ggeom_e={ggeom:.15e}')
    print(f'g_CPTG_e={g:.15e}')
    print(f'g_CPTG_e_uncertainty={ug:.15e}')
    print(f'g_dyn_e={gdyn:.15e}')
    print(f'g_dyn_e_uncertainty={ugdyn:.15e}')
    print(f'g_difference={dfield:.15e}')
    print(f'g_nominal_sigma={sigfield:.12f}')
    print(f'logM_CPTG_e={logMcptg:.12f}')
    print(f'logM_CPTG_e_uncertainty={ulogMcptg:.12f}')
    print(f'logM_difference={dmass:.12f}')
    print(f'logM_nominal_sigma={sigmass:.12f}')

if __name__ == '__main__':
    main()
