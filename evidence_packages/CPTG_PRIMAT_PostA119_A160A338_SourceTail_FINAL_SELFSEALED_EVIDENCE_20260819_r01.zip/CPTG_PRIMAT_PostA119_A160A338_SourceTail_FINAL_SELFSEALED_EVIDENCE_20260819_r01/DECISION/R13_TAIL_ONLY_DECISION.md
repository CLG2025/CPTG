# r13 tail-only decision

**PASS**

Rows: 18; PASS rows: 18; FAIL rows: 0.

Maximum absolute unrenormalized A=338 ratio departure from unity: `2.3592239273284576e-13`.

The leave-one-out test is not part of this tail-only rerun.
