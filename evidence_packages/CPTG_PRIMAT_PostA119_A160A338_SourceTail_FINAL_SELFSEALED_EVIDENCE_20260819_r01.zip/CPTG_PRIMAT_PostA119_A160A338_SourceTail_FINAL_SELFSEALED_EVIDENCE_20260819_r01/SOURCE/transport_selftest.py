from __future__ import annotations
import numpy as np

def source_integral(t,S):return float(np.trapezoid(np.sum(S,axis=0),t))
def truncate_exact_trapz(t,S,retain):
 r=np.sum(S,axis=0);w=np.zeros_like(t);dt=np.diff(t);w[0]=dt[0]/2;w[-1]=dt[-1]/2
 if len(t)>2:w[1:-1]=(dt[:-1]+dt[1:])/2
 c=w*r;tot=float(np.sum(c));target=retain*tot;cs=np.cumsum(c);k=int(np.searchsorted(cs,target,side='left'))
 out=S.copy();out[:,k+1:]=0.0;prev=float(cs[k-1]) if k>0 else 0.0
 alpha=(target-prev)/float(c[k]) if c[k]>0 else 0.0;alpha=max(0.0,min(1.0,alpha));out[:,k]*=alpha
 actual=source_integral(t,out)/tot
 return out,actual,k,alpha
def main():
 t=np.linspace(0,10,101);S=np.vstack([np.exp(-0.2*t),0.3*np.exp(-0.05*t)])
 for q in (0.99,0.999,0.9999):
  x,a,k,alpha=truncate_exact_trapz(t,S,q)
  if abs(a-q)>1e-12:raise RuntimeError(f'truncation quadrature mismatch {q} {a}')
  if np.any(x<0):raise RuntimeError('negative truncated source')
  if not (0<=alpha<=1):raise RuntimeError('invalid boundary-node scale')
 print('R13_TAIL_TRUNCATION_SELFTEST PASS')
 print('R13_SOURCE_TAIL_TRANSPORT_SELFTEST PASS')
if __name__=='__main__':main()
