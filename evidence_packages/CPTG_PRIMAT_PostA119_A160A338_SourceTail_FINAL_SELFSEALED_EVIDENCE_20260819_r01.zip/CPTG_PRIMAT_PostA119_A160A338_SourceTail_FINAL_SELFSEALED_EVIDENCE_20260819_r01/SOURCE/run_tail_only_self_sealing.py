from __future__ import annotations
from pathlib import Path
import subprocess,sys,os,json,csv,hashlib,zipfile,shutil,datetime,importlib.metadata
ROOT=Path(__file__).resolve().parents[1]; OUTROOT=Path(r'D:\Downloads')
PY=Path(r'D:\Downloads\CPTG_PRIMAT_A1A119_TRANSPORT_ENV_r02\Scripts\python.exe')
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def run(label,script,log):
 print('R13_TAILONLY_STAGE_START',label,flush=True)
 p=subprocess.Popen([str(PY),str(ROOT/'SOURCE'/script)],cwd=str(ROOT),stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,bufsize=1)
 with log.open('a',encoding='utf-8',newline='\n') as f:
  for line in p.stdout:
   print(line,end='',flush=True);f.write(line);f.flush()
 rc=p.wait();print('R13_TAILONLY_STAGE_END',label,'RC',rc,flush=True)
 return rc
def main():
 if str(Path(sys.executable)).lower()!=str(PY).lower():raise RuntimeError('wrong runtime '+sys.executable)
 ev=ROOT/'SELFSEALED_EVIDENCE'; shutil.rmtree(ev,ignore_errors=True)
 for d in ['AUDIT','CONFIG','ENVIRONMENT','INPUT_AUTHORITY','PROVENANCE','RESULTS','SOURCE','DECISION']:(ev/d).mkdir(parents=True,exist_ok=True)
 log=ev/'PROVENANCE/COMPLETE_STDOUT_STDERR.txt';log.write_text('',encoding='utf-8')
 stages=[('STATIC_VERIFY','static_verify_tail_only.py'),('R12_ADOPTION','adopt_r12_authority.py'),('RUNTIME_PREFLIGHT','runtime_preflight.py'),('TRANSPORT_SELFTEST','transport_selftest.py'),('TAIL_SCIENCE','run_tail_only.py')]
 sci_rc=None
 for label,script in stages:
  rc=run(label,script,log)
  if label=='TAIL_SCIENCE': sci_rc=rc
  elif rc!=0: raise SystemExit(rc)
 if sci_rc not in (0,5):raise SystemExit(sci_rc)
 # capture exact inputs/source/results after run
 for p in [ROOT/'CONFIG/FROZEN_R13_SOURCE_TAIL_ROBUSTNESS_PREREGISTRATION.json',ROOT/'CONFIG/TAIL_ONLY_EXECUTION_SCOPE_LOCK.json']:
  shutil.copy2(p,ev/'CONFIG'/p.name)
 for p in sorted((ROOT/'SOURCE').glob('*.py')):shutil.copy2(p,ev/'SOURCE'/p.name)
 for p in [ROOT/'PROVENANCE_INPUT/CPTG_PRIMAT_PostA119_A160A338_SourceTailRobustness_20260818_r13_HOTFIX_r01.zip',ROOT/'PROVENANCE_INPUT/CPTG_PRIMAT_PostA119_A160A338_SourceTailRobustness_20260818_r13_HOTFIX_r01.zip.sha256.txt']:
  shutil.copy2(p,ev/'INPUT_AUTHORITY'/p.name)
 for p in [ROOT/'EVIDENCE/R12_AUTHORITY_ADOPTION.json',ROOT/'EVIDENCE/UPSTREAM_R12_PASS_SUMMARY.json',ROOT/'EVIDENCE/UPSTREAM_R12_FROZEN_PREREGISTRATION.json']:
  shutil.copy2(p,ev/'INPUT_AUTHORITY'/p.name)
 shutil.copy2(ROOT/'OUTPUT/NATIVE_TRAJECTORY_FREEZE.json',ev/'INPUT_AUTHORITY/NATIVE_TRAJECTORY_FREEZE.json')
 # capture every native trajectory referenced by freeze
 fr=json.loads((ROOT/'OUTPUT/NATIVE_TRAJECTORY_FREEZE.json').read_text(encoding='utf-8'))
 nd=ev/'INPUT_AUTHORITY/NATIVE_TRAJECTORIES';nd.mkdir(exist_ok=True)
 for rec in fr['files']:
  src=ROOT/rec['path']; dst=nd/src.name;shutil.copy2(src,dst)
  if sha(dst)!=rec['sha256']:raise RuntimeError('trajectory capture mismatch '+src.name)
 for p in [ROOT/'RESULTS/R13_TAIL_ONLY_BASELINES.csv',ROOT/'RESULTS/R13_TAIL_ONLY_RESULTS.csv',ROOT/'EVIDENCE/R13_TAIL_ONLY_RESULT.json']:
  shutil.copy2(p,ev/'RESULTS'/p.name)
 env={'python_executable':sys.executable,'python_version':sys.version,'pynucastro':importlib.metadata.version('pynucastro'),'numpy':importlib.metadata.version('numpy'),'numba':importlib.metadata.version('numba'),'scipy':importlib.metadata.version('scipy'),'sealed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 (ev/'ENVIRONMENT/RUNTIME.json').write_text(json.dumps(env,indent=2,sort_keys=True)+'\n',encoding='utf-8')
 res=json.loads((ROOT/'EVIDENCE/R13_TAIL_ONLY_RESULT.json').read_text(encoding='utf-8'))
 decision=res['decision'];
 (ev/'DECISION/R13_TAIL_ONLY_DECISION.md').write_text(f"# r13 tail-only decision\n\n**{decision}**\n\nRows: {len(res['tail_rows'])}; PASS rows: {res['tail_pass_rows']}; FAIL rows: {res['tail_fail_rows']}.\n\nMaximum absolute unrenormalized A=338 ratio departure from unity: `{res['max_abs_unrenormalized_A338_ratio_minus_one']}`.\n\nThe leave-one-out test is not part of this tail-only rerun.\n",encoding='utf-8')
 # manifest
 lines=[]
 for p in sorted(ev.rglob('*')):
  if p.is_file() and p.name!='MANIFEST.sha256':lines.append(f"{sha(p)}  {p.relative_to(ev).as_posix()}")
 (ev/'MANIFEST.sha256').write_text('\n'.join(lines)+'\n',encoding='utf-8')
 # zip outside package root
 out=OUTROOT/'CPTG_PRIMAT_PostA119_A160A338_SourceTail_FINAL_SELFSEALED_EVIDENCE_20260819_r01.zip'
 if out.exists():out.unlink()
 with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
  for p in sorted(ev.rglob('*')):
   if p.is_file():z.write(p,arcname=f'CPTG_PRIMAT_PostA119_A160A338_SourceTail_FINAL_SELFSEALED_EVIDENCE_20260819_r01/{p.relative_to(ev).as_posix()}')
 # CRC reopen
 with zipfile.ZipFile(out,'r') as z:
  bad=z.testzip()
  if bad:raise RuntimeError('zip CRC fail '+bad)
 hs=sha(out); Path(str(out)+'.sha256.txt').write_text(f'{hs}  {out.name}\n',encoding='utf-8')
 print('R13_TAILONLY_EVIDENCE_SEAL PASS',flush=True)
 print('R13_TAILONLY_DECISION',decision,flush=True)
 print('R13_TAILONLY_EVIDENCE_ZIP',out,flush=True)
 print('R13_TAILONLY_EVIDENCE_SHA256',hs,flush=True)
 print('R13_TAILONLY_SELFSEAL_COMPLETE',flush=True)
 raise SystemExit(0 if decision=='PASS' else 5)
if __name__=='__main__':main()
