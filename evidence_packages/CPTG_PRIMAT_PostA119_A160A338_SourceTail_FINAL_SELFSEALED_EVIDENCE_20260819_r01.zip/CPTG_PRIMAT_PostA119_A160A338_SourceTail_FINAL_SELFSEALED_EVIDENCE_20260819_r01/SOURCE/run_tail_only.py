from __future__ import annotations
import csv, json, math, importlib.metadata
from pathlib import Path
import run_source_tail_robustness as r
from common import *

def main():
 if importlib.metadata.version('pynucastro')!='2.11.0': raise RuntimeError('pynucastro 2.11.0 required')
 if sha_file(OUTPUT/'NATIVE_TRAJECTORY_FREEZE.json')!='97fd7b4f4f4e7466be9e45be264e62faade5b55e80d415201ed4390405080f9a': raise RuntimeError('freeze mismatch')
 ad=load_json(EVIDENCE/'R12_AUTHORITY_ADOPTION.json'); r12=load_json(EVIDENCE/'UPSTREAM_R12_PASS_SUMMARY.json')
 if ad.get('pass') is not True or r12.get('decision')!='PASS': raise RuntimeError('r12 authority adoption required')
 cfg=load_json(CONFIG/'FROZEN_R13_SOURCE_TAIL_ROBUSTNESS_PREREGISTRATION.json'); tg=cfg['source_tail']['hard_gates']
 caps,betas=r.select_rates(); rows=[]; baselines=[]; overall=True
 r12_a338={round(float(a['eta10']),3):float(a['A338_P2048']) for a in r12['anchors']}
 for eta in ETA:
  print('R13_TAIL_ONLY_START',eta,flush=True)
  t,S,SE,SD,L,ii,st,C,species,src,keys,cb,bb,maxA,escape=r.precompute(eta,caps,betas)
  if maxA!=338 or escape: raise RuntimeError('baseline structural frontier mismatch')
  base,base_int=r.solve_mass(t,S,L,ii,st,C,species,r.TAIL_N)
  a338err=symmetric_rel(base[338],r12_a338[round(eta,3)])
  bok=a338err<=cfg['baseline_reproduction']['fresh_P2048_A338_relative_error_to_r12_max']; overall=overall and bok
  baselines.append({'eta10':eta,'A338_P2048':base[338],'R12_relative_error':a338err,'pass':bok})
  print('R13_TAIL_ONLY_BASELINE',eta,'A338',base[338],'R12_RELERR',a338err,'PASS' if bok else 'FAIL',flush=True)
  for f in r.TAIL_FRACS:
   St,actual,k,alpha=r.truncate_exact_trapz(t,S,f); tm,_=r.solve_mass(t,St,L,ii,st,C,species,r.TAIL_N)
   cp,wa=r.maxrel(base,tm,r.CHECKPOINTS); a338=symmetric_rel(base[338],tm[338]); pos=r.positive_region(tm); ferr=abs(actual-f)
   raw_ratio=(tm[338]*actual)/base[338]
   hard=True
   if f==0.999: hard=cp<=tg['retained_0p999_checkpoint_max_relative'] and a338<=tg['retained_0p999_A338_relative']
   if f==0.9999: hard=cp<=tg['retained_0p9999_checkpoint_max_relative'] and a338<=tg['retained_0p9999_A338_relative']
   ok=hard and pos and ferr<=tg['retained_fraction_quadrature_absolute_error_max']; overall=overall and ok
   rec={'eta10':eta,'retained_fraction_target':f,'retained_fraction_actual':actual,'cut_index':k,'boundary_node_scale':alpha,'pass':ok,'hard_amplitude_gate_applies':f in (0.999,0.9999),'renormalized_checkpoint_max_relative':cp,'worst_A':wa,'renormalized_A338_relative':a338,'renormalized_A338_ratio':tm[338]/base[338],'unrenormalized_A338_ratio':raw_ratio,'positive_A160_A338':pos}
   rows.append(rec)
   print('R13_TAIL_ONLY_ROW',eta,f,'PASS' if ok else 'FAIL','CHECKPOINT_REL',cp,'A338_REL',a338,'RAW_A338_RATIO',raw_ratio,'ACTUAL_RETAIN',actual,flush=True)
 RESULTS.mkdir(parents=True,exist_ok=True); EVIDENCE.mkdir(parents=True,exist_ok=True)
 with (RESULTS/'R13_TAIL_ONLY_BASELINES.csv').open('w',newline='',encoding='utf-8') as f:
  w=csv.DictWriter(f,fieldnames=list(baselines[0]));w.writeheader();w.writerows(baselines)
 with (RESULTS/'R13_TAIL_ONLY_RESULTS.csv').open('w',newline='',encoding='utf-8') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
 mx=max(abs(float(x['unrenormalized_A338_ratio'])-1.0) for x in rows)
 out={'schema':'cptg-r13-tail-only-result-v1','decision':'PASS' if overall else 'NOT_QUALIFIED','anchors':ETA,'tail_rows':rows,'baseline_rows':baselines,'tail_pass_rows':sum(x['pass'] is True for x in rows),'tail_fail_rows':sum(x['pass'] is not True for x in rows),'max_abs_unrenormalized_A338_ratio_minus_one':mx,'claim_boundary':'Source-tail robustness only; prescribed-PRIMAT-bath reduced graph, not native PRIMAT heavy-network evolution or primordial heavy-yield prediction.','leave_one_out_executed':False}
 atomic_json(EVIDENCE/'R13_TAIL_ONLY_RESULT.json',out)
 print('R13_TAIL_ONLY_DECISION','PASS' if overall else 'NOT_QUALIFIED','ROWS',len(rows),'PASS_ROWS',sum(x['pass'] is True for x in rows),'MAX_RAW_A338_RATIO_DEVIATION',mx,flush=True)
 if not overall: raise SystemExit(5)
if __name__=='__main__':main()
