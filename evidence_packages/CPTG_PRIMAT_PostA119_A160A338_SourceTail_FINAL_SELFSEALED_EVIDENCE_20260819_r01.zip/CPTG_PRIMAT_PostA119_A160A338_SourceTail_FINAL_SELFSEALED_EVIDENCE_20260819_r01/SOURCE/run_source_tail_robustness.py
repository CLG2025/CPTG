from __future__ import annotations
import csv,math,importlib.metadata,json
from collections import defaultdict,deque
import numpy as np
import pynucastro as pyna
from common import *
from positive_transport_core import solve_positive_exponential_inflow
CHECKPOINTS=[160,180,200,220,240,260,280,300,320,330,334,336,337,338]
POSITIVE_REGION=list(range(160,339));STRUCTURAL_REGION=list(range(24,339));LIGHT_TUPLES=set(LIGHT)
TAIL_FRACS=[0.99,0.999,0.9999]
LOO_N=1024;TAIL_N=2048;CONFIRM_N=2048
EXPECTED_EDGES={
'O20+He4->Ne24','F20+He4->Na24','Ne20+He4->Mg24','Na20+He4->Al24','Ne21+He4->Mg25','Na21+He4->Al25','Ne22+He4->Mg26','Na22+He4->Al26',
'Ne23+n->Ne24','Ne23+p->Na24','Ne23+He4->Mg27','Na23+n->Na24','Na23+p->Mg24','Na23+He4->Al27'}
def nt(n):return int(n.A),int(n.Z)
def edge_key(h,l,d):return f"{az_name(*h)}+{LIGHT[l]}->{az_name(*d)}"
def select_rates():
 rl=pyna.ReacLibLibrary();caps=[];betas=[]
 for r in rl.get_rates():
  rea=[nt(x) for x in r.reactants];pro=[nt(x) for x in r.products]
  if not r.weak and len(rea)==2 and len(pro)==1:
   ls=[x for x in rea if x in LIGHT_TUPLES]
   if len(ls)==1:
    l=ls[0];h=rea[1] if rea[0]==l else rea[0];d=pro[0]
    if h[0]>=6 and d==(h[0]+l[0],h[1]+l[1]):caps.append((h,l,d,r))
  if r.weak and getattr(r,'weak_type',None)=='beta_neg' and len(rea)==1 and len(pro)==1:
   s,d=rea[0],pro[0]
   if s[0]>=6 and d[0]==s[0] and d[1]==s[1]+1:betas.append((s,d,r))
 caps.sort(key=lambda x:(x[0],x[1],x[2],str(x[3])));betas.sort(key=lambda x:(x[0],x[1],str(x[2])))
 return caps,betas
def graph_parts(native,caps,betas):
 src=[(h,l,d,r) for h,l,d,r in caps if h in native and d not in native and d[0]>=24]
 keys=[edge_key(h,l,d) for h,l,d,r in src]
 if len(src)!=14 or set(keys)!=EXPECTED_EDGES or len(set(keys))!=14:raise RuntimeError('boundary-source edge registry mismatch: '+repr(keys))
 cb=defaultdict(list);bb=defaultdict(list)
 for h,l,d,r in caps:
  if h[0]>=24:cb[h].append((d,l,r))
 for s,d,r in betas:
  if s[0]>=24:bb[s].append((d,r))
 seeds={d for h,l,d,r in src};seen=set(seeds);q=deque(sorted(seeds))
 while q:
  s=q.popleft()
  for d,l,r in cb.get(s,[]):
   if d not in seen:seen.add(d);q.append(d)
  for d,r in bb.get(s,[]):
   if d not in seen:seen.add(d);q.append(d)
 species=sorted(seen,key=lambda x:(x[0],x[1]));idx={s:i for i,s in enumerate(species)}
 inc=[];out=defaultdict(list);escape=[]
 for s in species:
  for d,l,r in cb.get(s,[]):
   if d in idx:inc.append((idx[s],idx[d],'capture',l,r));out[s].append(('capture',d,l,r))
   else:escape.append((s,d,'capture'))
  for d,r in bb.get(s,[]):
   if d in idx:inc.append((idx[s],idx[d],'beta',None,r));out[s].append(('beta',d,None,r))
   else:escape.append((s,d,'beta'))
 inc.sort(key=lambda x:(x[1],x[0],x[2]));return src,keys,cb,bb,species,idx,inc,out,max(a for a,z in seen),escape
def subset_reach(active,src,cb,bb):
 seeds={src[i][2] for i in active};seen=set(seeds);q=deque(sorted(seeds))
 while q:
  s=q.popleft()
  for d,l,r in cb.get(s,[]):
   if d not in seen:seen.add(d);q.append(d)
  for d,r in bb.get(s,[]):
   if d not in seen:seen.add(d);q.append(d)
 maxA=max((a for a,z in seen),default=-1);masses={a for a,z in seen}
 return maxA,sorted(set(STRUCTURAL_REGION)-masses)
def load_traj(eta):
 z=np.load(OUTPUT/f'NATIVE_TRAJECTORIES/PRIMAT_NATIVE_TRAJECTORY_ETA{eta_tag(eta)}.npz')
 names=[str(x) for x in z['species']];az=[parse_primat_name(n) for n in names]
 return np.asarray(z['t_s'],float),np.asarray(z['T_K'],float),np.asarray(z['rho_b_g_cm3'],float),az,np.asarray(z['Y'],float)
def precompute(eta,caps,betas):
 t,T,rho,naz,Y=load_traj(eta);native=set(naz);ix={a:i for i,a in enumerate(naz)}
 src,keys,cb,bb,species,idx,inc,out,maxA,escape=graph_parts(native,caps,betas)
 ns=len(species);ntm=len(t);ne=len(inc);S=np.zeros((ns,ntm));SE=np.zeros((14,ntm));SD=np.zeros(14,dtype=np.int64);L=np.zeros((ns,ntm));C=np.zeros((ne,ntm))
 bath={l:rho*Y[ix[l],:] for l in LIGHT_TUPLES if l in ix};cache={}
 def rv(r):
  k=id(r)
  if k not in cache:cache[k]=np.maximum(np.array([float(r.eval(float(Tv))) for Tv in T]),0.0)
  return cache[k]
 for j,(h,l,d,r) in enumerate(src):
  v=rv(r)*bath[l]*Y[ix[h],:];SE[j,:]=v;SD[j]=idx[d];S[idx[d],:]+=v
 for e,(si,di,kind,l,r) in enumerate(inc):C[e,:]=rv(r)*bath[l] if kind=='capture' else rv(r)
 for s in species:
  si=idx[s]
  for kind,d,l,r in out.get(s,[]):L[si,:]+=rv(r)*bath[l] if kind=='capture' else rv(r)
 counts=np.zeros(ns,dtype=np.int64)
 for si,di,kind,l,r in inc:counts[di]+=1
 starts=np.zeros(ns+1,dtype=np.int64);starts[1:]=np.cumsum(counts)
 return t,S,SE,SD,L,np.array([x[0] for x in inc],dtype=np.int64),starts,C,species,src,keys,cb,bb,maxA,escape
def mass_sums(species,y):
 d={A:0.0 for A in STRUCTURAL_REGION}
 for (A,Z),v in zip(species,y):
  if A in d:d[A]+=float(v)
 return d
def maxrel(a,b,keys):
 vals={A:symmetric_rel(a[A],b[A]) for A in keys};A=max(vals,key=vals.get);return vals[A],A
def source_integral(t,S):return float(np.trapezoid(np.sum(S,axis=0),t))
def normalize(t,S):
 q=source_integral(t,S)
 if not math.isfinite(q) or q<=0:raise RuntimeError('invalid source integral')
 return S/q,q
def truncate_exact_trapz(t,S,retain):
 r=np.sum(S,axis=0);w=np.zeros_like(t)
 dt=np.diff(t);w[0]=dt[0]/2;w[-1]=dt[-1]/2
 if len(t)>2:w[1:-1]=(dt[:-1]+dt[1:])/2
 c=w*r;tot=float(np.sum(c));target=retain*tot;cs=np.cumsum(c);k=int(np.searchsorted(cs,target,side='left'))
 out=S.copy();out[:,k+1:]=0.0;prev=float(cs[k-1]) if k>0 else 0.0
 alpha=(target-prev)/float(c[k]) if c[k]>0 else 0.0;alpha=max(0.0,min(1.0,alpha));out[:,k]*=alpha
 actual=source_integral(t,out)/tot
 return out,actual,k,alpha
def solve_mass(t,S,L,ii,st,C,species,N):
 Sn,integ=normalize(t,S);y,mn=solve_positive_exponential_inflow(t,Sn,L,ii,st,C,N)
 if mn<0 or np.min(y)<0 or not np.all(np.isfinite(y)):raise RuntimeError('nonfinite/negative transport state')
 return mass_sums(species,y),integ
def positive_region(m):return all(math.isfinite(m[A]) and m[A]>0 for A in POSITIVE_REGION)
def main():
 if importlib.metadata.version('pynucastro')!='2.11.0':raise RuntimeError('pynucastro 2.11.0 required')
 if sha_file(OUTPUT/'NATIVE_TRAJECTORY_FREEZE.json')!='97fd7b4f4f4e7466be9e45be264e62faade5b55e80d415201ed4390405080f9a':raise RuntimeError('freeze mismatch')
 ad=load_json(EVIDENCE/'R12_AUTHORITY_ADOPTION.json');r12=load_json(EVIDENCE/'UPSTREAM_R12_PASS_SUMMARY.json')
 if ad.get('pass') is not True or r12.get('decision')!='PASS':raise RuntimeError('r12 authority adoption required')
 cfg=load_json(CONFIG/'FROZEN_R13_SOURCE_TAIL_ROBUSTNESS_PREREGISTRATION.json');tg=cfg['source_tail']['hard_gates'];lg=cfg['leave_one_out']['hard_gates']
 caps,betas=select_rates();tail_rows=[];loo_rows=[];confirm_candidates=[];edge_registry=None;overall=True
 r12_a338={round(float(a['eta10']),3):float(a['A338_P2048']) for a in r12['anchors']}
 for eta in ETA:
  print('R13_SOURCE_ROBUSTNESS_START',eta,flush=True)
  t,S,SE,SD,L,ii,st,C,species,src,keys,cb,bb,maxA,escape=precompute(eta,caps,betas)
  if maxA!=338 or escape:raise RuntimeError('baseline structural frontier mismatch')
  if edge_registry is None:edge_registry=[{'edge_id':i+1,'key':k,'source':az_name(*src[i][0]),'light':LIGHT[src[i][1]],'destination':az_name(*src[i][2]),'rate':str(src[i][3])} for i,k in enumerate(keys)]
  base2048,base_int=solve_mass(t,S,L,ii,st,C,species,TAIL_N);base1024,_=solve_mass(t,S,L,ii,st,C,species,LOO_N)
  a338err=symmetric_rel(base2048[338],r12_a338[round(eta,3)])
  if a338err>cfg['baseline_reproduction']['fresh_P2048_A338_relative_error_to_r12_max']:overall=False
  print('R13_BASELINE',eta,'A338',base2048[338],'R12_RELERR',a338err,flush=True)
  for f in TAIL_FRACS:
   St,actual,k,alpha=truncate_exact_trapz(t,S,f);tm,_=solve_mass(t,St,L,ii,st,C,species,TAIL_N)
   cp,wa=maxrel(base2048,tm,CHECKPOINTS);a338=symmetric_rel(base2048[338],tm[338]);pos=positive_region(tm);ferr=abs(actual-f)
   raw_ratio=(tm[338]*actual)/base2048[338]
   hard=True
   if f==0.999:hard=cp<=tg['retained_0p999_checkpoint_max_relative'] and a338<=tg['retained_0p999_A338_relative']
   if f==0.9999:hard=cp<=tg['retained_0p9999_checkpoint_max_relative'] and a338<=tg['retained_0p9999_A338_relative']
   ok=hard and pos and ferr<=tg['retained_fraction_quadrature_absolute_error_max'];overall=overall and ok
   rec={'eta10':eta,'retained_fraction_target':f,'retained_fraction_actual':actual,'cut_index':k,'boundary_node_scale':alpha,'pass':ok,'hard_amplitude_gate_applies':f in (0.999,0.9999),
        'renormalized_checkpoint_max_relative':cp,'worst_A':wa,'renormalized_A338_relative':a338,'renormalized_A338_ratio':tm[338]/base2048[338],
        'unrenormalized_A338_ratio':raw_ratio,'positive_A160_A338':pos}
   tail_rows.append(rec);print('R13_TAIL',eta,f,'PASS' if ok else 'FAIL','CHECKPOINT_REL',cp,'A338_REL',a338,'RAW_A338_RATIO',raw_ratio,'ACTUAL_RETAIN',actual,flush=True)
  for j,key in enumerate(keys):
   Sa=S.copy();Sa[SD[j],:]-=SE[j,:];Sa=np.maximum(Sa,0.0)
   m,aint=solve_mass(t,Sa,L,ii,st,C,species,LOO_N);cp,wa=maxrel(base1024,m,CHECKPOINTS);a338=symmetric_rel(base1024[338],m[338]);pos=positive_region(m)
   active=[x for x in range(14) if x!=j];rmax,missing=subset_reach(active,src,cb,bb);share=1.0-aint/base_int;raw_ratio=(m[338]*(aint/base_int))/base1024[338]
   ok=(rmax==338 and not missing and pos and cp<=lg['all_84_checkpoint_max_symmetric_relative'] and a338<=lg['all_84_A338_symmetric_relative']);overall=overall and ok
   score=max(cp,a338);rec={'eta10':eta,'edge_id':j+1,'edge_key':key,'pass':ok,'removed_source_share':share,'structural_reachable_max_A':rmax,'structural_missing_A24_A338':missing,
        'positive_A160_A338':pos,'renormalized_checkpoint_max_relative':cp,'worst_A':wa,'renormalized_A338_relative':a338,'renormalized_A338_ratio':m[338]/base1024[338],
        'unrenormalized_A338_ratio':raw_ratio,'screen_refinement':LOO_N,'sensitivity_score':score}
   loo_rows.append(rec);confirm_candidates.append((score,eta,j,key,cp,a338))
   print('R13_LOO',eta,j+1,key,'PASS' if ok else 'FAIL','SRC_SHARE',share,'CHECKPOINT_REL',cp,'A338_REL',a338,'REACH_MAX',rmax,flush=True)
 # Confirm three globally worst screen cases at P2048
 confirm=[]
 for score,eta,j,key,cp1024,a1024 in sorted(confirm_candidates,reverse=True)[:3]:
  t,S,SE,SD,L,ii,st,C,species,src,keys,cb,bb,maxA,escape=precompute(eta,caps,betas);base,_=solve_mass(t,S,L,ii,st,C,species,CONFIRM_N)
  Sa=S.copy();Sa[SD[j],:]-=SE[j,:];Sa=np.maximum(Sa,0.0);m,_=solve_mass(t,Sa,L,ii,st,C,species,CONFIRM_N)
  cp,wa=maxrel(base,m,CHECKPOINTS);a=symmetric_rel(base[338],m[338]);shift=max(abs(cp-cp1024),abs(a-a1024));ok=cp<=lg['top3_P2048_checkpoint_max_symmetric_relative'] and a<=lg['top3_P2048_A338_symmetric_relative'] and shift<=lg['top3_resolution_shift_in_sensitivity_max'];overall=overall and ok
  rec={'eta10':eta,'edge_id':j+1,'edge_key':key,'pass':ok,'P1024_checkpoint_relative':cp1024,'P2048_checkpoint_relative':cp,'P1024_A338_relative':a1024,'P2048_A338_relative':a,'resolution_shift':shift,'P2048_worst_A':wa};confirm.append(rec)
  print('R13_LOO_CONFIRM',eta,j+1,key,'PASS' if ok else 'FAIL','P2048_CHECKPOINT_REL',cp,'P2048_A338_REL',a,'SHIFT',shift,flush=True)
 # write outputs
 RESULTS.mkdir(parents=True,exist_ok=True);EVIDENCE.mkdir(parents=True,exist_ok=True)
 with (RESULTS/'BOUNDARY_SOURCE_EDGE_REGISTRY.csv').open('w',newline='',encoding='utf-8') as f:
  w=csv.DictWriter(f,fieldnames=list(edge_registry[0]));w.writeheader();w.writerows(edge_registry)
 with (RESULTS/'SOURCE_TAIL_TRUNCATION_RESULTS.csv').open('w',newline='',encoding='utf-8') as f:
  w=csv.DictWriter(f,fieldnames=list(tail_rows[0]));w.writeheader();w.writerows(tail_rows)
 with (RESULTS/'BOUNDARY_EDGE_LEAVE_ONE_OUT_RESULTS.csv').open('w',newline='',encoding='utf-8') as f:
  fields=[k for k in loo_rows[0] if k!='structural_missing_A24_A338'];w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows([{k:v for k,v in r.items() if k in fields} for r in loo_rows])
 out={'schema':'cptg-r13-source-tail-robustness-result-v1','decision':'PASS' if overall else 'NOT_QUALIFIED','tail_rows':tail_rows,'leave_one_out_rows':loo_rows,'top3_P2048_confirmations':confirm,
      'boundary_source_edges':edge_registry,'claim_boundary':cfg['claim_boundary'],'r12_endpoint_vectors_imported':False,'fresh_reaclib':True,'natural_frontier_A':338}
 atomic_json(EVIDENCE/'R13_SOURCE_TAIL_ROBUSTNESS.json',out)
 print('R13_SOURCE_TAIL_ROBUSTNESS','PASS' if overall else 'NOT_QUALIFIED')
 if not overall:raise SystemExit(5)
if __name__=='__main__':main()
