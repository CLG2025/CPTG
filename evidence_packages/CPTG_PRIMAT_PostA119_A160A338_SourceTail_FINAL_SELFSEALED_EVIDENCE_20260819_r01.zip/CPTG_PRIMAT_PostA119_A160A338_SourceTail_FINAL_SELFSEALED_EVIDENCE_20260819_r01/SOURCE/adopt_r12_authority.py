from __future__ import annotations
import json,hashlib,shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
R12=Path(r"D:\Downloads\CPTG_PRIMAT_PostA119_A160A338_FinerFrontierContinuumQualification_20260818_r12")
EXPECT_FREEZE="97fd7b4f4f4e7466be9e45be264e62faade5b55e80d415201ed4390405080f9a"
EXPECT_PREREG="2da41cf74fb4957f542d209d9e5158951398661e369e44d4ad5a3dd8568e329c"
EXPECT_GLOBAL={
 "global_P1024_2048_checkpoint_max":0.0015208908661584173,
 "global_BE1024_2048_checkpoint_max":0.030301545856681582,
 "global_continuum_cross_checkpoint_max":0.0017207632391533806,
 "global_P2048_Richardson_checkpoint_max":0.0005103661629565045,
}
def sha(p:Path):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def main():
 for d in (ROOT/'EVIDENCE',ROOT/'OUTPUT'):d.mkdir(parents=True,exist_ok=True)
 prereg=R12/'CONFIG/FROZEN_R12_FINER_FRONTIER_PREREGISTRATION.json'
 if not prereg.is_file() or sha(prereg)!=EXPECT_PREREG:raise RuntimeError('r12 frozen preregistration mismatch')
 result=R12/'EVIDENCE/R12_A160_A338_FINER_FRONTIER_CONTINUUM_QUALIFICATION.json'
 if not result.is_file():raise RuntimeError('r12 evidence missing; RUN_FINER_FRONTIER_WINDOWS.cmd must have completed')
 r=json.loads(result.read_text(encoding='utf-8'))
 if r.get('decision')!='PASS':raise RuntimeError('r12 PASS required')
 if len(r.get('anchors',[]))!=6 or any(a.get('pass') is not True for a in r['anchors']):raise RuntimeError('r12 six-anchor PASS structure required')
 for k,v in EXPECT_GLOBAL.items():
  x=float(r.get(k,float('nan')))
  if abs(x-v)>max(1e-15,1e-12*abs(v)):raise RuntimeError('r12 frozen global metric mismatch '+k)
 fp=R12/'OUTPUT/NATIVE_TRAJECTORY_FREEZE.json'
 if not fp.is_file() or sha(fp)!=EXPECT_FREEZE:raise RuntimeError('r12 native freeze mismatch')
 fr=json.loads(fp.read_text(encoding='utf-8'))
 for rec in fr['files']:
  s=R12/rec['path']
  if not s.is_file() or sha(s)!=rec['sha256']:raise RuntimeError('native member mismatch '+rec['path'])
  d=ROOT/rec['path'];d.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(s,d)
  if sha(d)!=rec['sha256']:raise RuntimeError('copy mismatch '+rec['path'])
 shutil.copy2(fp,ROOT/'OUTPUT/NATIVE_TRAJECTORY_FREEZE.json')
 shutil.copy2(result,ROOT/'EVIDENCE/UPSTREAM_R12_PASS_SUMMARY.json')
 shutil.copy2(prereg,ROOT/'EVIDENCE/UPSTREAM_R12_FROZEN_PREREGISTRATION.json')
 out={"schema":"cptg-r13-r12-adoption-v1","pass":True,"r12_decision":"PASS","r12_six_anchor_pass":True,"r12_metrics_verified":True,
      "native_freeze_sha256":EXPECT_FREEZE,"r12_preregistration_sha256":EXPECT_PREREG,"r12_endpoint_vectors_imported":False,
      "native_trajectories_imported":True,"historical_postsilicon_numerical_inputs":0}
 (ROOT/'EVIDENCE/R12_AUTHORITY_ADOPTION.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n',encoding='utf-8')
 print('R13_R12_AUTHORITY_ADOPTION PASS')
 print('R12_DECISION PASS')
 print('R12_SIX_ANCHOR_PASS True')
 print('R12_METRICS_VERIFIED True')
 print('FREEZE_SHA256',EXPECT_FREEZE)
 print('R12_ENDPOINT_VECTORS_IMPORTED False')
 print('HISTORICAL_POSTSILICON_NUMERICAL_INPUTS 0')
if __name__=='__main__':main()
