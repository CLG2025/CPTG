from pathlib import Path
import hashlib,json,py_compile
ROOT=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def ck(n,c):
 if not c:raise RuntimeError(n+' FAIL')
 print(n,'PASS')
pr=ROOT/'CONFIG/FROZEN_R13_SOURCE_TAIL_ROBUSTNESS_PREREGISTRATION.json'
ck('R13_TAILONLY_PREREG_UNCHANGED',sha(pr)=='acc25bffbe7b18ed886a162fee67b9a61571bb4a6a57fc0db3bbe6c73f660f6a')
p=json.loads(pr.read_text(encoding='utf-8'));s=json.loads((ROOT/'CONFIG/TAIL_ONLY_EXECUTION_SCOPE_LOCK.json').read_text(encoding='utf-8'))
ck('R13_TAILONLY_SCOPE',s['tail_only'] is True and s['leave_one_out_executed'] is False)
ck('R13_TAILONLY_FRACTIONS',p['source_tail']['retained_source_fractions']==[0.99,0.999,0.9999])
ck('R13_TAILONLY_REFINEMENT',p['numerics']['tail_production_refinement']==2048)
code=(ROOT/'SOURCE/run_tail_only.py').read_text(encoding='utf-8')
ck('R13_TAILONLY_NO_LOO_EXECUTION','for j,key in enumerate' not in code and 'LOO_N' not in code)
ck('R13_TAILONLY_EXACT_ORIGINAL_FUNCTIONS','r.truncate_exact_trapz' in code and 'r.solve_mass' in code and 'r.precompute' in code)
for q in sorted((ROOT/'SOURCE').glob('*.py')):py_compile.compile(str(q),doraise=True)
print('R13_TAILONLY_PYTHON_COMPILE PASS')
print('R13_TAILONLY_STATIC_VERIFY PASS')
