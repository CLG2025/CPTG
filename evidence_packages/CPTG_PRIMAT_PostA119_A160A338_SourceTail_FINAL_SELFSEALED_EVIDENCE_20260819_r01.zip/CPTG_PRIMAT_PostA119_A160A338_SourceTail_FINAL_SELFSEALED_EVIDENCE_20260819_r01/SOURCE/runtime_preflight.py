from __future__ import annotations
import sys, importlib.metadata, hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
EXPECTED=Path(r"D:\Downloads\CPTG_PRIMAT_A1A119_TRANSPORT_ENV_r02\Scripts\python.exe")
PREREG_SHA="acc25bffbe7b18ed886a162fee67b9a61571bb4a6a57fc0db3bbe6c73f660f6a"
def ck(name,cond,detail=""):
    if not cond:
        raise RuntimeError(f"{name} FAIL {detail}".rstrip())
    print(name,"PASS",detail)
def main():
    actual=Path(sys.executable)
    ck("R13_HOTFIX_RUNTIME_PYTHON",str(actual).lower()==str(EXPECTED).lower(),str(actual))
    ck("R13_HOTFIX_PYNUCASTRO_VERSION",importlib.metadata.version("pynucastro")=="2.11.0",importlib.metadata.version("pynucastro"))
    import numpy, numba, scipy, pynucastro
    ck("R13_HOTFIX_NUMPY_IMPORT",True,numpy.__version__)
    ck("R13_HOTFIX_NUMBA_IMPORT",True,numba.__version__)
    ck("R13_HOTFIX_SCIPY_IMPORT",True,scipy.__version__)
    p=ROOT/"CONFIG/FROZEN_R13_SOURCE_TAIL_ROBUSTNESS_PREREGISTRATION.json"
    h=hashlib.sha256(p.read_bytes()).hexdigest()
    ck("R13_HOTFIX_PREREG_UNCHANGED",h==PREREG_SHA,h)
    print("R13_HOTFIX_RUNTIME_PREFLIGHT PASS")
if __name__=="__main__": main()
