#!/usr/bin/env python3
"""Compute the Milky Way rotation, mass, structural, and Gaia comparison tables."""
from pathlib import Path
import sys, configparser, json, csv
import numpy as np
import pandas as pd
from scipy.integrate import quad
from scipy.special import gamma,gammainc

BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE/'code'))
from galaxy_field import fit_cptg_local_astar_profile,build_physical_baryonic_field,mond_acceleration,KPC_TO_M
G=4.30091727003628e-6   # (km/s)^2 kpc/M_sun
D=pd.read_csv(BASE/'inputs'/'milky_way_45.csv')
T=pd.read_csv(BASE/'inputs'/'numerical_targets_45.csv')
assert len(D)==len(T)==45 and np.array_equal(D.radius_kpc.to_numpy(),T.radius_kpc.to_numpy())
r=D.radius_kpc.to_numpy(float); v=D.vobs_km_s.to_numpy(float); e=D.errv_km_s.to_numpy(float)
assert np.all(np.diff(r)>0)
# Midplane bulge force for spheroid density defined by the enclosed homeoids.
ini=configparser.ConfigParser();ini.read(BASE/'inputs'/'McMillan17.ini')
b=ini['Potential bulge'];q=float(b['axisRatioZ']);rho0=float(b['densityNorm']);a=float(b['scaleRadius']);beta=float(b['beta']);cut=float(b['outerCutoffRadius']);ell=1-q*q
def density(s): return rho0*(1+s/a)**(-beta)*np.exp(-(s/cut)**2)
def bulge_force(R):
    integral=quad(lambda s: density(s)*s*s/np.sqrt(R*R-ell*s*s),0,R,epsrel=2e-11,limit=250)[0]
    return (4*np.pi*G*q/R)*integral
bulge=np.array([bulge_force(x) for x in r])
parts=['vthin2_km2_s2','vthick2_km2_s2','vHI2_km2_s2','vH2_2_km2_s2']
part_forces=np.column_stack([D[c].to_numpy(float)/r for c in parts]+[bulge])
material_force=part_forces.sum(axis=1)
material_speed=np.sqrt(material_force*r)
# Physical bulge acceleration corresponds to the unit-template bulge curve with factor 0.7.
vbulge_unit=np.sqrt(bulge*r/.7)
gbar=build_physical_baryonic_field(r*KPC_TO_M,D.vgas_signed_km_s.to_numpy(float)*1e3,D.vdisk_unit_km_s.to_numpy(float)*1e3,vbulge_unit*1e3)
fit=fit_cptg_local_astar_profile(gbar,r*KPC_TO_M,v*1e3,e*1e3)
vc=np.sqrt(fit['g_cptg']*r*KPC_TO_M)/1e3
baryon_speed=np.sqrt(np.maximum(gbar,0)*r*KPC_TO_M)/1e3
mond_speed=np.sqrt(mond_acceleration(gbar)*r*KPC_TO_M)/1e3
# Physical inventory inside a cylindrical aperture of radius R.
# A spheroidal shell contributes its full volume below R and its polar caps above R.
def material_aperture(R):
    enclosed=4*np.pi*q*(
        quad(lambda s:s*s*density(s),0,R,epsrel=2e-11,limit=250)[0]
        +quad(lambda s:s*s*density(s)*(1-np.sqrt(1-(R/s)**2)),R,100,epsrel=2e-11,limit=250)[0]
    )
    for section in ['Potential thin disk','Potential thick disk','Potential HI gas disk','Potential molecular gas disk']:
        disk=ini[section];sig0=float(disk['surfaceDensity']);rd=float(disk['scaleRadius']);rcut=float(disk.get('innerCutoffRadius','0'))
        enclosed+=2*np.pi*sig0*quad(lambda x:x*np.exp(-x/rd-rcut/x) if x else 0,0,R,epsrel=2e-11)[0]
    return enclosed
mat=np.array([material_aperture(R) for R in r])
grav=r*vc*vc/G; geom=grav-mat
geom_speed=np.sqrt(np.maximum(geom,0)*G/r)
share=100*geom/grav
chi=float(np.sum(((vc-v)/e)**2));rms=float(np.sqrt(np.mean((vc-v)**2)))
logr=np.log10((vc/v)**2)
# Registered sampled Structural Mode N, measured from the completed field.
g=vc*vc/r; dg=np.gradient(g,r,edge_order=1)
C=g*g+np.gradient(g,r,edge_order=1)**2
weight=np.abs(np.gradient(C,r,edge_order=1))
outer=r>r[-1]/5
smoothed=np.convolve(weight[outer],np.ones(5)/5,mode='same')
w=np.zeros_like(r);w[outer]=smoothed
lam=float(np.dot(r[outer],smoothed)/smoothed.sum());mode=float(r[-1]/lam)
# Published Gaia-based B2 Einasto model.
j=json.loads((BASE/'inputs'/'jiao_B2.json').read_text()); M0,h,n=j['M0_msun'],j['h_kpc'],j['n']
def halo(radii,m0=M0,hk=h,idx=n):
    return m0*idx*gamma(3*idx)*gammainc(3*idx,(np.asarray(radii)/hk)**(1/idx))
halo_mass=halo(r)
gaiashare=100*(1-j['M_baryonic_msun']/j['M_dynamical_msun'])
# Every sampled radial diagnostic used in the manuscript's figures and tables.
R=pd.DataFrame(dict(
 radius_kpc=r,observed_km_s=v,error_km_s=e,cptg_km_s=vc,
 baryonic_template_km_s=baryon_speed,physical_material_km_s=material_speed,
 geometric_mass_equivalent_speed_km_s=geom_speed,mond_km_s=mond_speed,
 thin_disk_force_km2_s2_kpc=part_forces[:,0],thick_disk_force_km2_s2_kpc=part_forces[:,1],
 HI_force_km2_s2_kpc=part_forces[:,2],H2_force_km2_s2_kpc=part_forces[:,3],
 oblate_bulge_force_km2_s2_kpc=part_forces[:,4],total_physical_force_km2_s2_kpc=material_force,
 cptg_source_m_s2=gbar,material_msun=mat,gravitational_equivalent_msun=grav,
 geometric_equivalent_msun=geom,geometric_share_percent=share,
 sigma_c_squared=fit['Sigma_C_squared'],polarization_m_s2=fit['polarization_response_m_s2'],
 transport_denominator=fit['transport_denominator'],
 residual_log10_acceleration=logr,structural_acceleration_km2_s2_kpc=g,
 structural_carrier=C,structural_weight=w,
 gaia_B2_einasto_halo_enclosed_msun=halo_mass,
 cptg_minus_gaia_halo_percent=100*(geom/halo_mass-1),
))
result_dir=BASE/'results';result_dir.mkdir(exist_ok=True)
R.to_csv(result_dir/'milky_way_45_results.csv',index=False,float_format='%.15g')
# Prescribed sensitivity cases from the paper.
sharecases=[]
for case,ds,dm in [('central',0,0),('material +5%',0,.05),('material -5%',0,-.05),('speed +1%',.01,0),('speed -1%',-.01,0)]:
    sharecases.append(dict(case=case,speed_change=ds,material_change=dm,geometric_share_percent=100*(1-mat[-1]*(1+dm)/(grav[-1]*(1+ds)**2))))
pd.DataFrame(sharecases).to_csv(result_dir/'mass_share_sensitivity.csv',index=False,float_format='%.15g')
def calc_mode(rr,vv,edge,window):
    gg=vv**2/rr; dc=np.gradient(gg,rr,edge_order=edge);cc=gg**2+dc**2;ww=np.abs(np.gradient(cc,rr,edge_order=edge));ss=rr>rr[-1]/5; ww=ww[ss]
    if window>1:ww=np.convolve(ww,np.ones(window)/window,mode='same')
    ll=np.dot(rr[ss],ww)/ww.sum();return (rr[-1]/ll,ll)
modecases=[]
for case,Rmax,edge,window in [('central',27.25,1,5),('no smoothing',27.25,1,1),('second-order boundary',27.25,2,5),('radial coverage 26.25',26.25,1,5),('radial coverage 25.25',25.25,1,5)]:
    mask=r<=Rmax; nn,ll=calc_mode(r[mask],vc[mask],edge,window)
    modecases.append(dict(case=case,outer_kpc=Rmax,gradient_order=edge,smoothing_points=window,N=nn,lambda_kpc=ll))
pd.DataFrame(modecases).to_csv(result_dir/'structural_mode_sensitivity.csv',index=False,float_format='%.15g')
paramcases=[]
for param in ['M0','h','n']:
    for value in j['einasto_endpoints'][param]:
        args=dict(m0=M0,hk=h,idx=n);args[{'M0':'m0','h':'hk','n':'idx'}[param]]=value
        paramcases.append(dict(parameter=param,value=value,gaia_halo_msun_at_27_25=float(halo(r[-1],**args))))
pd.DataFrame(paramcases).to_csv(result_dir/'gaia_einasto_parameter_sensitivity.csv',index=False,float_format='%.15g')
summary=dict(sample_count=len(r),outer_radius_kpc=float(r[-1]),chi_squared_diagonal=chi,
 rms_speed_residual_km_s=rms,population_std_log_acceleration_dex=float(np.std(logr,ddof=0)),
 rms_log_acceleration_dex=float(np.sqrt(np.mean(logr**2))),
 cptg_parameters={'kappa_C_kpc':float(fit['kappa_C_kpc']),'A_C':float(fit['A_C']),'c_C':float(fit['c_C'])},
 cptg_speed_outer_km_s=float(vc[-1]),observed_outer_km_s=float(v[-1]),
 outer_gravitational_equivalent_msun=float(grav[-1]),outer_material_msun=float(mat[-1]),outer_geometric_equivalent_msun=float(geom[-1]),
 outer_geometric_share_percent=float(share[-1]),structural_N=mode,organization_length_kpc=lam,
 gaia_B2_dark_share_percent=gaiashare,gaia_B2_share_lower_percent=100*(1-j['M_baryonic_msun']/j['M_dynamical_lower_msun']),
 gaia_B2_share_upper_percent=100*(1-j['M_baryonic_msun']/j['M_dynamical_upper_msun']),
 gaia_B2_einasto_27_25_msun=float(halo_mass[-1]),gaia_B2_einasto_virial_msun=float(halo(j['reported_virial_radius_kpc'])),
 gaia_B2_mass_budget_halo_msun=float(j['M_dynamical_msun']-j['M_baryonic_msun']),
 six_curve_definitions=['observed','CPTG','baryonic template','physical material','geometric equivalent','fixed a0 MOND'])
(result_dir/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print('PASS: 45 radial outputs; chi2 %.12f; N %.12f; geometric share %.9f%%; Gaia B2 %.9f%%'%(chi,mode,share[-1],gaiashare))
