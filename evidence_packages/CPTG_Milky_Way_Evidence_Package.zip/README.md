# CPTG Milky Way — Numerical Evidence

This package contains the observational inputs, Galactic material parameters, computational field kernel, independent source-field check, and numerical tables for the Milky Way results in *The Milky Way Through the Lens of CPTG: Galactic Rotation, Material Structure, and Geometric Gravity*.

The dataset comprises 45 published DR3+ composite circular-speed bins over 5.25–27.25 kpc. The adopted material source includes the finite-height thin and thick disks, atomic and molecular gas, and an oblate bulge. The registered CPTG galaxy solve uses observed circular speeds to evaluate local structural support and to determine galaxy-specific coefficients. Structural Mode N is evaluated from the completed field.

## Run

Python 3 with `numpy`, `pandas`, `scipy`, and `matplotlib`:

```
python -m pip install -r requirements.txt
python run.py
python axisymmetric_weak_field.py --sizes 480x285
python verify.py
python plot_figures.py
```

`run.py` writes the sampled velocity, force, mass-equivalent, Structural Mode, and Gaia B2 Einasto results under `results/`, together with the paper's sensitivity tables and the numerical summary. `axisymmetric_weak_field.py` independently solves the material density's axisymmetric Poisson problem. `verify.py` checks the numerical quantities and material-force agreement. `plot_figures.py` renders all five quantitative charts using the computed tables.

## Inputs

- `inputs/milky_way_45.csv`: Galactocentric radii; published DR3+ circular speeds and quoted errors; finite-height stellar and gas force components; CPTG baryonic source templates. The material inventory is integrated from `McMillan17.ini` during execution.
- `inputs/McMillan17.ini`: McMillan (2017) stellar, gas, and oblate-bulge density parameters, with no halo component in the material field.
- `inputs/jiao_B2.json`: Jiao et al. (2023) Table 4 B2 central quantities, asymmetric parameter endpoints, and mass limits.
- `inputs/numerical_targets_45.csv`: 45-row numerical targets for reproducibility assertions.
- `inputs/physical_force_targets_45.csv`: Material radial-force targets used by the independent Poisson solver.

## Output definitions

The six-curve figure shows observed rotation measurements, the CPTG reconstructed speed, the unit-template baryonic source, the physically normalized finite-height material-force speed, the spherical geometric mass-equivalent speed, and the fixed-acceleration MOND illustration.

The spherical gravitational equivalent is `M_grav_eq = R V_CPTG² / G`. The geometric equivalent is `M_geom_eq = M_grav_eq − M_material`, where `M_material` is the separately integrated axisymmetric density inventory. Structural Mode is the sampled post-solution measurement `N = R_max / λ`, with the five-point-smoothed structural weight over `r > R_max/5`.

The physical material-force terms are signed force contributions, and the circular-speed equivalents of separate components are not summed linearly. The logarithmic acceleration residual uses `log10(g_CPTG / g_observed)`, and its scatter is the population standard deviation over the 45 points.

## References

Sylos Labini et al., *Mass Models of the Milky Way and Estimation of Its Mass from the Gaia DR3 Data Set*, ApJ 945, 3 (2023), DOI 10.3847/1538-4357/acb92c.

McMillan, *The Mass Distribution and Gravitational Potential of the Milky Way*, MNRAS 465, 76–94 (2017), DOI 10.1093/mnras/stw2759.

Jiao et al., *Detection of the Keplerian decline in the Milky Way rotation curve*, A&A 678, A208 (2023), DOI 10.1051/0004-6361/202347513.

Glass, *CPTG in 153 Primary SPARC Galaxies: Resolved Rotation Curves and Geometric–Material Mass Equivalents*, DOI 10.5281/zenodo.23452615.

Glass, *Structural Mode N in CPTG: Measuring Gravitational Organization from Galaxies to Black Holes*, DOI 10.5281/zenodo.23289859.
