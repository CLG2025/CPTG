# Axisymmetric finite-volume Poisson calculation of the modeled material field.
import argparse, configparser, csv, json, time
from pathlib import Path
import numpy as np
from scipy import sparse
from scipy.sparse.linalg import spsolve
from scipy.special import ellipk, expit
from scipy.interpolate import CubicSpline

G=4.30091727003628e-6  # (km/s)^2 kpc / Msun
ROOT=Path(__file__).resolve().parent
CONFIG=ROOT/'inputs'/'McMillan17.ini'
RADIAL=ROOT/'inputs'/'physical_force_targets_45.csv'

def density(R,z,cfg):
    # Full finite-height McMillan stellar and gas density (McMillan17.ini), halo excluded
    R=np.asarray(R);z=np.asarray(z); result=np.zeros(np.broadcast_shapes(R.shape,z.shape))
    for nm in ['Potential thin disk','Potential thick disk','Potential HI gas disk','Potential molecular gas disk']:
        s=cfg[nm];sig0=float(s['surfaceDensity']);rd=float(s['scaleRadius']);h=float(s['scaleHeight']);rcut=float(s.get('innerCutoffRadius','0'))
        sig=sig0*np.exp(-R/rd-rcut/np.maximum(R,1e-300))
        if h>0: v=np.exp(-np.abs(z)/h)/(2*h)
        else:
            hh=abs(h)
            v=expit(-np.abs(z)/hh)*expit(np.abs(z)/hh)/hh   # sech^2(z/2h)/(4h)
        result=result+sig*v
    s=cfg['Potential bulge'];rho0=float(s['densityNorm']);a=float(s['scaleRadius']);q=float(s['axisRatioZ']);beta=float(s['beta']);rt=float(s['outerCutoffRadius']);gamma=float(s.get('gamma','0'))
    dist=np.sqrt(R*R+(z/q)**2)
    result=result+rho0*np.power(np.maximum(dist/a,1e-300),-gamma)*np.power(1+dist/a,gamma-beta)*np.exp(-(dist/rt)**2)
    return result

def finite_volume_density(rf,zf,cfg):
    # 2x2 Gauss integration in each cylindrical FV cell; yields volume mean.
    ra,rb=rf[:-1,None],rf[1:,None]
    za,zb=zf[None,:-1],zf[None,1:]
    rr=0.5*(ra+rb);zz=0.5*(za+zb)
    volume_r=0.5*(rb*rb-ra*ra)
    root=1/np.sqrt(3)
    weighted=np.zeros((len(rr),len(zz.flatten())))
    # array shapes (nr,1) and (1,nz)
    for t in [-root,root]:
        r=rr+t*0.5*(rb-ra)
        for u in [-root,root]:
            z=zz+u*0.5*(zb-za)
            weighted+=density(r,z,cfg)*r
    # each cell: integral rho*r dR dz / (integral r dR dz)
    return (weighted*(rb-ra)*(zb-za)/4)/(volume_r*(zb-za))

def potential_green(R,Z,r,z,dm):
    # Exact ring angular Green kernel, discrete FV source. Both ±z source layers.
    r=np.asarray(r).reshape(-1);z=np.asarray(z).reshape(-1);dm=np.asarray(dm).reshape(-1)
    total=0.
    for d in [Z-z,Z+z]:
        a=(R+r)**2+d*d
        m=np.clip(4*R*r/a,0,1-1e-14)
        total+=np.dot(dm,ellipk(m)/np.sqrt(a))
    return -G/np.pi *total # dm already includes source mass from both + and -z

def solve(nr,nz,rmax=72.,zmax=32.):
    cfg=configparser.ConfigParser();cfg.read(CONFIG)
    # coordinate cluster toward bulge center and thin gas midplane; no density smoothing
    rf=rmax*(np.linspace(0,1,nr+1)**1.37)
    zf=zmax*(np.linspace(0,1,nz+1)**1.49)
    rc=0.5*(rf[:-1]+rf[1:]);zc=0.5*(zf[:-1]+zf[1:])
    dens=finite_volume_density(rf,zf,cfg)
    volume=(.5*(rf[1:]**2-rf[:-1]**2))[:,None]*(zf[1:]-zf[:-1])[None,:]
    mass=4*np.pi*dens*volume # both z halves, 2π azimuth
    RR,ZZ=np.meshgrid(rc,zc,indexing='ij')
    rm=RR.ravel();zm=ZZ.ravel();dm=mass.ravel()
    # Direct Green boundary, not an assumed or fitted outer potential.
    t=time.time()
    bound_R=np.array([potential_green(rmax, zz,rm,zm,dm) for zz in zc])
    bound_Z=np.array([potential_green(rr, zmax,rm,zm,dm) for rr in rc])
    n=nr*nz
    rows=[];cols=[];vals=[]; rhs=np.zeros(n)
    for i in range(nr):
      for j in range(nz):
        idx=i*nz+j; diag=0.
        Vr=.5*(rf[i+1]**2-rf[i]**2)
        dz=zf[j+1]-zf[j]
        rhs[idx]=-4*np.pi*G*dens[i,j]*Vr*dz
        # inner radial boundary at axis symmetry (zero flux)
        if i>0:
          k=rf[i]*dz/(rc[i]-rc[i-1]);diag+=k;rows.append(idx);cols.append((i-1)*nz+j);vals.append(-k)
        # outer radial boundary known Green potential
        if i<nr-1:
          k=rf[i+1]*dz/(rc[i+1]-rc[i]);diag+=k;rows.append(idx);cols.append((i+1)*nz+j);vals.append(-k)
        else:
          k=rf[i+1]*dz/(rf[i+1]-rc[i]);diag+=k;rhs[idx]+=k*bound_R[j]
        # midplane reflection symmetry at z=0
        if j>0:
          k=Vr/(zc[j]-zc[j-1]);diag+=k;rows.append(idx);cols.append(i*nz+j-1);vals.append(-k)
        # top boundary known Green potential
        if j<nz-1:
          k=Vr/(zc[j+1]-zc[j]);diag+=k;rows.append(idx);cols.append(i*nz+j+1);vals.append(-k)
        else:
          k=Vr/(zf[-1]-zc[-1]);diag+=k;rhs[idx]+=k*bound_Z[i]
        rows.append(idx);cols.append(idx);vals.append(diag)
    A=sparse.csr_matrix((vals,(rows,cols)),shape=(n,n))
    phi=spsolve(A,rhs).reshape(nr,nz)
    # midplane force: extrapolate the solved potential quadratically to z=0
    # local z dependence even, so eliminate leading z^2 error using first two layers
    z0,z1=zc[:2]
    phi_mid=(phi[:,0]*z1*z1-phi[:,1]*z0*z0)/(z1*z1-z0*z0)
    spr=CubicSpline(rc,phi_mid,bc_type='natural')
    with RADIAL.open() as f: ref=list(csv.DictReader(f))
    rs=np.array([float(a['radius_kpc']) for a in ref]);source=np.array([float(a['g_R_km2_s2_kpc']) for a in ref]); g=spr(rs,1)
    rel=(g-source)/source
    # conservation: weighted integrated residual should be below roundoff except Dirichlet boundaries
    resid=A@phi.ravel()-rhs
    status={'nr':nr,'nz':nz,'n_cells':n,'mass_total_Msun':float(np.sum(mass)),
            'max_abs_eq_residual':float(np.max(np.abs(resid))),
            'rel_eq_residual_L2':float(np.linalg.norm(resid)/np.linalg.norm(rhs)),
            'mean_relative_force_error':float(np.mean(rel)),
            'median_abs_relative_force_error':float(np.median(np.abs(rel))),
            'max_abs_relative_force_error':float(np.max(np.abs(rel))),
            'R_8p25_force':float(g[6]),
            'time_s':float(time.time()-t),
            'z_first_cell_center_kpc':float(zc[0]),
            'min_radial_center_kpc':float(rc[0])}
    rowsout=[{'radius_kpc':float(r),'g_source_reference':float(v),'g_fv_weak':float(t),'relative_difference':float(e)} for r,v,t,e in zip(rs,source,g,rel)]
    return status,rowsout,{'rf':rf,'zf':zf,'rc':rc,'zc':zc,'density':dens,'phi':phi,'midplane':phi_mid}

if __name__=='__main__':
    par=argparse.ArgumentParser();par.add_argument('--sizes',nargs='+',default=['480x285']);args=par.parse_args()
    import time
    result=[]
    for case in args.sizes:
        nr,nz=map(int,case.split('x'))
        stat,rr,grid=solve(nr,nz)
        print(json.dumps(stat,indent=2),flush=True)
        result.append(stat)
        with (ROOT/f'AXIS_POISSON_{nr}x{nz}_45.csv').open('w',newline='') as f:
            w=csv.DictWriter(f,rr[0].keys());w.writeheader();w.writerows(rr)
    with (ROOT/'POISSON_CONVERGENCE.json').open('w') as f:json.dump(result,f,indent=2)
