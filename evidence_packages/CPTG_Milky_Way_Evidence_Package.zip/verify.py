#!/usr/bin/env python3
"""Verify the Milky Way numerical outputs and source-force calculation."""
import json
from pathlib import Path
import numpy as np,pandas as pd
p=Path(__file__).resolve().parent
S=json.loads((p/'results'/'summary.json').read_text())
A=pd.read_csv(p/'results'/'milky_way_45_results.csv')
T=pd.read_csv(p/'inputs'/'numerical_targets_45.csv')
F=pd.read_csv(p/'inputs'/'physical_force_targets_45.csv')
assert A.shape[0]==T.shape[0]==F.shape[0]==45
for output,ref in [('cptg_km_s','cptg_km_s'),('cptg_source_m_s2','cptg_source_m_s2'),('physical_material_km_s','physical_material_km_s'),('material_msun','material_msun'),('gravitational_equivalent_msun','gravitational_equivalent_msun'),('geometric_equivalent_msun','geometric_equivalent_msun'),('geometric_share_percent','geometric_share_percent'),('sigma_c_squared','sigma_c_squared'),('polarization_m_s2','polarization_m_s2'),('transport_denominator','transport_denominator')]:
  x=A[output].to_numpy();y=T[ref].to_numpy()
  assert np.allclose(x,y,rtol=(1e-6 if output in ('polarization_m_s2','transport_denominator') else 3e-8),atol=1e-18),f'{output}: {np.max(np.abs(x-y))}'
assert np.allclose(A.total_physical_force_km2_s2_kpc,F.g_R_km2_s2_kpc,rtol=1e-12,atol=1e-8)
assert abs(S['chi_squared_diagonal']-7.347858053646427)<1e-6
assert abs(S['rms_speed_residual_km_s']-1.7190310524447674)<1e-6
assert abs(S['population_std_log_acceleration_dex']-0.007518967357478576)<1e-7
assert abs(S['outer_geometric_share_percent']-68.74261646615982)<5e-6
assert abs(S['structural_N']-2.8268133240105247)<1e-7
assert abs(S['organization_length_kpc']-9.639830040612383)<1e-6
assert abs(S['gaia_B2_dark_share_percent']-69.95121951219512)<1e-9
assert abs(S['gaia_B2_einasto_27_25_msun']-143657501077.9399)<1e-2
expected_mass=[68.74261646615966,67.17974728946766,70.30548564285168,69.35851040697938,68.10796496904364]
assert np.allclose(pd.read_csv(p/'results'/'mass_share_sensitivity.csv').geometric_share_percent,expected_mass,rtol=0,atol=1e-5)
expected_N=[2.8268133240105247,2.926688811626679,2.8245105868664937,2.730165020748594,2.7905809043671987]
assert np.allclose(pd.read_csv(p/'results'/'structural_mode_sensitivity.csv').N,expected_N,rtol=0,atol=1e-7)
expected_einasto=[116625175606.28456,161035424595.43265,143804100495.0947,143151957051.2545,125068695502.86586,179212857088.05557]
assert np.allclose(pd.read_csv(p/'results'/'gaia_einasto_parameter_sensitivity.csv').gaia_halo_msun_at_27_25,expected_einasto,rtol=1e-12,atol=1e-3)
FV=p/'AXIS_POISSON_480x285_45.csv'
if FV.exists():
  f=pd.read_csv(FV)
  assert np.array_equal(f.radius_kpc,A.radius_kpc)
  assert max(abs((f.g_fv_weak-A.total_physical_force_km2_s2_kpc)/A.total_physical_force_km2_s2_kpc))<3.6e-5
  print('PASS: axisymmetric finite-volume source calculation')
else:
  print('NOTE: finite-volume check requires python axisymmetric_weak_field.py --sizes 480x285')
print('PASS: 45-point rotation, field components, mass equivalents, N, Gaia B2 mass, and sensitivity tables')
