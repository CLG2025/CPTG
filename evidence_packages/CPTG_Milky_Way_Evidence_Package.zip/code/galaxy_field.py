# Computational CPTG galaxy field functions.
# Numerical formulas and optimization operations preserved from the registered galaxy workbench.
from __future__ import annotations
import numpy as np
from typing import Any,Dict,List,Optional,Tuple
from scipy.interpolate import BSpline, UnivariateSpline
from scipy.optimize import least_squares,nnls

KPC_TO_M = 3.085677581491367e+19

A0_MOND = 1.2e-10

CPTG_KAPPA_MIN_KPC = 0.0001

CPTG_KAPPA_MAX_KPC = 10000000.0

CPTG_A_MIN = 1e-30

CPTG_A_MAX = 100000.0

CPTG_C_MIN = 1e-10

CPTG_C_MAX = 1000.0

CPTG_SUPPRESSION_INNER_POWER = 123.0 / 50.0

CPTG_SUPPRESSION_OUTER_POWER = 11.0 / 50.0

CPTG_SUPPRESSION_AT_UNIT_RATIO = 2.0 ** (-CPTG_SUPPRESSION_OUTER_POWER)

KAPPA_STRUCT = KPC_TO_M

MIN_POINTS_FOR_STRUCTURE = 1

EPS = 1e-30

def signed_square(v: np.ndarray) -> np.ndarray:
    arr = np.asarray(v, dtype=float)
    return arr * np.abs(arr)

def build_physical_baryonic_field(r_m: np.ndarray, vgas_m_s: np.ndarray, vdisk_m_s: np.ndarray, vbulge_m_s: np.ndarray) -> np.ndarray:
    gas_term = signed_square(vgas_m_s)
    disk_term = signed_square(vdisk_m_s)
    bulge_term = signed_square(vbulge_m_s)
    vb2 = gas_term + disk_term + bulge_term
    return vb2 / np.maximum(r_m, EPS)

def mond_acceleration(gbar_physical: np.ndarray) -> np.ndarray:
    gbar = np.maximum(np.asarray(gbar_physical, dtype=float), EPS)
    x = np.maximum(gbar / A0_MOND, EPS)
    return gbar / (1.0 - np.exp(-np.sqrt(x)))

def _resolved_spline_degree(n_points: int) -> int:
    return max(1, min(3, int(n_points) - 1))

def resolved_support_state(r_m: np.ndarray, vobs_m_s: np.ndarray, errv_m_s: np.ndarray) -> Dict[str, np.ndarray]:
    r_m = np.asarray(r_m, dtype=float)
    vobs_m_s = np.asarray(vobs_m_s, dtype=float)
    errv_m_s = np.asarray(errv_m_s, dtype=float)
    if r_m.size < 3 or np.any(~np.isfinite(r_m)) or np.any(r_m <= 0.0):
        raise ValueError('Resolved radii must be finite, positive, and contain at least 3 points')
    if np.any(np.diff(r_m) <= 0.0):
        raise ValueError('Resolved radii must be strictly increasing')
    if np.any(~np.isfinite(vobs_m_s)) or np.any(vobs_m_s <= 0.0):
        raise ValueError('Observed velocities must be finite and positive')
    if np.any(~np.isfinite(errv_m_s)) or np.any(errv_m_s <= 0.0):
        raise ValueError('Velocity uncertainties must be finite and positive')
    x = np.log(r_m)
    g_observed = vobs_m_s ** 2 / r_m
    sigma_g = 2.0 * vobs_m_s * errv_m_s / r_m
    w = g_observed / sigma_g
    k = _resolved_spline_degree(r_m.size)
    unconstrained_spline = UnivariateSpline(x, np.log(g_observed), w=w, s=float(r_m.size), k=k)
    t, c_padded, degree = unconstrained_spline._eval_args
    n_coef = len(t) - degree - 1
    c = np.asarray(c_padded[:n_coef], dtype=float)
    greville = np.array([np.mean(t[i + 1:i + degree + 1]) for i in range(n_coef)], dtype=float)
    h_coeff = c - greville
    d_unconstrained = -np.diff(h_coeff)
    active_knots = np.unique(t[degree:n_coef + 1])
    extrema = list(active_knots)
    if degree >= 3:
        second = unconstrained_spline.derivative(2)
        for xa, xb in zip(active_knots[:-1], active_knots[1:]):
            if xb <= xa:
                continue
            dxa = float(second(xa + (xb - xa) * 1e-12))
            dxb = float(second(xb - (xb - xa) * 1e-12))
            if dxa * dxb < 0.0:
                stationary = xa - dxa * (xb - xa) / (dxb - dxa)
                if xa < stationary < xb:
                    extrema.append(stationary)
    maximum_unconstrained_slope = float(np.max(unconstrained_spline.derivative(1)(np.asarray(extrema))))
    if maximum_unconstrained_slope <= 1.0:
        d = d_unconstrained
        repaired_coeff = h_coeff
        adjusted = False
    else:
        B = BSpline.design_matrix(x, t, degree, extrapolate=False).toarray()
        F = np.cumsum(B[:, ::-1], axis=1)[:, ::-1][:, 1:]
        target = unconstrained_spline(x) - x
        ww = w ** 2
        ybar = np.average(target, weights=ww)
        fbar = np.average(F, axis=0, weights=ww)
        d, _ = nnls(w[:, None] * (F - fbar), w * (ybar - target))
        c0 = ybar + fbar @ d
        repaired_coeff = c0 - np.r_[0.0, np.cumsum(d)]
        adjusted = True
    if not adjusted:
        log_g_smooth = unconstrained_spline(x)
        g_smooth = np.exp(log_g_smooth)
        slope = unconstrained_spline.derivative(1)(x)
        sigma_c_squared = (1.0 - slope) / 3.0
        curvature_log_support = unconstrained_spline.derivative(2)(x)
    else:
        repaired_log_g = BSpline(t, repaired_coeff + greville, degree)
        log_g_smooth = repaired_log_g(x)
        g_smooth = np.exp(log_g_smooth)
        derivative_knot_diffs = t[degree + 1:degree + n_coef] - t[1:n_coef]
        if np.any(derivative_knot_diffs <= 0.0):
            raise RuntimeError('Invalid spline derivative knot spans')
        positive_sigma_basis = BSpline(t[1:-1], degree * d / (3.0 * derivative_knot_diffs), degree - 1)
        sigma_c_squared = np.asarray(positive_sigma_basis(x), dtype=float)
        slope = 1.0 - 3.0 * sigma_c_squared
        curvature_log_support = repaired_log_g.derivative(2)(x)
    if np.any(~np.isfinite(sigma_c_squared)) or np.any(sigma_c_squared < 0.0):
        raise RuntimeError('Nonnegative spline support-state condition failed')
    dg_dr = g_smooth * slope / r_m
    sigma_unconstrained = (1.0 - unconstrained_spline.derivative(1)(x)) / 3.0
    support_chi2_unconstrained = np.sum(((np.sqrt(np.exp(unconstrained_spline(x)) * r_m) - vobs_m_s) / errv_m_s) ** 2)
    support_chi2_shape_constrained = np.sum(((np.sqrt(g_smooth * r_m) - vobs_m_s) / errv_m_s) ** 2)
    return {'x_log_r': x, 'g_support_observed': g_observed, 'g_support_smooth': g_smooth, 'sigma_g': sigma_g, 'log_slope': slope, 'log_slope_derivative': np.asarray(curvature_log_support, dtype=float), 'dg_dr': dg_dr, 'Sigma_C_squared': sigma_c_squared, 'Sigma_C_squared_unconstrained': sigma_unconstrained, 'support_shape_adjusted': adjusted, 'support_chi2_unconstrained': float(support_chi2_unconstrained), 'support_chi2_shape_constrained': float(support_chi2_shape_constrained), 'a_star_local': g_observed.copy()}

def cptg_bpol_from_support(r_m: np.ndarray, support_state: Dict[str, np.ndarray], kappa_kpc: float) -> np.ndarray:
    r_m = np.asarray(r_m, dtype=float)
    g = np.asarray(support_state['g_support_smooth'], dtype=float)
    s = np.asarray(support_state['log_slope'], dtype=float)
    t = np.asarray(support_state['log_slope_derivative'], dtype=float)
    kappa_m = max(float(kappa_kpc), CPTG_KAPPA_MIN_KPC) * KPC_TO_M
    z = (kappa_m / r_m) ** 2
    h = s ** 2 + 2.0
    q_linear = 4.0 - s - t + 4.0 / 3.0 * s * s
    q_quadratic = h * (s - 1.0) * (s / 3.0 - 2.0) + t * (s * s / 3.0 - 2.0)
    Q = 1.0 + q_linear * z + q_quadratic * z * z
    C = g ** 2 * (1.0 + h * z)
    return g * C ** (-2.0 / 3.0) * Q / (1.0 + h * z)

def _solve_cptg_implicit_high_accel(gbar: np.ndarray, a_star_local: np.ndarray, sigma_c_squared: np.ndarray, B_pol: np.ndarray, A_C: float, c_C: float) -> Tuple[Optional[np.ndarray], Optional[np.ndarray]]:
    gbar = np.asarray(gbar, dtype=float)
    a_star_local = np.maximum(np.asarray(a_star_local, dtype=float), EPS)
    sigma_c_squared = np.asarray(sigma_c_squared, dtype=float)
    B_pol = np.asarray(B_pol, dtype=float)
    denominator = 1.0 + float(c_C) * sigma_c_squared
    polarization_raw = float(A_C) * a_star_local ** (2.0 / 3.0) * B_pol
    g = np.maximum((gbar + polarization_raw * CPTG_SUPPRESSION_AT_UNIT_RATIO) / denominator, EPS)
    for _ in range(28):
        ratio = np.maximum(g / a_star_local, 1e-16)
        ratio_p = ratio ** CPTG_SUPPRESSION_INNER_POWER
        suppression = (1.0 + ratio_p) ** (-CPTG_SUPPRESSION_OUTER_POWER)
        F = denominator * g - gbar - polarization_raw * suppression
        dS_dg = -CPTG_SUPPRESSION_OUTER_POWER * CPTG_SUPPRESSION_INNER_POWER * ratio ** (CPTG_SUPPRESSION_INNER_POWER - 1.0) / a_star_local * (1.0 + ratio_p) ** (-CPTG_SUPPRESSION_OUTER_POWER - 1.0)
        dF_dg = denominator - polarization_raw * dS_dg
        if np.any(~np.isfinite(dF_dg)) or np.any(np.abs(dF_dg) < 1e-25):
            break
        trial = g - F / dF_dg
        invalid = ~np.isfinite(trial) | (trial <= 0.0)
        trial = np.where(invalid, 0.5 * g, trial)
        rel = float(np.max(np.abs(trial - g) / np.maximum(np.abs(trial), EPS)))
        g = trial
        if rel < 2e-11:
            break
    ratio = np.maximum(g / a_star_local, 1e-16)
    suppression = (1.0 + ratio ** CPTG_SUPPRESSION_INNER_POWER) ** (-CPTG_SUPPRESSION_OUTER_POWER)
    F = denominator * g - gbar - polarization_raw * suppression
    scale = np.maximum(np.abs(denominator * g) + np.abs(gbar) + np.abs(polarization_raw * suppression), EPS)
    normalized_residual = float(np.max(np.abs(F) / scale))
    if np.any(~np.isfinite(g)) or np.any(g <= 0.0) or (not np.isfinite(normalized_residual)) or (normalized_residual > 5e-08):
        g = np.maximum((gbar + polarization_raw * CPTG_SUPPRESSION_AT_UNIT_RATIO) / denominator, EPS)
        for _ in range(180):
            ratio = np.maximum(g / a_star_local, 1e-16)
            suppression = (1.0 + ratio ** CPTG_SUPPRESSION_INNER_POWER) ** (-CPTG_SUPPRESSION_OUTER_POWER)
            trial = (gbar + polarization_raw * suppression) / denominator
            if np.any(~np.isfinite(trial)) or np.any(trial <= 0.0):
                return (None, None)
            updated = 0.55 * trial + 0.45 * g
            rel = float(np.max(np.abs(updated - g) / np.maximum(np.abs(updated), EPS)))
            g = updated
            if rel < 1e-11:
                break
        ratio = np.maximum(g / a_star_local, 1e-16)
        suppression = (1.0 + ratio ** CPTG_SUPPRESSION_INNER_POWER) ** (-CPTG_SUPPRESSION_OUTER_POWER)
        exact = (gbar + polarization_raw * suppression) / denominator
        if np.any(~np.isfinite(exact)) or np.any(exact <= 0.0) or float(np.max(np.abs(exact - g) / np.maximum(np.abs(exact), EPS))) > 2e-07:
            return (None, None)
        g = exact
    ratio = np.maximum(g / a_star_local, 1e-16)
    suppression = (1.0 + ratio ** CPTG_SUPPRESSION_INNER_POWER) ** (-CPTG_SUPPRESSION_OUTER_POWER)
    return (g, suppression)

def fit_cptg_local_astar_profile(gbar_physical: np.ndarray, r_m: np.ndarray, vobs_m_s: np.ndarray, errv_m_s: np.ndarray) -> Dict[str, Any]:
    gbar = np.asarray(gbar_physical, dtype=float)
    r_m = np.asarray(r_m, dtype=float)
    vobs = np.asarray(vobs_m_s, dtype=float)
    errv = np.maximum(np.asarray(errv_m_s, dtype=float), EPS)
    support = resolved_support_state(r_m, vobs, errv)
    a_star_local = np.asarray(support['a_star_local'], dtype=float)
    a_star_23 = np.maximum(a_star_local, EPS) ** (2.0 / 3.0)
    sigma_c_squared = np.asarray(support['Sigma_C_squared'], dtype=float)
    gobs = np.asarray(support['g_support_observed'], dtype=float)
    sigma_g = np.asarray(support['sigma_g'], dtype=float)
    lower = np.log(np.array([CPTG_KAPPA_MIN_KPC, CPTG_A_MIN, CPTG_C_MIN], dtype=float))
    upper = np.log(np.array([CPTG_KAPPA_MAX_KPC, CPTG_A_MAX, CPTG_C_MAX], dtype=float))
    bpol_cache: Dict[float, np.ndarray] = {}

    def bpol_for_logk(log_kappa: float) -> np.ndarray:
        kappa = float(np.exp(log_kappa))
        key = round(float(log_kappa), 11)
        cached = bpol_cache.get(key)
        if cached is None:
            cached = cptg_bpol_from_support(r_m, support, kappa)
            bpol_cache[key] = cached
        return cached

    def model_from_theta(theta: np.ndarray) -> Tuple[Optional[np.ndarray], Optional[np.ndarray], np.ndarray]:
        log_kappa, log_A, log_c = theta
        B_pol = bpol_for_logk(float(log_kappa))
        A_C = float(np.exp(log_A))
        c_C = float(np.exp(log_c))
        g_model, suppression = _solve_cptg_implicit_high_accel(gbar, a_star_local, sigma_c_squared, B_pol, A_C, c_C)
        return (g_model, suppression, B_pol)

    def velocity_residual(theta: np.ndarray) -> np.ndarray:
        g_model, _, _ = model_from_theta(theta)
        if g_model is None or np.any(~np.isfinite(g_model)) or np.any(g_model <= 0.0):
            return np.full_like(vobs, 1000000.0)
        v_model = np.sqrt(g_model * r_m)
        return (v_model - vobs) / errv
    kappa_grid = np.geomspace(0.001, 1000000.0, 30)
    c_grid = np.geomspace(1e-08, CPTG_C_MAX, 18)
    candidate_seeds: List[Tuple[float, np.ndarray]] = []
    accel_weights = 1.0 / np.maximum(sigma_g, EPS) ** 2
    for kappa in kappa_grid:
        log_k = float(np.log(kappa))
        B_pol = bpol_for_logk(log_k)
        for c_C in c_grid:
            denominator = 1.0 + c_C * sigma_c_squared
            phi = CPTG_SUPPRESSION_AT_UNIT_RATIO * a_star_23 * B_pol / denominator
            base = gbar / denominator
            target = gobs - base
            denom_A = float(np.sum(accel_weights * phi ** 2))
            if denom_A > 0.0 and np.isfinite(denom_A):
                A_C = float(np.sum(accel_weights * phi * target) / denom_A)
            else:
                A_C = CPTG_A_MIN
            if not np.isfinite(A_C) or A_C <= 0.0:
                A_C = CPTG_A_MIN
            A_C = float(np.clip(A_C, CPTG_A_MIN, CPTG_A_MAX))
            g_approx = base + A_C * phi
            if np.any(~np.isfinite(g_approx)) or np.any(g_approx <= 0.0):
                chi2_approx = float('inf')
            else:
                v_approx = np.sqrt(g_approx * r_m)
                chi2_approx = float(np.sum(((v_approx - vobs) / errv) ** 2))
            candidate_seeds.append((chi2_approx, np.array([log_k, np.log(A_C), np.log(c_C)], dtype=float)))
    candidate_seeds.sort(key=lambda item: item[0])
    seeds: List[np.ndarray] = []
    for _, theta in candidate_seeds:
        if all((np.linalg.norm(theta - existing) > 0.25 for existing in seeds)):
            seeds.append(theta)
        if len(seeds) >= 12:
            break
    best_chi2 = float('inf')
    best_theta: Optional[np.ndarray] = None
    best_residual: Optional[np.ndarray] = None
    best_model: Optional[np.ndarray] = None
    best_suppression: Optional[np.ndarray] = None
    best_bpol: Optional[np.ndarray] = None
    for seed in seeds:
        seed = np.minimum(np.maximum(seed, lower + 1e-12), upper - 1e-12)
        solution = least_squares(velocity_residual, seed, bounds=(lower, upper), max_nfev=300, xtol=1e-10, ftol=1e-10, gtol=1e-10)
        residual = np.asarray(solution.fun, dtype=float)
        chi2 = float(np.sum(residual ** 2))
        if np.isfinite(chi2) and chi2 < best_chi2:
            g_model, suppression, B_pol = model_from_theta(np.asarray(solution.x, dtype=float))
            if g_model is not None and suppression is not None:
                best_chi2 = chi2
                best_theta = np.asarray(solution.x, dtype=float)
                best_residual = residual
                best_model = np.asarray(g_model, dtype=float)
                best_suppression = np.asarray(suppression, dtype=float)
                best_bpol = np.asarray(B_pol, dtype=float)
    if best_theta is None or best_residual is None or best_model is None or (best_suppression is None) or (best_bpol is None):
        raise RuntimeError('CPTG local-a_star suppressed profile optimization failed')
    kappa_C_kpc, A_C, c_C = np.exp(best_theta)
    polarization_raw = A_C * a_star_23 * best_bpol
    polarization_response = polarization_raw * best_suppression
    transport_denominator = 1.0 + c_C * sigma_c_squared
    return {'kappa_C_kpc': float(kappa_C_kpc), 'A_C': float(A_C), 'c_C': float(c_C), 'fit_chi2': best_chi2, 'g_cptg': best_model, 'B_pol': best_bpol, 'Sigma_g_high_accel': best_suppression, 'polarization_raw_m_s2': polarization_raw, 'polarization_response_m_s2': polarization_response, 'transport_denominator': transport_denominator, 'a_star_local_m_s2': a_star_local, 'a_star_min_m_s2': float(np.min(a_star_local)), 'a_star_median_m_s2': float(np.median(a_star_local)), 'a_star_max_m_s2': float(np.max(a_star_local)), 'Sigma_C_squared': sigma_c_squared, 'Sigma_C_squared_unconstrained': np.asarray(support['Sigma_C_squared_unconstrained'], dtype=float), 'support_shape_adjusted': bool(support['support_shape_adjusted']), 'support_chi2_unconstrained': float(support['support_chi2_unconstrained']), 'support_chi2_shape_constrained': float(support['support_chi2_shape_constrained']), 'g_support_smooth_m_s2': np.asarray(support['g_support_smooth'], dtype=float)}

def estimate_structure_scale_and_mode(r_m: np.ndarray, g_field: np.ndarray, kappa: float=KAPPA_STRUCT) -> float:
    r_m = np.asarray(r_m, dtype=float)
    g_field = np.asarray(g_field, dtype=float)
    if r_m.size < MIN_POINTS_FOR_STRUCTURE:
        return float('nan')
    order = np.argsort(r_m)
    r_sorted = r_m[order]
    g_sorted = np.maximum(g_field[order], EPS)
    dg = np.gradient(g_sorted, r_sorted)
    C = g_sorted ** 2 + (kappa * dg) ** 2
    dC = np.gradient(C, r_sorted)
    finite = np.isfinite(r_sorted) & np.isfinite(dC) & (r_sorted > 0)
    if np.count_nonzero(finite) < MIN_POINTS_FOR_STRUCTURE:
        return float('nan')
    R_m = float(np.max(r_sorted))
    mask_outer = (r_sorted > 1.0 / 5.0 * R_m) & finite
    if np.count_nonzero(mask_outer) < MIN_POINTS_FOR_STRUCTURE:
        return float('nan')
    r_outer = r_sorted[mask_outer]
    dC_outer = np.abs(dC[mask_outer])
    window = 5
    if len(dC_outer) > window:
        kernel = np.ones(window) / window
        dC_outer = np.convolve(dC_outer, kernel, mode='same')
    weight_sum = np.sum(dC_outer)
    if weight_sum <= 0 or not np.isfinite(weight_sum):
        return float('nan')
    lambda_m = float(np.sum(r_outer * dC_outer) / weight_sum)
    return float(R_m / lambda_m) if lambda_m > 0 else float('nan')
