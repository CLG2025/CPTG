#!/usr/bin/env python3
"""Render the five quantitative Milky Way manuscript figures from computed tables."""
from pathlib import Path
import numpy as np,pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
p=Path(__file__).resolve().parent
D=pd.read_csv(p/'results'/'milky_way_45_results.csv');r=D.radius_kpc.to_numpy(); f=p/'figures';f.mkdir(exist_ok=True)
plt.rcParams.update({'font.size':10,'figure.dpi':160,'savefig.dpi':180})
def save(name):plt.grid(alpha=.23);plt.tight_layout();plt.savefig(f/name);plt.close()
# Stellar / gas / oblate-bulge midplane material force equivalents.
plt.figure(figsize=(8.3,5.1))
for key,label in [('thin_disk_force_km2_s2_kpc','Thin stellar disk'),('thick_disk_force_km2_s2_kpc','Thick stellar disk'),('HI_force_km2_s2_kpc','Atomic gas'),('H2_force_km2_s2_kpc','Molecular gas'),('oblate_bulge_force_km2_s2_kpc','Oblate bulge')]:
 plt.plot(r,np.sqrt(np.maximum(D[key],0)*r),label=label)
plt.plot(r,D.physical_material_km_s,color='black',linewidth=2,label='Total physical material');plt.xlabel('Galactocentric radius (kpc)');plt.ylabel('Circular-speed equivalent (km/s)');plt.legend(fontsize=8,ncol=2);save('01_material_components.png')
# Full measured-field figure, keeping observational data separate from curves.
plt.figure(figsize=(9.5,5.3))
plt.errorbar(r,D.observed_km_s,yerr=D.error_km_s,fmt='o',color='#1353B8',ms=3,capsize=2,label='Observed')
for field,label,color in [('cptg_km_s','CPTG','#EC871B'),('baryonic_template_km_s','Baryonic template','#111111'),('physical_material_km_s','Physical material','#2688D2'),('geometric_mass_equivalent_speed_km_s','Geometric equivalent','#D32632'),('mond_km_s','MOND','#158A49')]:
 plt.plot(r,D[field],color=color,linewidth=1.7,label=label)
plt.xlabel('Galactocentric radius (kpc)');plt.ylabel('Circular speed (km/s)');plt.legend(fontsize=8,ncol=3);save('02_six_curves.png')
plt.figure(figsize=(8.3,5.1))
for field,label,color in [('gravitational_equivalent_msun','Gravitational equivalent','#EC871B'),('material_msun','Physical material','#2688D2'),('geometric_equivalent_msun','Geometric equivalent','#D32632')]:
 plt.plot(r,D[field]/1e11,label=label,color=color)
plt.xlabel('Galactocentric radius (kpc)');plt.ylabel(r'Enclosed mass equivalent ($10^{11}\,M_\odot$)');plt.legend();save('03_mass_equivalents.png')
plt.figure(figsize=(8.3,5.1)); w=D.structural_weight.to_numpy();plt.plot(r,w/w.max(),label='Normalized structural weight');plt.axvline(pd.read_json(p/'results'/'summary.json',typ='series')['organization_length_kpc'],linestyle='--',color='black',label='Organization length');plt.axvline(27.25/5,linestyle=':',color='gray',label='Structural interval boundary');plt.xlabel('Galactocentric radius (kpc)');plt.ylabel('Relative structural weight');plt.legend();save('04_structural_mode.png')
plt.figure(figsize=(8.3,5.1));plt.plot(r,D.geometric_equivalent_msun/1e11,color='#D32632',label='CPTG geometric mass equivalent');plt.plot(r,D.gaia_B2_einasto_halo_enclosed_msun/1e11,color='#123A73',linestyle='--',label='Gaia B2 Einasto halo');plt.axvline(26.5,linestyle=':',color='gray',label='Gaia last observed bin');plt.xlabel('Galactocentric radius (kpc)');plt.ylabel(r'Enclosed mass ($10^{11}\,M_\odot$)');plt.legend();save('05_gaia_b2_comparison.png')
print('PASS: five quantitative figures rendered from the results table')
