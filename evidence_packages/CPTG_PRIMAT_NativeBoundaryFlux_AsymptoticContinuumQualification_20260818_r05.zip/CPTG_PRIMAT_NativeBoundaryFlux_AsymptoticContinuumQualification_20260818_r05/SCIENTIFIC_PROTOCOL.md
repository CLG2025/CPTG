# r05 Asymptotic Continuum Qualification

r04 established three facts simultaneously:

1. the positive exponential method remained finite/non-negative;
2. its adjacent-refinement differences contracted strongly;
3. the frozen 64-substep ceiling was still too coarse for the r04 endpoint gates.

r05 therefore does not loosen r04. It asks a new continuum question at fresh 64, 128, and
256 refinements.

Two raw non-negative schemes are run independently: positive exponential inflow and triangular
backward Euler.

For each selected mass sector and eta10 anchor, the three-point geometric sequence is used to
estimate its observed order and generalized Richardson continuum limit.

The two continuum estimates must agree within 0.5%. The positive 128->256 raw difference must
already be <=0.5%, and its estimated 256 residual to continuum must be <=0.25%. Backward Euler
is allowed its first-order raw behavior but its 128->256 change must be <=4% and its observed
global order must lie between 0.5 and 1.5.

If all six anchors pass, 256 substeps is qualified for a separate final validation. No prior
r02/r03/r04 transport output is imported into the calculation.
