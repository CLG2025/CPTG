@echo off
setlocal
cd /d "%~dp0"
"D:\Downloads\ChatGPT\cptg-cmb-like\Scripts\python.exe" -u SOURCE\adopt_frozen_native_trajectories.py
exit /b %ERRORLEVEL%
