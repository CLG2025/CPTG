from __future__ import annotations
import math
import numpy as np
from positive_transport_core import solve_backward_euler,solve_positive_exponential_inflow

def main():
    # Single stiff sink with constant source has exact positive solution.
    t=np.linspace(0.0,1.0,17)
    source=np.ones((1,len(t)))*3.0
    loss=np.ones((1,len(t)))*200.0
    ii=np.empty(0,dtype=np.int64); st=np.array([0,0],dtype=np.int64); ic=np.empty((0,len(t)))
    exact=3.0/200.0*(1.0-math.exp(-200.0))
    e,min_e=solve_positive_exponential_inflow(t,source,loss,ii,st,ic,1)
    b,min_b=solve_backward_euler(t,source,loss,ii,st,ic,128)
    if min_e<0 or min_b<0 or e[0]<0 or b[0]<0: raise RuntimeError("positivity selftest")
    if abs(e[0]-exact)/exact>1e-12: raise RuntimeError("exponential stiff scalar exactness")
    if abs(b[0]-exact)/exact>0.01: raise RuntimeError("BE stiff scalar convergence")

    # Triangular chain and source-linearity.
    ns=3; nt=len(t)
    src=np.zeros((ns,nt)); src[0,:]=1.0
    los=np.zeros((ns,nt)); los[0,:]=20.;los[1,:]=15.;los[2,:]=2.
    inc_src=np.array([0,1],dtype=np.int64)
    inc_start=np.array([0,0,1,2],dtype=np.int64)
    coeff=np.zeros((2,nt));coeff[0,:]=20.;coeff[1,:]=15.
    y,_=solve_positive_exponential_inflow(t,src,los,inc_src,inc_start,coeff,8)
    yh,_=solve_positive_exponential_inflow(t,src*0.5,los,inc_src,inc_start,coeff,8)
    yd,_=solve_positive_exponential_inflow(t,src*2.0,los,inc_src,inc_start,coeff,8)
    z,_=solve_positive_exponential_inflow(t,src*0.0,los,inc_src,inc_start,coeff,8)
    if np.min(y)<0 or not np.all(np.isfinite(y)):raise RuntimeError("chain positivity")
    if not np.array_equal(z,np.zeros_like(z)):raise RuntimeError("zero-source")
    if np.max(np.abs(2*yh-y))>1e-13 or np.max(np.abs(yd/2-y))>1e-13:raise RuntimeError("linearity")
    print("R04_POSITIVE_TRANSPORT_CORE_SELFTEST PASS")
if __name__=="__main__":main()
