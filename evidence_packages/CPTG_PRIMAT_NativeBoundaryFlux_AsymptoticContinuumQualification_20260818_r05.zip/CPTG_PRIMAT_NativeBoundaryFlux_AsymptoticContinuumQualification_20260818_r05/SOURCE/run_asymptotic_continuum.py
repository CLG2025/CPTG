from __future__ import annotations
import json,math,importlib.metadata
from collections import defaultdict,deque
import numpy as np
import pynucastro as pyna
from common import *
from positive_transport_core import solve_backward_euler,solve_positive_exponential_inflow

LEVELS=[64,128,256]
SELECTED=[24,28,32,40,56,80,100,119]
LIGHT_TUPLES=set(LIGHT)

def nuc_tuple(n):return int(n.A),int(n.Z)

def select_rates():
    rl=pyna.ReacLibLibrary();caps=[];betas=[]
    for r in rl.get_rates():
        rea=[nuc_tuple(x) for x in r.reactants];pro=[nuc_tuple(x) for x in r.products]
        if not r.weak and len(rea)==2 and len(pro)==1:
            ls=[x for x in rea if x in LIGHT_TUPLES]
            if len(ls)==1:
                l=ls[0];h=rea[1] if rea[0]==l else rea[0];d=pro[0]
                if h[0]>=6 and d==(h[0]+l[0],h[1]+l[1]):caps.append((h,l,d,r))
        if r.weak and getattr(r,"weak_type",None)=="beta_neg" and len(rea)==1 and len(pro)==1:
            if rea[0][0]>=6 and pro[0][0]==rea[0][0] and pro[0][1]==rea[0][1]+1:betas.append((rea[0],pro[0],r))
    caps.sort(key=lambda x:(x[0],x[1],x[2],str(x[3])));betas.sort(key=lambda x:(x[0],x[1],str(x[2])))
    return caps,betas

def build_graph(native,maxA,caps,betas):
    source=[(h,l,d,r) for h,l,d,r in caps if h in native and d not in native and 24<=d[0]<=maxA]
    seeds={d for h,l,d,r in source}
    if not seeds:raise RuntimeError("no boundary source")
    cb=defaultdict(list);bb=defaultdict(list)
    for h,l,d,r in caps:
        if h[0]>=24:cb[h].append((d,l,r))
    for s,d,r in betas:
        if s[0]>=24:bb[s].append((d,r))
    seen=set(seeds);q=deque(sorted(seeds))
    while q:
        s=q.popleft()
        for d,l,r in cb.get(s,[]):
            if d[0]<=maxA and d not in seen:seen.add(d);q.append(d)
        for d,r in bb.get(s,[]):
            if d[0]<=maxA and d not in seen:seen.add(d);q.append(d)
    species=sorted(seen,key=lambda x:(x[0],x[1]));idx={s:i for i,s in enumerate(species)}
    incoming=[];outgoing=defaultdict(list)
    for s in species:
        for d,l,r in cb.get(s,[]):
            outgoing[s].append(("capture",d,l,r))
            if d in idx:
                if idx[d]<=idx[s]:raise RuntimeError("non-forward capture")
                incoming.append((idx[s],idx[d],"capture",l,r))
        for d,r in bb.get(s,[]):
            outgoing[s].append(("beta",d,None,r))
            if d in idx:
                if idx[d]<=idx[s]:raise RuntimeError("non-forward beta")
                incoming.append((idx[s],idx[d],"beta",None,r))
    incoming.sort(key=lambda e:(e[1],e[0],str(e[4])))
    return source,species,idx,incoming,outgoing

def load_traj(eta):
    z=np.load(OUTPUT/f"NATIVE_TRAJECTORIES/PRIMAT_NATIVE_TRAJECTORY_ETA{eta_tag(eta)}.npz")
    names=[str(x) for x in z["species"]];az=[parse_primat_name(n) for n in names]
    return np.asarray(z["t_s"],float),np.asarray(z["T_K"],float),np.asarray(z["rho_b_g_cm3"],float),az,np.asarray(z["Y"],float)

def precompute(eta,maxA,caps,betas):
    t,T,rho,naz,Y=load_traj(eta);native=set(naz);ixn={a:i for i,a in enumerate(naz)}
    source_edges,species,idx,incoming,outgoing=build_graph(native,maxA,caps,betas)
    ns=len(species);nt=len(t);ne=len(incoming)
    source=np.zeros((ns,nt));loss=np.zeros((ns,nt));inc=np.zeros((ne,nt))
    for h,l,d,r in source_edges:
        rv=np.array([float(r.eval(float(Tv))) for Tv in T])
        c=np.maximum(rv,0.0)*rho*Y[ixn[l],:]
        source[idx[d],:]+=c*Y[ixn[h],:]
    for e,(si,di,kind,l,r) in enumerate(incoming):
        rv=np.array([float(r.eval(float(Tv))) for Tv in T])
        inc[e,:]=np.maximum(rv,0.0)*rho*Y[ixn[l],:] if kind=="capture" else np.maximum(rv,0.0)
    for s in species:
        si=idx[s]
        for kind,d,l,r in outgoing.get(s,[]):
            rv=np.array([float(r.eval(float(Tv))) for Tv in T])
            loss[si,:]+=np.maximum(rv,0.0)*rho*Y[ixn[l],:] if kind=="capture" else np.maximum(rv,0.0)
    if not np.all(np.isfinite(source)) or not np.all(np.isfinite(loss)) or not np.all(np.isfinite(inc)):
        raise RuntimeError("nonfinite coefficients")
    if np.min(source)<0 or np.min(loss)<0 or (inc.size and np.min(inc)<0):
        raise RuntimeError("negative coefficients")
    counts=np.zeros(ns,dtype=np.int64)
    for si,di,kind,l,r in incoming:counts[di]+=1
    starts=np.zeros(ns+1,dtype=np.int64);starts[1:]=np.cumsum(counts)
    return t,source,loss,np.array([x[0] for x in incoming],dtype=np.int64),starts,inc,species,len(source_edges)

def masses(species,y):
    m={A:0.0 for A in range(24,120)}
    for s,v in zip(species,y):
        if 24<=s[0]<=119:m[s[0]]+=float(v)
    return m

def maxrel(a,b):
    by={A:symmetric_rel(a[A],b[A]) for A in SELECTED}
    return max(by.values()),by

def global_order(dcoarse,dfine):
    return math.log(dcoarse/dfine,2) if dcoarse>0 and dfine>0 else None

def richardson_three(seq):
    # per selected mass generalized Richardson from 64,128,256.
    out={};orders={};invalid=[]
    for A in SELECTED:
        x0=float(seq[64][A]);x1=float(seq[128][A]);x2=float(seq[256][A])
        d0=abs(x0-x1);d1=abs(x1-x2)
        if not all(math.isfinite(x) and x>=0 for x in (x0,x1,x2)) or d0<=0 or d1<=0:
            invalid.append(A);continue
        p=math.log(d0/d1,2)
        den=(2.0**p)-1.0
        if not math.isfinite(p) or abs(den)<1e-12:
            invalid.append(A);continue
        lim=x2+(x2-x1)/den
        if not math.isfinite(lim) or lim<=0:
            invalid.append(A);continue
        out[A]=lim;orders[A]=p
    return out,orders,invalid

def dict_rel(a,b):
    masses=sorted(set(a)&set(b))
    by={A:symmetric_rel(a[A],b[A]) for A in masses}
    return max(by.values()) if by else float("inf"),by

def main():
    if importlib.metadata.version("pynucastro")!="2.11.0":raise RuntimeError("pynucastro 2.11.0 required")
    if sha_file(OUTPUT/"NATIVE_TRAJECTORY_FREEZE.json")!="97fd7b4f4f4e7466be9e45be264e62faade5b55e80d415201ed4390405080f9a":
        raise RuntimeError("freeze mismatch")
    pre=load_json(CONFIG/"FROZEN_ASYMPTOTIC_PREREGISTRATION.json");g=pre["hard_gates"]
    caps,betas=select_rates()
    anchors=[]
    global_p64_128=0.;global_p128_256=0.;global_b64_128=0.;global_b128_256=0.
    global_cross=0.;global_presid=0.
    for eta in ETA:
        print("R05_ASYMPTOTIC_START",eta,flush=True)
        t,source,loss,ii,st,ic,species,nsource=precompute(eta,160,caps,betas)
        integ=float(np.trapezoid(np.sum(source,axis=0),t))
        if integ<=0 or not math.isfinite(integ):raise RuntimeError("source integral")
        sn=source/integ
        P={};B={}
        for L in LEVELS:
            y,mn=solve_positive_exponential_inflow(t,sn,loss,ii,st,ic,L)
            if mn<0 or np.min(y)<0 or not np.all(np.isfinite(y)):raise RuntimeError("positive method invalid")
            P[L]=masses(species,y)
        for L in LEVELS:
            y,mn=solve_backward_euler(t,sn,loss,ii,st,ic,L)
            if mn<0 or np.min(y)<0 or not np.all(np.isfinite(y)):raise RuntimeError("BE invalid")
            B[L]=masses(species,y)
        p01,p01_by=maxrel(P[64],P[128]);p12,p12_by=maxrel(P[128],P[256])
        b01,b01_by=maxrel(B[64],B[128]);b12,b12_by=maxrel(B[128],B[256])
        global_p64_128=max(global_p64_128,p01);global_p128_256=max(global_p128_256,p12)
        global_b64_128=max(global_b64_128,b01);global_b128_256=max(global_b128_256,b12)
        pglob=global_order(p01,p12);bglob=global_order(b01,b12)

        PR,PRorders,PRbad=richardson_three(P);BR,BRorders,BRbad=richardson_three(B)
        if PRbad or BRbad:raise RuntimeError(f"Richardson invalid eta={eta} primary={PRbad} BE={BRbad}")
        cross,cross_by=dict_rel(PR,BR);global_cross=max(global_cross,cross)
        presid,presid_by=dict_rel(P[256],PR);global_presid=max(global_presid,presid)

        yabs,_=solve_positive_exponential_inflow(t,source,loss,ii,st,ic,256)
        absrec=maxrel(masses(species,yabs),{A:P[256][A]*integ for A in P[256]})[0]
        z,_=solve_positive_exponential_inflow(t,source*0,loss,ii,st,ic,64)
        h,_=solve_positive_exponential_inflow(t,source*0.5,loss,ii,st,ic,64)
        d,_=solve_positive_exponential_inflow(t,source*2,loss,ii,st,ic,64)
        base,_=solve_positive_exponential_inflow(t,source,loss,ii,st,ic,64)
        zero=bool(np.array_equal(z,np.zeros_like(z)))
        lin=max(vector_max_rel(h*2,base),vector_max_rel(d/2,base))
        rec={"eta10":eta,"positive_64_128_max":p01,"positive_128_256_max":p12,
             "positive_global_order":pglob,"BE_64_128_max":b01,"BE_128_256_max":b12,
             "BE_global_order":bglob,"continuum_cross_scheme_max":cross,
             "positive256_to_Richardson_max":presid,
             "positive_Richardson_orders":PRorders,"BE_Richardson_orders":BRorders,
             "zero_source_exact_zero":zero,"linearity_max":lin,
             "absolute_reconstruction_max":absrec,"boundary_source_edges":nsource,
             "external_species":len(species)}
        anchors.append(rec)
        print("R05_ASYMPTOTIC_ANCHOR",eta,
              "P64_128",p01,"P128_256",p12,"P_ORDER",pglob,
              "BE64_128",b01,"BE128_256",b12,"BE_ORDER",bglob,
              "CONTINUUM_CROSS",cross,"P256_RICH",presid,flush=True)

    Pord=global_order(global_p64_128,global_p128_256)
    Bord=global_order(global_b64_128,global_b128_256)
    controls=all(a["zero_source_exact_zero"] and
                 a["linearity_max"]<=float(g["half_double_source_linearity_max_relative"]) and
                 a["absolute_reconstruction_max"]<=float(g["absolute_vs_normalized_reconstruction_max_relative"])
                 for a in anchors)
    passed=(
      global_p128_256<=float(g["positive_128_vs_256_allanchor_selected_mass_max_relative"]) and
      Pord is not None and float(g["positive_global_effective_order_min"])<=Pord<=float(g["positive_global_effective_order_max"]) and
      global_presid<=float(g["positive_richardson_256_residual_allanchor_selected_mass_max_relative"]) and
      global_b128_256<=float(g["BE_128_vs_256_allanchor_selected_mass_max_relative"]) and
      Bord is not None and float(g["BE_global_effective_order_min"])<=Bord<=float(g["BE_global_effective_order_max"]) and
      global_cross<=float(g["continuum_cross_scheme_allanchor_selected_mass_max_relative"]) and controls
    )
    out={"schema":"cptg-r05-asymptotic-continuum-result-v1","decision":"PASS" if passed else "NOT_QUALIFIED",
         "production_refinement":256 if passed else None,
         "global_positive_64_128_max":global_p64_128,"global_positive_128_256_max":global_p128_256,
         "global_positive_effective_order":Pord,
         "global_BE_64_128_max":global_b64_128,"global_BE_128_256_max":global_b128_256,
         "global_BE_effective_order":Bord,
         "global_continuum_cross_scheme_max":global_cross,
         "global_positive256_to_Richardson_max":global_presid,
         "controls_pass":controls,"anchors":anchors,"native_freeze_sha256":sha_file(OUTPUT/"NATIVE_TRAJECTORY_FREEZE.json"),
         "prior_transport_outputs_imported":False}
    (EVIDENCE).mkdir(parents=True,exist_ok=True);atomic_json(EVIDENCE/"ASYMPTOTIC_CONTINUUM_QUALIFICATION_RESULT.json",out)
    print("R05_GLOBAL_POSITIVE_64_128",global_p64_128)
    print("R05_GLOBAL_POSITIVE_128_256",global_p128_256)
    print("R05_GLOBAL_POSITIVE_ORDER",Pord)
    print("R05_GLOBAL_BE_64_128",global_b64_128)
    print("R05_GLOBAL_BE_128_256",global_b128_256)
    print("R05_GLOBAL_BE_ORDER",Bord)
    print("R05_GLOBAL_CONTINUUM_CROSS",global_cross)
    print("R05_GLOBAL_POSITIVE256_RICHARDSON",global_presid)
    print("R05_PRODUCTION_REFINEMENT",256 if passed else None)
    print("R05_ASYMPTOTIC_CONTINUUM_QUALIFICATION","PASS" if passed else "NOT_QUALIFIED")
    if not passed:raise SystemExit(5)
if __name__=="__main__":main()
