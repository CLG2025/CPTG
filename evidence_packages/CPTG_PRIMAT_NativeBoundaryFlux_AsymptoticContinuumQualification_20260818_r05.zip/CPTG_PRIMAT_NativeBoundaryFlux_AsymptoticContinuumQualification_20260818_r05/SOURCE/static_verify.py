from __future__ import annotations
import json,hashlib,py_compile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def sha(p):
    h=hashlib.sha256();h.update(p.read_bytes());return h.hexdigest()
def ck(n,c):
    if not c:raise RuntimeError(n+" FAIL")
    print(n,"PASS")
def main():
    p=json.loads((ROOT/"CONFIG/FROZEN_ASYMPTOTIC_PREREGISTRATION.json").read_text())
    ck("R05_PRIOR_RESULTS_PRESERVED",p["prior_status"]["no_prior_result_reclassified"] is True)
    ck("FROZEN_NATIVE_ONLY",p["native_trajectory_authority"]["regeneration_allowed"] is False and p["native_trajectory_authority"]["required_freeze_sha256"]=="97fd7b4f4f4e7466be9e45be264e62faade5b55e80d415201ed4390405080f9a")
    ck("SCIENTIFIC_GRAPH_UNCHANGED",p["scientific_graph"]["same_as_r02_r04"] is True and p["scientific_graph"]["historical_postsilicon_numerical_inputs"]==0)
    ck("FRESH_GEOMETRIC_REFINEMENT",p["fresh_sequences"]["positive_exponential_substeps"]==[64,128,256] and p["fresh_sequences"]["backward_euler_substeps"]==[64,128,256])
    ck("RICHARDSON_FROZEN",p["continuum_estimator"]["method"].startswith("per-mass generalized Richardson"))
    g=p["hard_gates"]
    ck("STRICT_PRIMARY_FINE_GATE",g["positive_128_vs_256_allanchor_selected_mass_max_relative"]==0.005 and g["positive_richardson_256_residual_allanchor_selected_mass_max_relative"]==0.0025)
    ck("STRICT_CONTINUUM_CROSS_GATE",g["continuum_cross_scheme_allanchor_selected_mass_max_relative"]==0.005)
    r=(ROOT/"SOURCE/run_asymptotic_continuum.py").read_text()
    ck("NO_PRIOR_TRANSPORT_IMPORT","RESULTS/" not in r and "POSITIVE_STIFF_TRANSPORT_QUALIFICATION_RESULT" not in r)
    ck("TWO_RAW_POSITIVE_SCHEMES","solve_positive_exponential_inflow" in r and "solve_backward_euler" in r)
    ck("PER_MASS_RICHARDSON","def richardson_three" in r and "2.0**p" in r)
    a=(ROOT/"SOURCE/adopt_frozen_native_trajectories.py").read_text()
    ck("ROBUST_OUTPUT_DIR_CREATION",'(ROOT/"EVIDENCE").mkdir(parents=True,exist_ok=True)' in a)
    pys=sorted((ROOT/"SOURCE").glob("*.py"))
    for x in pys:py_compile.compile(str(x),doraise=True)
    print("PYTHON_COMPILE",f"{len(pys)}/{len(pys)}","PASS")
    bad=[];n=0
    for line in (ROOT/"MANIFEST.sha256").read_text().splitlines():
        if not line.strip():continue
        h,rel=line.split("  ",1);n+=1;q=ROOT/rel
        if not q.is_file() or sha(q)!=h:bad.append(rel)
    ck(f"PACKAGE_MANIFEST {n-len(bad)}/{n}",not bad)
    print("R05_ASYMPTOTIC_CONTINUUM_STATIC_VERIFY PASS")
if __name__=="__main__":main()
