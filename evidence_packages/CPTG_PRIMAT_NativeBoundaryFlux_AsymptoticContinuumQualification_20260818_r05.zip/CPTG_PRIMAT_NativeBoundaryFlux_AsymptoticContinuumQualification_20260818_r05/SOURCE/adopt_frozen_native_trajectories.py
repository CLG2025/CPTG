from __future__ import annotations
import hashlib,json,shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
SRC=Path(r"D:\Downloads\CPTG_PRIMAT_NativeBoundaryFlux_A1A119_FinalValidation_20260817_r02")
EXPECT="97fd7b4f4f4e7466be9e45be264e62faade5b55e80d415201ed4390405080f9a"
def sha(p):
    h=hashlib.sha256()
    with p.open("rb") as f:
        for b in iter(lambda:f.read(1048576),b""):h.update(b)
    return h.hexdigest()
def main():
    (ROOT/"EVIDENCE").mkdir(parents=True,exist_ok=True)
    (ROOT/"OUTPUT").mkdir(parents=True,exist_ok=True)
    fp=SRC/"OUTPUT/NATIVE_TRAJECTORY_FREEZE.json"
    if not fp.is_file() or sha(fp)!=EXPECT:raise RuntimeError("native freeze identity mismatch")
    fr=json.loads(fp.read_text(encoding="utf-8"))
    if fr.get("eta_count")!=6:raise RuntimeError("eta_count")
    n=0
    for rec in fr["files"]:
        s=SRC/rec["path"]
        if not s.is_file() or sha(s)!=rec["sha256"]:raise RuntimeError("source member mismatch "+rec["path"])
        d=ROOT/rec["path"];d.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(s,d)
        if sha(d)!=rec["sha256"]:raise RuntimeError("copy mismatch "+rec["path"])
        n+=1
    shutil.copy2(fp,ROOT/"OUTPUT/NATIVE_TRAJECTORY_FREEZE.json")
    out={"schema":"cptg-r05-native-adoption-v1","pass":True,"freeze_sha256":EXPECT,"files_copied":n,
         "native_regenerated":False,"r02_r03_r04_transport_outputs_imported":False}
    (ROOT/"EVIDENCE/NATIVE_TRAJECTORY_ADOPTION.json").write_text(json.dumps(out,indent=2,sort_keys=True)+"\n",encoding="utf-8")
    print("R05_FROZEN_NATIVE_TRAJECTORY_ADOPTION PASS")
    print("FREEZE_SHA256",EXPECT)
    print("NATIVE_TRAJECTORY_REGENERATED False")
    print("PRIOR_TRANSPORT_OUTPUTS_IMPORTED False")
if __name__=="__main__":main()
