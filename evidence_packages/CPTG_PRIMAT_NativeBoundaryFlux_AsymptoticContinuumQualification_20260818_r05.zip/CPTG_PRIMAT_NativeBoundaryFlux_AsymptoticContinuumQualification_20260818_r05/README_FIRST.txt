# PRIMAT Boundary-Flux Asymptotic Continuum Qualification — r05

The scientific graph and frozen PRIMAT trajectory authority remain unchanged.

```text
97fd7b4f4f4e7466be9e45be264e62faade5b55e80d415201ed4390405080f9a
```

r02, r03, and r04 retain their original failure/not-qualified decisions.

r05 performs fresh positive-exponential and backward-Euler sequences at:

```text
64, 128, 256 substeps
```

and compares independent generalized-Richardson continuum estimates on:

```text
A = 24, 28, 32, 40, 56, 80, 100, 119
```

## Windows

```cmd
cd /d D:\Downloads\CPTG_PRIMAT_NativeBoundaryFlux_AsymptoticContinuumQualification_20260818_r05
RUN_STATIC_VERIFY_WINDOWS.cmd
RUN_ADOPT_FROZEN_NATIVE_TRAJECTORIES_WINDOWS.cmd
RUN_TRANSPORT_SELFTEST_WINDOWS.cmd
RUN_ASYMPTOTIC_CONTINUUM_WINDOWS.cmd
```

Required adoption:

```text
R05_FROZEN_NATIVE_TRAJECTORY_ADOPTION PASS
FREEZE_SHA256 97fd7b4f4f4e7466be9e45be264e62faade5b55e80d415201ed4390405080f9a
NATIVE_TRAJECTORY_REGENERATED False
PRIOR_TRANSPORT_OUTPUTS_IMPORTED False
```

Selftest:

```text
R04_POSITIVE_TRANSPORT_CORE_SELFTEST PASS
```

Final result:

```text
R05_PRODUCTION_REFINEMENT 256
R05_ASYMPTOTIC_CONTINUUM_QUALIFICATION PASS
```

or a fail-closed `NOT_QUALIFIED`.

A PASS qualifies only the numerical resolution for the later final A=1–119 evidence run.
