# CPTG 2026 Helium Observational Addendum — Author-Approved Corrections 1 and 2 (2026-10-23)

**Scope:** This is a reproducible observational-comparison addendum. It does not rerun PRIMAT, estimate a new parameter, revise frozen CPTG theory, or re-open the original lithium-study scientific gates.

The figures show **one unchanged CPTG result** against three observational references: the original observational benchmark (0.245 +/- 0.003), LBT, and EMPRESS XV. The other archived calculation (standard-radiation calibration) appears only in the numerical table as historical background, not as a new theoretical or observational state.

## Immutable manuscript identification

This package contains the author-approved two-correction revision of the unchanged audit-locked source dated October 23, 2026. The original source remains preserved separately.
SHA-256 of this revised TeX master: `4df0fc3a24ad094a261f67e657512b4976e6ae9a4109ba45cf2a9697ea3075f4`.
SHA-256 of the previous audit lock: `d04b1e72c4cba7151f06d2c7e188d5871ca6740e493f18bc3a03a12a4b29cf74`.
This package supersedes the *contents* of the earlier Revision 6 evidence ZIP for source matching, but does not modify the earlier archive or the original upstream CPTG PRIMAT authority.
Two author-approved manuscript changes were applied: (1) the abstract quantifies the 87.93% reduction in absolute observation-normalized discrepancy from the original benchmark to LBT and correctly identifies the EMPRESS residual as outside 1 sigma but within 2 sigma; (2) the Figure 1 caption quotation mark was closed. The third audit suggestion, changing the evidence-availability filename, was explicitly not applied. No other manuscript text changed.

## Package layout

- `CPTG_Primordial_Helium_Observational_Addendum.tex`: revised editable LaTeX manuscript
- `CPTG_Primordial_Helium_Observational_Addendum.pdf`: compiled review manuscript; **not used as a figure**
- `figures/helium_observations_vs_frozen_CPTG.png`: one frozen CPTG result versus three observations (300 dpi)
- `figures/helium_signed_residuals_vs_frozen_CPTG.png`: observational sigma distances from that same frozen CPTG result (300 dpi)
- `frozen_helium.csv`: exact original, unchanged CPTG and same-baryon calibration source values
- `observational_helium.csv`: original and 2026 reference values with published errors
- `results.csv`: six signed/absolute sigma ratios at high arithmetic precision
- `reproduce_comparison.py`: standard-library-only calculation and six assertions
- `make_figures.py`: generate two PNG figures from the included CSVs (requires Matplotlib)
- `SOURCE_PROVENANCE.md`: source references, original artifact hash, authority hashes, chronology
- `verify_package.py`, `SHA256SUMS.txt`: content integrity verification

## Reproduction

From the extracted ZIP directory:

```bash
python reproduce_comparison.py
```

Expected output ends with `PASS: six signed helium residuals; both physical outputs held fixed`. Running it regenerates `results.csv`.

To regenerate the **PNG** figures if Matplotlib is installed:

```bash
python make_figures.py
```

To compile the TeX manuscript if `pdflatex` is installed:

```bash
pdflatex -interaction=nonstopmode -halt-on-error CPTG_Primordial_Helium_Observational_Addendum.tex
pdflatex -interaction=nonstopmode -halt-on-error CPTG_Primordial_Helium_Observational_Addendum.tex
```

Check extracted-file hashes before running scripts (the scripts rewrite outputs):

```bash
python verify_package.py
```

This archive is **not** the original PRIMAT authority. Full parent-network reproduction is separately documented in the cited CPTG lithium study.

## Recorded comparisons

| Observational reference | Previously archived calibration (sigma) | Previously frozen CPTG (sigma) |
|---|---:|---:|
| Original paper anchor | +0.591017 | +0.253416 |
| LBT 2026 | +0.748500 | -0.030579 |
| EMPRESS XV 2026 | +1.643263 | +1.390062 |

No values in `frozen_helium.csv` were adjusted to obtain these differences. The signed ratios use only reported observational uncertainties, not a new combined error model.

## Figure labeling carried forward from Revision 6

The two PNG figures explicitly identify the original observational benchmark, the frozen CPTG theoretical line, and the zero-residual agreement line. These are labeling-only changes: the frozen inputs and calculated residuals are unchanged.

## Figure 2 display clarification (2026-10-23)

The Figure 2 horizontal axis now extends to -1.15 so the entire pale -1 sigma to +1 sigma band is visible, as stated in the unchanged manuscript caption. No observational inputs, calculated residuals, figure labels, manuscript words, citations, or hyperlink styling have been changed. The first PNG figure is unchanged byte-for-byte.
