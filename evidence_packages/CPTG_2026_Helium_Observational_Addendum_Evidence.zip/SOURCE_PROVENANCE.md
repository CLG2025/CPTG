# Source provenance — CPTG 2026 helium observational addendum (approved two-correction version, 2026-10-23)


## Current manuscript authority (2026-10-23)

The current author-approved TeX source has SHA-256 `4df0fc3a24ad094a261f67e657512b4976e6ae9a4109ba45cf2a9697ea3075f4`; the original audit-locked uploaded source remains unchanged with SHA-256 `d04b1e72c4cba7151f06d2c7e188d5871ca6740e493f18bc3a03a12a4b29cf74`. Only approved abstract clarification/relative improvement and Figure 1 caption punctuation differ in the manuscript. The compiled PDF is generated from the current revised source. Neither hash represents the upstream PRIMAT authority.

## Earlier revision history (not current master)

The user-selected restored master was preserved and was **not overwritten**.
Its SHA-256 is:

`8b2f3b086fb919ee87e93ff73bffe0cc6e30b2d2edbe19d6306b0794c86277c3`

Revision 4 implements the requested editorial revisions: correction of PDF-vs-PNG description; a single, named ZIP containing addendum evidence; a primary focus on observational residuals; a concise original-authority appendix; unambiguous naming of both previously calculated states; removal of boxed math; and consistent display of rounded residuals in the main text. The original scientific input values were not changed.

## Original theoretical numerical inputs (unchanged)

Source: C. L. Glass Jr., *The Cosmological Lithium Problem and the CPTG Lithium Solution*, DOI https://doi.org/10.5281/zenodo.22420032

- Previously frozen CPTG PRIMAT gate-off helium mass fraction: `0.24576024693340703`
- Previously archived, same-baryon standard-radiation calibration helium mass fraction: `0.2467730506356945`
- The calibration and CPTG values are both *computed states of the original frozen experiment*, not two observational measurements and not newly fitted to either LBT or EMPRESS.

## Observational comparison coordinates

- Original paper's helium reference: `0.245 ± 0.003`; source DOI https://doi.org/10.5281/zenodo.22420032
- LBT 2026: `0.2458 ± 0.0013`; DOI https://doi.org/10.3847/1538-4357/ae879b ; preprint https://arxiv.org/abs/2601.22238
- EMPRESS XV 2026 *journal* determination: `0.2402 ± 0.0040`; DOI https://doi.org/10.3847/1538-4357/ae64fc ; https://arxiv.org/abs/2506.24050

The same `z = (Yp_calculated - Yp_observed) / sigma_observed` is applied to all six pairings. This is a standardization of differences, **not** a newly calculated nuclear-reaction-network outcome or a fit.

## Parent evidence authority — reference only

Upstream authority-lock SHA256 (as *published in parent paper*, not independently rehashed here):
`43b65036e229dc5f04d445f5890399236aaf546c598f1711e572043db6b05bec`

Upstream final-evidence SHA256 (as *published in parent paper*, not independently rehashed here):
`9c44543cd2497e72170c0a64173423c9b3bf2f1f3924c9d4e77c16a318fb8b4c`

Upstream packages: https://github.com/CLG2025/CPTG/tree/main/evidence_packages

The addendum ZIP contains everything to recompute its **new observational arithmetic and PNG figures**. It intentionally does not claim to package the entire native PRIMAT toolchain needed to repeat the parent 2026 nuclear experiment.

## Chronology

LBT publicly posted its preprint in January 2026, and EMPRESS's initial preprint was posted in June 2025; these precede the August 19, 2026 authority lock. The addendum therefore makes no claim that the observations were first made available *after* CPTG's August freeze. The new result is the October 2026 comparison against the unchanged archived numerical outputs.


## Figure clarification (Revision 5)
Both published PNG figures display one frozen CPTG gate-off helium output against the original and 2026 observational determinations. The archived standard-radiation calibration is retained in the table and source data for provenance but is not drawn as a second before/after state.

## Figure labeling (Revision 6)
The original observational benchmark is labelled with its published value 0.245 +/- 0.003; Figure 1 identifies the frozen CPTG calculation and Figure 2 identifies the exact-agreement zero line. No numerical or source changes.
