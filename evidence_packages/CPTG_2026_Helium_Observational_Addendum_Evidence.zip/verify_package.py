#!/usr/bin/env python3
"""Verify SHA-256 checksums of extracted package entries (before running replay scripts)."""
import hashlib
from pathlib import Path
P=Path(__file__).resolve().parent
records=(P/'SHA256SUMS.txt').read_text(encoding='utf8').splitlines()
for row in records:
    if not row.strip() or row.startswith('#'):
        continue
    digest,filename=row.split('  ',1)
    content=(P/filename).read_bytes()
    observed=hashlib.sha256(content).hexdigest()
    if observed!=digest:
        raise SystemExit('FAIL SHA256: '+filename)
    print('OK',filename)
print('PASS: '+str(sum(bool(r.strip()) and not r.startswith('#') for r in records))+' files')
