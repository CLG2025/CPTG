#!/usr/bin/env python3
"""Render publication PNG figures from immutable CPTG and observational CSV inputs.
No recalculation of the CPTG abundance or nuclear network is performed.
"""
import csv
from decimal import Decimal
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import MultipleLocator, FormatStrFormatter
from matplotlib.lines import Line2D

BASE=Path(__file__).resolve().parent
DEST=BASE/'figures'
DEST.mkdir(exist_ok=True)
with (BASE/'frozen_helium.csv').open(newline='',encoding='utf-8') as f:
    frozen={r['state']:Decimal(r['Yp']) for r in csv.DictReader(f)}
with (BASE/'observational_helium.csv').open(newline='',encoding='utf-8') as f:
    observed={r['reference']:(Decimal(r['Yp_observed']),Decimal(r['sigma_observed'])) for r in csv.DictReader(f)}
assert set(observed)=={'Original_anchor','LBT_2026','EMPRESS_XV_2026'}
assert frozen['CPTG_gate_off']==Decimal('0.24576024693340703')
LOCK=frozen['CPTG_gate_off']
keys=['Original_anchor','LBT_2026','EMPRESS_XV_2026']
labels=[r'Original observational benchmark'+'\n'+r'$(0.245 \pm 0.003)$','LBT (2026)','EMPRESS XV (2026)']
colors=['#626262','#148171','#a34b37']

# Figure 1: one theoretical value, three empirical references.
fig,ax=plt.subplots(figsize=(7.15,3.35))
for i,(k,c) in enumerate(zip(keys,colors)):
    y,s=observed[k]
    ax.errorbar(float(y),i,xerr=float(s),fmt='o',ms=6,capthick=1.25,capsize=4,
                color=c,ecolor=c,elinewidth=1.6,zorder=3)
ax.axvline(float(LOCK),color='#164c70',lw=2.0,zorder=1)
fig.legend(handles=[Line2D([0],[0],color='#164c70',linewidth=2.0)],
           labels=[r'Frozen CPTG calculation: $Y_p=0.245760247$'],
           loc='upper center', bbox_to_anchor=(.58,.962), frameon=False,
           fontsize=9.9,handlelength=2.7)
ax.set_yticks(range(3),labels)
ax.set_ylim(2.42,-0.42)
ax.set_xlim(0.234,0.250)
ax.set_xlabel(r'Primordial helium-4 mass fraction $Y_p$',fontsize=10)
ax.xaxis.set_major_locator(MultipleLocator(.002))
ax.xaxis.set_major_formatter(FormatStrFormatter('%.3f'))
ax.grid(axis='x',alpha=.18,zorder=0)
ax.tick_params(labelsize=9)
ax.spines[['top','right']].set_visible(False)
fig.subplots_adjust(left=.39,right=.975,bottom=.19,top=.77)
fig.savefig(DEST/'helium_observations_vs_frozen_CPTG.png',dpi=300)
plt.close(fig)

# Figure 2: observational differences, NOT a before/after theory recalculation.
fig,ax=plt.subplots(figsize=(7.15,3.35))
ax.axvspan(-1,1,color='#d8e1e6',alpha=.30,zorder=0)
ax.axvline(0,color='#4c4c4c',lw=1.25,zorder=1)
for i,(k,c) in enumerate(zip(keys,colors)):
    y,s=observed[k]
    z=float((LOCK-y)/s)
    ax.plot([0,z],[i,i],color=c,lw=1.7,zorder=2)
    ax.plot([z],[i],marker='o',markersize=7.5,color=c,zorder=3)
    ax.text(1.58,i,f'{z:+.6f}',color=c,fontsize=9.5,ha='left',va='center')
ax.set_yticks(range(3),labels)
ax.set_ylim(2.45,-0.45)
ax.set_xlim(-1.15,2.0)  # Display the complete shaded [-1, +1] sigma band
ax.set_xlabel(r'Signed residual $(Y_p^{\rm CPTG}-Y_p^{\rm obs})/\sigma_{\rm obs}$',fontsize=9.6)
ax.xaxis.set_major_locator(MultipleLocator(.5))
ax.grid(axis='x',alpha=.13,zorder=0)
ax.tick_params(labelsize=9)
ax.spines[['top','right']].set_visible(False)
fig.text(.62,.972,'Same frozen CPTG result; only the observation changes',
         ha='center',va='top',fontsize=9.3,color='#164c70')
fig.legend(handles=[Line2D([0],[0],color='#4c4c4c',linewidth=1.3)],
           labels=[r'Exact agreement ($0\sigma$)'],
           loc='upper center',bbox_to_anchor=(.62,.907),frameon=False,
           fontsize=9.4,handlelength=2.5)
fig.subplots_adjust(left=.39,right=.975,bottom=.19,top=.77)
fig.savefig(DEST/'helium_signed_residuals_vs_frozen_CPTG.png',dpi=300)
plt.close(fig)
print('PASS: two PNG figures, one immutable CPTG abundance, three observational references')
