#!/usr/bin/env python3
"""Reproduce the addendum's six archived-value/observational-reference residuals.

Standard library only. No nuclear-reaction simulation, theory parameter estimation,
or observational correction is executed.
"""
import csv
from decimal import Decimal, getcontext
from pathlib import Path
getcontext().prec = 40
P = Path(__file__).resolve().parent

def read_values():
    with (P / 'frozen_helium.csv').open(newline='', encoding='utf-8') as f:
        vals = {row['state']: Decimal(row['Yp']) for row in csv.DictReader(f)}
    required = {'standard_radiation_calibration','CPTG_gate_off'}
    if vals.keys() != required:
        raise ValueError('Unexpected or missing frozen input states')
    if vals['standard_radiation_calibration'] != Decimal('0.2467730506356945'):
        raise ValueError('Calibration source does not match frozen input registry')
    if vals['CPTG_gate_off'] != Decimal('0.24576024693340703'):
        raise ValueError('CPTG source does not match frozen input registry')
    return vals

def main():
    vals=read_values()
    with (P/'observational_helium.csv').open(newline='',encoding='utf-8') as f:
        observations=list(csv.DictReader(f))
    if [r['reference'] for r in observations] != ['Original_anchor','LBT_2026','EMPRESS_XV_2026']:
        raise ValueError('Unexpected observation list or ordering')
    results=[]
    for ref in observations:
        y=Decimal(ref['Yp_observed']);e=Decimal(ref['sigma_observed'])
        assert e>0
        for state, source in vals.items():
            z=(source-y)/e
            results.append({'reference':ref['reference'],'calculation_state':state,
                            'Yp_calculated':str(source),'Yp_observed':str(y),
                            'sigma_observed':str(e),'signed_z':format(z,'.12f'),
                            'absolute_z':format(abs(z),'.12f')})
    with (P/'results.csv').open('w',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,fieldnames=results[0].keys());writer.writeheader();writer.writerows(results)
    target={
      ('Original_anchor','standard_radiation_calibration'):'0.591016878565',
      ('Original_anchor','CPTG_gate_off'):'0.253415644469',
      ('LBT_2026','standard_radiation_calibration'):'0.748500488996',
      ('LBT_2026','CPTG_gate_off'):'-0.030579281995',
      ('EMPRESS_XV_2026','standard_radiation_calibration'):'1.643262658924',
      ('EMPRESS_XV_2026','CPTG_gate_off'):'1.390061733352',
    }
    for row in results:
        k=(row['reference'],row['calculation_state'])
        assert Decimal(row['signed_z']).quantize(Decimal('0.000000000001')) == Decimal(target[k]), k
        print(row['reference'], row['calculation_state'], row['signed_z'])
    print('PASS: six signed helium residuals; both physical outputs held fixed')

if __name__=='__main__':
    main()
