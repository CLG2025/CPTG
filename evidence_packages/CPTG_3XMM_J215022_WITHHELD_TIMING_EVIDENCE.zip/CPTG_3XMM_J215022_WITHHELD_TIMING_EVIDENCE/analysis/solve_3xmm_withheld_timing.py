#!/usr/bin/env python3
"""
Deterministic numerical solution for 3XMM J215022.4-055108.

The calculation uses:
  * the QPO-independent Guolo et al. inner-radius and mass marginals,
  * the Zhang et al. 85-s QPO centroid,
  * an explicitly declared first-order CPTG luminosity-coordinate sensitivity
    translation of the reported linear SED scale,
  * the LT-at-ISCO timing hypothesis in the retained Kerr exterior,
  * the registered CPTG compact mass-spin and structural readout relations.

The Monte Carlo block reconstructs only published one-dimensional summary
marginals. It is an overlap diagnostic, not a reconstruction of the unavailable
joint kerrSED posterior.
"""

from pathlib import Path
import math
import numpy as np
import pandas as pd
from scipy.optimize import brentq
from scipy.integrate import quad

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "results"
OUT.mkdir(parents=True, exist_ok=True)

# Physical constants
G = 6.67430e-11
C = 299792458.0
C_KM_S = C / 1000.0
M_SUN = 1.98847e30
RG_SUN_KM = G * M_SUN / C**2 / 1000.0

# Observational inputs
Z = 0.055
NU_OBS_MHZ = 11.88
SIG_NU_OBS_MHZ = 0.38
NU_SRC_MHZ = NU_OBS_MHZ * (1.0 + Z)
SIG_NU_SRC_MHZ = SIG_NU_OBS_MHZ * (1.0 + Z)

LOG_RIN = 5.24
LOG_RIN_MINUS = 0.05
LOG_RIN_PLUS = 0.13
LOG_M = 4.39
LOG_M_MINUS = 0.08
LOG_M_PLUS = 0.17

# External low-z decoder used only for the declared sensitivity translation.
H0_REF = 73.0
OMEGA_M_REF = 0.3
OMEGA_L_REF = 0.7

# Registered CPTG affine luminosity comparison coordinate.
H0_L_AFF = 73.1711530416
B_PI = 1.0 - 1.0 / math.pi
T_PI = 1.0 / math.pi


def e_ref(z):
    return math.sqrt(OMEGA_M_REF * (1.0 + z) ** 3 + OMEGA_L_REF)


def e_pi(z):
    return math.sqrt(B_PI + T_PI * (1.0 + z) ** math.pi)


D_REF_MPC = (1.0 + Z) * C_KM_S / H0_REF * quad(lambda zz: 1.0 / e_ref(zz), 0, Z)[0]
D_CPTG_MPC = (1.0 + Z) * C_KM_S / H0_L_AFF * quad(lambda zz: 1.0 / e_pi(zz), 0, Z)[0]
DISTANCE_SCALE = D_CPTG_MPC / D_REF_MPC


# Kerr exterior
def r_isco(q):
    z1 = 1.0 + (1.0 - q * q) ** (1.0 / 3.0) * (
        (1.0 + q) ** (1.0 / 3.0) + (1.0 - q) ** (1.0 / 3.0)
    )
    z2 = math.sqrt(3.0 * q * q + z1 * z1)
    return 3.0 + z2 - math.sqrt((3.0 - z1) * (3.0 + z1 + 2.0 * z2))


def nu_lt_hz(m_msun, q):
    rho = r_isco(q)
    omega_phi = 1.0 / (rho ** 1.5 + q)
    omega_theta = omega_phi * math.sqrt(
        1.0 - 4.0 * q / rho ** 1.5 + 3.0 * q * q / rho**2
    )
    return C**3 / (2.0 * math.pi * G * m_msun * M_SUN) * (omega_phi - omega_theta)


def q_from_radius_frequency(r_km, nu_hz):
    def residual(q):
        m_msun = r_km / (r_isco(q) * RG_SUN_KM)
        return nu_lt_hz(m_msun, q) - nu_hz
    return brentq(residual, 1.0e-8, 0.999999)


def q_from_mass_frequency(m_msun, nu_hz):
    return brentq(lambda q: nu_lt_hz(m_msun, q) - nu_hz, 1.0e-8, 0.999999)


# Registered CPTG compact state
def a_pol(q):
    return brentq(lambda a: q * q * a**3 + a - 2.0, 1.0, 2.0)


def F(x):
    return (63.0 * x**5 - 90.0 * x**7 + 35.0 * x**9) / 8.0


def c_prime(x):
    return (
        x**3
        * (
            8575.0 * x**10
            + 337050.0 * x**8
            - 1102950.0 * x**6
            + 1235160.0 * x**4
            - 566433.0 * x**2
            + 87318.0
        )
        / 32.0
    )


def weight(x):
    return abs(c_prime(x))


def xi(x, q):
    return (x * (x * x + q * q) / (1.0 + q * q)) ** (1.0 / 3.0)


def n_bh(q):
    den = quad(lambda x: weight(x), 0, 1, epsabs=1e-12, limit=200)[0]
    num = quad(lambda x: xi(x, q) * weight(x), 0, 1, epsabs=1e-12, limit=200)[0]
    return den / num


def x_n(q):
    n = n_bh(q)
    rhs = (1.0 + q * q) / n**3
    return brentq(lambda x: x * (x * x + q * q) - rhs, 1e-12, 1.0)


def delta(x, q):
    return x * x - 2.0 * x * F(x) + q * q


def x_minus(q):
    grid = np.linspace(1e-7, 1.0, 30000)
    vals = np.array([delta(x, q) for x in grid])
    idx = np.where(vals[:-1] * vals[1:] < 0)[0]
    if len(idx) == 0:
        return np.nan
    i = idx[0]
    return brentq(lambda x: delta(x, q), grid[i], grid[i + 1])


def sigma(x, theta, q):
    return x * x + q * q * math.cos(theta) ** 2


def a_d(x, theta, q):
    return (x * x + q * q) ** 2 - q * q * delta(x, q) * math.sin(theta) ** 2


def lapse(x, theta, q):
    return math.sqrt(delta(x, q) * sigma(x, theta, q) / a_d(x, theta, q))


def lapse_bar(x, q):
    num = quad(
        lambda th: lapse(x, th, q) * sigma(x, th, q) * math.sin(th),
        0, math.pi, epsabs=1e-11,
    )[0]
    den = quad(lambda th: sigma(x, th, q) * math.sin(th), 0, math.pi, epsabs=1e-11)[0]
    return num / den


def omega_hat(x, theta, q):
    return 2.0 * q * x * F(x) / a_d(x, theta, q)


def omega_hat_bar(x, q):
    num = quad(
        lambda th: omega_hat(x, th, q) * sigma(x, th, q) * math.sin(th),
        0, math.pi, epsabs=1e-11,
    )[0]
    den = quad(lambda th: sigma(x, th, q) * math.sin(th), 0, math.pi, epsabs=1e-11)[0]
    return num / den


# Central solution
RIN_PUBLISHED_KM = 10**LOG_RIN
RIN_SENSITIVITY_KM = RIN_PUBLISHED_KM * DISTANCE_SCALE

Q_PRIMARY = q_from_radius_frequency(RIN_SENSITIVITY_KM, NU_SRC_MHZ * 1e-3)
RHO_ISCO_PRIMARY = r_isco(Q_PRIMARY)
M_PRIMARY = RIN_SENSITIVITY_KM / (RHO_ISCO_PRIMARY * RG_SUN_KM)

A_PRIMARY = a_pol(Q_PRIMARY)
MC_PRIMARY = M_PRIMARY / A_PRIMARY
MGEOM_PRIMARY = M_PRIMARY - MC_PRIMARY
GEOM_FRAC_PRIMARY = MGEOM_PRIMARY / M_PRIMARY
AC_PRIMARY = A_PRIMARY**2 * Q_PRIMARY

RM_PRIMARY = RG_SUN_KM * M_PRIMARY
RPLUS_PRIMARY = RM_PRIMARY * (1.0 + math.sqrt(1.0 - Q_PRIMARY * Q_PRIMARY))
N_PRIMARY = n_bh(Q_PRIMARY)
XN_PRIMARY = x_n(Q_PRIMARY)
XMINUS_PRIMARY = x_minus(Q_PRIMARY)
RN_PRIMARY = XN_PRIMARY * RM_PRIMARY
RMINUS_PRIMARY = XMINUS_PRIMARY * RM_PRIMARY
T24_PRIMARY = 24.0 * lapse_bar(XN_PRIMARY, Q_PRIMARY)
OMEGA_PRIMARY = C / (RM_PRIMARY * 1000.0) * omega_hat_bar(XN_PRIMARY, Q_PRIMARY)

# Coordinate/timing sensitivity benchmarks
Q_PUB_SRC = q_from_radius_frequency(RIN_PUBLISHED_KM, NU_SRC_MHZ * 1e-3)
M_PUB_SRC = RIN_PUBLISHED_KM / (r_isco(Q_PUB_SRC) * RG_SUN_KM)
Q_PUB_OBS = q_from_radius_frequency(RIN_PUBLISHED_KM, NU_OBS_MHZ * 1e-3)
M_PUB_OBS = RIN_PUBLISHED_KM / (r_isco(Q_PUB_OBS) * RG_SUN_KM)

# Reverse mass-first consistency check
M_GUOLO_PUBLISHED = 10**LOG_M
M_GUOLO_SENSITIVITY = M_GUOLO_PUBLISHED * DISTANCE_SCALE
Q_REVERSE = q_from_mass_frequency(M_GUOLO_SENSITIVITY, NU_SRC_MHZ * 1e-3)
R_REVERSE = r_isco(Q_REVERSE) * RG_SUN_KM * M_GUOLO_SENSITIVITY

# Wen et al. branch discrimination
M_WEN = 1.75e4
Q_WEN = 0.8
NU_WEN_MHZ = nu_lt_hz(M_WEN, Q_WEN) * 1e3
Q_WEN_REQUIRED = q_from_mass_frequency(M_WEN, NU_SRC_MHZ * 1e-3)
NU_WEN_CORNER_MHZ = nu_lt_hz(2.2e4, 0.78) * 1e3

# Published-summary uncertainty reconstruction
rng = np.random.default_rng(20261006)
NMC = 300_000
left = rng.random(NMC) < 0.5
mag = np.abs(rng.normal(size=NMC))
log_r_draw = np.where(left, LOG_RIN - LOG_RIN_MINUS * mag, LOG_RIN + LOG_RIN_PLUS * mag)
r_pub_draw = 10**log_r_draw
r_sensitivity_draw = r_pub_draw * DISTANCE_SCALE

nu_obs_draw = np.clip(rng.normal(NU_OBS_MHZ, SIG_NU_OBS_MHZ, NMC), 1e-6, None)
nu_src_draw = nu_obs_draw * (1.0 + Z) * 1e-3

q_grid = np.linspace(1e-6, 0.999999, 160000)
r_grid = np.array([r_isco(float(q)) for q in q_grid])
op = 1.0 / (r_grid**1.5 + q_grid)
oth = op * np.sqrt(1.0 - 4.0 * q_grid / r_grid**1.5 + 3.0 * q_grid**2 / r_grid**2)
k_grid = C**3 / (2.0 * np.pi * G * M_SUN) * (op - oth)
j_grid = k_grid * r_grid * RG_SUN_KM

q_draw = np.interp(nu_src_draw * r_sensitivity_draw, j_grid, q_grid)
rho_draw = np.interp(q_draw, q_grid, r_grid)
m_draw = r_sensitivity_draw / (rho_draw * RG_SUN_KM)

a_draw = np.full_like(q_draw, 1.36)
for _ in range(14):
    a_draw -= (q_draw**2 * a_draw**3 + a_draw - 2.0) / (3.0 * q_draw**2 * a_draw**2 + 1.0)
mc_draw = m_draw / a_draw
mg_draw = m_draw - mc_draw
f_draw = mg_draw / m_draw
ac_draw = a_draw**2 * q_draw


def quantiles(x):
    return np.quantile(x, [0.16, 0.50, 0.84])


M_GUOLO_LO_SENSITIVITY = 10 ** (LOG_M - LOG_M_MINUS) * DISTANCE_SCALE
M_GUOLO_HI_SENSITIVITY = 10 ** (LOG_M + LOG_M_PLUS) * DISTANCE_SCALE
MASS_OVERLAP = np.mean((m_draw >= M_GUOLO_LO_SENSITIVITY) & (m_draw <= M_GUOLO_HI_SENSITIVITY))

summary = {
    "R_in_sensitivity_km": quantiles(r_sensitivity_draw),
    "nu_source_mHz": quantiles(nu_src_draw * 1e3),
    "q_exterior": quantiles(q_draw),
    "M_infinity_Msun": quantiles(m_draw),
    "rho_ISCO": quantiles(rho_draw),
    "A_pol": quantiles(a_draw),
    "M_c_Msun": quantiles(mc_draw),
    "M_geom_Msun": quantiles(mg_draw),
    "geom_fraction": quantiles(f_draw),
    "a_c": quantiles(ac_draw),
}

rows = [[name, *vals] for name, vals in summary.items()]
rows.extend([
    ["z", Z, Z, Z],
    ["D_ref_Mpc_assumed_flat_0p3_0p7", D_REF_MPC, D_REF_MPC, D_REF_MPC],
    ["D_CPTG_aff_Mpc", D_CPTG_MPC, D_CPTG_MPC, D_CPTG_MPC],
    ["distance_scale", DISTANCE_SCALE, DISTANCE_SCALE, DISTANCE_SCALE],
    ["Rin_published_km", RIN_PUBLISHED_KM, RIN_PUBLISHED_KM, RIN_PUBLISHED_KM],
    ["Rin_first_order_sensitivity_km", RIN_SENSITIVITY_KM, RIN_SENSITIVITY_KM, RIN_SENSITIVITY_KM],
    ["nu_obs_mHz", NU_OBS_MHZ, NU_OBS_MHZ, NU_OBS_MHZ],
    ["nu_source_mHz_exact", NU_SRC_MHZ, NU_SRC_MHZ, NU_SRC_MHZ],
    ["primary_q_exact", Q_PRIMARY, Q_PRIMARY, Q_PRIMARY],
    ["primary_M_infinity_Msun_exact", M_PRIMARY, M_PRIMARY, M_PRIMARY],
    ["primary_rho_ISCO_exact", RHO_ISCO_PRIMARY, RHO_ISCO_PRIMARY, RHO_ISCO_PRIMARY],
    ["primary_A_pol_exact", A_PRIMARY, A_PRIMARY, A_PRIMARY],
    ["primary_M_c_Msun_exact", MC_PRIMARY, MC_PRIMARY, MC_PRIMARY],
    ["primary_M_geom_Msun_exact", MGEOM_PRIMARY, MGEOM_PRIMARY, MGEOM_PRIMARY],
    ["primary_geom_fraction_exact", GEOM_FRAC_PRIMARY, GEOM_FRAC_PRIMARY, GEOM_FRAC_PRIMARY],
    ["primary_a_c_exact", AC_PRIMARY, AC_PRIMARY, AC_PRIMARY],
    ["primary_N_BH_exact", N_PRIMARY, N_PRIMARY, N_PRIMARY],
    ["primary_x_N_exact", XN_PRIMARY, XN_PRIMARY, XN_PRIMARY],
    ["primary_x_minus_exact", XMINUS_PRIMARY, XMINUS_PRIMARY, XMINUS_PRIMARY],
    ["primary_rN_km_exact", RN_PRIMARY, RN_PRIMARY, RN_PRIMARY],
    ["primary_rminus_km_exact", RMINUS_PRIMARY, RMINUS_PRIMARY, RMINUS_PRIMARY],
    ["primary_rm_km_exact", RM_PRIMARY, RM_PRIMARY, RM_PRIMARY],
    ["primary_rplus_km_exact", RPLUS_PRIMARY, RPLUS_PRIMARY, RPLUS_PRIMARY],
    ["primary_T24N_hours_exact", T24_PRIMARY, T24_PRIMARY, T24_PRIMARY],
    ["primary_omegaN_rad_s_exact", OMEGA_PRIMARY, OMEGA_PRIMARY, OMEGA_PRIMARY],
    ["published_radius_source_frame_q", Q_PUB_SRC, Q_PUB_SRC, Q_PUB_SRC],
    ["published_radius_source_frame_M_Msun", M_PUB_SRC, M_PUB_SRC, M_PUB_SRC],
    ["published_radius_observer_frame_q", Q_PUB_OBS, Q_PUB_OBS, Q_PUB_OBS],
    ["published_radius_observer_frame_M_Msun", M_PUB_OBS, M_PUB_OBS, M_PUB_OBS],
    ["reverse_sensitivity_mass_median_M_Msun", M_GUOLO_SENSITIVITY, M_GUOLO_SENSITIVITY, M_GUOLO_SENSITIVITY],
    ["reverse_q_exact", Q_REVERSE, Q_REVERSE, Q_REVERSE],
    ["reverse_RISCO_km_exact", R_REVERSE, R_REVERSE, R_REVERSE],
    ["summary_mass_overlap_with_sensitivity_Guolo_68pct", MASS_OVERLAP, MASS_OVERLAP, MASS_OVERLAP],
    ["Wen_central_LT_mHz", NU_WEN_MHZ, NU_WEN_MHZ, NU_WEN_MHZ],
    ["Wen_required_q_for_source_QPO", Q_WEN_REQUIRED, Q_WEN_REQUIRED, Q_WEN_REQUIRED],
    ["Wen_favorable_corner_LT_mHz", NU_WEN_CORNER_MHZ, NU_WEN_CORNER_MHZ, NU_WEN_CORNER_MHZ],
])

csv_path = OUT / "3XMM_WITHHELD_TIMING_RESULTS.csv"
pd.DataFrame(rows, columns=["quantity", "p16_or_value", "median_or_value", "p84_or_value"]).to_csv(csv_path, index=False)

print("Coordinate sensitivity")
print(f"D_ref = {D_REF_MPC:.9f} Mpc")
print(f"D_CPTG_aff = {D_CPTG_MPC:.9f} Mpc")
print(f"scale = {DISTANCE_SCALE:.12f}")
print(f"Rin published = {RIN_PUBLISHED_KM:.6f} km")
print(f"Rin first-order sensitivity = {RIN_SENSITIVITY_KM:.6f} km")
print("\nPrimary source-frame LT-at-ISCO closure")
print(f"q = {Q_PRIMARY:.12f}")
print(f"M_inf = {M_PRIMARY:.6f} Msun")
print(f"rho_ISCO = {RHO_ISCO_PRIMARY:.12f}")
print(f"A_pol = {A_PRIMARY:.12f}")
print(f"M_c = {MC_PRIMARY:.6f} Msun")
print(f"M_geom = {MGEOM_PRIMARY:.6f} Msun")
print(f"geom share = {100 * GEOM_FRAC_PRIMARY:.6f}%")
print(f"a_c = {AC_PRIMARY:.12f}")
print(f"N_BH = {N_PRIMARY:.12f}")
print(f"x_N = {XN_PRIMARY:.12f}; x_minus = {XMINUS_PRIMARY:.12f}")
print(f"r_N={RN_PRIMARY:.6f}, r_minus={RMINUS_PRIMARY:.6f}, r_m={RM_PRIMARY:.6f}, r_plus={RPLUS_PRIMARY:.6f}, R_ISCO={RIN_SENSITIVITY_KM:.6f} km")
print(f"T24,N={T24_PRIMARY:.9f} h; omega_N={OMEGA_PRIMARY:.9f} rad/s")
print(f"summary overlap diagnostic={MASS_OVERLAP:.6f}")
print(f"Wen central LT-at-ISCO={NU_WEN_MHZ:.6f} mHz")
print(f"Wen favorable corner LT-at-ISCO={NU_WEN_CORNER_MHZ:.6f} mHz")
print(f"wrote {csv_path.name}")
