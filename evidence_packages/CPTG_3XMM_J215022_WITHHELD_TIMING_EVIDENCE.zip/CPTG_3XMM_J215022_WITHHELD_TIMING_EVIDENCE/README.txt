CPTG 3XMM J215022.4-055108 WITHHELD-TIMING EVIDENCE

Purpose
-------
This archive contains only the material needed to reproduce the numerical test of 3XMM J215022.4-055108.

Calculation
-----------
1. Read the QPO-independent Guolo et al. inner-radius marginal.
2. Apply the declared first-order CPTG luminosity-coordinate sensitivity translation to the reported linear scale.
3. Convert the observed 11.88 +/- 0.38 mHz QPO centroid to the source frame using z = 0.055.
4. Under the explicit Lense-Thirring-at-ISCO hypothesis, solve the retained Kerr exterior for q and M_infinity.
5. Compare the solved exterior mass with the independently reported Guolo mass support.
6. Apply the registered CPTG compact relations only after the exterior state is fixed.
7. Evaluate the Wen et al. high-spin branch with the same timing operator as a branch-discrimination check.

Contents
--------
analysis/solve_3xmm_withheld_timing.py   exact deterministic solver
inputs/OBSERVATIONAL_INPUTS.txt          numerical observational inputs and source DOIs
inputs/CPTG_RELATIONS.txt                CPTG relations and source DOIs used by the solver
results/3XMM_WITHHELD_TIMING_RESULTS.csv numerical output
logs/RUN_LOG.txt                         stdout from a clean execution
REPRODUCE.txt                            reproduction command and expected central values
requirements.txt                         Python dependencies
MANIFEST.txt                             file list and purpose
checksums/SHA256SUMS.txt                 SHA-256 hashes

