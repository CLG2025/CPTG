# PRIMAT Publication Validation Protocol

## Scope

This bundle documents two accepted PRIMAT validation layers:

1. full-network numerical authority for the frozen 428-reaction, 20,550-row campaign;
2. first-order native source/Jacobian mechanism validation for 14 mapped light-sector reactions at six eta10 anchors.

## Full-network authority contract

The campaign contains six baseline rows plus every combination of:

- 428 native PRIMAT reactions;
- eta10 = 6.044, 6.080, 6.094, 6.106, 6.128, 6.134;
- rate powers = -2, -1.5, -1, -0.5, +0.5, +1, +1.5, +2.

Required checks are complete combinatorial coverage, frozen-ledger identity, hash-linked request/result/stdout/stderr integrity, empty stderr, attempt-1 completion, C-backend identity, PRIMAT 0.3.2 identity, finite standard outputs, finite positive 59-nuclide final states, complete plus/minus pairs, complete eight-branch ladders, and direct rate-key evidence covering every native reaction.

## Native mechanism contract

For each of 14 mapped reactions and each eta10 anchor, the isolated native PRIMAT reaction source is propagated through PRIMAT's analytic Jacobian with BDF and Radau.

All 84 predictions are written and SHA-256 frozen before the authoritative perturbed-endpoint coefficients are opened.

Frozen gates:

- baseline Python/C relative difference <= 5e-6;
- source-direction residual <= 1e-10;
- source baryon residual <= 1e-10;
- primary response norm >= 1e-3;
- BDF endpoint vector relative error <= 0.02;
- Radau endpoint vector relative error <= 0.02;
- endpoint direction cosine >= 0.999;
- BDF/Radau cross-relative difference <= 5e-4;
- BDF/Radau direction cosine >= 0.999999.

No perturbed endpoint coefficient is used to fit a variational prediction.

## Scope limit

The accepted result establishes PRIMAT-native first-order source-to-endpoint transport over the tested primordial interval and mapped light-sector set. Separate evidence is required for any broader numerical domain or higher-order claim.
