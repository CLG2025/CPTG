CPTG PRIMAT Paper-Ready Validation Evidence — 2026-08-17 r02

Purpose
-------
Clean publication-facing evidence for the accepted PRIMAT validation.

Start here
----------
1. PAPER_READY_VALIDATION_SUMMARY.md
2. VALIDATION_PROTOCOL.md
3. 03_PAPER_TABLES/PAPER_CLAIM_REGISTER.csv
4. RUN_VERIFY_WINDOWS.cmd

Evidence groups
---------------
01_FULL_NETWORK_AUTHORITY/
  Frozen 20,550-row ledger; direct row-integrity reconstruction; exact
  ledger/commit/request/result contract audit; direct rate-proof audit;
  preproduction backend qualification; authoritative baselines.

02_NATIVE_MECHANISM_VALIDATION/
  Frozen 84-row prediction record; durable prediction rows; six source audits;
  six baseline records; endpoint comparisons; direct independent audit; exact
  prediction/evaluation method source and configuration.

03_PAPER_TABLES/
  Compact publication-facing claims, baselines, eta summaries, reaction
  summaries, and a recommended validation statement.

Registered upstream archives
----------------------------
See SOURCE_ARCHIVE_REGISTER.csv for exact filenames and SHA-256 identifiers.

Windows verification
--------------------
cd /d D:\Downloads\CPTG_PRIMAT_PaperReadyValidationEvidence_20260817_r02
RUN_VERIFY_WINDOWS.cmd

Required final line:
PRIMAT_PAPER_READY_VALIDATION_EVIDENCE PASS
