# Recommended Validation Statement

A complete PRIMAT v0.3.2 large-network campaign evaluated 428 native reactions over six baryon-density anchors and eight nonzero perturbation branches, producing 20,550 committed rows, 10,272 matched plus/minus perturbation pairs, and 2,568 complete ladders. Independent reconstruction found zero ledger/commit/request/result identity discrepancies, zero row-hash discrepancies, zero nonempty stderr records, and finite positive 59-nuclide final states for every row. A separate six-anchor native source/Jacobian validation generated and SHA-256-froze 84 first-order endpoint predictions before reference exposure. Across 48 primary resolved reaction-anchor tests, the worst endpoint-vector discrepancy was 0.0003676287 (0.03676%) and the minimum direction cosine was 0.9999999921; source-direction residuals remained at approximately machine precision.

Use only within the scope stated in `VALIDATION_PROTOCOL.md`.
