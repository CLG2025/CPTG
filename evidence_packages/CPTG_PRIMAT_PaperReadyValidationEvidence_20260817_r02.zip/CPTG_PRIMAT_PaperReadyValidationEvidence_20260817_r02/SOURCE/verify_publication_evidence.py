from pathlib import Path
import csv,json,hashlib,re,math
import pandas as pd
import numpy as np

ROOT=Path(__file__).resolve().parents[1]

def sha256_file(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()

def check(name,cond,detail=''):
    if not cond:
        print(name,'ERROR',detail)
        raise SystemExit(2)
    print(name,'PASS',detail)

# Manifest.
n=0
for line in (ROOT/'MANIFEST.sha256').read_text(encoding='utf-8').splitlines():
    if not line.strip(): continue
    h,rel=line.split('  ',1); p=ROOT/rel; n+=1
    check('MANIFEST_ENTRY',p.exists() and sha256_file(p)==h,rel)
print('PACKAGE_MANIFEST',f'{n}/{n}','PASS')

# Full network direct data.
a=json.loads((ROOT/'01_FULL_NETWORK_AUTHORITY/FULL_NETWORK_AUTHORITY_SUMMARY.json').read_text())
c=json.loads((ROOT/'01_FULL_NETWORK_AUTHORITY/FULL_NETWORK_CONTRACT_AUDIT.json').read_text())
ledger=pd.read_csv(ROOT/'01_FULL_NETWORK_AUTHORITY/FROZEN_20550_ROW_LEDGER.csv')
ri=pd.read_csv(ROOT/'01_FULL_NETWORK_AUTHORITY/FULL_NETWORK_ROW_INTEGRITY.csv')
rp=pd.read_csv(ROOT/'01_FULL_NETWORK_AUTHORITY/DIRECT_RATE_PROOF_AUDIT.csv')
q=json.loads((ROOT/'01_FULL_NETWORK_AUTHORITY/PREPRODUCTION_BACKEND_QUALIFICATION.json').read_text())

check('FULL_NETWORK_DECISION',a['decision']=='PASS' and c['decision']=='PASS')
check('FULL_NETWORK_ROWS',len(ledger)==20550 and ledger.run_id.nunique()==20550 and ledger.row_key.nunique()==20550)
check('FULL_NETWORK_COMBINATORICS',
      int((ledger.role=='BASELINE').sum())==6 and int((ledger.role!='BASELINE').sum())==20544
      and ledger.loc[ledger.role!='BASELINE','reaction'].nunique()==428
      and ledger.eta10.nunique()==6
      and ledger.loc[ledger.role!='BASELINE','rate_power'].nunique()==8)
sizes=ledger[ledger.role!='BASELINE'].groupby(['reaction','eta10']).size()
check('FULL_NETWORK_LADDERS',len(sizes)==2568 and bool((sizes==8).all()) and c['complete_eight_branch_ladders']==2568)
check('FULL_NETWORK_PAIRS',c['matched_plus_minus_pairs']==10272)
check('FULL_NETWORK_CONTRACT_IDENTITY',c['ledger_commit_request_result_identity_issues']==0 and c['request_result_field_mismatches']==0)
check('FULL_NETWORK_RATE_FACTOR',c['max_abs_rate_factor_minus_exp_neg_x']<=5e-15 and c['max_abs_primat_delta_minus_rate_factor_minus_one']<=5e-15)
check('FULL_NETWORK_ROW_INTEGRITY',len(ri)==20550 and bool(ri[['request_hash_match','result_hash_match','stdout_hash_match','stderr_hash_match']].all().all()))
check('FULL_NETWORK_STDERR',bool(ri.stderr_empty.all()))
check('FULL_NETWORK_ATTEMPT1',bool((ri.attempt==1).all()))
check('FULL_NETWORK_RUNTIME_ID',set(ri.backend)=={'c'} and set(ri.primat_version.astype(str))=={'0.3.2'})
check('FULL_NETWORK_OUTPUTS',bool(ri[['standard_outputs_finite','y_final_finite','y_final_positive']].all().all()) and set(ri.y_final_count)=={59})
check('DIRECT_RATE_PROOFS',len(rp)==856 and rp.reaction.nunique()==428 and bool(rp.key_matches_reaction.all()) and bool(rp.samples_all_finite.all()) and set(rp.n_points)=={64} and set(rp.sample_count)=={5})
check('PREPRODUCTION_QUALIFICATION',q['decision']=='PRIMAT_FULL428_QUALIFICATION_PASS' and max(q['c_python_relative_differences'].values())<=5e-6)

# Mechanism method chronology.
ma=json.loads((ROOT/'02_NATIVE_MECHANISM_VALIDATION/METHOD_SOURCE_AUDIT.json').read_text())
check('METHOD_SOURCE_AUDIT',
      ma['decision']=='PASS'
      and not ma['prediction_source_contains_authoritative_c1_reference']
      and not ma['prediction_source_contains_endpoint_comparison_filename']
      and ma['evaluator_requires_prediction_freeze']
      and ma['evaluator_reference_open_occurs_after_freeze_check']
      and ma['prediction_uses_native_jacobian']
      and ma['prediction_uses_native_rhs']
      and ma['prediction_requires_BDF']
      and ma['prediction_requires_Radau']
      and not ma['endpoint_fit_functions_present'])

# Mechanism direct evidence.
m=json.loads((ROOT/'02_NATIVE_MECHANISM_VALIDATION/INDEPENDENT_MECHANISM_AUDIT.json').read_text())
v=json.loads((ROOT/'02_NATIVE_MECHANISM_VALIDATION/SIXANCHOR_VALIDATION_RESULT.json').read_text())
f=json.loads((ROOT/'02_NATIVE_MECHANISM_VALIDATION/PREDICTION_FREEZE.json').read_text())
predp=ROOT/'02_NATIVE_MECHANISM_VALIDATION/SIXANCHOR_VARIATIONAL_PREDICTIONS_PRE_REFERENCE.csv'
pred_bytes=predp.read_bytes()
pred=pd.read_csv(predp)
comp=pd.read_csv(ROOT/'02_NATIVE_MECHANISM_VALIDATION/SIXANCHOR_VARIATIONAL_C1_COMPARISON.csv')
check('MECHANISM_DECISION',v['decision']=='PASS' and m['decision']=='PASS')
check('PREDICTION_FREEZE',len(pred)==84 and hashlib.sha256(pred_bytes).hexdigest()==f['sha256']==m['prediction_freeze_sha256_recomputed'] and f['perturbed_endpoint_reference_opened'] is False)
check('DURABLE_PREDICTIONS',len(list((ROOT/'02_NATIVE_MECHANISM_VALIDATION/DURABLE_PREDICTIONS').glob('*.json')))==84 and m['durable_rows_exactly_match_frozen_csv'])
primary=comp[comp.reference_norm>=1e-3]
secondary=comp[comp.reference_norm>=1e-4]
check('PRIMARY_RESOLVED',len(primary)==48)
check('SECONDARY_REPORTING',len(secondary)==66)
worst=max(primary.BDF_vector_relative_error.max(),primary.Radau_vector_relative_error.max())
mincos=min(primary.BDF_direction_cosine.min(),primary.Radau_direction_cosine.min())
check('PRIMARY_VECTOR_GATE',worst<=0.02 and abs(worst-m['max_primary_vector_relative_error_either_solver'])<1e-15)
check('PRIMARY_COSINE_GATE',mincos>=0.999 and abs(mincos-m['min_primary_direction_cosine_either_solver'])<1e-15)
check('CROSS_SOLVER_GATES',primary.BDF_Radau_vector_relative_difference.max()<=5e-4 and primary.BDF_Radau_direction_cosine.min()>=0.999999)

src=pd.concat([pd.read_csv(p) for p in sorted((ROOT/'02_NATIVE_MECHANISM_VALIDATION/SOURCE_AUDITS').glob('*.csv'))],ignore_index=True)
active=src[src.active.astype(bool)]
check('SOURCE_AUDITS',len(src)==6336 and len(active)==6283 and active.relative_source_direction_residual.max()<=1e-10 and active.baryon_relative_residual.max()<=1e-10)

vals=[]
bfiles=sorted((ROOT/'02_NATIVE_MECHANISM_VALIDATION/BASELINES').glob('BASELINE_ETA*.json'))
for p in bfiles:
    d=json.loads(p.read_text())
    vals.extend(float(x) for x in d['relative_differences'].values())
check('BASELINE_AUDIT',len(bfiles)==6 and len(vals)==24 and max(vals)<=5e-6 and abs(max(vals)-m['baseline_max_relative'])<1e-18)

# Paper claim file paths all exist.
claims=pd.read_csv(ROOT/'03_PAPER_TABLES/PAPER_CLAIM_REGISTER.csv')
check('PAPER_CLAIM_EVIDENCE_PATHS',all((ROOT/p).exists() for p in claims.evidence_file))

# Publication narrative hygiene. Raw scientific evidence and exact method source are excluded.
narrative=[
 ROOT/'README.txt', ROOT/'PACKAGE_METADATA.json', ROOT/'PAPER_READY_VALIDATION_SUMMARY.md',
 ROOT/'VALIDATION_PROTOCOL.md', ROOT/'SOURCE_ARCHIVE_REGISTER.csv',
 ROOT/'03_PAPER_TABLES/PAPER_CLAIM_REGISTER.csv',
 ROOT/'03_PAPER_TABLES/RECOMMENDED_VALIDATION_STATEMENT.md'
]
pat=re.compile(r'(?i)\b(failed|failure|refusal|supersed(?:e|ed|ing)|retired|invalid|incorrect|misimplementation|improper|forensic|debugging)\b|0/6')
hits=[]
for p in narrative:
    for i,line in enumerate(p.read_text(encoding='utf-8').splitlines(),1):
        if pat.search(line): hits.append((p.name,i,line))
check('PUBLICATION_NARRATIVE_HYGIENE',len(hits)==0,str(hits[:3]))

print('PRIMAT_PAPER_READY_VALIDATION_EVIDENCE PASS')
