from __future__ import annotations
import csv,json,os,time,importlib.metadata
from pathlib import Path
import numpy as np
from common import *

def load_baseline_refs():
    with open(REFERENCE/'AUTHORITATIVE_BASELINES_ALL6.csv',newline='',encoding='utf-8') as f:
        return {float(r['eta10']):r for r in csv.DictReader(f)}

def main():
    if importlib.metadata.version('primat')!='0.3.2':raise RuntimeError('PRIMAT 0.3.2 required')
    from primat.config import PRIMATConfig
    from primat.main import PRIMAT
    import primat.nuclear_network as nnmod

    targets=load_targets(); etas=load_etas(); base_refs=load_baseline_refs()
    sh=runtime_source_hashes()
    pred_dir=WORK/'PREDICTION_ROWS'; pred_dir.mkdir(parents=True,exist_ok=True)
    source_dir=WORK/'SOURCE_AUDITS'; source_dir.mkdir(parents=True,exist_ok=True)
    baseline_records=[]

    for ei,ETA10 in enumerate(etas,1):
        c_hash=contract_hash(ETA10,sh)
        complete=True
        for tr in targets:
            rp=pred_dir/f"eta{ETA10:.3f}_{tr['primat_reaction']}.json"
            if not rp.exists():
                complete=False; break
            try:
                rr=json.loads(rp.read_text(encoding='utf-8'))
                if rr.get('contract_hash')!=c_hash: complete=False; break
            except Exception: complete=False; break
        bpath=WORK/f"BASELINE_ETA{ETA10:.3f}.json"
        spath=source_dir/f"SOURCE_AUDIT_ETA{ETA10:.3f}.csv"
        if complete and bpath.exists() and spath.exists():
            print(f'PRIMAT_SIXANCHOR_REUSE eta10={ETA10} 14/14',flush=True)
            baseline_records.append(json.loads(bpath.read_text(encoding='utf-8')))
            continue

        probe=PRIMATConfig({'Omegabh2':0.02242})
        omega=(ETA10*1e-10)/float(probe.Omegabh2_to_eta0b)
        params={
          'Omegabh2':omega,'network':'large','amax':None,'strict_params':True,
          'numerical_precision':1e-10,'atol_large_LT':1e-26,'rate_grid_npts':4000,'rate_grid_T9_min':1e-3,'rate_grid_T9_max':10.0,
          'radiative_corrections':True,'finite_mass_corrections':True,'thermal_corrections':True,
          'spectral_distortions':True,'tau_n_normalization':True,'tau_n':878.4,'nuclear_qed_corrections':True,
          'mc_rate_rescale_cap':None,'cache_dir':str(Path(os.environ.get('CPTG_PRIMAT_CACHE',r'D:\Downloads\PRIMAT_v0.3.2\cache'))),
          'output_time_evolution':False,'output_rates_time_evolution':False,'output_file':None,
          'verbose':False,'show_progress':False,'rescale_nuclear_rates':False}

        captured=[]
        original=nnmod.solve_ivp
        def capture(fun,t_span,y0,*args,**kwargs):
            kw=dict(kwargs);kw['dense_output']=True
            sol=original(fun,t_span,y0,*args,**kw)
            captured.append({'method':kw.get('method','RK45'),'rtol':kw.get('rtol'),'atol':kw.get('atol'),'sol':sol})
            return sol
        nnmod.solve_ivp=capture
        t0=time.perf_counter()
        try:
            P=PRIMAT(params=params); result=P.solve(progress=False)
        finally:
            nnmod.solve_ivp=original
        base_seconds=time.perf_counter()-t0
        if len(captured)!=3 or [x['method'] for x in captured]!=['LSODA','BDF','BDF']:raise RuntimeError('unexpected baseline solver sequence')
        capHT,capMT,capLT=captured; solMT=capMT['sol'];solLT=capLT['sol']
        if not (solMT.success and solLT.success and solMT.sol is not None and solLT.sol is not None):raise RuntimeError('baseline dense solve failed')

        bref=base_refs[ETA10]
        brel={k:abs(float(result[k])-float(bref[k]))/max(abs(float(bref[k])),1e-300) for k in ('DoH','He3oH','Li7oH','YPBBN')}
        if max(brel.values())>5e-6:raise RuntimeError(f'baseline authority mismatch eta={ETA10}: {brel}')
        brec={'eta10':ETA10,'contract_hash':c_hash,'seconds':base_seconds,'relative_differences':brel}
        atomic_json(bpath,brec); baseline_records.append(brec)

        nucl=P.nucl; bg=P.background; cfg=P.cfg
        mt_net=nucl._mt_net;lt_net=nucl._lt_net;Kmt=nucl._K_MT;Klt=nucl._K_LT
        mt_names=list(mt_net.species);lt_names=list(lt_net.species)
        mt_ix={n:i for i,n in enumerate(mt_names)};lt_ix={n:i for i,n in enumerate(lt_names)}
        _,t_weak,t_nucl,t_end=P.nuclear._era_boundaries()
        mt_scale=natural_tangent_scale(solMT,capMT['rtol'],capMT['atol'])
        lt_scale=natural_tangent_scale(solLT,capLT['rtol'],capLT['atol'])

        def env(t):
            return float(bg.T_of_t(t))*cfg.MeV_to_Kelvin,float(bg.rhoB_BBN(t)),bg.weak_nTOp_frwrd,bg.weak_nTOp_bkwrd
        def era_coeff(era,t,reaction):
            if era=='MT':Y=np.asarray(solMT.sol(t),float);net=mt_net;K=Kmt;names=mt_names;clamp=False
            else:Y=np.asarray(solLT.sol(t),float);net=lt_net;K=Klt;names=lt_names;clamp=True
            T_K,rho,wf,wb=env(t);r=np.asarray(net.fill_buffer(T_K,wf,wb,clamp=clamp),float).copy()
            J=np.asarray(K.jacobian(Y,rho,r),float)
            if reaction not in net.names:b=np.zeros_like(Y)
            else:
                idx=net.names.index(reaction)
                if idx==0:raise RuntimeError('weak reaction outside diagnostic')
                j=idx-1;ro=np.zeros_like(r);ro[2+2*j]=r[2+2*j];ro[3+2*j]=r[3+2*j]
                b=np.asarray(K.rhs(Y,rho,ro),float)
            return J,b

        # Native source identity audit for this eta.
        source_rows=[]
        for tr in targets:
            rx=tr['primat_reaction'];s=tr['s']
            for era,sol,names,net in [('MT',solMT,mt_names,mt_net),('LT',solLT,lt_names,lt_net)]:
                if rx not in net.names:continue
                ts=np.asarray(sol.t,float);pick=np.unique(np.linspace(0,len(ts)-1,min(48,len(ts)),dtype=int))
                for ii in pick:
                    tt=float(ts[ii]);_,b=era_coeff(era,tt,rx);qv,bary=source_coordinate(b,names)
                    qnorm=float(np.linalg.norm(qv));bnorm=float(np.linalg.norm(b))
                    amp=float(np.dot(qv,s)/np.dot(s,s));res=float(np.linalg.norm(qv-amp*s))
                    active=qnorm>1e-30
                    source_rows.append({'eta10':ETA10,'reaction':rx,'primat_index':tr['primat_index'],'era':era,'t_s':tt,
                      'q_norm':qnorm,'amplitude':amp,'relative_source_direction_residual':res/max(qnorm,1e-300) if active else 0.0,
                      'baryon_residual':float(bary),'baryon_relative_residual':abs(float(bary))/max(bnorm,1e-300) if bnorm>1e-30 else 0.0,'active':active})
        active=[r for r in source_rows if r['active']]
        if max((r['relative_source_direction_residual'] for r in active),default=0)>1e-10:raise RuntimeError('source direction gate')
        if max((r['baryon_relative_residual'] for r in active),default=0)>1e-10:raise RuntimeError('source baryon gate')
        with open(spath,'w',newline='',encoding='utf-8') as f:
            w=csv.DictWriter(f,fieldnames=list(source_rows[0]));w.writeheader();w.writerows(source_rows)

        yfinal=np.asarray(solLT.y[:,-1],float)
        def propagate(rx,method):
            cm={}
            def coeff_m(t):
                k=float(t)
                if k not in cm:
                    J,b=era_coeff('MT',k,rx);cm[k]=(J,-b)
                return cm[k]
            sm,zmt=scaled_linear_solve(coeff_m,t_weak,t_nucl,np.zeros(len(mt_names)),mt_scale,method)
            if not sm.success:return None,'MT',sm.message
            z0=np.zeros(len(lt_names))
            for nm,i in mt_ix.items():
                if nm in lt_ix:z0[lt_ix[nm]]=zmt[i]
            cl={}
            def coeff_l(t):
                k=float(t)
                if k not in cl:
                    J,b=era_coeff('LT',k,rx);cl[k]=(J,-b)
                return cl[k]
            sl,zlt=scaled_linear_solve(coeff_l,t_nucl,t_end,z0,lt_scale,method)
            if not sl.success:return None,'LT',sl.message
            return {'c1':endpoint_c1(zlt,yfinal,lt_names),'MT':sm,'LT':sl},None,None

        for ri,tr in enumerate(targets,1):
            rx=tr['primat_reaction'];rp=pred_dir/f"eta{ETA10:.3f}_{rx}.json"
            if rp.exists():
                try:
                    old=json.loads(rp.read_text(encoding='utf-8'))
                    if old.get('contract_hash')==c_hash:
                        print(f'PRIMAT_SIXANCHOR_ROW_REUSE eta={ETA10} {ri}/14 {rx}',flush=True);continue
                except Exception:pass
            rr0=time.perf_counter()
            bdf,era,msg=propagate(rx,'BDF')
            if bdf is None:
                atomic_json(OUTPUT/'NUMERICAL_REFUSAL.json',{'eta10':ETA10,'reaction':rx,'method':'BDF','era':era,'message':str(msg),'production_effect':'NONE'})
                print('PRIMAT_SIXANCHOR_NUMERICAL_REFUSAL',ETA10,rx,'BDF',era,msg);raise SystemExit(3)
            rad,era,msg=propagate(rx,'Radau')
            if rad is None:
                atomic_json(OUTPUT/'NUMERICAL_REFUSAL.json',{'eta10':ETA10,'reaction':rx,'method':'Radau','era':era,'message':str(msg),'production_effect':'NONE'})
                print('PRIMAT_SIXANCHOR_NUMERICAL_REFUSAL',ETA10,rx,'Radau',era,msg);raise SystemExit(3)
            cb=np.asarray(bdf['c1']);cr=np.asarray(rad['c1'])
            row={'schema':'cptg-primat-sixanchor-prediction-row-v1','contract_hash':c_hash,'eta10':ETA10,
              'reaction':rx,'primat_index':tr['primat_index'],'legacy_reaction':tr['legacy_reaction'],'partition':tr['partition'],
              'BDF_c1_D_H':float(cb[0]),'BDF_c1_He3_H':float(cb[1]),'BDF_c1_Li7_H':float(cb[2]),
              'Radau_c1_D_H':float(cr[0]),'Radau_c1_He3_H':float(cr[1]),'Radau_c1_Li7_H':float(cr[2]),
              'BDF_Radau_vector_relative_difference':vec_rel(cb,cr),'BDF_Radau_direction_cosine':vec_cos(cb,cr),
              'BDF_MT_nfev':int(bdf['MT'].nfev),'BDF_LT_nfev':int(bdf['LT'].nfev),
              'Radau_MT_nfev':int(rad['MT'].nfev),'Radau_LT_nfev':int(rad['LT'].nfev),
              'elapsed_seconds':time.perf_counter()-rr0}
            atomic_json(rp,row)
            print(f"PRIMAT_SIXANCHOR_PREDICTION eta={ETA10} {ri}/14 {rx} CROSSREL={row['BDF_Radau_vector_relative_difference']:.6g} CROSSCOS={row['BDF_Radau_direction_cosine']:.12g}",flush=True)

    # Assemble/freeze all 84 predictions. This script never opens the perturbed-endpoint c1 reference.
    rows=[]
    for ETA10 in etas:
        c_hash=contract_hash(ETA10,sh)
        for tr in targets:
            rp=pred_dir/f"eta{ETA10:.3f}_{tr['primat_reaction']}.json"
            if not rp.exists():raise RuntimeError('missing prediction row '+str(rp))
            r=json.loads(rp.read_text(encoding='utf-8'))
            if r.get('contract_hash')!=c_hash:raise RuntimeError('row contract mismatch '+str(rp))
            rows.append(r)
    fields=[k for k in rows[0].keys() if k not in ('schema','contract_hash')]
    out=OUTPUT/'SIXANCHOR_VARIATIONAL_PREDICTIONS_PRE_REFERENCE.csv'
    with open(out,'w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows([{k:r[k] for k in fields} for r in rows])
    fr={'schema':'cptg-primat-sixanchor-prediction-freeze-v1','prediction_rows':len(rows),'sha256':sha256_file(out),
        'eta10_anchors':etas,'runtime_source_hashes':sh,'production_effect':'NONE','perturbed_endpoint_reference_opened':False}
    atomic_json(OUTPUT/'PREDICTION_FREEZE.json',fr)
    print('PRIMAT_SIXANCHOR_PREDICTIONS_FROZEN',fr['sha256'])
    print('PREDICTION_ROWS',len(rows),'/84')
    print('PERTURBED_ENDPOINT_REFERENCE_OPENED False')
    print('PRODUCTION_EFFECT NONE')

if __name__=='__main__':main()
