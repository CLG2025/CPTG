from __future__ import annotations
import csv,math,sys
from pathlib import Path
import numpy as np
from scipy.integrate import solve_ivp
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'SOURCE'))
from common import source_coordinate,endpoint_c1,natural_tangent_scale,scaled_linear_solve
def ck(n,c):
    if not c:raise AssertionError(n)
    print('PRIMAT_SIXANCHOR_SELFTEST',n,'PASS')
names=['n','p','H2','H3','He3','He4']
cases={
'n_p__d_g':([-1,-1,1,0,0,0],[2,0,0,0]),'d_n__t_g':([-1,0,-1,1,0,0],[1,3,0,1]),
'He3_n__a_g':([-1,0,0,0,-1,1],[1,1,4,1]),'He3_n__t_p':([-1,1,0,1,-1,0],[0,0,0,2]),
'd_p__He3_g':([0,-1,-1,0,1,0],[1,3,0,-1]),'t_p__a_g':([0,-1,0,-1,0,1],[1,1,4,-1]),
'd_d__He3_n':([1,0,-2,0,1,0],[-1,3,0,-1]),'d_d__t_p':([0,1,-2,1,0,0],[-1,3,0,1]),
't_d__a_n':([1,0,-1,-1,0,1],[-1,1,4,-1]),'He3_d__a_p':([0,1,-1,0,-1,1],[-1,1,4,1]),
'He3_He3__a_p_p':([0,2,0,0,-2,1],[-2,-2,4,2]),'He3_t__a_d':([0,0,1,-1,-1,1],[0,-2,4,0]),
't_t__a_n_n':([2,0,0,-2,0,1],[-2,-2,4,-2]),'He3_t__a_n_p':([1,1,0,-1,-1,1],[-2,-2,4,0])}
for rx,(v,s) in cases.items():
    q,b=source_coordinate(np.array(v,float),names);ck('source_'+rx,np.allclose(q,s,rtol=0,atol=1e-14) and abs(b)<1e-14)
A=np.array([[-4e3,2e3],[1e-3,-2.0]]);g=np.array([1e2,-3e-9])
def coeff(t):return A,g
z0=np.zeros(2)
s1,z1=scaled_linear_solve(coeff,1234567,1234567.02,z0,np.array([1.0,1e-10]),'BDF',rtol=1e-10,atol_u=1e-12)
s2,z2=scaled_linear_solve(coeff,1234567,1234567.02,z0,np.array([1.0,1e-10]),'Radau',rtol=1e-10,atol_u=1e-12)
ck('scaled_BDF_success',s1.success);ck('scaled_Radau_success',s2.success)
ck('scaled_cross_agreement',np.linalg.norm(z1-z2)/max(np.linalg.norm(z2),1e-30)<2e-8)
with open(ROOT/'CONFIG'/'ETA_ANCHORS.csv',newline='',encoding='utf-8') as f:etas=[float(r['eta10']) for r in csv.DictReader(f)]
ck('six_etas',etas==[6.044,6.08,6.094,6.106,6.128,6.134])
with open(ROOT/'REFERENCE'/'AUTHORITATIVE_C1_ALL6.csv',newline='',encoding='utf-8') as f:refs=list(csv.DictReader(f))
ck('reference_84_unique',len(refs)==84 and len({(r['eta10'],r['primat_reaction']) for r in refs})==84)
print('PRIMAT_SIXANCHOR_SELFTEST PASS')
