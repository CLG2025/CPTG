from __future__ import annotations
import csv, json, math, os, time, hashlib, importlib.metadata, inspect
from pathlib import Path
import numpy as np
from scipy.integrate import solve_ivp as scipy_solve_ivp

ROOT=Path(__file__).resolve().parents[1]
CONFIG=ROOT/'CONFIG'; REFERENCE=ROOT/'REFERENCE'; WORK=ROOT/'WORK'; OUTPUT=ROOT/'OUTPUT'
WORK.mkdir(exist_ok=True); OUTPUT.mkdir(exist_ok=True)

def atomic_json(path:Path,obj):
    path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix(path.suffix+'.tmp')
    with open(tmp,'w',encoding='utf-8',newline='\n') as f:
        json.dump(obj,f,sort_keys=True,indent=2); f.write('\n'); f.flush(); os.fsync(f.fileno())
    os.replace(tmp,path)

def sha256_file(path:Path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()

def load_targets():
    with open(CONFIG/'TARGET_14_REACTIONS.csv',newline='',encoding='utf-8') as f: rows=list(csv.DictReader(f))
    for r in rows:
        r['primat_index']=int(r['primat_index']); r['legacy_reaction']=int(r['legacy_reaction'])
        r['s']=np.array([float(r['q_VB']),float(r['q_BC']),float(r['q_CS']),float(r['pi'])])
    return rows

def load_etas():
    with open(CONFIG/'ETA_ANCHORS.csv',newline='',encoding='utf-8') as f:
        return [float(r['eta10']) for r in csv.DictReader(f)]

def source_coordinate(vec,names):
    d={n:float(vec[i]) for i,n in enumerate(names)}
    n=d.get('n',0.0); p=d.get('p',0.0); D=d.get('H2',0.0); T=d.get('H3',0.0); He3=d.get('He3',0.0); He4=d.get('He4',0.0)
    dXV=n+p; dXB=2*D; dXC=3*(T+He3); dXS=4*He4
    qVB=-dXV; qBC=qVB-dXB; qCS=qBC-dXC; pi=p-n
    return np.array([qVB,qBC,qCS,pi],float), dXV+dXB+dXC+dXS

def endpoint_c1(z,y,names):
    ix={n:i for i,n in enumerate(names)}
    val=lambda n:float(y[ix[n]]); der=lambda n:float(z[ix[n]])
    yp=val('p'); zp=der('p')
    return np.array([
      der('H2')/val('H2')-zp/yp,
      (der('H3')+der('He3'))/(val('H3')+val('He3'))-zp/yp,
      (der('Li7')+der('Be7'))/(val('Li7')+val('Be7'))-zp/yp],float)

def vec_rel(a,b,floor=1e-14):
    return float(np.linalg.norm(np.asarray(a)-np.asarray(b))/max(np.linalg.norm(b),floor))
def vec_cos(a,b,floor=1e-30):
    a=np.asarray(a,float); b=np.asarray(b,float); na=float(np.linalg.norm(a)); nb=float(np.linalg.norm(b))
    return float('nan') if na<floor or nb<floor else float(np.dot(a,b)/(na*nb))

def _atol_vector(atol,n,default=1e-30):
    if atol is None:return np.full(n,default,float)
    a=np.asarray(atol,float)
    if a.ndim==0:return np.full(n,float(a),float)
    if a.size!=n:raise RuntimeError(f'baseline atol size mismatch {a.size}!={n}')
    return a.copy()

def natural_tangent_scale(sol,baseline_rtol,baseline_atol):
    yscale=np.max(np.abs(np.asarray(sol.y,float)),axis=1)
    rtol=max(float(baseline_rtol),1e-30); atol=_atol_vector(baseline_atol,len(yscale))
    return np.maximum.reduce([yscale,atol/rtol,np.full(len(yscale),1e-30)])

def scaled_linear_solve(coeff,t0,t1,z0,scale,method,rtol=2e-9,atol_u=2e-11):
    scale=np.asarray(scale,float); z0=np.asarray(z0,float)
    if np.any(~np.isfinite(scale)) or np.any(scale<=0):raise RuntimeError('bad tangent scale')
    u0=z0/scale; dt=float(t1-t0)
    if dt<=0:raise RuntimeError('nonpositive era interval')
    def f_tau(tau,u):
        J,g=coeff(float(t0+tau)); z=scale*u
        return (J@z+g)/scale
    def j_tau(tau,u):
        J,_=coeff(float(t0+tau))
        return (J*scale[np.newaxis,:])/scale[:,np.newaxis]
    sol=scipy_solve_ivp(f_tau,[0.0,dt],u0,method=method,jac=j_tau,rtol=rtol,atol=atol_u)
    return sol,scale*np.asarray(sol.y[:,-1],float)

def runtime_source_hashes():
    import primat.main as mainmod, primat.nuclear_network as nnmod, primat.network_data as ndmod
    out={}
    for label,mod in [('main',mainmod),('nuclear_network',nnmod),('network_data',ndmod)]:
        pp=Path(inspect.getsourcefile(mod)).resolve(); out[label]={'path':str(pp),'sha256':sha256_file(pp)}
    return out

def contract_hash(eta,source_hashes):
    core={
      'eta10':float(eta),'primat':'0.3.2','network':'large','precision':1e-10,'atol_large_LT':1e-26,
      'coordinate':'x=-ln(rate_factor)','target_config_sha256':sha256_file(CONFIG/'TARGET_14_REACTIONS.csv'),
      'source_hashes':source_hashes}
    return hashlib.sha256(json.dumps(core,sort_keys=True,separators=(',',':')).encode()).hexdigest()
