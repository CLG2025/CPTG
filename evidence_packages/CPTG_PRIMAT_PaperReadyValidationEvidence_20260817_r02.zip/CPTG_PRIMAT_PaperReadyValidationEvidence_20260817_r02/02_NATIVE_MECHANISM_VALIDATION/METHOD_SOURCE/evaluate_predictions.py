from __future__ import annotations
import csv,json
import numpy as np
from common import *

def main():
    freeze_path=OUTPUT/'PREDICTION_FREEZE.json'
    pred_path=OUTPUT/'SIXANCHOR_VARIATIONAL_PREDICTIONS_PRE_REFERENCE.csv'
    if not freeze_path.exists() or not pred_path.exists():raise RuntimeError('prediction phase not complete')
    fr=json.loads(freeze_path.read_text(encoding='utf-8'))
    if fr.get('prediction_rows')!=84 or sha256_file(pred_path)!=fr.get('sha256'):raise RuntimeError('prediction freeze identity failure')

    with open(pred_path,newline='',encoding='utf-8') as f:pred=list(csv.DictReader(f))

    # Authoritative perturbed-endpoint coefficients are first opened here, after the 84-row freeze.
    with open(REFERENCE/'AUTHORITATIVE_C1_ALL6.csv',newline='',encoding='utf-8') as f:
        refs={(float(r['eta10']),r['primat_reaction']):np.array([float(r['c1_D_H']),float(r['c1_He3_H']),float(r['c1_Li7_H'])]) for r in csv.DictReader(f)}

    rows=[]
    for p in pred:
        eta=float(p['eta10']);rx=p['reaction'];ref=refs[(eta,rx)]
        cb=np.array([float(p['BDF_c1_D_H']),float(p['BDF_c1_He3_H']),float(p['BDF_c1_Li7_H'])])
        cr=np.array([float(p['Radau_c1_D_H']),float(p['Radau_c1_He3_H']),float(p['Radau_c1_Li7_H'])])
        mean=.5*(cb+cr);norm=float(np.linalg.norm(ref))
        row=dict(p)
        row.update({'c1_ref_D_H':float(ref[0]),'c1_ref_He3_H':float(ref[1]),'c1_ref_Li7_H':float(ref[2]),
          'reference_norm':norm,'BDF_vector_relative_error':vec_rel(cb,ref),'BDF_direction_cosine':vec_cos(cb,ref),
          'Radau_vector_relative_error':vec_rel(cr,ref),'Radau_direction_cosine':vec_cos(cr,ref),
          'mean_vector_relative_error':vec_rel(mean,ref),'mean_direction_cosine':vec_cos(mean,ref)})
        rows.append(row)
    with open(OUTPUT/'SIXANCHOR_VARIATIONAL_C1_COMPARISON.csv','w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

    # Re-read baseline/source evidence accumulated by prediction phase.
    baseline=[]
    for eta in load_etas():
        baseline.append(json.loads((WORK/f'BASELINE_ETA{eta:.3f}.json').read_text(encoding='utf-8')))
    bmax=max(max(x['relative_differences'].values()) for x in baseline)
    source_rows=[]
    for eta in load_etas():
        with open(WORK/'SOURCE_AUDITS'/f'SOURCE_AUDIT_ETA{eta:.3f}.csv',newline='',encoding='utf-8') as f:
            source_rows.extend(list(csv.DictReader(f)))
    active=[r for r in source_rows if str(r['active']).lower()=='true']
    smax=max(float(r['relative_source_direction_residual']) for r in active)
    barymax=max(float(r['baryon_relative_residual']) for r in active)

    primary=[r for r in rows if r['reference_norm']>=1e-3]
    secondary=[r for r in rows if r['reference_norm']>=1e-4]
    max_v=max(max(float(r['BDF_vector_relative_error']),float(r['Radau_vector_relative_error'])) for r in primary)
    min_c=min(min(float(r['BDF_direction_cosine']),float(r['Radau_direction_cosine'])) for r in primary)
    max_x=max(float(r['BDF_Radau_vector_relative_difference']) for r in primary)
    min_xc=min(float(r['BDF_Radau_direction_cosine']) for r in primary)

    per_eta=[]
    for eta in load_etas():
        rr=[r for r in rows if abs(float(r['eta10'])-eta)<1e-12]
        pr=[r for r in rr if r['reference_norm']>=1e-3]
        per_eta.append({'eta10':eta,'primary_resolved':len(pr),
          'max_vector_relative_error_either_solver':max(max(float(r['BDF_vector_relative_error']),float(r['Radau_vector_relative_error'])) for r in pr),
          'min_direction_cosine_either_solver':min(min(float(r['BDF_direction_cosine']),float(r['Radau_direction_cosine'])) for r in pr),
          'max_BDF_Radau_crossrel':max(float(r['BDF_Radau_vector_relative_difference']) for r in pr),
          'min_BDF_Radau_crosscos':min(float(r['BDF_Radau_direction_cosine']) for r in pr)})
    with open(OUTPUT/'SIXANCHOR_PER_ETA_SUMMARY.csv','w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(per_eta[0]));w.writeheader();w.writerows(per_eta)

    gates={'baseline_max_relative':5e-6,'source_direction_max_relative':1e-10,'source_baryon_relative_max':1e-10,
      'primary_norm_floor':1e-3,'secondary_norm_floor':1e-4,'primary_vector_relative_max':0.02,'primary_cosine_min':0.999,
      'BDF_Radau_crossrel_max':5e-4,'BDF_Radau_crosscos_min':0.999999}
    decision='PASS' if (bmax<=5e-6 and smax<=1e-10 and barymax<=1e-10 and max_v<=0.02 and min_c>=0.999 and max_x<=5e-4 and min_xc>=0.999999) else 'NOT_QUALIFIED'
    final={'schema':'cptg-primat-sixanchor-native-source-jacobian-validation-result-v1','decision':decision,
      'prediction_freeze_sha256':fr['sha256'],'prediction_rows':len(rows),'eta10_anchors':load_etas(),
      'primary_resolved_rows':len(primary),'secondary_rows':len(secondary),'source_active_samples':len(active),
      'baseline_max_relative':bmax,'max_source_direction_relative_residual':smax,'max_source_baryon_relative_residual':barymax,
      'max_primary_vector_relative_error_either_solver':max_v,'min_primary_direction_cosine_either_solver':min_c,
      'max_primary_BDF_Radau_crossrel':max_x,'min_primary_BDF_Radau_crosscos':min_xc,'gates':gates,
      'fit_to_perturbed_endpoints':'NONE','production_effect':'NONE',
      'claim_boundary':'Post-execution six-anchor native mechanism validation. All 84 predictions were frozen before endpoint c1 reference evaluation. No static L matrix fitted or promoted.'}
    atomic_json(OUTPUT/'SIXANCHOR_VALIDATION_RESULT.json',final)
    print('PRIMAT_SIXANCHOR_NATIVE_SOURCE_JACOBIAN_VALIDATION',decision)
    print('PREDICTION_FREEZE_SHA256',fr['sha256'])
    print('PREDICTION_ROWS',len(rows),'/84')
    print('PRIMARY_RESOLVED_ROWS',len(primary))
    print('SECONDARY_ROWS',len(secondary))
    print('MAX_SOURCE_DIRECTION_REL',smax)
    print('MAX_PRIMARY_VECTOR_REL',max_v)
    print('MIN_PRIMARY_COSINE',min_c)
    print('MAX_BDF_RADAU_CROSSREL',max_x)
    print('MIN_BDF_RADAU_CROSSCOS',min_xc)
    print('FIT_TO_PERTURBED_ENDPOINTS NONE')
    print('PRODUCTION_EFFECT NONE')
    if decision!='PASS':raise SystemExit(2)

if __name__=='__main__':main()
