@echo off
setlocal
cd /d "%~dp0"
set "PY=D:\Downloads\ChatGPT\cptg-cmb-like\Scripts\python.exe"
if not exist "%PY%" (
  echo PYTHON_NOT_FOUND %PY%
  exit /b 2
)
"%PY%" SOURCE\verify_publication_evidence.py
exit /b %ERRORLEVEL%
