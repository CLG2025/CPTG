# Route B Option 1 NPIPE TTTEEE Controlled f_r Ladder

Status: PASS

Claim boundary:

```text
controlled Route B Option 1 f_r ladder
not native CPTG perturbation-code validation
not completed Boltzmann/source implementation
does not use locked f-to-As proxy mapping
route_b_dummy is bookkeeping only
```

## Ladder rows

| f_r | Status | loglike | chi2 | delta chi2 vs identity | hard error |
|---:|---|---:|---:|---:|---:|
| 0.998 | PASS | -5333.075467643127 | 10666.150935286254 | 0.3991954043540318 | False |
| 0.997 | PASS | -5333.192395084583 | 10666.384790169166 | 0.6330502872660873 | False |
| 0.996 | PASS | -5333.318864797287 | 10666.637729594573 | 0.8859897126731084 | False |
| 0.994 | PASS | -5333.611217995467 | 10667.222435990934 | 1.4706961090341792 | False |
| 0.993 | PASS | -5333.768944985945 | 10667.53788997189 | 1.7861500899907696 | False |
| 0.992 | PASS | -5333.9406433847125 | 10667.881286769425 | 2.1295468875250663 | False |
| 0.991 | PASS | -5334.136493818725 | 10668.27298763745 | 2.5212477555505757 | False |

## Monotonicity with locked anchors

| From f_r | To f_r | From delta | To delta | Monotonic |
|---:|---:|---:|---:|---:|
| 1.0 | 0.999 | 0.0 | 0.19127252415637486 | True |
| 0.999 | 0.998 | 0.19127252415637486 | 0.3991954043540318 | True |
| 0.998 | 0.997 | 0.3991954043540318 | 0.6330502872660873 | True |
| 0.997 | 0.996 | 0.6330502872660873 | 0.8859897126731084 | True |
| 0.996 | 0.995 | 0.8859897126731084 | 1.1649298250158608 | True |
| 0.995 | 0.994 | 1.1649298250158608 | 1.4706961090341792 | True |
| 0.994 | 0.993 | 1.4706961090341792 | 1.7861500899907696 | True |
| 0.993 | 0.992 | 1.7861500899907696 | 2.1295468875250663 | True |
| 0.992 | 0.991 | 2.1295468875250663 | 2.5212477555505757 | True |
| 0.991 | 0.99 | 2.5212477555505757 | 2.9235930460708914 | True |

Output files:

```text
D:\Downloads\ChatGPT\CPTG_Planck_Perturbation_Validation_Starter\reports\cptg_source_implementation_validation\ROUTE_B_OPTION1_NPIPE_TTTEEE_FR_LADDER_ROWS.csv
D:\Downloads\ChatGPT\CPTG_Planck_Perturbation_Validation_Starter\reports\cptg_source_implementation_validation\ROUTE_B_OPTION1_NPIPE_TTTEEE_FR_LADDER_AUDIT.json
```

Validation reading:

- PASS means the controlled f_r ladder is accepted by NPIPE and remains monotonic against the locked anchors.
- This remains Route B bridge validation, not native CPTG perturbation-code validation.
- If PASS, lock the NPIPE geometry-response curve before expanding to Plik or split TT/TE/EE.