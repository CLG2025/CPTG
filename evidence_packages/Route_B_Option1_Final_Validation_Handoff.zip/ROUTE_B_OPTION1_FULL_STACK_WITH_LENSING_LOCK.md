# Route B Option 1 Full-Stack With Lensing Smoke Lock

Status:
LOCKED

Validation layer:
Route B geometry bridge, full-stack with lensing smoke.

Likelihood stack:
planck_NPIPE_highl_CamSpec.TTTEEE
planck_2018_lowl.TT
planck_2018_lowl.EE
planckpr4lensing.PlanckPR4LensingMarged

Primary response mode:
squared_amplitude

Mapping:
P(k) -> P(k) * C_T(a,k)^2

Rows:
f_r = 1.000
summed chi2 latest = 11094.58772933417
delta chi2 vs identity = 0.0

f_r = 0.999
summed chi2 latest = 11094.937838138996
delta chi2 vs identity = +0.3501088048269594

Claim boundary:
This is Route B geometry bridge validation.
This is not native CPTG perturbation-code validation.
This is not a completed Boltzmann/source implementation.
This does not use the locked f-to-As proxy mapping.
route_b_dummy is bookkeeping only.
The summed chi2 is a smoke metric from latest component loglikes, not a final profiled validation table.

Conclusion:
The Route B Option 1 curvature-transport bridge is accepted by the full high-ell, low-ell, and lensing stack. The near-identity geometry displacement f_r = 0.999 remains stable when PR4/NPIPE marginalized lensing is added.

Next step:
Prepare the final Route B validation summary report collecting:
1. CAMB bridge smoke and Cl residual audits.
2. NPIPE TTTEEE f_r ladder.
3. NPIPE split-sector audit.
4. Plik split-sector audit and TE inversion diagnostic.
5. No-lensing full-stack smoke.
6. Lensing-only Repair07.
7. Full-stack with lensing smoke.
