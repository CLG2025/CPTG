# Route B Option 1 Plik TE Inversion Diagnostic

Status: PASS

Classification:

```text
Plik accepted all Route B Option 1 rows; strict monotonicity failure is isolated to TE.
```

Claim boundary:

```text
diagnostic classification only
not native CPTG perturbation-code validation
not completed Boltzmann/source implementation
does not use locked f-to-As proxy mapping
route_b_dummy is bookkeeping only
```

## Sector classification

| Sector | All rows passed | Monotonic | Best f_r | Best chi2 | Best delta vs identity |
|---|---:|---:|---:|---:|---:|
| TT | True | True | 1.0 | 806.375248017936 | 0.0 |
| TE | True | False | 0.995 | 891.35052224256 | -0.42739544772939553 |
| EE | True | True | 1.0 | 744.5461453543203 | 0.0 |
| TTTEEE | True | True | 1.0 | 2433.6167494730716 | 0.0 |

## TE rows

| f_r | chi2 | delta chi2 vs identity | monotonic from previous |
|---:|---:|---:|---:|
| 1.0 | 891.7779176902894 | 0.0 | True |
| 0.999 | 891.5886210045966 | -0.1892966856928524 | False |
| 0.995 | 891.35052224256 | -0.42739544772939553 | False |
| 0.99 | 892.2297929253443 | 0.45187523505489935 | True |

## Validation reading

- Plik did not reject the Route B geometry bridge.
- The Plik failure flag is caused by a TE-sector nonmonotonic preference, not a runtime or provider failure.
- Next run should be TE-only refinement around f_r = 0.999 to 0.990, not a broad Plik rerun.