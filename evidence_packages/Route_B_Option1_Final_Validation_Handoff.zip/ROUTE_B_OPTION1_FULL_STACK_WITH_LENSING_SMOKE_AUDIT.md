# Route B Option 1 Full-Stack With Lensing Smoke Audit

Status: PASS

Claim boundary:

```text
Route B Option 1 full-stack+lensing smoke
NPIPE TTTEEE + low-ell TT + low-ell EE + PR4 lensing marginalized
not native CPTG perturbation-code validation
not completed Boltzmann/source implementation
does not use locked f-to-As proxy mapping
route_b_dummy is bookkeeping only
```

Likelihood stack:

```text
npipe_highl_TTTEEE: planck_NPIPE_highl_CamSpec.TTTEEE
lowl_TT: planck_2018_lowl.TT
lowl_EE: planck_2018_lowl.EE
pr4_lensing_marged: planckpr4lensing.PlanckPR4LensingMarged
```

## Rows

| f_r | Status | summed chi2 latest | delta chi2 vs identity | required seen | hard error |
|---:|---|---:|---:|---|---:|
| 1.0 | PASS | 11094.58772933417 | 0.0 | `{"lowl_EE": true, "lowl_TT": true, "npipe_highl_TTTEEE": true, "pr4_lensing_marged": true}` | False |
| 0.999 | PASS | 11094.937838138996 | 0.3501088048269594 | `{"lowl_EE": true, "lowl_TT": true, "npipe_highl_TTTEEE": true, "pr4_lensing_marged": true}` | False |

## Component loglikes

### f_r = 1.0

```json
{"planck_2018_lowl.ee": -198.47766945292557, "planck_2018_lowl.tt": -11.179180557997114, "planck_npipe_highl_camspec.ttteee": -5332.868466081382, "planckpr4lensing.planckpr4lensingmarged": -4.768548574779368}
```

### f_r = 0.999

```json
{"planck_2018_lowl.ee": -198.47766945292557, "planck_2018_lowl.tt": -11.174047161821449, "planck_npipe_highl_camspec.ttteee": -5332.967447489877, "planckpr4lensing.planckpr4lensingmarged": -4.849754964874748}
```

Output files:

```text
D:\Downloads\ChatGPT\CPTG_Planck_Perturbation_Validation_Starter\reports\cptg_source_implementation_validation\ROUTE_B_OPTION1_FULL_STACK_WITH_LENSING_SMOKE_ROWS.csv
D:\Downloads\ChatGPT\CPTG_Planck_Perturbation_Validation_Starter\reports\cptg_source_implementation_validation\ROUTE_B_OPTION1_FULL_STACK_WITH_LENSING_SMOKE_AUDIT.json
```

Validation reading:

- PASS means the Route B bridge is consumed by the full high/low/lensing stack.
- The summed chi2 is a smoke metric from latest component loglikes, not a final profiled validation table.
- If PASS, lock this full-stack+lensing smoke and prepare the final validation summary.