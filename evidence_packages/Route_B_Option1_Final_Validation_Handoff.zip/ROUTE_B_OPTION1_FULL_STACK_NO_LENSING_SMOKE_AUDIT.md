# Route B Option 1 Full-Stack No-Lensing Smoke Audit

Status: PASS

Claim boundary:

```text
Route B Option 1 no-lensing full-stack smoke
NPIPE TTTEEE + low-ell TT + low-ell EE
not native CPTG perturbation-code validation
not completed Boltzmann/source implementation
does not use locked f-to-As proxy mapping
route_b_dummy is bookkeeping only
```

Likelihood stack:

```text
npipe_highl_TTTEEE: planck_NPIPE_highl_CamSpec.TTTEEE
lowl_TT: planck_2018_lowl.TT
lowl_EE: planck_2018_lowl.EE
```

## Rows

| f_r | Status | summed Planck chi2 latest | delta chi2 vs identity | required seen | hard error |
|---:|---|---:|---:|---|---:|
| 1.0 | PASS | 11085.05136541299 | 0.0 | `{"lowl_EE": true, "lowl_TT": true, "npipe_highl_TTTEEE": true}` | False |
| 0.999 | PASS | 11085.23859954396 | 0.187234130969955 | `{"lowl_EE": true, "lowl_TT": true, "npipe_highl_TTTEEE": true}` | False |

## Component loglikes

### f_r = 1.0

```json
{"planck_2018_lowl.ee": -198.47766945292557, "planck_2018_lowl.tt": -11.179191186845344, "planck_npipe_highl_camspec.ttteee": -5332.868822066724}
```

### f_r = 0.999

```json
{"planck_2018_lowl.ee": -198.47766945292557, "planck_2018_lowl.tt": -11.173909552818401, "planck_npipe_highl_camspec.ttteee": -5332.967720766236}
```

Output files:

```text
D:\Downloads\ChatGPT\CPTG_Planck_Perturbation_Validation_Starter\reports\cptg_source_implementation_validation\ROUTE_B_OPTION1_FULL_STACK_NO_LENSING_SMOKE_ROWS.csv
D:\Downloads\ChatGPT\CPTG_Planck_Perturbation_Validation_Starter\reports\cptg_source_implementation_validation\ROUTE_B_OPTION1_FULL_STACK_NO_LENSING_SMOKE_AUDIT.json
```

Validation reading:

- PASS means the Route B bridge is consumed by high-ell NPIPE plus low-ell TT/EE in one no-lensing stack.
- The summed chi2 is a smoke metric from latest component loglikes, not a final profiled validation table.
- If PASS, lock the no-lensing full-stack smoke before adding lensing.