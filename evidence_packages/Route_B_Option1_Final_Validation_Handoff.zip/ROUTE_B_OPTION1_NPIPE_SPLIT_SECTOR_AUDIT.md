# Route B Option 1 NPIPE Split-Sector Geometry Audit

Status: PASS

Claim boundary:

```text
Route B Option 1 NPIPE split-sector geometry check
not native CPTG perturbation-code validation
not completed Boltzmann/source implementation
does not use locked f-to-As proxy mapping
route_b_dummy is bookkeeping only
```

## Raw split-sector rows

| Sector | f_r | Status | loglike | chi2 | hard error |
|---|---:|---|---:|---:|---:|
| TT | 1.0 | PASS | -3239.376212969367 | 6478.752425938734 | False |
| TT | 0.999 | PASS | -3239.4638580966193 | 6478.927716193239 | False |
| TT | 0.995 | PASS | -3239.924611205885 | 6479.84922241177 | False |
| TT | 0.99 | PASS | -3240.8065388493806 | 6481.613077698761 | False |
| TE | 1.0 | PASS | -1069.2113869940213 | 2138.4227739880425 | False |
| TE | 0.999 | PASS | -1069.241607144699 | 2138.483214289398 | False |
| TE | 0.995 | PASS | -1069.3906156642945 | 2138.781231328589 | False |
| TE | 0.99 | PASS | -1069.6397039850006 | 2139.279407970001 | False |
| EE | 1.0 | PASS | -1009.9598265938895 | 2019.919653187779 | False |
| EE | 0.999 | PASS | -1009.971831935256 | 2019.943663870512 | False |
| EE | 0.995 | PASS | -1010.0361823971189 | 2020.0723647942377 | False |
| EE | 0.99 | PASS | -1010.1527468873162 | 2020.3054937746324 | False |
| TTTEEE | 1.0 | PASS | -5332.8758609471315 | 10665.751721894263 | False |
| TTTEEE | 0.999 | PASS | -5332.970643761006 | 10665.941287522011 | False |
| TTTEEE | 0.995 | PASS | -5333.4547714848295 | 10666.909542969659 | False |
| TTTEEE | 0.99 | PASS | -5334.332102844985 | 10668.66420568997 | False |

## Sector-normalized trend

| Sector | f_r | chi2 | delta chi2 vs sector identity | Monotonic |
|---|---:|---:|---:|---:|
| TT | 1.0 | 6478.752425938734 | 0.0 | True |
| TT | 0.999 | 6478.927716193239 | 0.17529025450494373 | True |
| TT | 0.995 | 6479.84922241177 | 1.0967964730361928 | True |
| TT | 0.99 | 6481.613077698761 | 2.8606517600273946 | True |
| TE | 1.0 | 2138.4227739880425 | 0.0 | True |
| TE | 0.999 | 2138.483214289398 | 0.060440301355356496 | True |
| TE | 0.995 | 2138.781231328589 | 0.3584573405464653 | True |
| TE | 0.99 | 2139.279407970001 | 0.8566339819585664 | True |
| EE | 1.0 | 2019.919653187779 | 0.0 | True |
| EE | 0.999 | 2019.943663870512 | 0.02401068273297824 | True |
| EE | 0.995 | 2020.0723647942377 | 0.1527116064587517 | True |
| EE | 0.99 | 2020.3054937746324 | 0.38584058685341915 | True |
| TTTEEE | 1.0 | 10665.751721894263 | 0.0 | True |
| TTTEEE | 0.999 | 10665.941287522011 | 0.18956562774837948 | True |
| TTTEEE | 0.995 | 10666.909542969659 | 1.1578210753959866 | True |
| TTTEEE | 0.99 | 10668.66420568997 | 2.9124837957060663 | True |

Output files:

```text
D:\Downloads\ChatGPT\CPTG_Planck_Perturbation_Validation_Starter\reports\cptg_source_implementation_validation\ROUTE_B_OPTION1_NPIPE_SPLIT_SECTOR_ROWS.csv
D:\Downloads\ChatGPT\CPTG_Planck_Perturbation_Validation_Starter\reports\cptg_source_implementation_validation\ROUTE_B_OPTION1_NPIPE_SPLIT_SECTOR_AUDIT.json
```

Validation reading:

- PASS means NPIPE TT, TE, EE, and TTTEEE each accept the Route B Option 1 geometry bridge rows.
- Sector-normalized monotonicity should be interpreted as a stress diagnostic, not a final source-code validation claim.
- If PASS, lock NPIPE split-sector behavior before expanding to Plik.