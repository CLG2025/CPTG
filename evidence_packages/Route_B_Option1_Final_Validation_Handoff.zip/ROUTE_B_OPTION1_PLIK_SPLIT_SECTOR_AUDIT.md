# Route B Option 1 Plik Split-Sector Geometry Audit

Status: FAIL

Claim boundary:

```text
Route B Option 1 Plik split-sector geometry check
not native CPTG perturbation-code validation
not completed Boltzmann/source implementation
does not use locked f-to-As proxy mapping
route_b_dummy is bookkeeping only
```

## Raw split-sector rows

| Sector | f_r | Status | loglike | chi2 | hard error |
|---|---:|---|---:|---:|---:|
| TT | 1.0 | PASS | -403.187624008968 | 806.375248017936 | False |
| TT | 0.999 | PASS | -403.2438985113922 | 806.4877970227844 | False |
| TT | 0.995 | PASS | -403.5902404316513 | 807.1804808633026 | False |
| TT | 0.99 | PASS | -404.2683511345784 | 808.5367022691568 | False |
| TE | 1.0 | PASS | -445.8889588451447 | 891.7779176902894 | False |
| TE | 0.999 | PASS | -445.7943105022983 | 891.5886210045966 | False |
| TE | 0.995 | PASS | -445.67526112128 | 891.35052224256 | False |
| TE | 0.99 | PASS | -446.11489646267216 | 892.2297929253443 | False |
| EE | 1.0 | PASS | -372.27307267716014 | 744.5461453543203 | False |
| EE | 0.999 | PASS | -372.33607778615607 | 744.6721555723121 | False |
| EE | 0.995 | PASS | -372.85643954673935 | 745.7128790934787 | False |
| EE | 0.99 | PASS | -374.11372469021427 | 748.2274493804285 | False |
| TTTEEE | 1.0 | PASS | -1216.8083747365358 | 2433.6167494730716 | False |
| TTTEEE | 0.999 | PASS | -1216.88836577429 | 2433.77673154858 | False |
| TTTEEE | 0.995 | PASS | -1217.3334224228295 | 2434.666844845659 | False |
| TTTEEE | 0.99 | PASS | -1218.1301190673844 | 2436.2602381347688 | False |

## Sector-normalized trend

| Sector | f_r | chi2 | delta chi2 vs sector identity | Monotonic |
|---|---:|---:|---:|---:|
| TT | 1.0 | 806.375248017936 | 0.0 | True |
| TT | 0.999 | 806.4877970227844 | 0.11254900484846075 | True |
| TT | 0.995 | 807.1804808633026 | 0.8052328453666178 | True |
| TT | 0.99 | 808.5367022691568 | 2.161454251220789 | True |
| TE | 1.0 | 891.7779176902894 | 0.0 | True |
| TE | 0.999 | 891.5886210045966 | -0.1892966856928524 | False |
| TE | 0.995 | 891.35052224256 | -0.42739544772939553 | False |
| TE | 0.99 | 892.2297929253443 | 0.45187523505489935 | True |
| EE | 1.0 | 744.5461453543203 | 0.0 | True |
| EE | 0.999 | 744.6721555723121 | 0.12601021799184764 | True |
| EE | 0.995 | 745.7128790934787 | 1.166733739158417 | True |
| EE | 0.99 | 748.2274493804285 | 3.6813040261082506 | True |
| TTTEEE | 1.0 | 2433.6167494730716 | 0.0 | True |
| TTTEEE | 0.999 | 2433.77673154858 | 0.15998207550819643 | True |
| TTTEEE | 0.995 | 2434.666844845659 | 1.0500953725872932 | True |
| TTTEEE | 0.99 | 2436.2602381347688 | 2.64348866169712 | True |

Output files:

```text
D:\Downloads\ChatGPT\CPTG_Planck_Perturbation_Validation_Starter\reports\cptg_source_implementation_validation\ROUTE_B_OPTION1_PLIK_SPLIT_SECTOR_ROWS.csv
D:\Downloads\ChatGPT\CPTG_Planck_Perturbation_Validation_Starter\reports\cptg_source_implementation_validation\ROUTE_B_OPTION1_PLIK_SPLIT_SECTOR_AUDIT.json
```

Validation reading:

- PASS means Plik TT, TE, EE, and TTTEEE each accept the Route B Option 1 geometry bridge rows.
- If FAIL, inspect only the failed sector console before rerunning anything.
- This remains Route B bridge validation, not native CPTG perturbation-code validation.