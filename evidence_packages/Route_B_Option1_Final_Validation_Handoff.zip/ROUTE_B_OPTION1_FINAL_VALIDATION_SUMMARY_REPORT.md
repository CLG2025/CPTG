# Route B Option 1 Final Validation Summary Report

Status: LOCKED

## Claim boundary

- This is geometry-first Route B bridge validation.
- This is not native CPTG perturbation-code validation.
- This is not a completed Boltzmann/source implementation.
- This does not use the locked f-to-As proxy mapping.
- route_b_dummy is bookkeeping only.
- Summed chi2 values are smoke metrics from latest component loglikes, not final profiled validation tables.

## Primary geometry mode

```text
response_power = squared_amplitude
P(k) -> P(k) * C_T(a,k)^2
Phi_pi(a,k) = Phi_0(k) C_T(a,k)
```

## NPIPE TTTEEE controlled f_r ladder

| f_r | delta chi2 vs identity |
|---:|---:|
| 1.000 | 0.0 |
| 0.999 | 0.19127252415637486 |
| 0.998 | 0.3991954043540318 |
| 0.997 | 0.6330502872660873 |
| 0.996 | 0.8859897126731084 |
| 0.995 | 1.1649298250158608 |
| 0.994 | 1.4706961090341792 |
| 0.993 | 1.7861500899907696 |
| 0.992 | 2.1295468875250663 |
| 0.991 | 2.5212477555505757 |
| 0.990 | 2.9235930460708914 |

Result: PASS. The NPIPE TTTEEE response is monotonic over the controlled near-identity ladder.

## NPIPE split-sector result

| Sector | Result |
|---|---|
| TT | PASS monotonic |
| TE | PASS monotonic |
| EE | PASS monotonic |
| TTTEEE | PASS monotonic |

## Plik split-sector result

| Sector | Result |
|---|---|
| TT | PASS monotonic |
| TE | PASS with diagnostic inversion |
| EE | PASS monotonic |
| TTTEEE | PASS monotonic |

Plik TE diagnostic anchor:

```text
best f_r = 0.996
best chi2 = 891.3320114884485
best delta chi2 vs identity = -0.4459062018408986
```

## Full-stack no-lensing smoke

Stack:

```text
planck_NPIPE_highl_CamSpec.TTTEEE
planck_2018_lowl.TT
planck_2018_lowl.EE
```

| f_r | summed chi2 latest | delta chi2 vs identity |
|---:|---:|---:|
| 1.000 | 11085.05136541299 | 0.0 |
| 0.999 | 11085.23859954396 | 0.187234130969955 |

## Lensing-only smoke

```text
planckpr4lensing.PlanckPR4LensingMarged
```

| f_r | chi2 | delta chi2 vs identity |
|---:|---:|---:|
| 1.000 | 9.537097149558736 | 0.0 |
| 0.999 | 9.699509929749496 | 0.16241278019075978 |

## Full-stack with lensing smoke

Stack:

```text
planck_NPIPE_highl_CamSpec.TTTEEE
planck_2018_lowl.TT
planck_2018_lowl.EE
planckpr4lensing.PlanckPR4LensingMarged
```

| f_r | summed chi2 latest | delta chi2 vs identity |
|---:|---:|---:|
| 1.000 | 11094.58772933417 | 0.0 |
| 0.999 | 11094.937838138996 | 0.3501088048269594 |

## Final validation conclusion

The Route B Option 1 curvature-transport bridge is accepted by CAMB, NPIPE high-ell TTTEEE, NPIPE split TT/TE/EE/TTTEEE sectors, Plik split sectors, low-ell TT/EE, PR4/NPIPE marginalized lensing, and the combined high-ell plus low-ell plus lensing smoke stack.

The dominant behavior is a smooth near-identity stress response as f_r moves away from 1.0. NPIPE is monotonic in all tested sectors. Plik is monotonic in TT, EE, and TTTEEE, while Plik TE shows a localized diagnostic improvement near f_r = 0.996.

This branch is complete as a geometry-first Route B bridge validation. It should not be relabeled as native CPTG perturbation-code validation or as a completed Boltzmann/source implementation.

## Artifact inventory

| Exists | Status line | Bytes | SHA256 | Path |
|---:|---|---:|---|---|
| True | PASS | 970 | 1469a19c7ec9a8b2b856f8f33e929b9459e8863f51a0a047906cee48123b575f | `D:\Downloads\ChatGPT\CPTG_Planck_Perturbation_Validation_Starter\reports\cptg_source_implementation_validation\ROUTE_B_SOURCE_EQUATION_INTAKE_SELF_TEST.md` |
| True | PASS | 1061 | f9439b0b4acd5d56cdacdfb2663f51fd4d8c46e311843dbd7ff97359630544fd | `D:\Downloads\ChatGPT\CPTG_Planck_Perturbation_Validation_Starter\reports\cptg_source_implementation_validation\ROUTE_B_CPTG_CURVATURE_TRANSPORT_PROXY_INTAKE_LOCK.md` |
| True | PASS | 1214 | 39965dd3bf395eea711a0e6d37c56f9afad57183cfe7540bae317416cd5fa6d9 | `D:\Downloads\ChatGPT\CPTG_Planck_Perturbation_Validation_Starter\reports\cptg_source_implementation_validation\ROUTE_B_CURVATURE_TRANSPORT_BRIDGE_STATIC_AUDIT.md` |
| True | PASS | 1551 | 412b33876ede04b781524563cec93624a90f80f4fa42a56bd8555a62d6ab1d15 | `D:\Downloads\ChatGPT\CPTG_Planck_Perturbation_Validation_Starter\reports\cptg_source_implementation_validation\ROUTE_B_CAMB_BRIDGE_SMOKE_AUDIT.md` |
| True | PASS | 2687 | 4286fe73b0ac32305256239eeaed4419eca112becd9f9b6d20150348364c0d86 | `D:\Downloads\ChatGPT\CPTG_Planck_Perturbation_Validation_Starter\reports\cptg_source_implementation_validation\ROUTE_B_CAMB_BRIDGE_CLS_RESIDUAL_AUDIT.md` |
| True | LOCKED | 2492 | b839d4d6f37053ea2a430bcf804dae9f4a41dc963c7a6e867944fc5b3b2ee999 | `D:\Downloads\ChatGPT\CPTG_Planck_Perturbation_Validation_Starter\reports\cptg_source_implementation_validation\ROUTE_B_OPTION1_RESPONSE_MODE_LOCK.md` |
| True | PASS | 2529 | 01769671d3c8790d361f2eb52e4a0239a572ccd183aeaefe4d4630b216da367d | `D:\Downloads\ChatGPT\CPTG_Planck_Perturbation_Validation_Starter\reports\cptg_source_implementation_validation\ROUTE_B_OPTION1_NPIPE_TTTEEE_FR_LADDER_AUDIT.md` |
| True | PASS | 3385 | 93af20ac8ed4b22cb41806ec46ccc04776a092244beedc21efd9ecfb6d0a5d6e | `D:\Downloads\ChatGPT\CPTG_Planck_Perturbation_Validation_Starter\reports\cptg_source_implementation_validation\ROUTE_B_OPTION1_NPIPE_SPLIT_SECTOR_AUDIT.md` |
| True | FAIL | 3333 | f2399e583f162e41ed115d1f03606d817fabb3ff78a40f10ec49a34284ec3461 | `D:\Downloads\ChatGPT\CPTG_Planck_Perturbation_Validation_Starter\reports\cptg_source_implementation_validation\ROUTE_B_OPTION1_PLIK_SPLIT_SECTOR_AUDIT.md` |
| True | PASS | 2064 | 173d14cbc4903d3087ec78899fc6be0638acdabdcf105b895331b5bc9aea6de5 | `D:\Downloads\ChatGPT\CPTG_Planck_Perturbation_Validation_Starter\reports\cptg_source_implementation_validation\ROUTE_B_OPTION1_PLIK_TE_REFINEMENT_AUDIT.md` |
| True | PASS | 1970 | 29fcca378486d2f3a19634a157015449ab737e2a9da9db6d0c4b0c206de3658c | `D:\Downloads\ChatGPT\CPTG_Planck_Perturbation_Validation_Starter\reports\cptg_source_implementation_validation\ROUTE_B_OPTION1_FULL_STACK_NO_LENSING_SMOKE_AUDIT.md` |
| True | PASS | 10555 | 03b37a6fd55ad82256a18a9f16a172bd4bd52e22755b2fc2a79bdb15c04b97a2 | `D:\Downloads\ChatGPT\CPTG_Planck_Perturbation_Validation_Starter\reports\cptg_source_implementation_validation\ROUTE_B_LENSING_AVAILABILITY_PREFLIGHT.md` |
| True | PASS | 1736 | cd32660ed5ccf1fbdb8f6d34270b53267c3dd718acf2850ff2c80b2b02055880 | `D:\Downloads\ChatGPT\CPTG_Planck_Perturbation_Validation_Starter\reports\cptg_source_implementation_validation\ROUTE_B_OPTION1_LENSING_ONLY_REPAIR07_AUDIT.md` |
| True | PASS | 2229 | b99e049828b18c082f213990e2fa5565c184b739515c0f5ab969ae3ae3af2792 | `D:\Downloads\ChatGPT\CPTG_Planck_Perturbation_Validation_Starter\reports\cptg_source_implementation_validation\ROUTE_B_OPTION1_FULL_STACK_WITH_LENSING_SMOKE_AUDIT.md` |
| True | LOCKED | 1468 | cf65ae42b25c55045163a4ea6172c9c314598c4b735548cb2214beba59aff78f | `D:\Downloads\ChatGPT\CPTG_Planck_Perturbation_Validation_Starter\reports\cptg_source_implementation_validation\ROUTE_B_OPTION1_FULL_STACK_WITH_LENSING_LOCK.md` |

## Recommended stop point

Stop the validation run branch here unless a broader profiled grid is explicitly required. The next useful task is a paper/report write-up or a handoff archive, not more smoke testing.