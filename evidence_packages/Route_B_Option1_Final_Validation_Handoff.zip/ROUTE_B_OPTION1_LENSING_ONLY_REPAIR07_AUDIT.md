# Route B Option 1 Lensing-Only Repair07 Audit

Status: PASS

Repair:

```text
The previous lensing-only failure was caused by scipy minimize crashing with zero sampled parameters after valid loglikes were computed.
Repair07 uses the evaluate sampler first, then bounded bookkeeping dummy fallback if needed.
```

Claim boundary:

```text
Route B Option 1 lensing-only Repair07
repairs sampler-only failure from no sampled parameters
Planck PR4/NPIPE lensing marginalized component only
not native CPTG perturbation-code validation
not completed Boltzmann/source implementation
does not use locked f-to-As proxy mapping
route_b_dummy is bookkeeping only
```

Lensing likelihood:

```text
planckpr4lensing.PlanckPR4LensingMarged
```

## Rows

| f_r | Status | chosen mode | loglike | chi2 | delta chi2 vs identity | hard error |
|---:|---|---|---:|---:|---:|---:|
| 1.0 | PASS | evaluate | -4.768548574779368 | 9.537097149558736 | 0.0 | False |
| 0.999 | PASS | evaluate | -4.849754964874748 | 9.699509929749496 | 0.16241278019075978 | False |

Output files:

```text
D:\Downloads\ChatGPT\CPTG_Planck_Perturbation_Validation_Starter\reports\cptg_source_implementation_validation\ROUTE_B_OPTION1_LENSING_ONLY_REPAIR07_ROWS.csv
D:\Downloads\ChatGPT\CPTG_Planck_Perturbation_Validation_Starter\reports\cptg_source_implementation_validation\ROUTE_B_OPTION1_LENSING_ONLY_REPAIR07_AUDIT.json
```

Validation reading:

- PASS means the Route B bridge provides lensing spectra to the selected PR4 lensing-only likelihood without sampler failure.
- If PASS, lensing can be added to the two-row full-stack smoke.
- This remains Route B bridge validation, not native CPTG perturbation-code validation.