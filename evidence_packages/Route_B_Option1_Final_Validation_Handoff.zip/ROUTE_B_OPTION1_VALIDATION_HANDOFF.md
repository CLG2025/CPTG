# Route B Option 1 Validation Handoff

Status:
COMPLETE / LOCKED

Branch:
Route B Option 1 curvature-transport geometry bridge.

Primary geometry mode:
squared_amplitude

Mapping:
P(k) -> P(k) * C_T(a,k)^2

Equation basis:
Phi_pi(a,k) = Phi_0(k) C_T(a,k)

Claim boundary:
This is geometry-first Route B bridge validation.
This is not native CPTG perturbation-code validation.
This is not a completed Boltzmann/source implementation.
This does not use the locked f-to-As proxy mapping.
route_b_dummy is bookkeeping only.
Summed chi2 values are smoke metrics from latest component loglikes, not final profiled validation tables.

Final locked result:
The Route B Option 1 curvature-transport bridge is accepted by:
- CAMB bridge smoke and Cl residual audits
- NPIPE high-ell TTTEEE controlled f_r ladder
- NPIPE split TT/TE/EE/TTTEEE sectors
- Plik split TT/TE/EE/TTTEEE sectors
- Planck low-ell TT and EE
- PR4/NPIPE marginalized lensing
- Combined high-ell + low-ell + lensing smoke stack

Key endpoint:
Full-stack with lensing:
f_r = 1.000  chi2 = 11094.58772933417
f_r = 0.999  chi2 = 11094.937838138996
delta chi2 = +0.3501088048269594

NPIPE behavior:
All tested sectors monotonic.

Plik behavior:
TT, EE, TTTEEE monotonic.
TE has a localized diagnostic improvement.
Best Plik TE:
f_r = 0.996
chi2 = 891.3320114884485
delta chi2 vs identity = -0.4459062018408986

Important nuance:
ROUTE_B_OPTION1_PLIK_SPLIT_SECTOR_AUDIT.md has Status: FAIL only because the strict monotonicity rule caught the TE inversion. This is classified and resolved by the TE inversion diagnostic and TE refinement audit. Do not treat it as an unresolved runtime failure.

Stop point:
Do not run more smoke tests unless a broader profiled grid is explicitly required.
Next useful work:
1. Write the validation paper/report.
2. Update README with the Route B validation status.
3. Package the validation artifacts.
