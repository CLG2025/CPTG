# Route B Option 1 Plik TE Refinement Audit

Status: PASS

Claim boundary:

```text
Plik TE-only Route B Option 1 refinement
not native CPTG perturbation-code validation
not completed Boltzmann/source implementation
does not use locked f-to-As proxy mapping
route_b_dummy is bookkeeping only
```

Reference:

```text
Plik TE identity chi2 = 891.7779176902894
Prior coarse best: f_r = 0.995, delta chi2 = -0.42739544772939553
```

## TE refinement rows

| f_r | Status | loglike | chi2 | delta chi2 vs identity | hard error |
|---:|---|---:|---:|---:|---:|
| 0.998 | PASS | -445.7255202033456 | 891.4510404066912 | -0.3268772835982645 | False |
| 0.997 | PASS | -445.68272757394453 | 891.3654551478891 | -0.4124625424003625 | False |
| 0.996 | PASS | -445.66600574422426 | 891.3320114884485 | -0.4459062018408986 | False |
| 0.995 | PASS | -445.67520633543035 | 891.3504126708607 | -0.427505019428736 | False |
| 0.994 | PASS | -445.710731668169 | 891.421463336338 | -0.35645435395144887 | False |
| 0.993 | PASS | -445.7722122188825 | 891.544424437765 | -0.23349325252445396 | False |
| 0.992 | PASS | -445.86021536309096 | 891.7204307261819 | -0.057486964107511085 | False |
| 0.991 | PASS | -445.9743232603737 | 891.9486465207474 | 0.1707288304579606 | False |

## Best row

```text
best f_r = 0.996
best chi2 = 891.3320114884485
best delta chi2 vs identity = -0.4459062018408986
```

Output files:

```text
D:\Downloads\ChatGPT\CPTG_Planck_Perturbation_Validation_Starter\reports\cptg_source_implementation_validation\ROUTE_B_OPTION1_PLIK_TE_REFINEMENT_ROWS.csv
D:\Downloads\ChatGPT\CPTG_Planck_Perturbation_Validation_Starter\reports\cptg_source_implementation_validation\ROUTE_B_OPTION1_PLIK_TE_REFINEMENT_AUDIT.json
```

Validation reading:

- PASS means the TE dip is confirmed as a sector preference, not a runtime failure.
- The best f_r should be treated as a Plik TE diagnostic anchor, not as the aggregate target.
- Next step after PASS is to lock Plik split-sector behavior with TE inversion noted.