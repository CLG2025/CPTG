from __future__ import annotations
import json, math, sys
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import spearmanr, rankdata, pearsonr
from sklearn.linear_model import LinearRegression, Ridge
from sklearn.metrics import mean_absolute_error
from sklearn.model_selection import KFold
from sklearn.preprocessing import StandardScaler

SEED=20260829
N_PERM=10000
N_FOLD_SEEDS=100


def partial_spearman(df, x, y, controls):
    sub=df[[x,y]+controls].dropna().copy()
    cols=[x,y]+controls
    R={c:rankdata(sub[c].to_numpy(float)) for c in cols}
    C=np.column_stack([R[c] for c in controls])
    rx,ry=R[x],R[y]
    ex=rx-LinearRegression().fit(C,rx).predict(C)
    ey=ry-LinearRegression().fit(C,ry).predict(C)
    r,p=pearsonr(ex,ey)
    return len(sub),float(r),float(p)


def make_X(df, cols):
    return np.column_stack([np.log10(df[c].to_numpy(float)) for c in cols])


def folds(n, seed=SEED):
    return list(KFold(n_splits=10,shuffle=True,random_state=seed).split(np.arange(n)))


def cv_predict(X,y,extra=None,seed=SEED):
    pred=np.empty(len(y))
    for tr,te in folds(len(y),seed):
        Xtr,Xte=X[tr],X[te]
        if extra is not None:
            ex=np.asarray(extra)
            if ex.ndim==1: ex=ex[:,None]
            Xtr=np.column_stack([Xtr,ex[tr]])
            Xte=np.column_stack([Xte,ex[te]])
        sc=StandardScaler().fit(Xtr)
        mdl=Ridge(alpha=1).fit(sc.transform(Xtr),y[tr])
        pred[te]=mdl.predict(sc.transform(Xte))
    return pred


def ridge_predict_fold(Xtr,ytr,Xte,alpha=1.0):
    mu=Xtr.mean(axis=0); sd=Xtr.std(axis=0,ddof=0)
    sd=np.where(sd==0,1,sd)
    Ztr=(Xtr-mu)/sd; Zte=(Xte-mu)/sd
    ym=ytr.mean(); yc=ytr-ym
    coef=np.linalg.solve(Ztr.T@Ztr+alpha*np.eye(Ztr.shape[1]),Ztr.T@yc)
    return ym+Zte@coef


def residual_perm(df, cols, B=N_PERM, seed=SEED):
    y=df['T'].to_numpy(float); N=df['CSMI_N'].to_numpy(float); X=make_X(df,cols)
    fd=folds(len(y),seed)
    base=cv_predict(X,y,None,seed); plus=cv_predict(X,y,N,seed)
    bmae=mean_absolute_error(y,base); nmae=mean_absolute_error(y,plus); obs=bmae-nmae
    nhat=np.empty(len(N))
    for tr,te in fd:
        sc=StandardScaler().fit(X[tr])
        mdl=Ridge(alpha=1).fit(sc.transform(X[tr]),N[tr])
        nhat[te]=mdl.predict(sc.transform(X[te]))
    resid=N-nhat
    rng=np.random.default_rng(seed+817)
    null=np.empty(B)
    for b in range(B):
        npv=nhat+rng.permutation(resid)
        pred=np.empty(len(y))
        for tr,te in fd:
            pred[te]=ridge_predict_fold(np.column_stack([X[tr],npv[tr]]),y[tr],np.column_stack([X[te],npv[te]]))
        null[b]=bmae-mean_absolute_error(y,pred)
    p=(1+np.sum(null>=obs))/(B+1)
    return {
        'n':len(y),'baseline_mae':bmae,'plus_N_mae':nmae,'improvement_percent':100*obs/bmae,
        'residual_permutation_p':p,'null_q025':float(np.quantile(null,.025)),
        'null_median':float(np.median(null)),'null_q975':float(np.quantile(null,.975)),
        'n_permutations':B
    }


def repeat_fold_sensitivity(df, cols, nseeds=N_FOLD_SEEDS):
    y=df['T'].to_numpy(float); N=df['CSMI_N'].to_numpy(float); X=make_X(df,cols)
    vals=[]
    for j in range(nseeds):
        seed=SEED+j
        b=mean_absolute_error(y,cv_predict(X,y,None,seed))
        n=mean_absolute_error(y,cv_predict(X,y,N,seed))
        vals.append(100*(b-n)/b)
    a=np.asarray(vals)
    return {'mean_percent':float(a.mean()),'median_percent':float(np.median(a)),
            'q025':float(np.quantile(a,.025)),'q975':float(np.quantile(a,.975)),
            'fraction_positive':float(np.mean(a>0)),'n_fold_seeds':nseeds}


def main(master, outdir):
    out=Path(outdir); out.mkdir(parents=True,exist_ok=True)
    df=pd.read_csv(master)
    # sampling correlations
    rows=[]
    for a,b in [('CSMI_N','n_points'),('T','n_points'),('CSMI_N','D_Mpc'),('T','D_Mpc')]:
        r,p=spearmanr(df[a],df[b]); rows.append({'x':a,'y':b,'n':len(df),'rho':r,'p':p})
    pd.DataFrame(rows).to_csv(out/'sampling_pairwise_correlations.csv',index=False)
    # partial controls
    partial=[]
    for controls in [['n_points'],['n_points','D_Mpc']]:
        n,r,p=partial_spearman(df,'CSMI_N','T',controls)
        partial.append({'controls':'+'.join(controls),'n':n,'partial_rho':r,'p':p})
    pd.DataFrame(partial).to_csv(out/'sampling_partial_spearman.csv',index=False)
    # resolved subsets
    subsets=[]
    for cut in [10,15,20]:
        sub=df[df['n_points']>=cut]
        r,p=spearmanr(sub['CSMI_N'],sub['T'])
        subsets.append({'minimum_points':cut,'n':len(sub),'rho_N_T':r,'p':p})
    pd.DataFrame(subsets).to_csv(out/'sampling_resolved_subset_robustness.csv',index=False)
    # prediction sensitivity
    base5=['L36_1e9Lsun','Reff_kpc','SBeff_Lsun_pc2','Rdisk_kpc','MHI_1e9Msun']
    df6=df[df['Vflat_km_s']>0].copy().reset_index(drop=True)
    base6=base5+['Vflat_km_s']
    models=[
        ('metadata5',df,base5),('metadata5+n_points',df,base5+['n_points']),
        ('metadata5+n_points+D',df,base5+['n_points','D_Mpc']),
        ('metadata6',df6,base6),('metadata6+n_points',df6,base6+['n_points']),
        ('metadata6+n_points+D',df6,base6+['n_points','D_Mpc'])]
    pred_rows=[]; repeated={}
    for name,d,cols in models:
        rr=residual_perm(d,cols)
        rr['model']=name; rr['features']=';'.join(cols)
        pred_rows.append(rr)
        repeated[name]=repeat_fold_sensitivity(d,cols)
    pd.DataFrame(pred_rows)[['model','n','baseline_mae','plus_N_mae','improvement_percent','residual_permutation_p','null_q025','null_median','null_q975','n_permutations','features']].to_csv(out/'sampling_prediction_sensitivity.csv',index=False)
    with open(out/'sampling_repeat_100fold_sensitivity.json','w') as f: json.dump(repeated,f,indent=2)
    summary={'sample_n':len(df),'pairwise':rows,'partial':partial,'resolved_subsets':subsets,'prediction':pred_rows,'repeat_100fold':repeated}
    with open(out/'sampling_control_summary.json','w') as f: json.dump(summary,f,indent=2)
    print('SAMPLING_CONTROL_EXTENSION PASS')

if __name__=='__main__':
    if len(sys.argv)!=3:
        print('usage: python run_sampling_controls_r09.py primary_153_master_table.csv OUTPUT_DIR')
        raise SystemExit(2)
    main(sys.argv[1],sys.argv[2])
