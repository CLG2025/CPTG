@echo off
setlocal
cd /d %~dp0
if not exist results_recomputed mkdir results_recomputed
python scripts\run_sampling_controls.py inputs\primary_153_master_table.csv results_recomputed
if errorlevel 1 exit /b 1
echo SAMPLING_CONTROL_EXTENSION PASS
