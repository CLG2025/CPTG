CPTG STRUCTURAL MODE N — SAMPLING CONTROL COMPANION
Date: 2026-08-29

Purpose
-------
Quantify the dependence of the registered sampled Structural Mode estimator on radial sampling density and distance, and test whether the primary N--Hubble-type ordering survives those controls.

Authority
---------
Input master table is copied unchanged from the Primary-153 Structural Mode validation evidence chain.
No CPTG galaxy law, Structural Mode definition, CSMI threshold, or galaxy-specific parameter is changed.

Headline results
----------------
rho_S(N,n_points) = +0.692155835745
rho_S(T,n_points) = -0.521910925089
partial rho_S(N,T | n_points) = -0.401082757823, p=2.78e-7
partial rho_S(N,T | n_points,D) = -0.300808280016, p=1.58e-4

Resolution-restricted N--T correlations:
>=10 points: n=115, rho=-0.602782505689
>=15 points: n=81,  rho=-0.606590539404
>=20 points: n=58,  rho=-0.617545460511

Fold-held-out prediction
------------------------
The original metadata-only baselines retain an N increment, but the increment shrinks after n_points is added and is not detected in the full-sample model after both n_points and distance are included. The residual-permutation sensitivity preserves the estimated N dependence on each declared baseline before permuting its residual component.

Reproduction
------------
The full reproduction script is scripts/run_sampling_controls.py. It performs 10,000 residual permutations for each sensitivity model and 100 deterministic ten-fold partition checks, so execution may take several minutes depending on the machine.
