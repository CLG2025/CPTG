@echo off
setlocal
cd /d "%~dp0"
set "PYEXE=D:\Downloads\ChatGPT\cptg-cmb-like\Scripts\python.exe"
if not exist "%PYEXE%" set "PYEXE=python"
"%PYEXE%" scripts\RUN_ASTAR_ABLATION.py
if errorlevel 1 exit /b 1
endlocal
