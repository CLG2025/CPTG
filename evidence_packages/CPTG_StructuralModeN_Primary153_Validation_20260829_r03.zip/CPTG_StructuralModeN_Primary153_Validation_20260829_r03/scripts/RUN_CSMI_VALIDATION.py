#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import argparse, importlib.util, json, math, sys
import numpy as np
import pandas as pd
from scipy.stats import spearmanr, fisher_exact

ROOT = Path(__file__).resolve().parents[1]
INPUTS = ROOT / "inputs"
RESULTS = ROOT / "rerun_results"
KPC_TO_M = 3.085677581491367e19

MORPH = {0:"S0",1:"Sa",2:"Sab",3:"Sb",4:"Sbc",5:"Sc",6:"Scd",7:"Sd",8:"Sdm",9:"Sm",10:"Im",11:"BCD"}

def load_workbench():
    p = INPUTS / "cptg_sparc_browser_workbench_v1_12_0.py"
    spec = importlib.util.spec_from_file_location("cptg_workbench_frozen", p)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = mod
    spec.loader.exec_module(mod)
    return mod

def parse_metadata():
    rows=[]
    p=INPUTS/'SPARC_Lelli2016c.mrt'
    for line in p.read_text(encoding='utf-8',errors='replace').splitlines():
        s=line.strip(); parts=s.split()
        if len(parts) < 19 or not any(ch.isalpha() for ch in parts[0]):
            continue
        try:
            vals=[parts[0], int(parts[1]), float(parts[2]), float(parts[3]), int(parts[4]),
                  float(parts[5]), float(parts[6]), float(parts[7]), float(parts[8]), float(parts[9]),
                  float(parts[10]), float(parts[11]), float(parts[12]), float(parts[13]), float(parts[14]),
                  float(parts[15]), float(parts[16]), int(parts[17]), ' '.join(parts[18:])]
        except Exception:
            continue
        rows.append(vals)
    cols=['galaxy','T','D_Mpc','e_D_Mpc','f_D','Inc_deg','e_Inc_deg','L36_1e9Lsun','e_L36',
          'Reff_kpc','SBeff_Lsun_pc2','Rdisk_kpc','SBdisk_Lsun_pc2','MHI_1e9Msun','RHI_kpc',
          'Vflat_km_s','e_Vflat_km_s','Q','Ref']
    return pd.DataFrame(rows,columns=cols)

def outer_slope(point_df):
    x=np.asarray(point_df['radius_kpc'],float); y=np.asarray(point_df['vobs_km_s'],float)
    n=max(3,int(math.ceil(len(x)/3)))
    x=x[-n:]; y=y[-n:]
    m=(x>0)&(y>0)&np.isfinite(x)&np.isfinite(y)
    if m.sum()<3: return float('nan')
    return float(np.polyfit(np.log(x[m]),np.log(y[m]),1)[0])

def headline():
    wb=load_workbench()
    meta=parse_metadata()
    primary=meta[(meta.Q != 3)&(meta.Inc_deg>=30)].copy()
    base=pd.read_csv(INPUTS/'primary_metadata_results.csv')
    if len(primary)!=153 or len(base)!=153:
        raise RuntimeError(f'primary count mismatch metadata={len(primary)} results={len(base)}')
    df=base.merge(primary,on='galaxy',how='inner',validate='one_to_one')
    if len(df)!=153: raise RuntimeError('metadata/results join mismatch')
    slopes=[]; n_recalc=[]
    for _, row in df.iterrows():
        g=row.galaxy
        raw_path=INPUTS/'sparc_database'/f'{g}_rotmod.dat'
        gal=wb.parse_sparc_dat_text(raw_path.read_text(encoding='utf-8',errors='replace'), raw_path.name)
        r=np.asarray(gal.radius_kpc,float)*KPC_TO_M
        vg=np.asarray(gal.vgas_km_s,float)*1000.0
        vd=np.asarray(gal.vdisk_km_s,float)*1000.0
        vb=np.asarray(gal.vbulge_km_s,float)*1000.0
        gbar=wb.build_baryonic_field(r,vg,vd,vb,wb.CPTG_GAS_WEIGHT,wb.CPTG_DISK_WEIGHT,wb.CPTG_BULGE_WEIGHT)
        gg=wb.cptg_acceleration(gbar,r,float(row.a_star_m_s2),float(row.Rc_m))
        n_recalc.append(wb.estimate_structure_scale_and_mode(r,gg))
        pt=pd.DataFrame({'radius_kpc':gal.radius_kpc,'vobs_km_s':gal.vobs_km_s})
        slopes.append(outer_slope(pt))
    df['outer_slope_obs']=slopes
    max_n_diff=float(np.max(np.abs(np.asarray(n_recalc)-np.asarray(df.CSMI_N))))
    if max_n_diff > 1e-12:
        raise RuntimeError(f'frozen CSMI readout does not reproduce saved N; max diff={max_n_diff:.3e}')
    rT,pT=spearmanr(df.CSMI_N,df['T'])
    ra,pa=spearmanr(df.CSMI_N,df.a_star_m_s2)
    rs,ps=spearmanr(df.CSMI_N,df.outer_slope_obs)
    rSB,pSB=spearmanr(df.CSMI_N,df.SBeff_Lsun_pc2)
    low=df[df.CSMI_N<=2.15]; high=df[df.CSMI_N>2.80]
    low_irr=int((low['T']>=9).sum()); high_irr=int((high['T']>=9).sum())
    low_early=int((low['T']<=4).sum()); high_early=int((high['T']<=4).sum())
    fp_irr=fisher_exact([[low_irr,len(low)-low_irr],[high_irr,len(high)-high_irr]])[1]
    fp_early=fisher_exact([[low_early,len(low)-low_early],[high_early,len(high)-high_early]])[1]
    out={
      'primary_galaxies':153,
      'rotation_curve_points':int(df.n_points.sum()),
      'N_mean':float(df.CSMI_N.mean()),'N_median':float(df.CSMI_N.median()),
      'N_vs_T':{'rho':float(rT),'p':float(pT)},
      'N_vs_a_star':{'rho':float(ra),'p':float(pa)},
      'N_vs_outer_slope':{'rho':float(rs),'p':float(ps)},
      'N_vs_SBeff':{'rho':float(rSB),'p':float(pSB)},
      'broad_contrast':{'low_n':len(low),'high_n':len(high),'low_median_T':float(low['T'].median()),
                        'high_median_T':float(high['T'].median()),'fisher_irregular_p':float(fp_irr),
                        'fisher_early_p':float(fp_early)}
    }
    RESULTS.mkdir(exist_ok=True)
    (RESULTS/'headline_results_rerun.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
    print('PRIMARY_GALAXIES',153)
    print('ROTATION_CURVE_POINTS',out['rotation_curve_points'])
    print('N_VS_T_SPEARMAN',f'{rT:.12f}','P',f'{pT:.6e}')
    print('N_VS_ASTAR_SPEARMAN',f'{ra:.12f}','P',f'{pa:.6e}')
    print('N_VS_OUTER_SLOPE_SPEARMAN',f'{rs:.12f}','P',f'{ps:.6e}')
    print('N_VS_SBEFF_SPEARMAN',f'{rSB:.12f}','P',f'{pSB:.6e}')
    # tolerance checks against frozen evidence
    if not (abs(rT+0.6081707380749901)<1e-9 and abs(ra-0.09986530497366408)<1e-9 and abs(rs+0.4484707758701566)<1e-9):
        raise RuntimeError('headline statistics differ from frozen evidence')
    return df, wb

def noise_mc(df,wb,draws=10):
    rng_base=20260829; rows=[]; clipped=0
    for gi,row in df.reset_index(drop=True).iterrows():
        g=row.galaxy; pt=pd.read_csv(INPUTS/'point_results'/f'{g}_point_results.csv')
        r=np.asarray(pt.radius_kpc,float)*KPC_TO_M
        vo=np.asarray(pt.vobs_km_s,float)*1000.0; er=np.asarray(pt.errv_km_s,float)*1000.0
        vg=np.asarray(pt.vgas_km_s,float)*1000.0; vd=np.asarray(pt.vdisk_km_s,float)*1000.0; vb=np.asarray(pt.vbulge_km_s,float)*1000.0
        gbar=wb.build_baryonic_field(r,vg,vd,vb,wb.CPTG_GAS_WEIGHT,wb.CPTG_DISK_WEIGHT,wb.CPTG_BULGE_WEIGHT)
        rng=np.random.default_rng(rng_base+gi*1009)
        ns=[]; labels=[]; ast=[]
        for _ in range(draws):
            vv=vo+rng.normal(0.0,er)
            c=int((vv<=0).sum()); clipped+=c; vv=np.maximum(vv,1e-3)
            fit=wb.fit_a_star_and_rc_for_galaxy(gbar,r,vv,er)
            gg=wb.cptg_acceleration(gbar,r,fit['a_star'],fit['rc'])
            nn=wb.estimate_structure_scale_and_mode(r,gg)
            ns.append(nn); labels.append(wb.detect_galaxy_type_from_mode(nn)); ast.append(fit['a_star'])
        rows.append({'galaxy':g,'N_saved':row.CSMI_N,'N_noise_std':float(np.std(ns)),
                     'N_noise_median_abs_delta':float(np.median(np.abs(np.asarray(ns)-row.CSMI_N))),
                     'label_retention_fraction':float(np.mean(np.asarray(labels)==row.mode_label)),
                     'a_star_noise_rel_std':float(np.std(ast)/np.mean(ast))})
    out=pd.DataFrame(rows); out.to_csv(RESULTS/'measurement_noise_mc10_rerun.csv',index=False)
    print('NOISE_MEDIAN_N_STD',out.N_noise_std.median())
    print('NOISE_MEAN_LABEL_RETENTION',out.label_retention_fraction.mean())
    print('NOISE_CLIPPED_POINTS',clipped)

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--full',action='store_true'); args=ap.parse_args()
    df,wb=headline()
    if args.full: noise_mc(df,wb,10)
    print('CSMI_PRIMARY153_VALIDATION PASS')
if __name__=='__main__': main()
