#!/usr/bin/env python3
from pathlib import Path
import hashlib, sys
ROOT=Path(__file__).resolve().parents[1]
expected={
 'inputs/cptg_sparc_browser_workbench_v1_12_0.py':'517f5927bdec8def168ab7592f660679a093c27bfc36ff857c86149cc0bd16cc',
 'inputs/SPARC_Lelli2016c.mrt':'5aa0501f6b0d881fa579030e315e7b5b6ef561a5bd3a07472f9929c7e5728243',
 'inputs/primary_metadata_results.csv':'10542127d125a1cc14f739b80d8b369e775160ee9dd3bbd81944f432dc6a6f47',
}
def sha(p):
 h=hashlib.sha256();
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
 return h.hexdigest()
fail=[]
for rel,dig in expected.items():
 p=ROOT/rel
 if not p.exists() or sha(p)!=dig: fail.append(rel)

manifest=ROOT/'PACKAGE_SHA256_MANIFEST.txt'
if manifest.exists():
    for line in manifest.read_text(encoding='utf-8').splitlines():
        if not line.strip(): continue
        dig, rel = line.split('  ',1)
        fp=ROOT/rel
        if not fp.exists() or sha(fp)!=dig:
            fail.append('manifest:'+rel)


for rel in ['results/multivariate_extension_summary.json','results/multivariate_partial_controls.csv','MULTIVARIATE_EXTENSION_REPORT.txt','scripts/RUN_MULTIVARIATE_EXTENSION.py','results/a_star_ablation_summary.csv','results/a_star_ablation_summary.json','results/branch_to_authority_comparison.csv','results/information_criteria.json','ASTAR_ABLATION_REPORT.txt','scripts/RUN_ASTAR_ABLATION.py','RUN_ASTAR_ABLATION_WINDOWS.cmd']:
    if not (ROOT/rel).exists(): fail.append('missing:'+rel)

raw=list((ROOT/'inputs/sparc_database').glob('*_rotmod.dat'))
pts=list((ROOT/'inputs/point_results').glob('*_point_results.csv'))
if len(raw)!=153: fail.append(f'raw_count={len(raw)}')
if len(pts)!=153: fail.append(f'point_count={len(pts)}')
if fail:
 print('CSMI_PRIMARY153_STATIC_VERIFY FAIL')
 for x in fail: print(' -',x)
 raise SystemExit(1)
print('WORKBENCH_SHA256 PASS')
print('METADATA_SHA256 PASS')
print('PRIMARY_RESULTS_SHA256 PASS')
print('PRIMARY_RAW_FILES 153 PASS')
print('PRIMARY_POINT_RESULTS 153 PASS')
print('CSMI_PRIMARY153_R03_STATIC_VERIFY PASS')
