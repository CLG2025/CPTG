#!/usr/bin/env python3
from pathlib import Path
import importlib.util, sys, numpy as np, pandas as pd, json, math
from scipy.optimize import minimize_scalar
from scipy.stats import spearmanr, chi2_contingency
from sklearn.model_selection import KFold

ROOT=Path(__file__).resolve().parents[1]
WBPATH=ROOT/'inputs/cptg_sparc_browser_workbench_v1_12_0.py'
spec=importlib.util.spec_from_file_location('wb_ablate',WBPATH)
wb=importlib.util.module_from_spec(spec); sys.modules['wb_ablate']=wb; spec.loader.exec_module(wb)
master=pd.read_csv(ROOT/'results/primary_153_master_table.csv')
rawdir=ROOT/'inputs/sparc_database'

records=[]
for _,row in master.iterrows():
    name=row['galaxy']; p=rawdir/f'{name}_rotmod.dat'
    gal=wb.parse_sparc_dat_text(p.read_text(encoding='utf-8',errors='replace'),p.name)
    r_m=gal.radius_kpc*wb.KPC_TO_M
    gbar=wb.build_baryonic_field(r_m,gal.vgas_km_s*1000,gal.vdisk_km_s*1000,gal.vbulge_km_s*1000,wb.CPTG_GAS_WEIGHT,wb.CPTG_DISK_WEIGHT,wb.CPTG_BULGE_WEIGHT)
    records.append((name,gal,r_m,gbar))

def branch_eval(a):
    rows=[]; total=0.0; npts=0; rc=wb.rc_from_a_star(a)
    for name,gal,r_m,gbar in records:
        g=wb.cptg_acceleration(gbar,r_m,a_star=a,rc=rc)
        v=np.sqrt(np.maximum(g,0)*r_m)/1000
        st=wb.chi2_stats(gal.vobs_km_s,gal.errv_km_s,v)
        N=wb.estimate_structure_scale_and_mode(r_m,g)
        rows.append((name,st['chi2'],st['chi2_per_point'],st['rms_km_s'],st['mae_km_s'],N,wb.detect_galaxy_type_from_mode(N)))
        total += st['chi2']; npts += st['n_points']
    return total,npts,rows

def object_eval():
    amap=dict(zip(master['galaxy'],master['a_star_m_s2']))
    rows=[]; total=0.0; npts=0
    for name,gal,r_m,gbar in records:
        a=float(amap[name]); rc=wb.rc_from_a_star(a)
        g=wb.cptg_acceleration(gbar,r_m,a_star=a,rc=rc)
        v=np.sqrt(np.maximum(g,0)*r_m)/1000
        st=wb.chi2_stats(gal.vobs_km_s,gal.errv_km_s,v)
        N=wb.estimate_structure_scale_and_mode(r_m,g)
        rows.append((name,st['chi2'],st['chi2_per_point'],st['rms_km_s'],st['mae_km_s'],N,wb.detect_galaxy_type_from_mode(N)))
        total += st['chi2']; npts += st['n_points']
    return total,npts,rows

def bias_corrected_cramers_v(data):
    tab=pd.crosstab(data['mode_label'],data['morph_family']).to_numpy()
    chi,p,_,_=chi2_contingency(tab); n=tab.sum(); r,k=tab.shape; phi=chi/n
    phi=max(0,phi-((k-1)*(r-1))/(n-1)); rr=r-((r-1)**2)/(n-1); kk=k-((k-1)**2)/(n-1)
    return float(np.sqrt(phi/min(rr-1,kk-1))),float(chi),float(p)

def ridge_pred(Xtr,ytr,Xte,alpha=1.0):
    mu=Xtr.mean(0); sd=Xtr.std(0); sd=np.where(sd==0,1,sd); Z=(Xtr-mu)/sd; Zv=(Xte-mu)/sd; ym=ytr.mean()
    beta=np.linalg.solve(Z.T@Z+alpha*np.eye(Z.shape[1]),Z.T@(ytr-ym)); return ym+Zv@beta

def cv_mae(X,y,splits):
    e=[]
    for tr,te in splits: e.extend(np.abs(y[te]-ridge_pred(X[tr],y[tr],X[te])))
    return float(np.mean(e))

def incremental_cv(data,cols):
    z=data[['T','N_branch']+cols].replace([np.inf,-np.inf],np.nan).dropna().copy()
    for c in cols: z=z[z[c]>0]
    for c in cols: z[c]=np.log10(z[c].astype(float))
    X=z[cols].to_numpy(); N=z['N_branch'].to_numpy(); y=z['T'].to_numpy(); splits=list(KFold(10,shuffle=True,random_state=20260829).split(z))
    base=cv_mae(X,y,splits); plus=cv_mae(np.column_stack([X,N]),y,splits)
    return len(z),base,plus,100*(base-plus)/base

# Global fixed-scale search. The coarse scan establishes the basin; the bounded search refines it.
def total_chi_log(x): return branch_eval(10.0**x)[0]
xs=np.linspace(-12,-9,31); chis=np.array([total_chi_log(float(x)) for x in xs])
i=int(np.argmin(chis)); lo=float(xs[max(0,i-1)]); hi=float(xs[min(len(xs)-1,i+1)])
opt=minimize_scalar(total_chi_log,bounds=(lo,hi),method='bounded',options={'xatol':1e-10})
global_a=10.0**float(opt.x); median_a=float(master['a_star_m_s2'].median())
branches=[('object_specific',None),('mond_like_fixed',1.2e-10),('sample_median_fixed',median_a),('global_chi2_fixed',global_a)]

summaries=[]; branch_frames={}
for name,a in branches:
    total,npts,rows=object_eval() if a is None else branch_eval(a)
    br=pd.DataFrame(rows,columns=['galaxy','chi2','chi2_per_point','rms_km_s','mae_km_s','N_branch','mode_label_branch'])
    br.to_csv(ROOT/'results'/f'{name}_galaxy_results.csv',index=False)
    d=master.drop(columns=['mode_label']).merge(br[['galaxy','N_branch','mode_label_branch']],on='galaxy',how='left'); d['mode_label']=d['mode_label_branch']
    rT,pT=spearmanr(d['N_branch'],d['T']); rs,ps=spearmanr(d['N_branch'],d['outer_slope_obs'])
    V,chi,pchi=bias_corrected_cramers_v(d)
    cv5=incremental_cv(d,['L36_1e9Lsun','Reff_kpc','SBeff_Lsun_pc2','Rdisk_kpc','MHI_1e9Msun'])
    cv6=incremental_cv(d,['L36_1e9Lsun','Reff_kpc','SBeff_Lsun_pc2','Rdisk_kpc','MHI_1e9Msun','Vflat_km_s'])
    summaries.append({'branch':name,'a_star_m_s2':None if a is None else float(a),'total_chi2':float(total),'points':int(npts),'chi2_per_point':float(total/npts),'N_mean':float(d.N_branch.mean()),'N_median':float(d.N_branch.median()),'rho_N_T':float(rT),'p_N_T':float(pT),'rho_N_outer_slope':float(rs),'p_N_outer_slope':float(ps),'cramers_V_mode_morph':V,'chi2_mode_morph':chi,'p_mode_morph':pchi,'cv5_n':cv5[0],'cv5_base_mae':cv5[1],'cv5_plus_N_mae':cv5[2],'cv5_improvement_pct':cv5[3],'cv6_n':cv6[0],'cv6_base_mae':cv6[1],'cv6_plus_N_mae':cv6[2],'cv6_improvement_pct':cv6[3]})
    branch_frames[name]=br.set_index('galaxy')

sumdf=pd.DataFrame(summaries); base=sumdf.iloc[0]
sumdf['chi2_ratio_vs_object']=sumdf.total_chi2/base.total_chi2
sumdf['rho_N_T_fraction_abs']=sumdf.rho_N_T.abs()/abs(base.rho_N_T)
sumdf['rho_slope_fraction_abs']=sumdf.rho_N_outer_slope.abs()/abs(base.rho_N_outer_slope)
sumdf['cramers_V_fraction']=sumdf.cramers_V_mode_morph/base.cramers_V_mode_morph
sumdf.to_csv(ROOT/'results/a_star_ablation_summary.csv',index=False)
(ROOT/'results/a_star_ablation_summary.json').write_text(json.dumps({'global_scan':{'log10_grid':xs.tolist(),'total_chi2':chis.tolist(),'global_log10_a':float(opt.x),'global_a_star_m_s2':global_a,'global_total_chi2':float(opt.fun)},'branches':summaries},indent=2)+'\n')

obj=branch_frames['object_specific']; comp=[]
for name in ['mond_like_fixed','sample_median_fixed','global_chi2_fixed']:
    j=obj.join(branch_frames[name],lsuffix='_object',rsuffix='_fixed'); rho,p=spearmanr(j.N_branch_object,j.N_branch_fixed); delta=j.N_branch_fixed-j.N_branch_object
    comp.append({'branch':name,'rho_N_object_vs_fixed':float(rho),'p_N_object_vs_fixed':float(p),'csmi_label_retention_fraction':float((j.mode_label_branch_object==j.mode_label_branch_fixed).mean()),'median_abs_delta_N':float(np.median(np.abs(delta))),'mean_abs_delta_N':float(np.mean(np.abs(delta))),'max_abs_delta_N':float(np.max(np.abs(delta))),'fraction_galaxies_fixed_chi2_worse':float((j.chi2_fixed>j.chi2_object).mean()),'median_per_galaxy_chi2_ratio':float(np.median(j.chi2_fixed/np.maximum(j.chi2_object,1e-300)))})
pd.DataFrame(comp).to_csv(ROOT/'results/branch_to_authority_comparison.csv',index=False)

glob=sumdf[sumdf.branch=='global_chi2_fixed'].iloc[0]; n=int(base.points); kobj=153; kglob=1
info={
    'object_specific_AIC':float(base.total_chi2+2*kobj),
    'global_fixed_AIC':float(glob.total_chi2+2*kglob),
    'delta_AIC_fixed_minus_object':float((glob.total_chi2+2*kglob)-(base.total_chi2+2*kobj)),
    'object_specific_BIC':float(base.total_chi2+kobj*math.log(n)),
    'global_fixed_BIC':float(glob.total_chi2+kglob*math.log(n)),
    'delta_BIC_fixed_minus_object':float((glob.total_chi2+kglob*math.log(n))-(base.total_chi2+kobj*math.log(n))),
    'n_points':n,'k_object_specific':kobj,'k_global_fixed':kglob,
    'global_fixed_chi2_ratio':float(glob.total_chi2/base.total_chi2),
}

(ROOT/'results/information_criteria.json').write_text(json.dumps(info,indent=2)+'\n')

# Fail-closed headline checks.
def close(x,y,rtol=2e-6,atol=1e-6): return abs(x-y) <= atol + rtol*abs(y)
gcmp=pd.DataFrame(comp).set_index('branch').loc['global_chi2_fixed']
checks=[
 close(global_a,1.2526825586498285e-10,rtol=2e-6,atol=0),
 close(float(base.total_chi2),27377.456854,rtol=1e-8,atol=1e-3),
 close(float(glob.total_chi2),150502.719659,rtol=1e-8,atol=1e-3),
 close(float(glob.rho_N_T),-0.596649,rtol=2e-6,atol=2e-6),
 close(float(gcmp.rho_N_object_vs_fixed),0.998080093281,rtol=2e-6,atol=2e-6),
]
if not all(checks):
    print('CSMI_ASTAR_ABLATION FAIL'); raise SystemExit(1)
print('PRIMARY_GALAXIES 153')
print('ROTATION_CURVE_POINTS 3168')
print(f'GLOBAL_FIXED_ASTAR {global_a:.12e}')
print(f'OBJECT_SPECIFIC_TOTAL_CHI2 {base.total_chi2:.6f}')
print(f'GLOBAL_FIXED_TOTAL_CHI2 {glob.total_chi2:.6f}')
print(f'GLOBAL_FIXED_CHI2_RATIO {glob.total_chi2/base.total_chi2:.9f}')
print(f'GLOBAL_FIXED_N_VS_T {glob.rho_N_T:.12f}')
print(f'N_OBJECT_VS_FIXED {gcmp.rho_N_object_vs_fixed:.12f}')
print('CSMI_ASTAR_ABLATION PASS')
