from pathlib import Path
import pandas as pd, numpy as np, json
from scipy.stats import rankdata, pearsonr, chi2_contingency
from sklearn.model_selection import KFold
from sklearn.metrics import normalized_mutual_info_score

ROOT=Path(__file__).resolve().parents[1]
df=pd.read_csv(ROOT/'results/primary_153_master_table.csv')
for c in ['Vflat_km_s','e_Vflat_km_s','RHI_kpc']:
    df.loc[df[c] <= 0,c]=np.nan

def partial_spearman(data,x,y,controls):
    z=data[[x,y]+controls].dropna()
    rx=rankdata(z[x]); ry=rankdata(z[y]); C=np.column_stack([np.ones(len(z))]+[rankdata(z[c]) for c in controls])
    ex=rx-C@np.linalg.lstsq(C,rx,rcond=None)[0]; ey=ry-C@np.linalg.lstsq(C,ry,rcond=None)[0]
    r,p=pearsonr(ex,ey); return len(z),float(r),float(p)
sets={'a_star':['a_star_m_s2'],'SBeff':['SBeff_Lsun_pc2'],'Vflat':['Vflat_km_s'],'L36':['L36_1e9Lsun'],'Reff':['Reff_kpc'],'Rdisk':['Rdisk_kpc'],'MHI':['MHI_1e9Msun'],'L36+Reff+MHI':['L36_1e9Lsun','Reff_kpc','MHI_1e9Msun'],'L36+Reff+MHI+SBeff':['L36_1e9Lsun','Reff_kpc','MHI_1e9Msun','SBeff_Lsun_pc2'],'L36+Reff+MHI+Rdisk+SBeff':['L36_1e9Lsun','Reff_kpc','MHI_1e9Msun','Rdisk_kpc','SBeff_Lsun_pc2'],'Vflat+SBeff':['Vflat_km_s','SBeff_Lsun_pc2'],'Vflat+SBeff+L36+Rdisk+MHI':['Vflat_km_s','SBeff_Lsun_pc2','L36_1e9Lsun','Rdisk_kpc','MHI_1e9Msun'],'all_plus_a_star':['Vflat_km_s','SBeff_Lsun_pc2','L36_1e9Lsun','Rdisk_kpc','MHI_1e9Msun','a_star_m_s2']}
partial=[]
for name,c in sets.items():
    n,r,p=partial_spearman(df,'CSMI_N','T',c); partial.append({'controlled_for':name,'n':n,'partial_spearman_r':r,'p':p})

# categorical association fast contingency permutations
modes=pd.Categorical(df.mode_label); fams=pd.Categorical(df.morph_family)
mi=modes.codes; fi=fams.codes; nr=len(modes.categories); nk=len(fams.categories)
def table_from_codes(a,b):
    t=np.zeros((nr,nk),dtype=int); np.add.at(t,(a,b),1); return t
obs_tab=table_from_codes(mi,fi); obs_chi=chi2_contingency(obs_tab)[0]
n=obs_tab.sum(); phi2=obs_chi/n; phi2corr=max(0,phi2-((nk-1)*(nr-1))/(n-1)); rcorr=nr-((nr-1)**2)/(n-1); kcorr=nk-((nk-1)**2)/(n-1); V=float(np.sqrt(phi2corr/min(kcorr-1,rcorr-1)))
obs_nmi=float(normalized_mutual_info_score(fi,mi)); rng=np.random.default_rng(20260829); nperm_cat=10000; ge=0
for _ in range(nperm_cat):
    ch=chi2_contingency(table_from_codes(mi,rng.permutation(fi)))[0]; ge += ch>=obs_chi-1e-14
cat={'chi2':float(obs_chi),'asymptotic_p':float(chi2_contingency(obs_tab)[1]),'cramers_V_bias_corrected':V,'normalized_mutual_information':obs_nmi,'chi2_permutation_p':float((ge+1)/(nperm_cat+1)),'n_permutations':nperm_cat}

def ridge_pred(Xtr,ytr,Xte,alpha=1.0):
    mu=Xtr.mean(0); sd=Xtr.std(0); sd=np.where(sd==0,1,sd); Z=(Xtr-mu)/sd; Zv=(Xte-mu)/sd; ym=ytr.mean(); beta=np.linalg.solve(Z.T@Z+alpha*np.eye(Z.shape[1]),Z.T@(ytr-ym)); return ym+Zv@beta

def cv_mae(X,y,splits):
    e=[]
    for tr,te in splits:e.extend(np.abs(y[te]-ridge_pred(X[tr],y[tr],X[te])))
    return float(np.mean(e))

def inc_test(tag,cols,seed,nperm=10000):
    z=df[['T','CSMI_N']+cols].dropna().copy()
    for c in cols:z[c]=np.log10(z[c].astype(float))
    X=z[cols].to_numpy(); N=z.CSMI_N.to_numpy(); y=z['T'].to_numpy(); splits=list(KFold(10,shuffle=True,random_state=20260829).split(z)); base=cv_mae(X,y,splits); plus=cv_mae(np.column_stack([X,N]),y,splits); imp=base-plus; rng=np.random.default_rng(seed); vals=np.empty(nperm)
    for j in range(nperm):vals[j]=base-cv_mae(np.column_stack([X,rng.permutation(N)]),y,splits)
    return {'model':tag,'n':len(z),'baseline_mae':base,'plus_N_mae':plus,'mae_improvement':imp,'improvement_percent':100*imp/base,'permutation_p':float((np.sum(vals>=imp-1e-14)+1)/(nperm+1)),'null_q025':float(np.quantile(vals,.025)),'null_median':float(np.median(vals)),'null_q975':float(np.quantile(vals,.975)),'n_permutations':nperm}

cv5=inc_test('metadata5',['L36_1e9Lsun','Reff_kpc','SBeff_Lsun_pc2','Rdisk_kpc','MHI_1e9Msun'],20260830)
cv6=inc_test('metadata6',['L36_1e9Lsun','Reff_kpc','SBeff_Lsun_pc2','Rdisk_kpc','MHI_1e9Msun','Vflat_km_s'],20260831)
result={'partial_controls':partial,'morphology_association':cat,'incremental_prediction':[cv5,cv6]}
out=ROOT/'results/multivariate_extension_summary_rerun.json'
out.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,indent=2))
print('CSMI_MULTIVARIATE_EXTENSION PASS')
