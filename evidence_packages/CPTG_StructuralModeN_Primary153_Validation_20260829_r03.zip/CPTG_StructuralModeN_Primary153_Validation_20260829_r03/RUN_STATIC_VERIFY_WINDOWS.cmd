@echo off
setlocal
python scripts\STATIC_VERIFY.py
if errorlevel 1 exit /b 1
