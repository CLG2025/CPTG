@echo off
setlocal
python scripts\RUN_CSMI_VALIDATION.py
if errorlevel 1 exit /b 1
