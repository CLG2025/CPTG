@echo off
setlocal
python scripts\RUN_MULTIVARIATE_EXTENSION.py
if errorlevel 1 exit /b 1
