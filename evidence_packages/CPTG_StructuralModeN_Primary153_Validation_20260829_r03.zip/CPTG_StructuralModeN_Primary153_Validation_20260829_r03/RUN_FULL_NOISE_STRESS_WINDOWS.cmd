@echo off
setlocal
python scripts\RUN_CSMI_VALIDATION.py --full
if errorlevel 1 exit /b 1
