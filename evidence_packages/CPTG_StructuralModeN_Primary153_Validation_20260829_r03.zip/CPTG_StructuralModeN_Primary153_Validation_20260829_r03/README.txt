CPTG Structural Mode N / CSMI Primary-SPARC Validation — 2026-08-29 r01

This package freezes the first dedicated 153-primary-galaxy validation of Structural
Mode N and the existing CSMI descriptive bands using CPTG SPARC Browser Workbench
v1.12.0. No theory equation, a_star inference rule, Structural Mode definition, or
CSMI threshold was changed during the validation.

Run on Windows Command Prompt:

  cd /d <THIS_EXTRACTED_FOLDER>
  RUN_STATIC_VERIFY_WINDOWS.cmd
  RUN_VALIDATION_WINDOWS.cmd

Expected static result:
  CSMI_PRIMARY153_STATIC_VERIFY PASS

Expected validation headline includes:
  PRIMARY_GALAXIES 153
  N_VS_T_SPEARMAN approximately -0.608171
  N_VS_ASTAR_SPEARMAN approximately +0.099865
  N_VS_OUTER_SLOPE_SPEARMAN approximately -0.448471
  CSMI_PRIMARY153_VALIDATION PASS

See VALIDATION_REPORT.txt for scientific interpretation and claim boundaries.

R02 MULTIVARIATE EXTENSION
--------------------------
This revision preserves the complete r01 primary-153 validation and adds a
postdecision multivariate structural test. It does not change the workbench,
Structural Mode N, CSMI thresholds, primary-sample rule, source weights, or
rotation-curve solutions.

New tests:
- partial rank controls against conventional SPARC structure variables;
- CSMI-band versus broad morphology association;
- fixed ten-fold incremental Hubble-type prediction with N added to conventional
  metadata baselines;
- 10,000-permutation significance tests for the morphology association and both
  incremental-prediction models.

Run:
  RUN_STATIC_VERIFY_WINDOWS.cmd
  RUN_VALIDATION_WINDOWS.cmd
  RUN_MULTIVARIATE_EXTENSION_WINDOWS.cmd

UNIVERSAL a_STAR ABLATION
Run:
  RUN_ASTAR_ABLATION_WINDOWS.cmd

This test compares the object-specific CPTG acceleration-scale solution with three one-scale restrictions: the MOND-like numerical control, the primary-sample median CPTG scale, and the globally chi-square-optimized universal CPTG scale. It recomputes Rc, the nonlinear field, Structural Mode N, and CSMI for every branch.

Expected headline output:
  PRIMARY_GALAXIES 153
  ROTATION_CURVE_POINTS 3168
  GLOBAL_FIXED_ASTAR 1.252682558650e-10
  OBJECT_SPECIFIC_TOTAL_CHI2 27377.456854
  GLOBAL_FIXED_TOTAL_CHI2 150502.719659
  GLOBAL_FIXED_CHI2_RATIO 5.497322869
  GLOBAL_FIXED_N_VS_T -0.596649...
  N_OBJECT_VS_FIXED 0.998080...
  CSMI_ASTAR_ABLATION PASS
