#!/usr/bin/env python3
"""
CPTG AGC 114905 - Resolved Structural Mode Audit r02
Date: 2026-09-02

Purpose
-------
Evaluate the continuous CPTG Structural Mode N from the resolved, continuous
Eq. (9)/(10) source field after the fiducial AGC 114905 source authority and
coupled uncertainty audit have been fixed.

Registered Structural Mode definition
-------------------------------------
Cg(r) = g(r)^2 + kappa_struct^2 (dg/dr)^2
kappa_struct = 1 kpc
w(r) = |dCg/dr|
lambda = integral_{R/5}^{R} r w dr / integral_{R/5}^{R} w dr
N = R/lambda

The outer readout R is fixed here to the outermost observed 2024 tilted-ring
kinematic coordinate. The field between rings is not interpolated from five
velocity points: it is solved continuously from the published analytic gas
and stellar source laws and the retained a_star for each realization.

This script consumes the exact 10,000-draw coupled-uncertainty table produced
by CPTG_AGC114905_CoupledUncertaintyAudit_20260902_r02.py. Thus measurement
uncertainty enters N only through the re-fitted a_star, while geometry and
source-normalization perturbations enter both the source field and a_star.

No profile-coefficient covariance is invented because none is supplied in
the observational paper.
"""

from __future__ import annotations

import math
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.integrate import simpson
from scipy.interpolate import CubicSpline
from scipy.special import j0, j1, erfcx
from scipy.stats import spearmanr

# ----------------------------- constants ---------------------------------

G_KPC = 4.300917270e-6
C = 299792458.0
KPC_M = 3.085677581491367e19
D0 = 78.7
I0_DEG = 31.0
I0 = math.radians(I0_DEG)
KPC_ASEC0 = 0.368

R0 = np.array([
    1.1043687554503552,
    3.310655163822101,
    5.515765042979943,
    7.722051451351689,
    9.92716133050953,
])
THETA = R0/KPC_ASEC0
THETA_OUT = float(THETA[-1])

# Published source-law parameters.
S0S=3.6703
RPEX=3.6155
C1,C2,C3,C4=0.5576,-0.1126,0.0085,-0.0002
S0G=3.953
R1,R2,ALPHA=0.676,375.220,559.231
RE0=2.80
ZGAS=1.3

# Structural definition.
KAPPA_KPC=1.0
P=123/50
Q=11/50

# High-resolution normalized radial grid. The registered readout begins at x=0.2.
X=np.linspace(0.08,1.0,900)
MASK=X>=0.2

# Distance nodes include the exact fiducial D=78.7 Mpc.
DNODES=np.array([74.2,75.7,77.2,78.7,80.2,81.7,83.2])

# -------------------------- Hankel source solver --------------------------

def prepare_hankel(sigma_func,rmax,nr,nk,kmax,vertical,h):
    rp=np.linspace(0.0,rmax,nr)
    sig=sigma_func(rp)
    k=np.linspace(0.0,kmax,nk)
    S=np.empty(nk)
    chunk=350
    for i in range(0,nk,chunk):
        kk=k[i:i+chunk,None]
        S[i:i+chunk]=simpson(
            j0(kk*rp[None,:])*(sig*rp)[None,:],x=rp,axis=1
        )
    if vertical=="gaussian":
        F=erfcx(k*h/math.sqrt(2))
    elif vertical=="sech2":
        u=np.linspace(0.0,12.0,1800)
        zz=1/np.cosh(u)**2
        F=np.empty(nk)
        for i in range(0,nk,chunk):
            kk=k[i:i+chunk,None]
            F[i:i+chunk]=simpson(
                zz[None,:]*np.exp(-kk*h*u[None,:]),x=u,axis=1
            )
    else:
        F=np.ones(nk)
    return k,S,F

def eval_hankel(r,prep):
    k,S,F=prep
    out=np.empty(len(r))
    for i,R in enumerate(r):
        gg=2*math.pi*G_KPC*simpson(k*j1(k*R)*S*F,x=k)
        out[i]=math.copysign(math.sqrt(abs(R*gg)),R*gg)
    return out

def dense_source_D(D):
    s=KPC_ASEC0*(D/D0)
    Rout=THETA_OUT*s
    Re=RE0*(D/D0)
    zstar=0.196*(Re/1.678)**0.633

    def sigs(r):
        a=np.asarray(r)/s
        poly=1+C1*a+C2*a*a+C3*a**3+C4*a**4
        return S0S*np.exp(-a/RPEX)*poly*1e6

    def sigg(r):
        a=np.asarray(r)/s
        return S0G*np.exp(-a/R1)*(1+a/R2)**ALPHA*1e6

    # Match the GALPYNAMICS array-wrapper integration scale, 2*Rout.
    rcut=2*Rout
    ps=prepare_hankel(
        sigs,rcut,nr=6000,nk=7000,kmax=90*(D0/D),
        vertical="sech2",h=zstar
    )
    pg=prepare_hankel(
        sigg,rcut,nr=6000,nk=7000,kmax=60*(D0/D),
        vertical="gaussian",h=ZGAS
    )
    r=X*Rout
    return Rout,eval_hankel(r,ps),eval_hankel(r,pg)

VS=[]
VG=[]
RO=[]
for D in DNODES:
    ro,vs,vg=dense_source_D(float(D))
    RO.append(ro); VS.append(vs); VG.append(vg)
VS=np.asarray(VS); VG=np.asarray(VG); RO=np.asarray(RO)
VS_D=CubicSpline(DNODES,VS,axis=0)
VG_D=CubicSpline(DNODES,VG,axis=0)

# ----------------------------- CPTG solve ---------------------------------

def solve_field(gbar,a,r_m):
    Rc=48*np.pi*C*C/a
    x=r_m/Rc
    ggeom=0.5*a*x**(7/5)/(1+x**(12/5))
    A=np.sqrt(a*gbar)+ggeom
    g=gbar+A
    for _ in range(70):
        gn=gbar+A/(1+(g/a)**P)**Q
        if np.max(np.abs(gn-g)/np.maximum(gn,1e-40)) < 1e-12:
            return gn
        g=gn
    return g

def structural_mode(D,i_deg,fstar,fgas,a_star):
    Rout=THETA_OUT*(KPC_ASEC0*D/D0)
    r=X*Rout

    inc=math.cos(math.radians(i_deg))/math.cos(I0)
    vs=VS_D(D)*math.sqrt(inc*fstar)
    vg=VG_D(D)*math.sqrt(inc*fgas)

    vbar_c2=(27/50)*vg**2+(23/50)*vs**2
    rm=r*KPC_M
    gbar=vbar_c2*1e6/rm
    g=solve_field(gbar,a_star,rm)

    rr=r[MASK]
    gg=g[MASK]
    gs=CubicSpline(rr,gg)
    dg_dr_kpc=gs.derivative(1)(rr)

    # Since kappa_struct = 1 kpc, kappa^2 (dg/dr_m)^2 is
    # numerically equal to (dg/dr_kpc)^2 in the expression below.
    Cg=gg**2+(KAPPA_KPC*dg_dr_kpc)**2
    cs=CubicSpline(rr,Cg)
    w=np.abs(cs.derivative(1)(rr))

    den=simpson(w,x=rr)
    lam=simpson(rr*w,x=rr)/den
    return Rout/lam,lam

def csmi(n):
    if n<=1.45: return "Dwarf Irregular"
    if n<=1.75: return "Magellanic Irregular"
    if n<=1.95: return "LSB Dwarf Disk"
    if n<=2.15: return "Transition Dwarf"
    if n<=2.35: return "LSB Spiral"
    if n<=2.55: return "Very Late Spiral"
    if n<=2.80: return "Late Spiral"
    if n<=3.05: return "Intermediate Spiral"
    if n<=3.30: return "Early Spiral"
    if n<=3.55: return "Bulged Spiral"
    if n<=3.72: return "Lenticular/Early Disk"
    return "High-Mode Outlier"

# ----------------------------- input draws --------------------------------

base=Path(__file__).parent
infile=base/"CPTG_AGC114905_CoupledUncertaintyAudit_20260902_r02_COMBINED.csv"
draws=pd.read_csv(infile)

Nvals=np.empty(len(draws))
Lvals=np.empty(len(draws))
for j,row in draws.iterrows():
    Nvals[j],Lvals[j]=structural_mode(
        float(row["D_Mpc"]),
        float(row["inclination_deg"]),
        float(row["stellar_norm_factor"]),
        float(row["gas_norm_factor"]),
        float(row["a_star"]),
    )

draws["Structural_Mode_N"]=Nvals
draws["lambda_kpc"]=Lvals
draws["CSMI_label"]=[csmi(x) for x in Nvals]
outfile=base/"CPTG_AGC114905_StructuralModeResolvedAudit_20260902_r02_DRAWS.csv"
draws.to_csv(outfile,index=False)

# Fiducial point from source-authority direct solution.
A_FID=7.279693927339e-12
N_FID,L_FID=structural_mode(D0,I0_DEG,1.0,1.0,A_FID)

# Numerical grid convergence using subsamples of the already high-resolution field
# is checked by independently re-evaluating the centroid on nested samplings.
def mode_from_sample_count(nsample):
    Rout=THETA_OUT*KPC_ASEC0
    r=X*Rout
    vs=VS_D(D0)
    vg=VG_D(D0)
    v2=(27/50)*vg**2+(23/50)*vs**2
    rm=r*KPC_M
    g=solve_field(v2*1e6/rm,A_FID,rm)

    idx=np.unique(np.linspace(np.searchsorted(X,0.2),len(X)-1,nsample).astype(int))
    rr=r[idx]; gg=g[idx]
    gs=CubicSpline(rr,gg)
    dg=gs.derivative(1)(rr)
    Cg=gg**2+dg**2
    cs=CubicSpline(rr,Cg)
    w=np.abs(cs.derivative(1)(rr))
    lam=simpson(rr*w,x=rr)/simpson(w,x=rr)
    return Rout/lam

conv={n:mode_from_sample_count(n) for n in [100,200,400,700]}

# Sensitivity of N to a_star alone at fixed fiducial source.
aper=np.percentile(draws["a_star"],[2.5,16,50,84,97.5])
Na=[]
for a in aper:
    n,_=structural_mode(D0,I0_DEG,1.0,1.0,float(a))
    Na.append(n)

# Statistics.
pcts=np.percentile(Nvals,[0.5,2.5,16,50,84,97.5,99.5])
labels=draws["CSMI_label"].value_counts()

def rho(col):
    rr=spearmanr(Nvals,draws[col].to_numpy())
    return float(rr.statistic),float(rr.pvalue)

rhos={
    "D_Mpc":rho("D_Mpc"),
    "inclination_deg":rho("inclination_deg"),
    "a_star":rho("a_star"),
    "stellar_norm_factor":rho("stellar_norm_factor"),
    "gas_norm_factor":rho("gas_norm_factor"),
}
ratio=draws["stellar_norm_factor"].to_numpy()/draws["gas_norm_factor"].to_numpy()
rr=spearmanr(Nvals,ratio)
rho_ratio=(float(rr.statistic),float(rr.pvalue))

lines=[]
lines.append("CPTG AGC 114905 RESOLVED STRUCTURAL MODE AUDIT r02")
lines.append("")
lines.append("READOUT AUTHORITY")
lines.append("R = outermost observed 2024 tilted-ring kinematic radius.")
lines.append("Continuous Eq. N=R/lambda is used; the five-point sampled estimator is NOT used.")
lines.append("Continuous source = published Eq9/Eq10 stellar/gas profiles.")
lines.append("kappa_struct = 1 kpc.")
lines.append("")
lines.append("FIDUCIAL RESULT")
lines.append(f"Rout = {THETA_OUT*KPC_ASEC0:.12f} kpc")
lines.append(f"a_star = {A_FID:.12e} m/s^2")
lines.append(f"N = {N_FID:.12f}")
lines.append(f"lambda = {L_FID:.12f} kpc")
lines.append(f"fiducial CSMI band = {csmi(N_FID)}")
lines.append("")
lines.append("NUMERICAL CONVERGENCE")
for n,v in conv.items():
    lines.append(f"N with {n} readout samples = {v:.12f}")
lines.append(f"max convergence spread = {max(conv.values())-min(conv.values()):.12e}")
lines.append("")
lines.append("10,000-DRAW CONTINUOUS N DISTRIBUTION")
lines.append("percentiles [p0.5,p2.5,p16,p50,p84,p97.5,p99.5] =")
lines.append("  "+", ".join(f"{x:.12f}" for x in pcts))
lines.append(f"minimum N = {np.min(Nvals):.12f}")
lines.append(f"maximum N = {np.max(Nvals):.12f}")
lines.append("")
lines.append("CSMI OCCUPANCY")
for lab in [
    "Dwarf Irregular","Magellanic Irregular","LSB Dwarf Disk",
    "Transition Dwarf","LSB Spiral","Very Late Spiral","Late Spiral",
    "Intermediate Spiral","Early Spiral","Bulged Spiral",
    "Lenticular/Early Disk","High-Mode Outlier"
]:
    c=int(labels.get(lab,0))
    if c:
        lines.append(f"{lab}: {c}/10000 = {100*c/10000:.2f}%")
lines.append("")
lines.append("A_STAR-ONLY SENSITIVITY AT FIXED SOURCE")
for a,n in zip(aper,Na):
    lines.append(f"a_star={a:.12e} -> N={n:.12f}")
lines.append(f"N spread across a_star p2.5-p97.5 = {max(Na)-min(Na):.12e}")
lines.append("")
lines.append("SPEARMAN SENSITIVITY OF N")
for key,(r,pv) in rhos.items():
    lines.append(f"rho(N,{key}) = {r:+.8f}, p={pv:.6e}")
lines.append(f"rho(N,stellar_norm/gas_norm) = {rho_ratio[0]:+.8f}, p={rho_ratio[1]:.6e}")
lines.append("")
lines.append("INTERPRETATION")
lines.append("1. The outer observed kinematic ring defines the registered Structural Mode readout radius.")
lines.append("2. The fiducial solution is a low-mode N~1.50 system.")
lines.append("3. Geometry and a_star amplitude uncertainty have little direct effect on N.")
lines.append("4. Relative stellar/gas source normalization broadens the continuous N")
lines.append("   distribution enough to cross several descriptive CSMI thresholds.")
lines.append("5. Therefore continuous N is the authoritative structural result; a single")
lines.append("   hard CSMI label is not uncertainty-stable for AGC 114905.")
lines.append("")
lines.append("DECISION")
lines.append("RESOLVED_CONTINUOUS_STRUCTURAL_MODE PASS")
lines.append("OUTER_READOUT_CONVENTION CLOSED")
lines.append("FIDUCIAL_N_LOW_MODE PASS")
lines.append("SINGLE_CSMI_LABEL NOT_FROZEN")

(base/"CPTG_AGC114905_StructuralModeResolvedAudit_20260902_r02_REPORT.txt").write_text(
    "\n".join(lines)+"\n",encoding="utf-8"
)
print("\n".join(lines))
