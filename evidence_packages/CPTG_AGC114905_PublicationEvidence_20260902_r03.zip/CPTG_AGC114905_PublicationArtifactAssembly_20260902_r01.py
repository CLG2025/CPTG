#!/usr/bin/env python3
"""
CPTG AGC 114905 - Publication Artifact Assembly r01
Date: 2026-09-02

Consumes the numerical audit outputs in this evidence package and regenerates
the publication-facing five-ring table and Figures 1-3. No fitting or new
scientific inference is performed by this script.
"""
from pathlib import Path
import math
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

HERE=Path(__file__).resolve().parent
SRC=pd.read_csv(HERE/'CPTG_AGC114905_SourceAuthorityClosure_20260902_r03_FIDUCIAL.csv')
UNC=pd.read_csv(HERE/'CPTG_AGC114905_CoupledUncertaintyAudit_20260902_r02_COMBINED.csv')
STR=pd.read_csv(HERE/'CPTG_AGC114905_StructuralModeResolvedAudit_20260902_r02_DRAWS.csv')

C=299792458.0
KPC_M=3.085677581491367e19
A0=1.2e-10
R=SRC['R_kpc'].to_numpy()
VOBS=SRC['Vobs_km_s'].to_numpy()
SIG=SRC['sigmaV_km_s'].to_numpy()
VS=SRC['Vstar_GALP_equiv_km_s'].to_numpy()
VG=SRC['Vgas_GALP_equiv_km_s'].to_numpy()
VORD=SRC['Vbar_ordinary_km_s'].to_numpy()
VCPTG=SRC['VCPTG_km_s'].to_numpy()
VCPTGSRC=SRC['Vbar_CPTG_source_km_s'].to_numpy()
RM=R*KPC_M
gbar=VORD**2*1e6/RM
gmond=0.5*gbar*(1+np.sqrt(1+4*A0/gbar))
VMOND=np.sqrt(gmond*RM)/1000
RES=VCPTG-VOBS
RESSIG=RES/SIG

pub=pd.DataFrame({
    'R_kpc':R,'Vobs_km_s':VOBS,'sigmaV_km_s':SIG,
    'Vstar_GALP_equiv_km_s':VS,'Vgas_GALP_equiv_km_s':VG,
    'Vbar_ordinary_km_s':VORD,'Vbar_CPTG_source_km_s':VCPTGSRC,
    'VCPTG_km_s':VCPTG,'CPTG_residual_km_s':RES,
    'CPTG_residual_sigma':RESSIG,'VMOND_simple_fixed_a0_km_s':VMOND,
})
pub.to_csv(HERE/'CPTG_AGC114905_FinalFiducialFiveRingTable_20260902_r03.csv',index=False)

# Figure 1: resolved rotation-curve comparison.
fig,ax=plt.subplots(figsize=(8.4,5.4))
ax.errorbar(R,VOBS,yerr=SIG,fmt='o',capsize=3,color='black',label='Observed circular speed')
ax.plot(R,VORD,marker='s',linestyle='-',color='blue',label='Ordinary baryonic response')
ax.plot(R,VCPTG,marker='^',linestyle='-',color='orange',label='CPTG')
ax.plot(R,VMOND,marker='x',linestyle='-',color='green',label=r'MOND, simple $\mu$, fixed $a_0$')
ax.set_xlabel('Radius (kpc)'); ax.set_ylabel(r'Circular speed (km s$^{-1}$)')
ax.set_title('AGC 114905: Fiducial-Geometry Five-Ring Comparison')
ax.legend(fontsize=8); fig.tight_layout()
fig.savefig(HERE/'CPTG_AGC114905_FiducialRotationCurve_20260902_r05.png',dpi=220)
plt.close(fig)

# Figure 2: a_star uncertainty.
fig,ax=plt.subplots(figsize=(8.0,5.2))
ax.hist(UNC['a_star'].to_numpy(),bins=55)
ax.axvline(7.279693927339e-12,linestyle='--',color='orange',label='Fiducial CPTG')
ax.axvline(float(np.median(UNC['a_star'])),linestyle=':',color='black',label='Combined median')
ax.set_xlabel(r'$a_\star$ (m s$^{-2}$)'); ax.set_ylabel('Realizations')
ax.set_title(r'AGC 114905: Combined $a_\star$ Uncertainty'); ax.legend(); fig.tight_layout()
fig.savefig(HERE/'CPTG_AGC114905_AstarUncertainty_20260902_r03.png',dpi=220)
plt.close(fig)

# Figure 3: Structural Mode distribution.
fig,ax=plt.subplots(figsize=(8.0,5.2))
ax.hist(STR['Structural_Mode_N'].to_numpy(),bins=55)
for boundary in [1.45,1.75,1.95,2.15,2.35]:
    ax.axvline(boundary,linestyle=':',color='black',linewidth=0.9)
ax.axvline(1.496656823827,linestyle='--',color='orange',label='Fiducial CPTG')
ax.set_xlabel(r'Structural Mode $N$'); ax.set_ylabel('Realizations')
ax.set_title('AGC 114905: Structural Mode Distribution'); ax.legend(); fig.tight_layout()
fig.savefig(HERE/'CPTG_AGC114905_StructuralModeDistribution_20260902_r03.png',dpi=220)
plt.close(fig)

print('PUBLICATION_ARTIFACT_ASSEMBLY PASS')
print('table = CPTG_AGC114905_FinalFiducialFiveRingTable_20260902_r03.csv')
print('figure1 = CPTG_AGC114905_FiducialRotationCurve_20260902_r05.png')
print('figure2 = CPTG_AGC114905_AstarUncertainty_20260902_r03.png')
print('figure3 = CPTG_AGC114905_StructuralModeDistribution_20260902_r03.png')
