# AGC 114905 CPTG Publication Evidence Package

This archive contains the publication-facing numerical data, executable audits, derived outputs, and figures supporting the AGC 114905 resolved-source CPTG rotation-curve analysis.

## Source-force authority

### `CPTG_AGC114905_SourceAuthorityClosure_20260902_r03.py`
Executable source-force authority calculation. It reconstructs the published stellar and gas surface-density laws, evaluates the finite-thickness source in two independent ways, and solves the fiducial CPTG field using the locked galaxy source coefficients: gas `27/50` and stellar disk `23/50`.

### `CPTG_AGC114905_SourceAuthorityClosure_20260902_r03_FIDUCIAL.csv`
Machine-readable fiducial five-ring output from the source-authority calculation. It records the adopted radii, observed velocities and uncertainties, direct stellar and gas component speeds, ordinary baryonic speed, locked-weight CPTG source speed, and CPTG prediction.

### `CPTG_AGC114905_SourceAuthorityClosure_20260902_r03_REPORT.txt`
Publication-facing source-authority report containing the independent force-solver cross-check and retained fiducial CPTG result.

## Coupled observational-uncertainty audit

### `CPTG_AGC114905_CoupledUncertaintyAudit_20260902_r02.py`
Executable Monte Carlo audit. It propagates the adopted distance, inclination, stellar normalization, gas normalization, and five-ring velocity uncertainties. Every realization evaluates the same sampled galaxy with baryon-only dynamics, simple-interpolation MOND with fixed universal `a0 = 1.2e-10 m/s^2`, and CPTG with one object-dependent `a_star`. The comparison uses the manuscript's matched-source five-ring `BICdiag` convention.

### `CPTG_AGC114905_CoupledUncertaintyAudit_20260902_r02_COMBINED.csv`
The 10,000 combined uncertainty realizations used for the reported `a_star` distribution and matched-source diagnostic comparison.

### `CPTG_AGC114905_CoupledUncertaintyAudit_20260902_r02_REPORT.txt`
Publication-facing uncertainty report. It presents the model comparison as counts of realizations with the lowest `BICdiag` for CPTG, baryon-only dynamics, and simple-interpolation MOND.

## Stellar outer-tail sensitivity

### `CPTG_AGC114905_StellarOuterTailSensitivity_20260902_r01.py`
Standalone current-authority audit of the radial integration extent of the published stellar poly-exponential source. It uses the same direct GALPYNAMICS-equivalent source solver and locked CPTG coefficients as the fiducial authority calculation.

### `CPTG_AGC114905_StellarOuterTailSensitivity_20260902_r01.csv`
Machine-readable results for the adopted `2*Rmax` stellar integration extent and three alternate outer-tail bounds.

### `CPTG_AGC114905_StellarOuterTailSensitivity_20260902_r01_REPORT.txt`
Summary of the outer-tail sensitivity. Across the tested alternate bounds, the largest change in inferred `a_star` is below 0.4%, leaving the low-response result unchanged.

## Structural Mode audit

### `CPTG_AGC114905_StructuralModeResolvedAudit_20260902_r02.py`
Executable post-solution Structural Mode calculation. It evaluates continuous Structural Mode `N` from the resolved CPTG field after the dynamical solution is selected, using the outermost observed tilted ring as the readout radius.

### `CPTG_AGC114905_StructuralModeResolvedAudit_20260902_r02_DRAWS.csv`
The 10,000 uncertainty realizations with their derived Structural Mode `N`, structural length, and CSMI label.

### `CPTG_AGC114905_StructuralModeResolvedAudit_20260902_r02_REPORT.txt`
Publication-facing Structural Mode report containing the fiducial result, convergence checks, uncertainty distribution, CSMI occupancy, and sensitivity analysis.

## Publication artifact assembly

### `CPTG_AGC114905_PublicationArtifactAssembly_20260902_r01.py`
Deterministic assembly script that consumes the audit outputs and regenerates the publication-facing five-ring table and Figures 1-3. It performs no new fit or scientific inference.

### `CPTG_AGC114905_FinalFiducialFiveRingTable_20260902_r03.csv`
Publication-facing five-ring table assembled directly from the source-authority output. It includes the ordinary baryonic response, CPTG prediction and residuals, and the simple-interpolation MOND prediction with fixed universal `a0`.

### `CPTG_AGC114905_FiducialRotationCurve_20260902_r05.png`
Publication Figure 1: observed circular speeds, ordinary baryonic response, CPTG prediction, and simple-interpolation MOND prediction.

### `CPTG_AGC114905_AstarUncertainty_20260902_r03.png`
Publication Figure 2: combined 10,000-realization distribution of the inferred CPTG structural acceleration scale `a_star`.

### `CPTG_AGC114905_StructuralModeDistribution_20260902_r03.png`
Publication Figure 3: continuous Structural Mode `N` distribution with the fiducial CPTG value and current CSMI boundaries.

## Integrity and package QA

### `CPTG_AGC114905_PublicationEvidence_20260902_r03_QA.txt`
Machine-readable closure summary for the publication archive, including principal numerical checks and public-language checks.

### `SHA256SUMS.txt`
SHA-256 identity of every other file in the archive.

## Reproduction sequence

1. Run `CPTG_AGC114905_SourceAuthorityClosure_20260902_r03.py`.
2. Run `CPTG_AGC114905_CoupledUncertaintyAudit_20260902_r02.py`.
3. Run `CPTG_AGC114905_StellarOuterTailSensitivity_20260902_r01.py`.
4. Run `CPTG_AGC114905_StructuralModeResolvedAudit_20260902_r02.py`.
5. Run `CPTG_AGC114905_PublicationArtifactAssembly_20260902_r01.py` to regenerate the final table and figures.

The coupled uncertainty calculation is the longest step. The packaged combined CSV is the retained deterministic result from the declared seeds. The observational source quantities and external theory references are documented in the manuscript and its cited literature.
