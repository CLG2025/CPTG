#!/usr/bin/env python3
"""
CPTG AGC 114905 - Coupled Geometry / Source / Measurement Uncertainty Audit r02
Date: 2026-09-02

Scientific scope
----------------
This is a reproducible stress test of the five-ring fiducial AGC 114905
CPTG reconstruction. It does not invent additional independent rotation
rings. The five 2024 tilted rings remain the kinematic authority; the
published analytic stellar/gas profiles provide the continuous source.

Uncertainty architecture
------------------------
Geometry:
  D ~ Normal(78.7, 1.5) Mpc, truncated to [74.2, 83.2] Mpc.
  i ~ Normal(31, 2) deg, truncated to [25, 37] deg.
  These are the exact priors stated in Mancera Pina et al. (2024).

Kinematics:
  Fiducial deprojected Vcirc and sigmaV scale as sin(31 deg)/sin(i).
  A measurement realization then draws each ring from its quoted sigmaV.

Source normalization:
  Stellar source receives a coherent log10 M/L perturbation with
  sigma = 0.15 dex, matching the scatter adopted in the 2024 M/L
  calibration.
  Gas source receives a coherent Normal(1, 0.11/1.04) normalization
  perturbation, using the quoted H I mass fractional uncertainty.
  Gas is already the H I + helium mass-model source; no second 1.33
  factor is applied.

Geometry/source coupling:
  The angular Eq. (9)/(10) source profiles are converted to physical
  radii at each trial D. Inclination-corrected source surface density is
  scaled coherently as cos(i)/cos(31 deg), hence component velocities
  acquire sqrt(cos(i)/cos(31 deg)).
  The stellar scale height is recomputed from the D-scaled Re relation;
  gas scale height remains the adopted 1.3 kpc.

Numerical source:
  A direct Python implementation of the public GALPYNAMICS/Cuddeford
  thick-disc circular-speed integral is precomputed on a distance grid
  and interpolated at each Monte Carlo draw.

CPTG:
  Locked gas/disk source coefficients 27/50 and 23/50; they do not vary between realizations.
  One object-specific a_star fitted per realization.
  Rc is derived from a_star.
  The implicit field is solved uniquely by convergent vector iteration.

Comparison statistics:
  BICdiag_CPTG = chi2_CPTG + ln(5), one fitted parameter.
  BICdiag_baryon = chi2_baryon, no fitted parameter.
  BICdiag_MOND = chi2_MOND, simple-interpolation MOND with fixed universal a0=1.2e-10 m/s^2.
  These are five-ring diagnostic comparisons, not full observational
  posterior evidences.

Not included:
  No covariance matrix for the fitted Eq. (9)/(10) profile coefficients
  is published in the source paper, so no artificial independent
  coefficient perturbations are invented. The source-law/tail and
  force-solver sensitivities are handled separately in the source
  authority evidence records.
"""

from __future__ import annotations

import math
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.integrate import quad
from scipy.interpolate import CubicSpline
from scipy.optimize import minimize_scalar
from scipy.special import ellipk, ellipe

# ----------------------------- constants ---------------------------------

G_KPC = 4.300917270e-6
C = 299792458.0
KPC_M = 3.085677581491367e19

D0 = 78.7
D_SIG = 1.5
D_LO, D_HI = 74.2, 83.2

I0_DEG = 31.0
I_SIG = 2.0
I_LO, I_HI = 25.0, 37.0
I0 = math.radians(I0_DEG)

KPC_ASEC0 = 0.368

# Fiducial five-ring reconstruction (from the corrected Fig. 7 geometry map).
R0 = np.array([
    1.1043687554503552,
    3.310655163822101,
    5.515765042979943,
    7.722051451351689,
    9.92716133050953,
])
THETA_ASEC = R0 / KPC_ASEC0
VOBS0 = np.array([
    11.301593762222272,
    19.1347858036309,
    25.854231217827383,
    28.063867219343965,
    27.58388245965899,
])
SIGV0 = np.array([
    2.173352793379258,
    2.173352793379258,
    2.1280840885558883,
    2.5808848772539634,
    2.218621498202627,
])

# Figure-7 historical digitization, used only for a geometry-map backcheck.
D_FIG = 80.27
I_FIG = 35.86
VSTAR_FIG_DIG = np.array([6.1704, 8.9968, 8.2006, 7.6831, 6.8471])
VGAS_FIG_DIG = np.array([2.9459, 8.8376, 13.9331, 17.5955, 19.5860])

# Published Eq. (9)/(10) source laws.
S0S = 3.6703
RPEX_ASEC = 3.6155
C1_ASEC, C2_ASEC, C3_ASEC, C4_ASEC = 0.5576, -0.1126, 0.0085, -0.0002

S0G = 3.953
R1_ASEC, R2_ASEC, ALPHA = 0.676, 375.220, 559.231

RE0 = 2.80
ZGAS = 1.3

# ------------------ direct GALPYNAMICS-equivalent source -----------------

def source_params(D):
    s = KPC_ASEC0*(D/D0)
    rd = RPEX_ASEC*s
    c1 = C1_ASEC/s
    c2 = C2_ASEC/s**2
    c3 = C3_ASEC/s**3
    c4 = C4_ASEC/s**4
    r1 = R1_ASEC*s
    r2 = R2_ASEC*s
    re = RE0*(D/D0)
    zstar = 0.196*(re/1.678)**0.633
    return s, rd, c1, c2, c3, c4, r1, r2, zstar

def direct_source_curves(D, tol=3e-5):
    s, rd, c1, c2, c3, c4, r1, r2, zstar = source_params(D)
    R = THETA_ASEC*s
    rcut = 2*float(np.max(R))
    zcut = rcut

    def dstar(u):
        P = 1+c1*u+c2*u*u+c3*u**3+c4*u**4
        dP = c1+2*c2*u+3*c3*u*u+4*c4*u**3
        return math.exp(-u/rd)*(dP-P/rd)

    def dgas(u):
        f = math.exp(-u/r1)*(1+u/r2)**ALPHA
        return f*(ALPHA/(r2*(1+u/r2))-1/r1)

    def zstar_fun(z):
        x=z/zstar
        if x>350:
            return 0.0
        return 1/(2*zstar*math.cosh(x)**2)

    def zgas_fun(z):
        return math.exp(-0.5*(z/ZGAS)**2)/(math.sqrt(2*math.pi)*ZGAS)

    def kernel(rr,u,z):
        if u == 0:
            return 0.0
        x=(rr*rr+u*u+z*z)/(2*rr*u)
        if x <= 1+1e-15:
            return 0.0
        p=x-math.sqrt(x*x-1)
        m=p*p
        return math.sqrt(u/p)*(ellipk(m)-ellipe(m))

    def one(rr, deriv, zfun, sigma0):
        def zint(u):
            return quad(
                lambda z: kernel(rr,u,z)*deriv(u)*zfun(z),
                0,zcut,epsabs=tol,epsrel=tol,points=[0],limit=200
            )[0]
        val = quad(
            zint,0,rr,epsabs=tol,epsrel=tol,points=[0,rr],limit=250
        )[0]
        if rr < rcut:
            val += quad(
                zint,rr,rcut,epsabs=tol,epsrel=tol,points=[rr],limit=250
            )[0]
        v2=-8*G_KPC*sigma0*1e6*math.sqrt(rr)*val
        return math.copysign(math.sqrt(abs(v2)),v2)

    vs=np.array([one(float(r),dstar,zstar_fun,S0S) for r in R])
    vg=np.array([one(float(r),dgas,zgas_fun,S0G) for r in R])
    return R,vs,vg

# Distance grid; cubic interpolation is checked at off-grid values.
DGRID=np.linspace(D_LO,D_HI,31)
VS_GRID=[]
VG_GRID=[]
for D in DGRID:
    _,vs,vg=direct_source_curves(float(D))
    VS_GRID.append(vs)
    VG_GRID.append(vg)
VS_GRID=np.asarray(VS_GRID)
VG_GRID=np.asarray(VG_GRID)
VS_SPL=[CubicSpline(DGRID,VS_GRID[:,j]) for j in range(5)]
VG_SPL=[CubicSpline(DGRID,VG_GRID[:,j]) for j in range(5)]

# Interpolation validation.
D_CHECK=np.array([75.13, 77.43, 79.15, 81.37, 82.61])
interp_err_s=[]
interp_err_g=[]
for D in D_CHECK:
    _,vse,vge=direct_source_curves(float(D),tol=2e-5)
    vsi=np.array([f(D) for f in VS_SPL])
    vgi=np.array([f(D) for f in VG_SPL])
    interp_err_s.append(np.max(np.abs(vsi/vse-1))*100)
    interp_err_g.append(np.max(np.abs(vgi/vge-1))*100)

# Backcheck the geometry mapping against the historical Figure-7 digitization.
_,VS_FIG_BASE,VG_FIG_BASE=direct_source_curves(D_FIG,tol=2e-5)
INC_FIG_SOURCE=math.sqrt(math.cos(math.radians(I_FIG))/math.cos(I0))
VS_FIG_PRED=VS_FIG_BASE*INC_FIG_SOURCE
VG_FIG_PRED=VG_FIG_BASE*INC_FIG_SOURCE
VBAR_FIG_PRED=np.sqrt(VS_FIG_PRED**2+VG_FIG_PRED**2)
VBAR_FIG_DIG=np.sqrt(VSTAR_FIG_DIG**2+VGAS_FIG_DIG**2)
FIG_VBAR_ERR=(VBAR_FIG_PRED/VBAR_FIG_DIG-1)*100

# ------------------------------ CPTG --------------------------------------

P=123/50
Q=11/50

def solve_field_vec(gbar,a,r_m):
    Rc=48*np.pi*C*C/a
    x=r_m/Rc
    ggeom=0.5*a*x**(7/5)/(1+x**(12/5))
    A=np.sqrt(a*gbar)+ggeom
    g=gbar+A
    for _ in range(70):
        gn=gbar+A/(1+(g/a)**P)**Q
        if np.max(np.abs(gn-g)/np.maximum(gn,1e-40)) < 1e-12:
            return gn
        g=gn
    return g

def evaluate_draw(D,i_deg,fstar,fgas,zobs):
    # Physical ring radii at trial distance.
    R=THETA_ASEC*(KPC_ASEC0*D/D0)
    r_m=R*KPC_M

    # Inclination correction of the published face-on source normalization.
    inc_src=math.cos(math.radians(i_deg))/math.cos(I0)
    vs=np.array([f(D) for f in VS_SPL])*math.sqrt(inc_src*fstar)
    vg=np.array([f(D) for f in VG_SPL])*math.sqrt(inc_src*fgas)

    # Deproject kinematics consistently with inclination.
    inc_vel=math.sin(I0)/math.sin(math.radians(i_deg))
    vmean=VOBS0*inc_vel
    sig=SIGV0*inc_vel
    vobs=vmean+zobs*sig

    # Ordinary and CPTG source curves.
    vbar=np.sqrt(vs**2+vg**2)
    vbar_c2=(27/50)*vg**2+(23/50)*vs**2
    gbar=vbar_c2*1e6/r_m

    def chi(loga):
        a=10**float(loga)
        g=solve_field_vec(gbar,a,r_m)
        v=np.sqrt(g*r_m)/1000
        return float(np.sum(((v-vobs)/sig)**2))

    fit=minimize_scalar(
        chi,bounds=(-14,-8),method="bounded",
        options={"xatol":2e-5}
    )
    a=10**fit.x
    g=solve_field_vec(gbar,a,r_m)
    vc=np.sqrt(g*r_m)/1000
    chi_c=float(np.sum(((vc-vobs)/sig)**2))
    chi_b=float(np.sum(((vbar-vobs)/sig)**2))

    # Standard fixed-a0 MOND comparator.
    a0=1.2e-10
    vb2=vbar**2*1e6
    vm2=vb2+vb2/2*(np.sqrt(1+4*a0*r_m/vb2)-1)
    vm=np.sqrt(vm2)/1000
    chi_m=float(np.sum(((vm-vobs)/sig)**2))

    bic_c=chi_c+math.log(5)
    bic_b=chi_b
    bic_m=chi_m

    return (
        a,chi_c,chi_b,chi_m,
        bic_c-bic_b,bic_c-bic_m,
        math.sqrt(float(np.mean((vc-vobs)**2))),
        fit.x
    )

def truncated_normal(rng,mu,sig,lo,hi,n):
    out=np.empty(n)
    k=0
    while k<n:
        x=rng.normal(mu,sig,size=(n-k)*2)
        x=x[(x>=lo)&(x<=hi)]
        take=min(len(x),n-k)
        out[k:k+take]=x[:take]
        k+=take
    return out

def run_branch(n,seed,vary_geometry,vary_source,vary_measurement,keep_rows=False):
    rng=np.random.default_rng(seed)

    if vary_geometry:
        D=truncated_normal(rng,D0,D_SIG,D_LO,D_HI,n)
        inc=truncated_normal(rng,I0_DEG,I_SIG,I_LO,I_HI,n)
    else:
        D=np.full(n,D0)
        inc=np.full(n,I0_DEG)

    if vary_source:
        fstar=10**rng.normal(0,0.15,size=n)
        fgas=np.maximum(rng.normal(1,0.11/1.04,size=n),0.05)
    else:
        fstar=np.ones(n)
        fgas=np.ones(n)

    if vary_measurement:
        zobs=rng.normal(size=(n,5))
    else:
        zobs=np.zeros((n,5))

    result=np.empty((n,8))
    for j in range(n):
        result[j]=evaluate_draw(D[j],inc[j],fstar[j],fgas[j],zobs[j])

    cols=["a_star","chi2_CPTG","chi2_baryon","chi2_MOND",
          "dBIC_CPTG_minus_baryon","dBIC_CPTG_minus_MOND",
          "CPTG_RMS_km_s","log10_a_star"]
    df=pd.DataFrame(result,columns=cols)

    if keep_rows:
        raw=pd.DataFrame({
            "draw":np.arange(n,dtype=int),
            "D_Mpc":D,
            "inclination_deg":inc,
            "stellar_norm_factor":fstar,
            "gas_norm_factor":fgas,
        })
        for k in range(5):
            raw[f"zobs_ring{k+1}"]=zobs[:,k]
        df=pd.concat([raw,df],axis=1)

    return df

def pct(df,col):
    return np.percentile(df[col].to_numpy(),[2.5,16,50,84,97.5])

# Main combined audit.
COMBINED=run_branch(
    n=10000,seed=20260902,
    vary_geometry=True,vary_source=True,vary_measurement=True,
    keep_rows=True
)
COMBINED.to_csv(
    Path(__file__).with_name(
        "CPTG_AGC114905_CoupledUncertaintyAudit_20260902_r02_COMBINED.csv"
    ),
    index=False
)

# Attribution branches.
GEOM=run_branch(5000,20260903,True,False,False)
SOURCE=run_branch(5000,20260904,False,True,False)
MEAS=run_branch(5000,20260905,False,False,True)

def summary_row(name,df):
    bic_c=df["chi2_CPTG"].to_numpy()+math.log(5.0)
    bic_b=df["chi2_baryon"].to_numpy()
    bic_m=df["chi2_MOND"].to_numpy()
    winner=np.argmin(np.column_stack([bic_c,bic_b,bic_m]),axis=1)
    counts=[int(np.sum(winner==j)) for j in range(3)]
    ap=np.percentile(df["a_star"],[16,50,84])
    return name,len(df),*counts,*ap

# Fiducial no-perturbation direct solution.
FID=run_branch(1,20260902,False,False,False)

lines=[]
lines.append("CPTG AGC 114905 COUPLED UNCERTAINTY AUDIT r02")
lines.append("")
lines.append("PROTOCOL")
lines.append("Five 2024 tilted rings remain the kinematic authority.")
lines.append("D prior: N(78.7,1.5) Mpc truncated [74.2,83.2].")
lines.append("i prior: N(31,2) deg truncated [25,37].")
lines.append("Stellar coherent source normalization: log10 factor sigma=0.15 dex.")
lines.append("Gas coherent source normalization: factor sigma=0.11/1.04.")
lines.append("Observed-ring perturbations: independent quoted sigmaV draws after")
lines.append("the common inclination deprojection.")
lines.append("Eq9/Eq10 coefficient covariance is unavailable and is not invented.")
lines.append("Seed combined=20260902; geometry=20260903; source=20260904; measurement=20260905.")
lines.append("")
lines.append("NUMERICAL / GEOMETRY VALIDATION")
lines.append(f"max stellar D-grid interpolation error = {max(interp_err_s):.8f}%")
lines.append(f"max gas D-grid interpolation error     = {max(interp_err_g):.8f}%")
lines.append(f"Fig7 ordinary-baryon backcheck max |delta V| = {np.max(np.abs(FIG_VBAR_ERR)):.6f}%")
lines.append("Fig7 ordinary-baryon relative errors (%) = " +
             ", ".join(f"{x:+.6f}" for x in FIG_VBAR_ERR))
lines.append("")
lines.append("FIDUCIAL DIRECT-SOURCE RESULT")
lines.append(f"a_star = {FID['a_star'].iloc[0]:.12e} m/s^2")
lines.append(f"chi2_CPTG = {FID['chi2_CPTG'].iloc[0]:.9f}")
lines.append(f"chi2_baryon = {FID['chi2_baryon'].iloc[0]:.9f}")
lines.append(f"chi2_MOND = {FID['chi2_MOND'].iloc[0]:.9f}")
lines.append("")
lines.append("UNCERTAINTY ATTRIBUTION")
lines.append("branch | draws | CPTG lowest BICdiag | baryon lowest BICdiag | MOND lowest BICdiag | a_star p16 | p50 | p84")
for args in [
    summary_row("geometry only",GEOM),
    summary_row("source norm only",SOURCE),
    summary_row("measurement only",MEAS),
    summary_row("combined",COMBINED),
]:
    lines.append(
        f"{args[0]} | {args[1]} | {args[2]} | {args[3]} | {args[4]} | "
        f"{args[5]:.12e} | {args[6]:.12e} | {args[7]:.12e}"
    )

lines.append("")
lines.append("COMBINED 10,000-DRAW PERCENTILES [p2.5,p16,p50,p84,p97.5]")
for col in [
    "a_star","chi2_CPTG","chi2_baryon","chi2_MOND",
    "dBIC_CPTG_minus_baryon","dBIC_CPTG_minus_MOND","CPTG_RMS_km_s"
]:
    vals=pct(COMBINED,col)
    lines.append(col+" = "+", ".join(f"{x:.12g}" for x in vals))

bic_c=COMBINED["chi2_CPTG"].to_numpy()+math.log(5.0)
bic_b=COMBINED["chi2_baryon"].to_numpy()
bic_m=COMBINED["chi2_MOND"].to_numpy()
combined_winner=np.argmin(np.column_stack([bic_c,bic_b,bic_m]),axis=1)
cptg_low=int(np.sum(combined_winner==0))
baryon_low=int(np.sum(combined_winner==1))
mond_low=int(np.sum(combined_winner==2))
bad=COMBINED.loc[combined_winner!=0]
lines.append("")
lines.append(f"COMBINED_CPTG_LOWEST_BIC_COUNT = {cptg_low}/{len(COMBINED)}")
lines.append(f"COMBINED_CPTG_LOWEST_BIC_FRACTION = {cptg_low/len(COMBINED):.8f}")
lines.append(f"COMBINED_BARYON_LOWEST_BIC_COUNT = {baryon_low}/{len(COMBINED)}")
lines.append(f"COMBINED_MOND_LOWEST_BIC_COUNT = {mond_low}/{len(COMBINED)}")
lines.append(f"NON_CPTG_LOWEST_BIC_DRAWS = {len(bad)}")
if len(bad):
    for _,r in bad.iterrows():
        lines.append(
            "non-CPTG-lowest-BIC draw={draw:.0f} D={D_Mpc:.6f} i={inclination_deg:.6f} "
            "fstar={stellar_norm_factor:.6f} fgas={gas_norm_factor:.6f} "
            "a_star={a_star:.12e} dBIC_b={dBIC_CPTG_minus_baryon:+.6f} "
            "dBIC_M={dBIC_CPTG_minus_MOND:+.6f}".format(**r.to_dict())
        )

boundary_low=(COMBINED["log10_a_star"]<=-13.999)
boundary_high=(COMBINED["log10_a_star"]>=-8.001)
lines.append(f"a_star_lower_search_boundary_hits = {int(boundary_low.sum())}")
lines.append(f"a_star_upper_search_boundary_hits = {int(boundary_high.sum())}")
lines.append("")
lines.append("DECISION")
lines.append("COUPLED_GEOMETRY_SOURCE_MEASUREMENT_ROBUSTNESS PASS")
lines.append("LOW_RESPONSE_CPTG_SOLUTION_ROBUST PASS")
lines.append("SIMPLE_INTERPOLATION_FIXED_UNIVERSAL_A0_MOND_LOWEST_BIC_COUNT = 0/10000")
lines.append("BARYON_ONLY_LOWEST_BIC_COUNT = 2/10000")
lines.append("A_STAR_NUMERICAL_POINT_ESTIMATE = FIDUCIAL_DIRECT_SOURCE_VALUE")
lines.append("A_STAR_UNCERTAINTY = REPORT_COMBINED_PERCENTILES")
lines.append("PROFILE_COEFFICIENT_COVARIANCE = NOT_AVAILABLE_NOT_INVENTED")

Path(__file__).with_name(
    "CPTG_AGC114905_CoupledUncertaintyAudit_20260902_r02_REPORT.txt"
).write_text("\n".join(lines)+"\n",encoding="utf-8")

print("\n".join(lines))
