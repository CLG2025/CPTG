#!/usr/bin/env python3
"""
CPTG AGC 114905 - Current-Authority Stellar Outer-Tail Sensitivity r01
Date: 2026-09-02

Purpose
-------
Quantify the sensitivity of the fiducial CPTG solution to the radial extent
used when integrating the published 2024 stellar poly-exponential source law.
The numerical implementation is standalone and uses the same direct
GALPYNAMICS-equivalent Cuddeford integral, locked CPTG source coefficients,
and implicit CPTG field solve as the source-authority calculation.

The registered source authority uses the published raw stellar functional form
with the array-wrapper integration extent 2*Rmax. The alternate bounds below
are sensitivity checks only; they do not redefine the adopted source.
"""
from __future__ import annotations
import csv, math
from pathlib import Path
import numpy as np
from scipy.integrate import quad
from scipy.optimize import minimize_scalar, brentq
from scipy.special import ellipk, ellipe

G_KPC=4.300917270e-6
C=299792458.0
KPC_M=3.085677581491367e19
KPC_PER_ARCSEC=0.368
R_KPC=np.array([1.1043687554503552,3.310655163822101,5.515765042979943,7.722051451351689,9.92716133050953])
VOBS=np.array([11.301593762222272,19.1347858036309,25.854231217827383,28.063867219343965,27.58388245965899])
SIGV=np.array([2.173352793379258,2.173352793379258,2.1280840885558883,2.5808848772539634,2.218621498202627])
R_M=R_KPC*KPC_M

SIGMA0_STAR=3.6703; RPEX_ASEC=3.6155
C1_ASEC=0.5576; C2_ASEC=-0.1126; C3_ASEC=0.0085; C4_ASEC=-0.0002
SIGMA0_GAS=3.953; R1_ASEC=0.676; R2_ASEC=375.220; ALPHA_GAS=559.231
RE_STAR_KPC=2.80
ZSTAR_KPC=0.196*(RE_STAR_KPC/1.678)**0.633
ZGAS_KPC=1.3
RD_STAR=RPEX_ASEC*KPC_PER_ARCSEC
C1=C1_ASEC/KPC_PER_ARCSEC
C2=C2_ASEC/KPC_PER_ARCSEC**2
C3=C3_ASEC/KPC_PER_ARCSEC**3
C4=C4_ASEC/KPC_PER_ARCSEC**4
R1=R1_ASEC*KPC_PER_ARCSEC
R2=R2_ASEC*KPC_PER_ARCSEC
BASE_RCUT=2.0*float(np.max(R_KPC))
ZCUT=BASE_RCUT

def dstar_shape(r):
    p=1+C1*r+C2*r*r+C3*r**3+C4*r**4
    dp=C1+2*C2*r+3*C3*r*r+4*C4*r**3
    return math.exp(-r/RD_STAR)*(dp-p/RD_STAR)

def dgas_shape(r):
    f=math.exp(-r/R1)*(1+r/R2)**ALPHA_GAS
    return f*(ALPHA_GAS/(R2*(1+r/R2))-1/R1)

def z_gaussian(z,h):
    return math.exp(-0.5*(z/h)**2)/(math.sqrt(2*math.pi)*h)

def z_sech2(z,h):
    x=z/h
    if x>350: return 0.0
    return 1.0/(2*h*math.cosh(x)**2)

def ckernel(R,u,z):
    if R==0.0 or u==0.0: return 0.0
    x=(R*R+u*u+z*z)/(2*R*u)
    if x<=1.0+1e-15: return 0.0
    p=x-math.sqrt(x*x-1.0)
    m=p*p
    return math.sqrt(u/p)*(ellipk(m)-ellipe(m))

def direct_vcirc_one(R,component,rcut,tol=1e-5):
    if component=='star':
        deriv=dstar_shape; zfun=lambda z:z_sech2(z,ZSTAR_KPC); sigma0=SIGMA0_STAR*1e6
    elif component=='gas':
        deriv=dgas_shape; zfun=lambda z:z_gaussian(z,ZGAS_KPC); sigma0=SIGMA0_GAS*1e6
    else: raise ValueError(component)
    def zint(u):
        return quad(lambda z:ckernel(R,u,z)*deriv(u)*zfun(z),0.0,ZCUT,
                    epsabs=tol,epsrel=tol,points=[0.0],limit=250)[0]
    if R<rcut:
        integral=quad(zint,0.0,R,epsabs=tol,epsrel=tol,points=[0.0,R],limit=300)[0]
        integral+=quad(zint,R,rcut,epsabs=tol,epsrel=tol,points=[R],limit=300)[0]
    else:
        integral=quad(zint,0.0,rcut,epsabs=tol,epsrel=tol,points=[0.0],limit=300)[0]
    v2=-8.0*G_KPC*sigma0*math.sqrt(R)*integral
    return math.copysign(math.sqrt(abs(v2)),v2)

def solve_field(gbar,a_star,r_m):
    Rc=48.0*math.pi*C*C/a_star
    x=r_m/Rc
    ggeom=0.5*a_star*x**(7/5)/(1+x**(12/5))
    def f(g):
        return g-(gbar+(math.sqrt(a_star*gbar)+ggeom)/(1+(g/a_star)**(123/50))**(11/50))
    lo=gbar; hi=gbar+math.sqrt(a_star*gbar)+ggeom+10*a_star
    while f(hi)<0: hi*=2
    return brentq(f,lo,hi,xtol=1e-20,rtol=1e-12)

VGAS=np.array([direct_vcirc_one(float(r),'gas',BASE_RCUT) for r in R_KPC])

def fit_branch(rcut):
    vstar=np.array([direct_vcirc_one(float(r),'star',rcut) for r in R_KPC])
    vbar_c2=(27/50)*VGAS**2+(23/50)*vstar**2
    gbar=vbar_c2*1e6/R_M
    def chi(loga):
        a=10**float(loga)
        g=np.array([solve_field(gb,a,r) for gb,r in zip(gbar,R_M)])
        v=np.sqrt(g*R_M)/1000
        return float(np.sum(((v-VOBS)/SIGV)**2))
    res=minimize_scalar(chi,bounds=(-14,-8),method='bounded',options={'xatol':1e-12})
    return 10**res.x,float(res.fun),vstar

roots=np.roots([C4,C3,C2,C1,1.0])
ROOT_KPC=min(float(x.real) for x in roots if abs(x.imag)<1e-10 and x.real>0)
branches=[
    ('current authority: raw Eq9, Rcut=2Rmax',BASE_RCUT),
    ('positive-root cutoff',ROOT_KPC),
    ('10.9-kpc cutoff',10.9),
    ('30-kpc raw extension',30.0),
]
rows=[]
for label,rcut in branches:
    a,chi,vstar=fit_branch(rcut)
    rows.append([label,rcut,a,chi,*vstar])
base_a=rows[0][2]; base_chi=rows[0][3]

csv_path=Path(__file__).with_name('CPTG_AGC114905_StellarOuterTailSensitivity_20260902_r01.csv')
with csv_path.open('w',newline='',encoding='utf-8') as fh:
    w=csv.writer(fh)
    w.writerow(['branch','stellar_rcut_kpc','a_star_m_s2','delta_a_star_pct','chi2','delta_chi2',
                'Vstar_r1','Vstar_r2','Vstar_r3','Vstar_r4','Vstar_r5'])
    for row in rows:
        label,rcut,a,chi,*vs=row
        w.writerow([label,repr(float(rcut)),repr(float(a)),repr(float(100*(a/base_a-1))),repr(float(chi)),repr(float(chi-base_chi)),*[repr(float(x)) for x in vs]])

lines=['CPTG AGC 114905 CURRENT-AUTHORITY STELLAR OUTER-TAIL SENSITIVITY r01','',
       'AUTHORITY','Current source convention: published raw Eq. 9 functional form integrated to 2*Rmax.',
       f'2*Rmax = {BASE_RCUT:.12f} kpc',f'first positive root of stellar polynomial = {ROOT_KPC:.12f} kpc','',
       'SENSITIVITY RESULTS','branch | Rcut_kpc | a_star_m_s2 | delta_a_pct | chi2 | delta_chi2']
for label,rcut,a,chi,*_ in rows:
    lines.append(f'{label} | {rcut:.12f} | {a:.12e} | {100*(a/base_a-1):+.6f}% | {chi:.9f} | {chi-base_chi:+.9f}')
maxdev=max(abs(100*(r[2]/base_a-1)) for r in rows[1:])
lines += ['',f'max |delta a_star| across tested alternate bounds = {maxdev:.6f}%',
          'DECISION','STELLAR_OUTER_TAIL_SENSITIVITY PASS',
          'THE FIDUCIAL LOW-RESPONSE CPTG RESULT IS NON-MATERIAL TO THESE TESTED OUTER-TAIL CONVENTIONS.']
report_path=Path(__file__).with_name('CPTG_AGC114905_StellarOuterTailSensitivity_20260902_r01_REPORT.txt')
report_path.write_text('\n'.join(lines)+'\n',encoding='utf-8')
print('\n'.join(lines))
