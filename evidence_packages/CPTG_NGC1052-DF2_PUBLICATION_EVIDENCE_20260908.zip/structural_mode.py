import math
import numpy as np
from scipy.interpolate import PchipInterpolator
from scipy.special import gammaincinv
from df2_solver import DF2Solver

KAPPA_STRUCT_KPC = 1.0

CSMI_INTERVALS = [
    (-math.inf, 1.45, 'Dwarf Irregular'),
    (1.45, 1.75, 'Magellanic Irregular'),
    (1.75, 1.95, 'LSB Dwarf Disk'),
    (1.95, 2.15, 'Transition Dwarf'),
    (2.15, 2.35, 'LSB Spiral'),
    (2.35, 2.55, 'Very Late Spiral'),
    (2.55, 2.80, 'Late Spiral'),
    (2.80, 3.05, 'Intermediate Spiral'),
    (3.05, 3.30, 'Early Spiral'),
    (3.30, 3.55, 'Bulged Spiral'),
    (3.55, 3.72, 'Lenticular/Early Disk'),
    (3.72, math.inf, 'High-Mode Outlier'),
]

def csmi_label(N):
    for lo, hi, label in CSMI_INTERVALS:
        if N <= hi and N > lo:
            return label
    raise ValueError(N)

def structural_mode(distance_mpc=17.6, re_arcsec=22.6, sersic_n=0.6,
                    lv_20mpc=1.1e8, ml_v=2.0, support_anchor_kms=9.2,
                    nr=8000, dense_points=100001):
    s = DF2Solver(distance_mpc=distance_mpc, re_arcsec=re_arcsec,
                  sersic_n=sersic_n, lv_20mpc=lv_20mpc, ml_v=ml_v,
                  support_anchor_kms=support_anchor_kms, nr=nr)
    x95 = (gammaincinv(2.0*s.n, 0.95)/s.bn)**s.n
    R95 = x95*s.re_kpc
    r0 = R95/5.0

    g = PchipInterpolator(s.r_kpc, s.gcptg_si)
    r = np.linspace(r0, R95, int(dense_points))
    gv = g(r)
    dgdr = g.derivative()(r)  # acceleration per kpc because r is in kpc
    Cg = gv*gv + (KAPPA_STRUCT_KPC*dgdr)**2

    # The registered weight is w=|dC_g/dr|.  For DF2 C_g has one turning
    # point on [R95/5,R95], so evaluate the total variation directly.
    dC = np.diff(Cg)
    dr_mid = 0.5*(r[:-1] + r[1:])
    variation = np.abs(dC)
    denominator = float(np.sum(variation))
    numerator = float(np.sum(dr_mid*variation))
    if not denominator > 0:
        raise RuntimeError('Structural weight is zero')
    lam = numerator/denominator
    N = R95/lam

    signs = np.sign(dC)
    idx = np.where(signs[:-1]*signs[1:] < 0)[0]
    turning = [float(r[i+1]) for i in idx]
    return {
        'distance_mpc': s.distance_mpc,
        're_arcsec': s.re_arcsec,
        'sersic_n': s.n,
        'ml_v': s.ml_v,
        'support_anchor_kms': s.support_anchor_kms,
        're_kpc': s.re_kpc,
        'R95_over_Re': float(x95),
        'R95_kpc': float(R95),
        'registered_inner_kpc': float(r0),
        'lambda_kpc': float(lam),
        'N': float(N),
        'CSMI_label': csmi_label(float(N)),
        'turning_point_count': len(turning),
        'turning_points_kpc': turning,
        'nr': int(nr),
        'dense_points': int(dense_points),
    }
