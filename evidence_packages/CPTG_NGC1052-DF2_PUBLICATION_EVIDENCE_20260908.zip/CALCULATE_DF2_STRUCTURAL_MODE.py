import csv, json, math
from pathlib import Path
from structural_mode import structural_mode

HERE=Path(__file__).resolve().parent

CASES = [
    ('primary','same-semimajor sphere',{}),
    ('geometry','area-preserving circularized radius',{'re_arcsec':22.6*math.sqrt(0.85)}),
    ('distance','D=17.0 Mpc',{'distance_mpc':17.0}),
    ('distance','D=18.2 Mpc',{'distance_mpc':18.2}),
    ('stellar_ML','M/L_V=1.5',{'ml_v':1.5}),
    ('stellar_ML','M/L_V=2.5',{'ml_v':2.5}),
    ('support_anchor','sigma_MUSE=4.7 km/s',{'support_anchor_kms':4.7}),
    ('support_anchor','sigma_MUSE=13.0 km/s',{'support_anchor_kms':13.0}),
]

def main():
    rows=[]
    for group,label,kwargs in CASES:
        r=structural_mode(nr=8000,dense_points=100001,**kwargs)
        r['group']=group; r['case']=label; rows.append(r)
    primary=rows[0]
    (HERE/'structural_mode_primary.json').write_text(json.dumps(primary,indent=2,sort_keys=True),encoding='utf-8')
    fields=['group','case','distance_mpc','re_arcsec','sersic_n','ml_v','support_anchor_kms',
            're_kpc','R95_over_Re','R95_kpc','registered_inner_kpc','lambda_kpc','N','CSMI_label',
            'turning_point_count','turning_points_kpc','nr','dense_points']
    with (HERE/'structural_mode_results.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=fields); w.writeheader()
        for r in rows:
            rr=dict(r); rr['turning_points_kpc']=';'.join(f'{x:.12g}' for x in r['turning_points_kpc']); w.writerow(rr)
    print('STRUCTURAL MODE N')
    print(f"R95_kpc={primary['R95_kpc']:.12f}")
    print(f"lambda_kpc={primary['lambda_kpc']:.12f}")
    print(f"N={primary['N']:.12f}")
    print(f"CSMI_label={primary['CSMI_label']}")
    print(f"turning_points_kpc={primary['turning_points_kpc']}")

if __name__=='__main__': main()
