import csv, json, math
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt
from df2_solver import DF2Solver, SI_PER_KMS2_PER_KPC

HERE = Path(__file__).resolve().parent
A0 = 1.2e-10
VHOST_KMS = 210.0
D_DF2 = 17.6
D_HOST = 21.3
RA_HOST_DEG = 40.26999
DEC_HOST_DEG = -8.25576
RA_DF2_DEG = 40.44531
DEC_DF2_DEG = -8.40297

def angsep(ra1, dec1, ra2, dec2):
    ra1, dec1, ra2, dec2 = map(math.radians, (ra1, dec1, ra2, dec2))
    c = math.sin(dec1)*math.sin(dec2) + math.cos(dec1)*math.cos(dec2)*math.cos(ra1-ra2)
    return math.acos(max(-1.0, min(1.0, c)))

def mu(x):
    return x/(1.0+x)

def efe_field(gN_values, ge):
    out = np.empty_like(gN_values)
    mue = mu(ge/A0)
    for i,gN in enumerate(gN_values):
        rhs = gN + ge*mue
        def f(g):
            return (g+ge)*mu((g+ge)/A0)-rhs
        lo=0.0
        hi=max(10.0*A0,10.0*(gN+ge)+A0)
        while f(hi)<0.0:
            hi*=2.0
        for _ in range(200):
            mid=0.5*(lo+hi)
            if f(mid)>0.0:
                hi=mid
            else:
                lo=mid
        out[i]=0.5*(lo+hi)
    return out

s=DF2Solver(distance_mpc=17.6,re_arcsec=22.6,sersic_n=0.6,
            lv_20mpc=1.1e8,ml_v=2.0,support_anchor_kms=9.2,nr=800)

theta=angsep(RA_HOST_DEG,DEC_HOST_DEG,RA_DF2_DEG,DEC_DF2_DEG)
dsep_central_mpc=math.sqrt(D_DF2**2+D_HOST**2-2.0*D_DF2*D_HOST*math.cos(theta))
dsep_codist_kpc=D_DF2*1000.0*theta
KPC_M=3.085677581491367e19
MPC_M=3.085677581491367e22
v=VHOST_KMS*1000.0
ge_central=v*v/(dsep_central_mpc*MPC_M)
ge_codist=v*v/(dsep_codist_kpc*KPC_M)

gN_si=s.gstar_k*SI_PER_KMS2_PER_KPC
giso_si=0.5*(gN_si+np.sqrt(gN_si*gN_si+4.0*A0*gN_si))
gefe_central_si=efe_field(gN_si,ge_central)
gefe_codist_si=efe_field(gN_si,ge_codist)

giso_k=giso_si/SI_PER_KMS2_PER_KPC
gefe_central_k=gefe_central_si/SI_PER_KMS2_PER_KPC
gefe_codist_k=gefe_codist_si/SI_PER_KMS2_PER_KPC

aps=np.linspace(0.15,2.20,42)
b=np.array([s.aperture_second_moment(s.gstar_k,0.0,float(a),121) for a in aps])
c=np.array([s.aperture_second_moment(s.gcptg_k,0.0,float(a),121) for a in aps])
mi=np.array([s.aperture_second_moment(giso_k,0.0,float(a),121) for a in aps])
mec=np.array([s.aperture_second_moment(gefe_central_k,0.0,float(a),121) for a in aps])
meco=np.array([s.aperture_second_moment(gefe_codist_k,0.0,float(a),121) for a in aps])

with (HERE/"NGC1052-DF2_observed_diffuse_stellar_comparison.csv").open("w",newline="",encoding="utf-8") as f:
    w=csv.writer(f)
    w.writerow(["R_over_Re","sigma_CPTG_kms","sigma_baryonic_kms",
                "sigma_MOND_EFE_codistance_kms",
                "sigma_MOND_EFE_central_distances_kms",
                "sigma_MOND_isolated_kms"])
    for row in zip(aps,c,b,meco,mec,mi):
        w.writerow(row)

fig,ax=plt.subplots(figsize=(10,7),dpi=240)
ax.plot(aps,c,color="tab:orange",linewidth=2.2,label="CPTG")
ax.plot(aps,b,color="tab:blue",linewidth=2.2,label="Baryonic / Newtonian")
ax.fill_between(aps,meco,mec,color="tab:green",alpha=0.15,label="MOND EFE geometry bracket")
ax.plot(aps,mec,color="tab:green",linewidth=2.2,label="MOND + EFE (central distances)")
ax.plot(aps,mi,color="tab:green",linewidth=1.8,linestyle="--",label="MOND isolated")
ax.errorbar([1.0],[9.2],yerr=np.array([[4.5],[3.8]]),fmt="o",color="tab:red",capsize=4,
            markersize=6,label=r"Observed MUSE within $R_e$")
ax.errorbar([0.7],[6.3],yerr=np.array([[3.7],[3.1]]),fmt="s",color="tab:purple",capsize=4,
            markersize=6,label="Observed KCWI diffuse light")
ax.axvline(1.0,color="tab:blue",linestyle="--",linewidth=1.0)
ax.axvline(0.7,color="tab:blue",linestyle=":",linewidth=1.0)
ax.text(1.012,0.035,r"$R_e$",transform=ax.get_xaxis_transform(),ha="left",va="bottom",fontsize=9)
ax.text(0.712,0.035,r"$0.7R_e$",transform=ax.get_xaxis_transform(),ha="left",va="bottom",fontsize=9)
primary=json.loads((HERE/"primary_result.json").read_text())
delta=float(primary["sigma_cptg_re_kms"]-9.2)
ax.annotate(r"$\Delta_{\rm cl}=-0.0050$ km s$^{-1}$"+"\n(shared-input closure)",
            xy=(1.0,float(np.interp(1.0,aps,c))),xytext=(1.08,10.35),fontsize=8.5,
            ha="left",va="bottom",arrowprops=dict(arrowstyle="-",linewidth=0.8))
ax.set_xlim(0.15,2.20); ax.set_ylim(4.0,25.0)
ax.set_xlabel(r"Circular aperture radius ($R/R_e$)")
ax.set_ylabel(r"Aperture-integrated line-of-sight dispersion $\sigma_{\rm ap}(<R)$ (km s$^{-1}$)")
ax.set_title("NGC 1052-DF2: observed diffuse-stellar comparison")
ax.grid(True,alpha=0.25); ax.legend(loc="upper right",frameon=True,fontsize=8.3)
ax.text(0.98,0.02,"Same-semimajor spherical reduction\n"
        r"MUSE sets the CPTG support scale $a_\star$"+"\n"
        "MOND EFE band is a geometry bracket, not a probability interval",
        transform=ax.transAxes,ha="right",va="bottom",fontsize=7.9)
fig.tight_layout()
fig.savefig(HERE/"NGC1052-DF2_observed_diffuse_stellar_comparison.png",bbox_inches="tight")
plt.close(fig)

result={
 "angular_separation_arcmin": math.degrees(theta)*60.0,
 "central_3d_separation_mpc": dsep_central_mpc,
 "codistance_projected_separation_kpc": dsep_codist_kpc,
 "gext_central_over_a0": ge_central/A0,
 "gext_codistance_over_a0": ge_codist/A0,
 "sigma_CPTG_curve_Re_kms": float(np.interp(1.0,aps,c)),
 "paper_primary_sigma_CPTG_Re_kms": float(primary["sigma_cptg_re_kms"]),
 "sigma_baryonic_Re_kms": float(np.interp(1.0,aps,b)),
 "sigma_MOND_EFE_codistance_Re_kms": float(np.interp(1.0,aps,meco)),
 "sigma_MOND_EFE_central_distances_Re_kms": float(np.interp(1.0,aps,mec)),
 "sigma_MOND_isolated_Re_kms": float(np.interp(1.0,aps,mi)),
 "delta_cl_kms": delta,
 "fractional_delta_cl": delta/9.2,
 "shared_normalized_delta_cl": delta/4.5
}
(HERE/"comparison_primary_result.json").write_text(json.dumps(result,indent=2,sort_keys=True),encoding="utf-8")
print(json.dumps(result,indent=2,sort_keys=True))
