# NGC 1052-DF2 Finite-Polarization Jeans Evidence Summary

## Observational inputs

Distance: D = 17.6 +/- 0.6 Mpc.

Stellar structure at the source reference distance: Sersic n = 0.6, projected b/a = 0.85, major-axis R_e = 22.6 arcsec, L_V = 1.10e+08 Lsun at 20 Mpc, and reference M_star/L_V = 2.0.

At 17.6 Mpc the stellar mass normalization is

M_star = 1.703680000e+08 Msun,

and the documented major-axis effective radius is

R_e = 1.928393087 kpc.

Keim et al. (2026) give the DF2 integrated-light dispersions used here:

MUSE: 9.2 (+3.8/-4.5) km/s,
KCWI: 6.3 (+3.1/-3.7) km/s.

## CPTG pressure-support anchor

Within the declared one-radius pressure-supported reduction,

a_star = sigma_MUSE^2 / R_e
       = 1.422425546792e-12 m/s^2.

This is a reduction-specific boundary anchor rather than a universal identity.

R_c = 48 pi c^2/a_star = 3.087823e+05 Gpc.

## Radial source and CPTG field

The primary radial calculation is a same-semimajor spherical reduction: the measured major-axis R_e is retained as the radial scale, the projected Sersic law is Abel-deprojected, and the density is normalized to the distance-scaled stellar mass.

The baryonic field is

g_star(r) = G M_star(<r)/r^2.

The CPTG field is solved independently at every radius from

g(r) = g_star(r) + [sqrt(a_star g_star(r)) + g_geom(r)]/[1+(g(r)/a_star)^(123/50)]^(11/50),

with

g_geom(r) = (1/2) a_star (r/R_c)^(7/5)/[1+(r/R_c)^(12/5)].

At R_e:

g_star = 1.946047179190e-12 m/s^2,
g_CPTG = 3.018348722384e-12 m/s^2,
g_CPTG/g_star = 1.551015183,
g_geom = 1.464754549482e-28 m/s^2.

The finite local response is polarization-dominated; the formal transport remnant is retained and negligible at this radius.

## Jeans and aperture projection

The complete solved radial field is passed through the spherical Jeans equation and projected into the aperture. No local field-ratio velocity rescaling is used.

Primary orbital case: beta_J = 0.

Stellar-source-only aperture moment:

sigma_star(<R_e) = 7.227669 km/s.

Finite-polarization CPTG aperture moment:

sigma_CPTG(<R_e) = 9.194999 km/s.

Difference from the MUSE pressure-support anchor:

-0.005001 km/s.

Because MUSE supplies the one-radius anchor used to determine a_star, this is a shared-input closure calculation, not a held-out prediction.

## Cross-instrument control

The centered circular 0.7 R_e control gives

sigma_CPTG(<0.7 R_e) = 9.457695 km/s.

Compared with the Keim et al. KCWI value 6.3 (+3.1/-3.7) km/s, this is 1.019 times the quoted upper-side 1-sigma uncertainty above the central value. It is therefore approximately a 1.02-sigma cross-instrument consistency result. The actual KCWI field is not represented by this centered circular control, so no exact KCWI-footprint prediction is claimed.

## Geometry sensitivity

The source paper identifies 22.6 arcsec as the major-axis R_e. The primary calculation retains that documented semimajor scale. As an area-preserving sensitivity, R_e,circ = R_e sqrt(b/a) = 20.836170 arcsec is also solved. Its outputs are recorded in sensitivity_results.csv.


## Structural Mode N

The retained solved CPTG radial field also supplies the registered post-solution Structural Mode. For the projected Sersic source, the 95-percent-light radius is

R95 = 4.294872689 kpc = 2.227176979 Re.

With

C_g(r) = g(r)^2 + kappa_struct^2 [dg(r)/dr]^2,

kappa_struct = 1 kpc,

w(r) = |dC_g/dr|,

lambda = integral[r w(r)dr]/integral[w(r)dr] on R95/5 <= r <= R95,

and N = R95/lambda, the primary solved field gives

lambda = 2.741171454 kpc,

N = 1.566801917.

The DF2 C_g profile has one turning point on the registered interval, at approximately 1.9603 kpc, so the absolute structural weight is integrated directly rather than using a monotone endpoint identity. The independent higher-resolution calculation gives N = 1.566801562.

Under the current CSMI interval map, 1.45 < N <= 1.75 corresponds to the descriptive label Magellanic Irregular. The continuous N value is the scientific readout; the CSMI name is not a visual morphology assignment. DF2 remains in this same low-mode interval under the distance, stellar-M/L, support-anchor, and circularized-radius sensitivities included in structural_mode_results.csv.

## Numerical verification

Mass closure = 1.
Production Abel reprojection maximum relative error = 1.173513e-07.
Production implicit-field maximum relative residual = 4.040021e-16.
Independent higher-resolution results are in VERIFY_OUTPUT.txt.

## Evidence claim

The diffuse stellar body of NGC 1052-DF2 admits a finite, low-response CPTG pressure-supported closure in a documented same-semimajor spherical reduction. The measured stellar mass is the material source; curvature polarization modifies the radial gravitational field; the formal geometric transport term is retained and locally negligible. No non-baryonic matter source and no Structural Mode N input enter the calculation; N is evaluated only after the radial field is solved.

The evidence supports this radial Jeans closure and its stated geometry sensitivities. It does not claim a completed arbitrary-geometry prolate CPTG field solution.


## MOND comparison figure update

This package also includes the paper figure `NGC1052-DF2_observed_diffuse_stellar_comparison.png`, its curve table `NGC1052-DF2_observed_diffuse_stellar_comparison.csv`, and `MOND_COMPARISON_METHOD.md`.
The paper figure distinguishes isolated MOND from a MOND external-field geometry bracket computed with the one-dimensional ansatz used by Famaey, McGaugh, and Milgrom (2018). The bracket spans a conditional co-distance strong-EFE case and the current central-distance weak-EFE case; it is not a probability interval.

## Observed-model comparison and closure residual

The paper figure now distinguishes the MOND external-field geometry from the
isolated limit.

At R_e:

- baryonic/Newtonian = 7.227678 km/s
- CPTG = 9.195009 km/s
- MOND EFE, conditional co-distance geometry = 13.221809 km/s
- MOND EFE, current central-distance geometry = 21.323995 km/s
- MOND isolated = 21.599894 km/s

The shaded MOND EFE region is a geometry bracket, not a probability interval.

The CPTG shared-input closure residual is

Delta_cl = -0.005000675 km/s
         = -0.054355 percent of the MUSE central value.

Because MUSE sets a_star, this residual is a closure diagnostic rather than a
held-out goodness-of-fit statistic.
