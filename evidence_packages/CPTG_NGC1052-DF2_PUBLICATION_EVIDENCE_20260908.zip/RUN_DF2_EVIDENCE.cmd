@echo off
setlocal
cd /d "%~dp0"
echo ============================================================
echo CPTG NGC 1052-DF2 PUBLICATION EVIDENCE
echo ============================================================
python CALCULATE_DF2_EVIDENCE.py
if errorlevel 1 exit /b 1
python CALCULATE_DF2_STRUCTURAL_MODE.py
if errorlevel 1 exit /b 1
python VERIFY_DF2_EVIDENCE.py > VERIFY_OUTPUT.txt
if errorlevel 1 exit /b 1
type VERIFY_OUTPUT.txt
echo.
echo COMPLETE
endlocal
