import json
from pathlib import Path
from df2_solver import DF2Solver
from structural_mode import structural_mode

HERE = Path(__file__).resolve().parent

def fail(msg):
    print('VERIFY FAIL:', msg)
    raise SystemExit(1)

def main():
    p = json.loads((HERE/'primary_result.json').read_text())
    s = DF2Solver(distance_mpc=17.6, re_arcsec=22.6, sersic_n=0.6,
                  lv_20mpc=1.1e8, ml_v=2.0, support_anchor_kms=9.2, nr=1000)
    star = s.aperture_second_moment(s.gstar_k, 0.0, 1.0, 121)
    cptg = s.aperture_second_moment(s.gcptg_k, 0.0, 1.0, 121)
    c07 = s.aperture_second_moment(s.gcptg_k, 0.0, 0.7, 121)
    reproj = s.reprojection_error(81)

    if abs(s.mass_closure-1.0) > 1e-8:
        fail(f'mass closure {s.mass_closure}')
    if reproj > 1e-5:
        fail(f'Abel reprojection error {reproj}')
    if s.max_root_residual > 1e-12:
        fail(f'CPTG root residual {s.max_root_residual}')
    for name, a, b in [
        ('sigma_star_Re', star, p['sigma_star_re_kms']),
        ('sigma_CPTG_Re', cptg, p['sigma_cptg_re_kms']),
        ('sigma_CPTG_0p7Re', c07, p['sigma_cptg_0p7re_kms'])]:
        if abs(a-b) > 0.01:
            fail(f'{name} production/high-resolution mismatch {a} vs {b}')

    stored_n = json.loads((HERE/'structural_mode_primary.json').read_text())
    high_n = structural_mode(nr=16000, dense_points=200001)
    if abs(high_n['N'] - stored_n['N']) > 5e-5:
        fail(f"Structural Mode mismatch {high_n['N']} vs {stored_n['N']}")
    if high_n['turning_point_count'] != 1:
        fail(f"unexpected Structural Mode turning-point count {high_n['turning_point_count']}")

    print('VERIFY PASS')
    print(f'highres_sigma_star_Re={star:.9f}')
    print(f'highres_sigma_CPTG_Re={cptg:.9f}')
    print(f'highres_sigma_CPTG_0p7Re={c07:.9f}')
    print(f'highres_mass_closure={s.mass_closure:.15g}')
    print(f'highres_reprojection_max_rel={reproj:.6e}')
    print(f'highres_root_max_rel={s.max_root_residual:.6e}')
    print(f"highres_structural_N={high_n['N']:.12f}")
    print(f"highres_structural_lambda_kpc={high_n['lambda_kpc']:.12f}")
    print(f"highres_structural_R95_kpc={high_n['R95_kpc']:.12f}")

if __name__ == '__main__':
    main()
