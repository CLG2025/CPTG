# MOND comparison method

The paper comparison figure uses the same DF2 stellar source and the same
isotropic Jeans/aperture projection for the baryonic, CPTG, and MOND curves.

## Isolated MOND

The isolated control uses

mu(x) = x/(1+x)

with

a0 = 1.2e-10 m s^-2.

At R_e the result is

sigma_MOND,iso(<R_e) = 21.599894 km/s.

## External-field geometry

The MOND EFE comparison uses the one-dimensional ansatz of
Famaey, McGaugh, and Milgrom (2018),

(g+g_e) mu[(g+g_e)/a0]
=
g_N + g_e mu(g_e/a0),

with the same host circular-speed prescription V = 210 km/s used in that work.

The current distance inputs are

DF2 = 17.6 +/- 0.6 Mpc,
NGC 1052 = 21.3 +/- 1.7 Mpc,

and their tabulated sky coordinates give an angular separation of
13.650869 arcmin.

Using the central distances gives a 3-D separation of

D_sep,central = 3.700799 Mpc,

and therefore

g_e,central/a0 = 0.00321819.

The corresponding Jeans aperture result is

sigma_MOND,EFE,central(<R_e) = 21.323995 km/s.

A conditional co-distance/minimum-separation geometry at 17.6 Mpc gives a
projected separation of

D_sep,codistance = 69.887431 kpc,

with

g_e,codistance/a0 = 0.17041496,

and

sigma_MOND,EFE,codistance(<R_e) = 13.221809 km/s.

The shaded green region in the paper is therefore a **geometry bracket** between
those two conditional cases. It is not a statistical confidence interval.

The original Famaey et al. 20-Mpc projected-separation calculation corresponds
to approximately 80 kpc and g_e approximately 0.15 a0. Their paper also states
that when internal and external fields are comparable, the one-dimensional
expression is an ansatz and the exact treatment requires a numerical MOND
Poisson solver.

## CPTG shared-input closure residual

At R_e,

Delta_cl = sigma_CPTG - sigma_MUSE
         = -0.005000675 km/s.

The fractional closure residual is

Delta_cl / sigma_MUSE = -5.435516511e-04
                      = -0.054246 percent.

A formal asymmetric-error normalization using the lower MUSE uncertainty is

z_cl,shared = -0.001111261

These are explicitly labeled **shared-input closure** quantities because the
same MUSE central value sets a_star. They are not held-out fit residuals and
must not be used as independent model-selection statistics.
