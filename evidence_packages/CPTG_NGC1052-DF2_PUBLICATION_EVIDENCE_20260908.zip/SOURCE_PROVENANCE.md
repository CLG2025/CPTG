# Source Provenance

## Distance
Yimeng Tang, Gagandeep S. Anand, Aaron J. Romanowsky, Pieter G. van Dokkum, Kevin A. Bundy.
"New Measurements of Distances to Galaxies in the NGC 1052 Field with the Hubble and James Webb Space Telescopes: Testing the Bullet-Dwarf Origin of the Trail."
The Astrophysical Journal Letters 1005, L16 (2026).
DOI: 10.3847/2041-8213/ae77ef.
arXiv:2606.05144.
Used quantity: JWST TRGB distance to DF2, D = 17.6 +/- 0.6 Mpc.

## Stellar structure and luminosity normalization
Pieter van Dokkum et al.
"A galaxy lacking dark matter."
Nature 555, 629-632 (2018).
DOI: 10.1038/nature25767.
arXiv:1803.10237.
Used quantities: Sersic n = 0.6, projected b/a = 0.85, major-axis R_e = 22.6 arcsec, L_V = 1.1e8 Lsun at 20 Mpc, and reference M_star/L_V = 2.0.

## Integrated stellar kinematics
Eric Emsellem et al.
"The ultra-diffuse galaxy NGC 1052-DF2 with MUSE. I. Kinematics of the stellar body."
Astronomy & Astrophysics 625, A76 (2019).
DOI: 10.1051/0004-6361/201834909.
arXiv:1812.07345.
Role: source of the MUSE stellar-body kinematic measurement and prolate-like velocity-gradient context.

Shany Danieli et al.
"Still Missing Dark Matter: KCWI High-resolution Stellar Kinematics of NGC1052-DF2."
The Astrophysical Journal Letters 874, L12 (2019).
DOI: 10.3847/2041-8213/ab0e8c.
arXiv:1901.03711.
Role: source of the KCWI diffuse-light measurement and observing context.

Michael A. Keim, Pieter van Dokkum, Zili Shen, Shany Danieli, Imad Pasha.
"A Third Galaxy Missing Dark Matter along a Trail of Galaxies in the NGC 1052 Field."
The Astrophysical Journal 1004, 210 (2026).
DOI: 10.3847/1538-4357/ae6b8d.
arXiv:2603.15860.
Used integrated-light values for DF2:
- KCWI: 6.3 (+3.1/-3.7) km/s;
- MUSE: 9.2 (+3.8/-4.5) km/s.
These are the kinematic values used by the evidence calculation.


## MOND comparison provenance

The paper figure's MOND isolated and MOND+EFE comparison curves use the same DF2 stellar-source inputs as the CPTG calculation. The MOND+EFE control follows the one-dimensional ansatz quoted in Famaey, McGaugh, and Milgrom, *MOND and the dynamics of NGC1052-DF2*, Mon. Not. R. Astron. Soc. 480, 473--476 (2018), DOI: 10.1093/mnras/sty1884.

## MOND external-field geometry used in the paper comparison

Tang et al. (2026) provide the current distance inputs used to evaluate the
NGC 1052 external-field geometry:

- DF2 JWST TRGB: 17.6 +/- 0.6 Mpc
- NGC 1052 HST SBF: 21.3 +/- 1.7 Mpc
- NGC 1052 coordinates: RA 40.26999 deg, Dec -8.25576 deg
- DF2 coordinates: RA 40.44531 deg, Dec -8.40297 deg

These coordinates give an angular separation of 13.650869 arcmin.
The central distances imply a three-dimensional separation of
3.700799 Mpc.

Famaey, McGaugh, and Milgrom (2018), *MOND and the dynamics of
NGC1052-DF2*, MNRAS 480, 473--476, DOI 10.1093/mnras/sty1884, use a
host circular speed of 210 km/s and g_e = V^2/D. Their original co-distance
20-Mpc geometry gives an approximately 80-kpc projected separation and
g_e approximately 0.15 a0. The present evidence package retains that
co-distance case only as the strong-EFE boundary of a geometry bracket.
