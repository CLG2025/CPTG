import numpy as np
import math
from scipy.integrate import quad, cumulative_trapezoid, trapezoid
from scipy.special import gammaincinv
from scipy.interpolate import PchipInterpolator

G_KPC = 4.30091e-6  # kpc (km/s)^2 Msun^-1
PC_M = 3.085677581491367e16
KPC_M = 1e3 * PC_M
SI_PER_KMS2_PER_KPC = 1e6 / KPC_M
C = 299792458.0

class DF2Solver:
    def __init__(self, distance_mpc=17.6, re_arcsec=22.6, sersic_n=0.6,
                 lv_20mpc=1.1e8, ml_v=2.0, support_anchor_kms=9.2,
                 nr=800):
        self.distance_mpc=float(distance_mpc)
        self.re_arcsec=float(re_arcsec)
        self.n=float(sersic_n)
        self.lv_20mpc=float(lv_20mpc)
        self.ml_v=float(ml_v)
        self.support_anchor_kms=float(support_anchor_kms)
        self.nr=int(nr)
        self.mstar = self.lv_20mpc * (self.distance_mpc/20.0)**2 * self.ml_v
        self.re_kpc = self.re_arcsec * (self.distance_mpc*1e6) / 206265.0 / 1e3
        self.a_star = (self.support_anchor_kms*1000.0)**2 / (self.re_kpc*KPC_M)
        self.bn = float(gammaincinv(2.0*self.n, 0.5))
        self._build_source()
        self._build_fields()

    def _dI(self, x):
        if x <= 0: return 0.0
        z = self.bn*x**(1.0/self.n)
        if z > 700: return 0.0
        return math.exp(-z)*(-self.bn/self.n)*x**(1.0/self.n-1.0)

    def _rho_shape(self, x):
        # Abel deprojection using R = r cosh(u), in units of Re.
        xmax = 25.0
        umax = math.acosh(xmax/x) if x < xmax else 1.0
        val,_ = quad(lambda u: self._dI(x*math.cosh(u)), 0.0, umax,
                     epsabs=2e-11, epsrel=2e-9, limit=160)
        return -val/math.pi

    def _build_source(self):
        self.x = np.geomspace(1e-5, 15.0, self.nr)
        shape = np.array([self._rho_shape(float(xx)) for xx in self.x])
        raw_norm = trapezoid(4.0*np.pi*shape*self.x*self.x, self.x)
        self.rho_n = shape/raw_norm
        self.r_kpc = self.x*self.re_kpc
        self.rho = self.mstar/self.re_kpc**3 * self.rho_n
        shell = 4.0*np.pi*self.rho*self.r_kpc*self.r_kpc
        self.menc = np.concatenate(([0.0], cumulative_trapezoid(shell, self.r_kpc)))
        self.mass_closure = float(self.menc[-1]/self.mstar)
        self.gstar_k = np.empty_like(self.r_kpc)
        self.gstar_k[1:] = G_KPC*self.menc[1:]/self.r_kpc[1:]**2
        self.gstar_k[0] = self.gstar_k[1]*(self.r_kpc[0]/self.r_kpc[1])
        self._rho_interp = PchipInterpolator(np.log(self.r_kpc), np.log(self.rho), extrapolate=False)

    def _build_fields(self):
        gs = self.gstar_k*SI_PER_KMS2_PER_KPC
        self.rc_m = 48.0*math.pi*C*C/self.a_star
        r_m = self.r_kpc*KPC_M
        gg = 0.5*self.a_star*(r_m/self.rc_m)**(7.0/5.0)/(1.0+(r_m/self.rc_m)**(12.0/5.0))
        self.ggeom_si = gg
        out = np.empty_like(gs)
        p,q = 123.0/50.0, 11.0/50.0
        max_res = 0.0
        for i,(gb,ggeo) in enumerate(zip(gs,gg)):
            A = math.sqrt(max(self.a_star*gb,0.0)) + ggeo
            def rhs(g): return gb + A/(1.0+(g/self.a_star)**p)**q
            lo = gb
            hi = gb + self.a_star + 10.0*math.sqrt(max(self.a_star*gb,0.0)) + abs(ggeo)
            while hi-rhs(hi) < 0: hi *= 2.0
            for _ in range(110):
                mid=(lo+hi)/2.0
                if mid-rhs(mid)>0: hi=mid
                else: lo=mid
            g=(lo+hi)/2.0
            out[i]=g
            max_res=max(max_res, abs(g-rhs(g))/max(g,1e-300))
        self.gcptg_si=out
        self.gcptg_k=out/SI_PER_KMS2_PER_KPC
        self.max_root_residual=float(max_res)

    def _interp_log(self, values):
        mask=values>1e-280
        return PchipInterpolator(np.log(self.r_kpc[mask]), np.log(values[mask]), extrapolate=False)

    def _eval(self, interp, r):
        if r <= self.r_kpc[0]: return math.exp(float(interp(math.log(self.r_kpc[0]))))
        if r >= self.r_kpc[-2]: return 0.0
        y=interp(math.log(r))
        return math.exp(float(y)) if np.isfinite(y) else 0.0

    def jeans_radial(self, field_k, beta=0.0):
        f=self.rho*field_k*self.r_kpc**(2.0*beta)
        J=-cumulative_trapezoid(f[::-1], self.r_kpc[::-1], initial=0.0)[::-1]
        s2=np.maximum(J/(self.rho*self.r_kpc**(2.0*beta)),0.0)
        s2[-1]=0.0
        return s2

    def aperture_second_moment(self, field_k, beta=0.0, aperture_re=1.0, nR=101):
        s2=self.jeans_radial(field_k,beta)
        sI=self._interp_log(s2)
        Rgrid=np.linspace(0.0,aperture_re*self.re_kpc,nR)
        Ivals=[]; Jvals=[]
        rmax=self.r_kpc[-2]
        for R in Rgrid:
            zmax=math.sqrt(max(rmax*rmax-R*R,0.0))
            def den(z):
                return 2.0*self._eval(self._rho_interp, math.hypot(R,z))
            def num(z):
                rr=math.hypot(R,z)
                rh=self._eval(self._rho_interp,rr)
                ss=self._eval(sI,rr)
                fac=1.0-beta*R*R/(rr*rr) if rr else 1.0-beta
                return 2.0*rh*ss*fac
            I,_=quad(den,0.0,zmax,epsabs=1e-5,epsrel=5e-6,limit=150)
            J,_=quad(num,0.0,zmax,epsabs=1e-4,epsrel=5e-6,limit=150)
            Ivals.append(I); Jvals.append(J)
        Ivals=np.array(Ivals); Jvals=np.array(Jvals)
        return math.sqrt(trapezoid(Jvals*Rgrid,Rgrid)/trapezoid(Ivals*Rgrid,Rgrid))

    def reprojection_error(self,nR=61):
        Rgrid=np.linspace(0.0,self.re_kpc,nR)
        vals=[]; rmax=self.r_kpc[-2]
        for R in Rgrid:
            zmax=math.sqrt(max(rmax*rmax-R*R,0.0))
            I,_=quad(lambda z:2.0*self._eval(self._rho_interp,math.hypot(R,z)),0.0,zmax,
                     epsabs=1e-5,epsrel=5e-6,limit=150)
            vals.append(I)
        vals=np.array(vals)
        shape=vals/vals[0]
        analytic=np.exp(-self.bn*(Rgrid/self.re_kpc)**(1.0/self.n))
        return float(np.max(np.abs(shape/analytic-1.0)))

    def at_re(self):
        x=1.0
        gs=float(np.interp(x,self.x,self.gstar_k))*SI_PER_KMS2_PER_KPC
        gc=float(np.interp(x,self.x,self.gcptg_si))
        gg=float(np.interp(x,self.x,self.ggeom_si))
        return gs,gc,gg
