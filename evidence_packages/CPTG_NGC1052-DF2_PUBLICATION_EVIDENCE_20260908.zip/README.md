# CPTG NGC 1052-DF2 Publication Evidence

Standalone computational evidence for the diffuse stellar body of NGC 1052-DF2.

Run on Windows:

    RUN_DF2_EVIDENCE.cmd

Manual run:

    python CALCULATE_DF2_EVIDENCE.py
    python CALCULATE_DF2_STRUCTURAL_MODE.py
    python VERIFY_DF2_EVIDENCE.py

Scope:
- diffuse stellar body only;
- no globular-cluster or planetary-nebula dynamical inference;
- primary geometry is a same-semimajor spherical radial reduction using the documented major-axis effective radius;
- an area-preserving circularized-radius sphere is included as a geometry sensitivity;
- finite curvature-polarization response and the formal transport term are retained;
- Structural Mode N is evaluated only after the radial CPTG field is solved and is not fitted;
- the weak prolate-like ordered stellar field is not claimed to be solved.

The MUSE integrated-light dispersion from Keim et al. (2026) supplies the declared one-radius pressure-support anchor. The same solved radial field is passed through Jeans and aperture projection. The KCWI integrated-light value from the same source is retained as a cross-instrument consistency control.

The retained solved field also supplies the registered Structural Mode readout at the projected 95-percent-light radius. The continuous N value is primary; the CSMI name is a descriptive post-solution catalog label rather than a morphology input.

Additional included products:
- NGC1052-DF2_observed_diffuse_stellar_comparison.png
- NGC1052-DF2_observed_diffuse_stellar_comparison.csv
- MOND_COMPARISON_METHOD.md

The paper comparison figure includes a MOND EFE geometry bracket. Its lower boundary is a conditional co-distance strong-EFE case and its upper boundary uses the current central DF2/NGC 1052 distance geometry. The band is not a statistical confidence interval.
