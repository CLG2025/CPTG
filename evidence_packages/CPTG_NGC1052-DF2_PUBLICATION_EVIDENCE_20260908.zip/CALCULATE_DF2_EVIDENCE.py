import csv, json, math
from pathlib import Path
from df2_solver import DF2Solver, PC_M
HERE=Path(__file__).resolve().parent
D=17.6; RE=22.6; N=0.6; Q=0.85; LV20=110000000.0; MLV=2.0
MUSE=9.2; KCWI=6.3; KCWI_MINUS=3.7; KCWI_PLUS=3.1
RE_CIRC=RE*math.sqrt(Q)

def run_case(distance=D, re_arcsec=RE, ml=MLV, anchor=MUSE, beta=0.0, nr=800, nR=101):
    s=DF2Solver(distance_mpc=distance,re_arcsec=re_arcsec,sersic_n=N,lv_20mpc=LV20,ml_v=ml,support_anchor_kms=anchor,nr=nr)
    star=s.aperture_second_moment(s.gstar_k,beta,1.0,nR)
    cptg=s.aperture_second_moment(s.gcptg_k,beta,1.0,nR)
    c07=s.aperture_second_moment(s.gcptg_k,beta,0.7,nR)
    gs,gc,gg=s.at_re()
    return dict(distance_mpc=s.distance_mpc,re_arcsec=re_arcsec,ml_v=s.ml_v,anchor_kms=s.support_anchor_kms,beta=beta,
        mstar_msun=s.mstar,re_kpc=s.re_kpc,bn=s.bn,a_star_mps2=s.a_star,rc_gpc=s.rc_m/(1e9*PC_M),
        gstar_re_mps2=gs,gcptg_re_mps2=gc,ggeom_re_mps2=gg,re_response=gc/gs,
        sigma_star_re_kms=star,sigma_cptg_re_kms=cptg,sigma_cptg_0p7re_kms=c07,
        mass_closure=s.mass_closure,reprojection_max_rel=s.reprojection_error(),root_max_rel=s.max_root_residual)

def main():
    p=run_case()
    (HERE/'primary_result.json').write_text(json.dumps(p,indent=2,sort_keys=True),encoding='utf-8')
    s=DF2Solver(distance_mpc=D,re_arcsec=RE,sersic_n=N,lv_20mpc=LV20,ml_v=MLV,support_anchor_kms=MUSE,nr=800)
    sr2=s.jeans_radial(s.gstar_k,0.0); cr2=s.jeans_radial(s.gcptg_k,0.0)
    with (HERE/'radial_profile.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.writer(f); w.writerow(['r_over_Re','r_kpc','rho_Msun_kpc3','Menc_Msun','gstar_mps2','gcptg_mps2','ggeom_mps2','sigma_r_star_kms','sigma_r_cptg_kms'])
        for i in range(0,len(s.r_kpc),4):
            w.writerow([s.x[i],s.r_kpc[i],s.rho[i],s.menc[i],s.gstar_k[i]*(1e6/(1000*PC_M)),s.gcptg_si[i],s.ggeom_si[i],math.sqrt(max(sr2[i],0)),math.sqrt(max(cr2[i],0))])
    sens=[]
    for beta in (-0.3,0.0,0.22): sens.append(('anisotropy',f'beta={beta}',run_case(beta=beta)))
    for ml in (1.5,1.75,2.0,2.25,2.5): sens.append(('stellar_ML',f'ML={ml}',run_case(ml=ml)))
    for d in (17.0,17.6,18.2): sens.append(('distance',f'D={d}',run_case(distance=d)))
    for a in (4.699999999999999,9.2,13.0): sens.append(('support_anchor',f'sigma={a}',run_case(anchor=a)))
    sens.append(('geometry','major_axis_same_semimajor_sphere',run_case(re_arcsec=RE)))
    sens.append(('geometry','area_preserving_circularized_sphere',run_case(re_arcsec=RE_CIRC)))
    fields=['group','case','distance_mpc','re_arcsec','ml_v','anchor_kms','beta','mstar_msun','re_kpc','a_star_mps2','re_response','sigma_star_re_kms','sigma_cptg_re_kms','sigma_cptg_0p7re_kms']
    with (HERE/'sensitivity_results.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=fields); w.writeheader()
        for grp,label,res in sens:
            rec={'group':grp,'case':label}; rec.update({k:res[k] for k in fields if k not in ('group','case')}); w.writerow(rec)
    with (HERE/'aperture_results.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.writer(f); w.writerow(['quantity','value_kms','comparison_central_kms','comparison_minus_kms','comparison_plus_kms','normalized_upper_residual','classification'])
        w.writerow(['stellar-only same-semimajor spherical <Re',p['sigma_star_re_kms'],'','','','','baryonic baseline'])
        w.writerow(['CPTG same-semimajor spherical <Re',p['sigma_cptg_re_kms'],MUSE,4.5,3.8,'', 'shared-input closure'])
        upper_res=(p['sigma_cptg_0p7re_kms']-KCWI)/KCWI_PLUS
        w.writerow(['CPTG centered circular control <0.7Re',p['sigma_cptg_0p7re_kms'],KCWI,KCWI_MINUS,KCWI_PLUS,upper_res,'cross-instrument consistency control'])
    print('CPTG NGC 1052-DF2 PUBLICATION EVIDENCE')
    for k in ['mstar_msun','re_kpc','a_star_mps2','gstar_re_mps2','gcptg_re_mps2','re_response','sigma_star_re_kms','sigma_cptg_re_kms','sigma_cptg_0p7re_kms','mass_closure','reprojection_max_rel','root_max_rel']:
        print(f'{k}={p[k]:.15g}')
if __name__=='__main__': main()
