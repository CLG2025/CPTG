# Theory and Method Authority

1. The material source is baryonic and is reconstructed before the response field is solved.
2. Pressure support changes the observational interface between the gravitational field and stellar kinematics.
3. The observable support coordinate sigma^2/R_e is not universally identical to a_star. In the declared one-radius pressure-supported reduction it is used as the boundary anchor for the object-specific response scale.
4. The radial CPTG response is solved at every radius:
   g = g_star + [sqrt(a_star g_star)+g_geom]/[1+(g/a_star)^(123/50)]^(11/50).
5. The transport continuation is
   g_geom = (1/2) a_star (r/R_c)^(7/5)/[1+(r/R_c)^(12/5)],
   R_c = 48 pi c^2/a_star.
6. The complete radial field is passed through the Jeans equation and aperture projection; a local g_CPTG/g_star ratio is not used to rescale a velocity dispersion.
7. Structural Mode N is post-solution and is not used to determine the field. For the retained solved radial field,
   C_g(r) = g(r)^2 + kappa_struct^2 [dg(r)/dr]^2, with kappa_struct = 1 kpc,
   w(r) = |dC_g/dr|,
   lambda = integral[r w(r)dr]/integral[w(r)dr] over R95/5 <= r <= R95,
   and N = R95/lambda.
8. Because DF2 C_g has one turning point on the registered interval, its Structural Mode is evaluated by direct absolute total-variation integration rather than a monotone endpoint identity.

CPTG documents used:
- Carter L. Glass Jr., "Curvature Polarization Transport Gravity: A Unified Geometric Framework for Structure, Cosmology, and Nuclear Reactions," DOI: 10.5281/zenodo.22441039.
- Carter L. Glass Jr., "CPTG Native-Phase Jeans and Structural Validation: XMM-VID1-2075," DOI: 10.5281/zenodo.22445804.
- Carter L. Glass Jr., "Structural Mode N in CPTG: Galaxy Structural Classification from the Solved CPTG Field," DOI: 10.5281/zenodo.22436682.

The XMM-VID1-2075 study provides the direct precedent for the declared one-radius pressure-support estimator followed by an Abel-deprojected radial source, nonlinear CPTG field solve, Jeans reconstruction, and aperture projection. The Structural Mode study provides the registered post-solution C_g, w, lambda, N definitions and current CSMI interval map. The DF2 calculation uses the same ordering and states its geometry approximation explicitly.


## MOND comparison control used in the paper figure

For figure-level comparison only, the paper includes an isolated MOND control and a MOND external-field geometry bracket derived from the same DF2 stellar source and passed through the same isotropic Jeans/aperture projection used for the CPTG and baryonic curves. The EFE bracket uses the one-dimensional ansatz of Famaey, McGaugh, and Milgrom (2018). Its strong-EFE boundary is a conditional co-distance geometry; its weak-EFE boundary uses the current central DF2 and NGC 1052 distance estimates. The bracket is not a statistical confidence interval.
