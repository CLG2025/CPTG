#!/usr/bin/env python3
from pathlib import Path
import hashlib, sys
base=Path(__file__).resolve().parent
manifest=base/'SHA256SUMS.txt'
if not manifest.is_file():
    raise SystemExit('FAIL: SHA256SUMS.txt missing')
listed=set()
failed=False
for line in manifest.read_text(encoding='utf-8').splitlines():
    if not line.strip(): continue
    expected,name=line.split('  ',1)
    listed.add(name)
    p=base/name
    if not p.is_file():
        print(f'FAIL missing: {name}'); failed=True; continue
    got=hashlib.sha256(p.read_bytes()).hexdigest()
    if got!=expected:
        print(f'FAIL hash: {name}\n  expected {expected}\n  got      {got}'); failed=True
    else:
        print(f'OK {name}')
extra=sorted(p.name for p in base.iterdir() if p.is_file() and p.name not in listed and p.name not in {'SHA256SUMS.txt'})
if extra:
    print('FAIL unexpected files before reproduction: '+', '.join(extra)); failed=True
if failed: raise SystemExit(1)
print('PACKAGE INTEGRITY: PASS')
