@echo off
setlocal
cd /d "%~dp0"
python -S VERIFY_PACKAGE.py
if errorlevel 1 exit /b 3
python -S CPTG_DESI_BAO_BlockCovariance.py
exit /b %errorlevel%
