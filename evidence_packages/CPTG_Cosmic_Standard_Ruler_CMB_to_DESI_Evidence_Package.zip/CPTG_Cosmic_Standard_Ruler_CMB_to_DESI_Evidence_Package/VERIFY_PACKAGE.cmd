@echo off
setlocal
cd /d "%~dp0"
python -S VERIFY_PACKAGE.py
exit /b %errorlevel%
