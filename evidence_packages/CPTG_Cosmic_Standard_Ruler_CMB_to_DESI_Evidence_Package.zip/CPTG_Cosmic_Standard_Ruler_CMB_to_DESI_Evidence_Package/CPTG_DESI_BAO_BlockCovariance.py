#!/usr/bin/env python3
"""Fail-closed offline CMB-to-DESI evidence reproduction for
CPTG and the Cosmic Standard Ruler.

The controlling calculation reads only the frozen input snapshots shipped beside
this script and verifies their SHA-256 identities before using them. It performs
no network access.
"""
from __future__ import annotations
import csv, math, hashlib
from pathlib import Path
from typing import List, Sequence, Tuple

BASE=Path(__file__).resolve().parent
OUTPUT_SUMMARY_CSV="CPTG_DESI_BAO_BlockCovariance_Results.csv"
OUTPUT_PER_POINT_CSV="CPTG_DESI_BAO_BlockCovariance_PerPoint.csv"

EXPECTED_SHA256={'Planck_CMB_Comparison_Inputs.csv': 'bf948e9729e90a9b3bbefa8721a01841f0607fb4a49cc6c5dbc46f03bc3a86a5', 'DESI_DR2_LowerZ_Mean_11.txt': 'efa89d11539c435866729be0c110d278876d2edfcfe6b7cf1ceb75894bb21337', 'DESI_DR2_LowerZ_Covariance_11x11.txt': '37c3166d40460eed14fefb839b23089aeeaa73ea7dbfd22f63192bd604359da0', 'DESI_LyAlpha_AP_BAO_z2p33.csv': '6c0eaf0f7be3d3e224489e337eab8bd454dcbdd5529c74868c084867b6a22f5d'}
P_AC=3.0-math.pi/100.0
B_PI=1.0-1.0/math.pi
T_PI=1.0/math.pi
G_T=P_AC/math.pi
C_MS=299792458.0
C_KMS=299792.458
MPC_M=3.0856775814913673e22
A_PI0=math.pi**1.5*1.0e-10


def file_sha256(path: Path)->str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

def require_inputs():
    for name,expected in EXPECTED_SHA256.items():
        p=BASE/name
        if not p.is_file(): raise FileNotFoundError(f"Required frozen input missing: {name}")
        got=file_sha256(p)
        if got!=expected: raise RuntimeError(f"Frozen input hash mismatch for {name}: {got} != {expected}")

def read_planck():
    rows=list(csv.DictReader((BASE/'Planck_CMB_Comparison_Inputs.csv').open(encoding='utf-8')))
    d={r['quantity']:r for r in rows}
    theta=float(d['100theta_star']['value'])/100.0
    sigma_theta=float(d['100theta_star']['sigma'])/100.0
    zstar=float(d['z_star']['value'])
    sigma_z=float(d['z_star']['sigma'])
    return theta,sigma_theta,zstar,sigma_z

def read_lower_mean():
    out=[]
    for raw in (BASE/'DESI_DR2_LowerZ_Mean_11.txt').read_text(encoding='utf-8').splitlines():
        s=raw.strip()
        if not s or s.startswith('#'): continue
        z,v,q=s.split()
        out.append((float(z),float(v),q))
    if len(out)!=11: raise RuntimeError(f"Expected 11 lower-z rows, found {len(out)}")
    return out

def read_cov_11():
    rows=[]
    for raw in (BASE/'DESI_DR2_LowerZ_Covariance_11x11.txt').read_text(encoding='utf-8').splitlines():
        s=raw.strip()
        if s: rows.append([float(x) for x in s.split()])
    if len(rows)!=11 or any(len(r)!=11 for r in rows): raise RuntimeError('Expected 11x11 lower-z covariance')
    return rows

def read_lya():
    rows=list(csv.DictReader((BASE/'DESI_LyAlpha_AP_BAO_z2p33.csv').open(encoding='utf-8')))
    if len(rows)!=2: raise RuntimeError('Expected 2 Ly-alpha rows')
    d={r['observable']:r for r in rows}
    z=float(rows[0]['z'])
    dh=float(d['DH_over_rs']['value']); sdh=float(d['DH_over_rs']['sigma'])
    dm=float(d['DM_over_rs']['value']); sdm=float(d['DM_over_rs']['sigma'])
    rho=float(rows[0]['rho_DM_DH'])
    return z,dh,sdh,dm,sdm,rho

def e_branch(z,p): return math.sqrt(B_PI+T_PI*(1.0+z)**p)

def adaptive_simpson(f,a,b,eps=1e-13,maxdepth=40):
    fa,fb=f(a),f(b); c=(a+b)/2.0; fc=f(c)
    s=(b-a)*(fa+4.0*fc+fb)/6.0
    def rec(a,b,fa,fb,fc,s,eps,depth):
        c=(a+b)/2.0; l=(a+c)/2.0; r=(c+b)/2.0
        fl,fr=f(l),f(r)
        sl=(c-a)*(fa+4.0*fl+fc)/6.0
        sr=(b-c)*(fc+4.0*fr+fb)/6.0
        s2=sl+sr
        if depth<=0 or abs(s2-s)<=15.0*eps:
            return s2+(s2-s)/15.0
        return rec(a,c,fa,fc,fl,sl,eps/2.0,depth-1)+rec(c,b,fc,fb,fr,sr,eps/2.0,depth-1)
    return rec(a,b,fa,fb,fc,s,eps,maxdepth)

def integral_inv_e(z,p):
    if z==0: return 0.0
    return adaptive_simpson(lambda x:1.0/e_branch(x,p),0.0,z)

def derive_cmb():
    theta,s_theta,zstar,s_z=read_planck()
    I=integral_inv_e(zstar,P_AC)
    A=1.0/(theta*I)
    dA_dtheta=-A/theta
    dA_dz=-A/(I*e_branch(zstar,P_AC))
    sigma_A=math.sqrt((dA_dtheta*s_theta)**2+(dA_dz*s_z)**2)
    Hinf_s=A_PI0/C_MS
    Hinf=Hinf_s*MPC_M/1000.0
    H0_pi=Hinf/math.sqrt(B_PI)
    H0_ac=H0_pi*math.sqrt(G_T)
    chi_ac=(C_KMS/H0_ac)*I
    r_ac=theta*chi_ac
    chi_pi=(C_KMS/H0_pi)*I
    r_pi=theta*chi_pi
    return dict(theta=theta,sigma_theta=s_theta,zstar=zstar,sigma_z=s_z,I=I,A=A,sigma_A=sigma_A,
                Hinf_s=Hinf_s,Hinf=Hinf,H0_pi=H0_pi,H0_ac=H0_ac,chi_ac=chi_ac,r_ac=r_ac,
                chi_pi=chi_pi,r_pi=r_pi)

def assemble_data():
    lower=read_lower_mean(); c11=read_cov_11(); z,dh,sdh,dm,sdm,rho=read_lya()
    rows=lower+[(z,dh,'DH_over_rs'),(z,dm,'DM_over_rs')]
    cov=[[0.0]*13 for _ in range(13)]
    for i in range(11):
        for j in range(11): cov[i][j]=c11[i][j]
    off=rho*sdh*sdm
    cov[11][11]=sdh**2; cov[12][12]=sdm**2; cov[11][12]=cov[12][11]=off
    return rows,cov

def solve_linear(A,b):
    n=len(b); M=[list(map(float,A[i]))+[float(b[i])] for i in range(n)]
    for col in range(n):
        pivot=max(range(col,n),key=lambda r:abs(M[r][col]))
        if abs(M[pivot][col])<1e-18: raise RuntimeError('Singular matrix')
        M[col],M[pivot]=M[pivot],M[col]
        piv=M[col][col]
        for j in range(col,n+1): M[col][j]/=piv
        for r in range(n):
            if r==col: continue
            fac=M[r][col]
            if fac:
                for j in range(col,n+1): M[r][j]-=fac*M[col][j]
    return [M[i][n] for i in range(n)]
def dot(a,b): return sum(x*y for x,y in zip(a,b))
def submatrix(M,idx): return [[M[i][j] for j in idx] for i in idx]
def covariance_chi2(cov,resid): return dot(resid,solve_linear(cov,resid))

def gammaincc(a,x):
    if x<0 or a<=0: raise ValueError
    if x==0: return 1.0
    gln=math.lgamma(a); eps=3e-14; fpmin=1e-300
    if x<a+1.0:
        ap=a; summ=1.0/a; delta=summ
        for _ in range(10000):
            ap+=1.0; delta*=x/ap; summ+=delta
            if abs(delta)<abs(summ)*eps: break
        p=summ*math.exp(-x+a*math.log(x)-gln)
        return max(0.0,min(1.0,1.0-p))
    b=x+1.0-a; c=1.0/fpmin; d=1.0/b; h=d
    for i in range(1,10000):
        an=-i*(i-a); b+=2.0; d=an*d+b
        if abs(d)<fpmin:d=fpmin
        c=b+an/c
        if abs(c)<fpmin:c=fpmin
        d=1.0/d; delta=d*c; h*=delta
        if abs(delta-1.0)<eps: break
    q=math.exp(-x+a*math.log(x)-gln)*h
    return max(0.0,min(1.0,q))
def chi2_sf(x,dof): return gammaincc(0.5*dof,0.5*x)

def shape_value(z,q,p):
    dh=1.0/e_branch(z,p); dm=integral_inv_e(z,p)
    if q=='DM_over_rs': return dm
    if q=='DH_over_rs': return dh
    if q=='DV_over_rs': return (z*dm*dm*dh)**(1.0/3.0)
    raise ValueError(q)
def shape_vector(rows,p): return [shape_value(z,q,p) for z,_,q in rows]
def fixed_prediction(rows,p,A): return [A*x for x in shape_vector(rows,p)]
def one_normalization_fit(rows,cov,p):
    data=[v for _,v,_ in rows]; f=shape_vector(rows,p)
    ci_d=solve_linear(cov,data); ci_f=solve_linear(cov,f)
    den=dot(f,ci_f); A=dot(f,ci_d)/den; sA=1.0/math.sqrt(den)
    pred=[A*x for x in f]; res=[m-d for m,d in zip(pred,data)]; chi=covariance_chi2(cov,res)
    return dict(A_best=A,sigma_A=sA,predicted=pred,residual=res,chi2=chi,dof=len(rows)-1,p=chi2_sf(chi,len(rows)-1))

BLOCKS=[('BGS z=0.295',[0]),('LRG1 z=0.510',[1,2]),('LRG2 z=0.706',[3,4]),('LRG3+ELG1 z=0.934',[5,6]),('ELG2 z=1.321',[7,8]),('QSO z=1.484',[9,10]),('LyA z=2.330',[11,12])]
LOW=[0,1,2,3,4]; MID=[5,6,7,8]; HIGH=[9,10,11,12]; DM=[1,3,5,7,9,12]; DH=[2,4,6,8,10,11]
ANISO=[[1,2],[3,4],[5,6],[7,8],[9,10],[12,11]]
def subset_fixed(rows,cov,pred,idx):
    res=[pred[i]-rows[i][1] for i in idx]; c=submatrix(cov,idx); chi=covariance_chi2(c,res); n=len(idx)
    return chi,n,chi2_sf(chi,n)
def ap_shape(rows,cov,p):
    chi=0.0
    for i_dm,i_dh in ANISO:
        dm=rows[i_dm][1]; dh=rows[i_dh][1]; obs=dm/dh; z=rows[i_dm][0]
        model=shape_value(z,'DM_over_rs',p)/shape_value(z,'DH_over_rs',p)
        c=submatrix(cov,[i_dm,i_dh]); j0=1.0/dh; j1=-dm/(dh*dh)
        var=j0*j0*c[0][0]+2*j0*j1*c[0][1]+j1*j1*c[1][1]
        chi+=(model-obs)**2/var
    return chi,6,chi2_sf(chi,6)

def main():
    require_inputs(); cmb=derive_cmb(); rows,cov=assemble_data()
    A=cmb['A']; sA_cmb=cmb['sigma_A']
    pred=fixed_prediction(rows,P_AC,A); res=[pred[i]-rows[i][1] for i in range(13)]
    chi=covariance_chi2(cov,res); p=chi2_sf(chi,13)
    free=one_normalization_fit(rows,cov,P_AC); pi=one_normalization_fit(rows,cov,math.pi)
    loo=[]
    for name,omit in BLOCKS:
        keep=[i for i in range(13) if i not in omit]; loo.append((name,*subset_fixed(rows,cov,pred,keep)))
    splits={'z<=0.706':subset_fixed(rows,cov,pred,LOW),'0.934<=z<=1.321':subset_fixed(rows,cov,pred,MID),'z>=1.484':subset_fixed(rows,cov,pred,HIGH)}
    sectors={'DM/r':subset_fixed(rows,cov,pred,DM),'DH/r':subset_fixed(rows,cov,pred,DH)}
    shape_ac=ap_shape(rows,cov,P_AC); shape_pi=ap_shape(rows,cov,math.pi)
    block_tests={name:subset_fixed(rows,cov,pred,idx) for name,idx in BLOCKS}
    with (BASE/OUTPUT_PER_POINT_CSV).open('w',newline='',encoding='utf-8') as f:
        w=csv.writer(f); w.writerow(['index','z','observable','observed','cptg_fixed_prediction','marginal_sigma','marginal_pull'])
        for i,(z,obs,q) in enumerate(rows):
            s=math.sqrt(cov[i][i]); w.writerow([i+1,f'{z:.8g}',q,f'{obs:.12g}',f'{pred[i]:.12g}',f'{s:.12g}',f'{(pred[i]-obs)/s:.9g}'])
    with (BASE/OUTPUT_SUMMARY_CSV).open('w',newline='',encoding='utf-8') as f:
        w=csv.writer(f); w.writerow(['section','quantity','value','notes'])
        for k in ['theta','sigma_theta','zstar','sigma_z','I','Hinf_s','Hinf','H0_pi','H0_ac','chi_pi','r_pi','chi_ac','r_ac','A','sigma_A']:
            w.writerow(['cmb_derivation',k,f'{cmb[k]:.16g}','derived from frozen Planck comparison inputs'])
        w.writerow(['branch','p_ac',f'{P_AC:.16g}','fixed p_ac = 3 - pi/100'])
        w.writerow(['fixed_test','A_CPTG',f'{A:.16g}','derived upstream from frozen CMB inputs'])
        w.writerow(['fixed_test','chi2',f'{chi:.16g}','13-observable block covariance'])
        w.writerow(['fixed_test','dof',13,'zero DESI fitted parameters']); w.writerow(['fixed_test','p',f'{p:.16g}','chi-square survival probability'])
        dA=A-free['A_best']; sd=math.sqrt(sA_cmb**2+free['sigma_A']**2)
        for q,v,note in [('A_DESI',free['A_best'],'one-normalization diagnostic'),('sigma_A_DESI',free['sigma_A'],'conditional on fixed acoustic shape'),('chi2_free',free['chi2'],'one fitted normalization'),('dof_free',free['dof'],'13-1'),('p_free',free['p'],'chi-square survival probability'),('delta_A',dA,'A_CPTG - A_DESI'),('sigma_delta_A',sd,'quadrature CMB + DESI diagnostic uncertainties'),('delta_A_sigma',dA/sd,'standardized normalization displacement'),('delta_chi2',chi-free['chi2'],'cost of fixing normalization upstream')]: w.writerow(['diagnostic_A',q,f'{v:.16g}',note])
        for name,(bc,bd,bp) in block_tests.items(): w.writerow(['block_test',name,f'{bc:.16g}',f'dof={bd}, p={bp:.16g}'])
        for name,lc,ld,lp in loo: w.writerow(['leave_one_block_out',name,f'{lc:.16g}',f'dof={ld}, p={lp:.16g}'])
        for name,(sc,sdof,sp) in splits.items(): w.writerow(['redshift_split',name,f'{sc:.16g}',f'dof={sdof}, p={sp:.16g}'])
        for name,(sc,sdof,sp) in sectors.items(): w.writerow(['sector',name,f'{sc:.16g}',f'dof={sdof}, p={sp:.16g}'])
        w.writerow(['shape_test','acoustic_chi2',f'{shape_ac[0]:.16g}',f'dof=6, p={shape_ac[2]:.16g}']); w.writerow(['shape_test','native_pi_chi2',f'{shape_pi[0]:.16g}',f'dof=6, p={shape_pi[2]:.16g}'])
        w.writerow(['native_pi_control','A_best',f"{pi['A_best']:.16g}",'one fitted normalization']); w.writerow(['native_pi_control','chi2',f"{pi['chi2']:.16g}",f"dof={pi['dof']}, p={pi['p']:.16g}"])
    maxpull=max(abs((pred[i]-rows[i][1])/math.sqrt(cov[i][i])) for i in range(13))
    print('FROZEN INPUT HASH VERIFICATION: PASS')
    print(f"I_star      = {cmb['I']:.15f}")
    print(f"A_CPTG      = {A:.12f} +/- {sA_cmb:.12f}")
    print(f"r_ac^[pi]   = {cmb['r_pi']:.9f} Mpc")
    print(f"r_ac^[ac]   = {cmb['r_ac']:.9f} Mpc")
    print(f"chi2        = {chi:.10f}")
    print('dof         = 13')
    print(f"p           = {p:.10f}")
    print(f"max |pull|  = {maxpull:.6f} sigma")
    print(f"A_DESI      = {free['A_best']:.10f} +/- {free['sigma_A']:.10f}")
    print(f"Delta chi2  = {chi-free['chi2']:.10f}")
    print(f"LyA block   = chi2 {block_tests['LyA z=2.330'][0]:.10f}, dof 2, p {block_tests['LyA z=2.330'][2]:.10f}")
    print(f"native-pi   = chi2 {pi['chi2']:.10f}, dof {pi['dof']}, p {pi['p']:.6e}")
    print(f"AP acoustic = chi2 {shape_ac[0]:.10f}, dof 6, p {shape_ac[2]:.10f}")
    print(f"AP native-pi= chi2 {shape_pi[0]:.10f}, dof 6, p {shape_pi[2]:.6e}")
    print(f"Wrote {OUTPUT_SUMMARY_CSV}")
    print(f"Wrote {OUTPUT_PER_POINT_CSV}")

if __name__=='__main__': main()
