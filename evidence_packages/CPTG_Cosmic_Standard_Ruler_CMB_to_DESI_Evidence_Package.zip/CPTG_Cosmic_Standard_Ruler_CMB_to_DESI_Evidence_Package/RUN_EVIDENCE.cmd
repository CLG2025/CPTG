@echo off
setlocal
cd /d "%~dp0"
echo ============================================================
echo CPTG COSMIC STANDARD RULER - FULL EVIDENCE REPRODUCTION
echo ============================================================
python -S VERIFY_PACKAGE.py
if errorlevel 1 goto :integrityfail
python -S CPTG_DESI_BAO_BlockCovariance.py > REPRODUCTION_LOG.txt 2>&1
if errorlevel 1 goto :fail
python CPTG_DESI_BAO_MakeFigures.py >> REPRODUCTION_LOG.txt 2>&1
if errorlevel 1 goto :figfail
echo PASS
exit /b 0
:integrityfail
echo Package integrity verification failed.
exit /b 3
:figfail
echo Figure generation failed. Install requirements_figures.txt and rerun.
exit /b 2
:fail
echo Numerical evidence reproduction failed. See REPRODUCTION_LOG.txt
exit /b 1
