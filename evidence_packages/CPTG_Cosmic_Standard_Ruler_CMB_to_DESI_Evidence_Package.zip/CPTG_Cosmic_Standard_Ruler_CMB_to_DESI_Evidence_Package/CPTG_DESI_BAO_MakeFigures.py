#!/usr/bin/env python3
from pathlib import Path
import csv, math
import matplotlib.pyplot as plt
import numpy as np
import CPTG_DESI_BAO_BlockCovariance as ev

BASE=Path(__file__).resolve().parent
ev.require_inputs()
cmb=ev.derive_cmb(); rows,cov=ev.assemble_data(); A=cmb['A']
pred=ev.fixed_prediction(rows,ev.P_AC,A)

zgrid=np.linspace(0.0,2.45,450)
dm=np.array([A*ev.integral_inv_e(float(z),ev.P_AC) for z in zgrid])
dh=np.array([A/ev.e_branch(float(z),ev.P_AC) for z in zgrid])
dv=np.array([0.0 if z==0 else A*(float(z)*ev.integral_inv_e(float(z),ev.P_AC)**2/ev.e_branch(float(z),ev.P_AC))**(1/3) for z in zgrid])
fig,ax=plt.subplots(figsize=(9.4,5.9))
l_dm,=ax.plot(zgrid,dm,'-',linewidth=2.0,label=r'CPTG $D_M/r$ — transverse')
l_dh,=ax.plot(zgrid,dh,'--',linewidth=2.0,label=r'CPTG $D_H/r$ — radial')
l_dv,=ax.plot(zgrid,dv,':',linewidth=2.2,label=r'CPTG $D_V/r$ — isotropic')
styles={'DM_over_rs':('o',l_dm.get_color(),r'DESI $D_M/r$ — circles'),'DH_over_rs':('s',l_dh.get_color(),r'DESI $D_H/r$ — squares'),'DV_over_rs':('^',l_dv.get_color(),r'DESI $D_V/r$ — triangle')}
for q in ('DM_over_rs','DH_over_rs','DV_over_rs'):
    idx=[i for i,r in enumerate(rows) if r[2]==q]; marker,color,label=styles[q]
    ax.errorbar([rows[i][0] for i in idx],[rows[i][1] for i in idx],yerr=[math.sqrt(cov[i][i]) for i in idx],fmt=marker,linestyle='none',markersize=6.2,capsize=3,elinewidth=1.1,markeredgewidth=1.0,color=color,label=label,zorder=4)
ax.set_xlabel('Redshift z'); ax.set_ylabel('Dimensionless BAO distance ratio'); ax.set_title('CPTG Direct Projection into DESI Standard-Ruler Coordinates'); ax.set_xlim(-0.02,2.52); ax.set_ylim(-0.5,41.8); ax.legend(loc='center right',fontsize=9); fig.tight_layout()
fig.savefig(BASE/'CPTG_DESI_Direct_Projection.png',dpi=240,bbox_inches='tight',metadata={'Software':'CPTG evidence reproduction'})
plt.close(fig)

pulls=[(pred[i]-rows[i][1])/math.sqrt(cov[i][i]) for i in range(13)]
fig,ax=plt.subplots(figsize=(9.4,5.2))
style2={'DM_over_rs':('o',r'DESI $D_M/r$ — circles'),'DH_over_rs':('s',r'DESI $D_H/r$ — squares'),'DV_over_rs':('^',r'DESI $D_V/r$ — triangle')}
for q in ('DM_over_rs','DH_over_rs','DV_over_rs'):
    idx=[i for i,r in enumerate(rows) if r[2]==q]; marker,label=style2[q]
    ax.scatter([rows[i][0] for i in idx],[pulls[i] for i in idx],marker=marker,s=58,label=label,zorder=4)
ax.axhline(0.0,linewidth=1.0); ax.axhline(2.0,linestyle='--',linewidth=1.0); ax.axhline(-2.0,linestyle='--',linewidth=1.0)
ax.set_xlabel('Redshift z'); ax.set_ylabel(r'Marginal residual $(\mathrm{CPTG}-\mathrm{DESI})/\sigma$'); ax.set_title('CPTG Residual Pulls in DESI Standard-Ruler Coordinates'); ax.set_xlim(0.18,2.45); ax.set_ylim(-2.35,2.35); ax.legend(loc='best',fontsize=9); fig.tight_layout()
fig.savefig(BASE/'CPTG_DESI_Residual_Pulls.png',dpi=240,bbox_inches='tight',metadata={'Software':'CPTG evidence reproduction'})
plt.close(fig)
print('Wrote CPTG_DESI_Direct_Projection.png')
print('Wrote CPTG_DESI_Residual_Pulls.png')
