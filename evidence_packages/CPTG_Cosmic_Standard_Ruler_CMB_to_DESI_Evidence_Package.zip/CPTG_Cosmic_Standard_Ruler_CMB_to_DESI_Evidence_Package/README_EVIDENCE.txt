CPTG AND THE COSMIC STANDARD RULER
A Direct CMB-to-DESI Test of the Acoustic Projection

EVIDENCE ARCHIVE
CPTG_Cosmic_Standard_Ruler_CMB_to_DESI_Evidence_Package.zip

This package is the frozen, standalone CMB-to-DESI evidence chain for the publication source included here.

Controlling chain
1. Verify frozen input SHA-256 identities.
2. Read Planck comparison inputs and derive I_star, A_CPTG, sigma_A,CMB, and both dimensional comparison-coordinate representations.
3. Read the frozen 11-observable lower-z DESI vector/covariance and frozen z=2.33 Ly-alpha AP+BAO block.
4. Evaluate the fixed zero-DESI-fit 13-observable CPTG test.
5. Reproduce the normalization diagnostic, all redshift/sector/block tests, AP-shape tests, and native-pi negative control.
6. Regenerate both publication figures from the same frozen inputs and derived CMB normalization.

No network retrieval occurs in the controlling numerical calculation.

Integrity verification before rerun
  python -S VERIFY_PACKAGE.py
  or double-click VERIFY_PACKAGE.cmd

Numerical reproduction (standard library only)
  python -S CPTG_DESI_BAO_BlockCovariance.py

Full reproduction including figures
  pip install -r requirements_figures.txt
  RUN_EVIDENCE.cmd

Expected headline values
  I_star      = 3.213146044210493
  A_CPTG      = 29.893522144251 +/- 0.008902070387
  r_ac^[pi]   = 144.471593001 Mpc
  r_ac^[ac]   = 148.621869963 Mpc
  chi2        = 13.6024620904
  dof         = 13
  p           = 0.4024238163
  A_DESI      = 29.8295509892 +/- 0.0816008671
  native-pi   = chi2 113.3927924830, dof 12, p 1.27344e-18

The two dimensional ruler representations are deliberately distinguished. The publication uses r_ac = r_ac^[ac] for its fully acoustic representation. The parent Pi comparison-coordinate convention uses r_ac^[pi]. The dimensionless normalization A_CPTG is identical because the dimensional prefactor cancels.
