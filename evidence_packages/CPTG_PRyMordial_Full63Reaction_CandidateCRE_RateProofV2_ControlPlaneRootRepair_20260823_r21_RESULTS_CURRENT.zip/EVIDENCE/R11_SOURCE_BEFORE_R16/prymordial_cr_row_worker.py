from __future__ import annotations
import argparse,json,math,os,subprocess,sys,time
from pathlib import Path
from common import ROOT,load_json,write_atomic,sha_file,requests_equal,physical_solver_profile

def run_profile(profile,request,base):
    base.mkdir(parents=True,exist_ok=True)
    res=base/"result.json";proof=base/"proof.json";out=base/"stdout.txt";err=base/"stderr.txt"
    cmd=[sys.executable,str(ROOT/"SOURCE/prymordial_single_profile_worker.py"),
         "--source-root",str(ROOT/"WORK/SOURCE"/profile),"--request",str(request),"--result",str(res),"--proof",str(proof)]
    env=os.environ.copy();env.update({"PYTHONDONTWRITEBYTECODE":"1","OMP_NUM_THREADS":"1","OPENBLAS_NUM_THREADS":"1","MKL_NUM_THREADS":"1",
                                      "PYTHONPYCACHEPREFIX":str(ROOT/"WORK/PYCACHE"),"NUMBA_CACHE_DIR":str(ROOT/"WORK/NUMBA_CACHE")})
    with out.open("wb") as fo,err.open("wb") as fe:
        p=subprocess.run(cmd,cwd=str(ROOT),env=env,stdout=fo,stderr=fe)
    return p.returncode,res,proof,out,err

def eligible_cs_refusal(row,rc,res,proof):
    if rc!=10 or not res.is_file() or not proof.is_file():return False,[f"returncode={rc}"]
    r=load_json(res);pf=load_json(proof);errs=[]
    if r.get("ok") is not False or r.get("error_classification")!="SOLVER_PRECISION_OR_SUCCESS_REFUSAL":errs.append("classification")
    if r.get("precision_authority_id")!="candidate_C":errs.append("precision_authority")
    if not requests_equal(r.get("request",{}),row):errs.append("request")
    sid=load_json(ROOT/"WORK/SOURCE_IDENTITY.json")
    if r.get("source_main_sha256")!=sid["candidate_cs"]["PRyM_main_sha256"]:errs.append("source")
    sp=r.get("solver_precision",{})
    if sp.get("requested")!=physical_solver_profile(ROOT) or sp.get("contract_identity_pass") is not True or sp.get("solver_success_pass") is not False:errs.append("precision")
    sol=r.get("solver_status",{})
    if not sol or sol.get("HT",{}).get("success") is not True or sol.get("MT",{}).get("success") is not True or sol.get("LT",{}).get("success") is not False:errs.append("solver_pattern")
    off=r.get("official_PRyMresults")
    if not isinstance(off,list) or len(off)!=8 or not all(math.isfinite(float(v)) for v in off):errs.append("outputs")
    if pf.get("pass") is not True:errs.append("proof")
    if row["kind"]=="perturbed":
        if pf.get("reaction")!=row["reaction"]:errs.append("proof_reaction")
        try:
            if float(pf.get("requested_factor"))!=float(row["rate_factor"]):errs.append("proof_factor")
            if float(pf.get("worst_relative_error",999))>2e-11:errs.append("proof_error")
        except Exception:errs.append("proof_numeric")
    recs=r.get("scaled_shifted_records",[])
    if not (len(recs)==1 and recs[0].get("success") is False and float(recs[0].get("rtol"))==2e-9 and
            float(recs[0].get("atol_y_min"))==1e-16 and float(recs[0].get("atol_y_max"))==1e-16):errs.append("scaled_record")
    return not errs,errs

def validate_success(row,profile,rc,res,proof,require_scaled):
    if rc!=0 or not res.is_file() or not proof.is_file():return False,["process_or_output"]
    r=load_json(res);pf=load_json(proof);errs=[]
    if r.get("ok") is not True:errs.append("result")
    if r.get("precision_authority_id")!="candidate_C":errs.append("precision_authority")
    if not requests_equal(r.get("request",{}),row):errs.append("request")
    sid=load_json(ROOT/"WORK/SOURCE_IDENTITY.json")
    key="candidate_cs" if profile=="CANDIDATE_CS" else "candidate_c"
    if r.get("source_main_sha256")!=sid[key]["PRyM_main_sha256"]:errs.append("source")
    sp=r.get("solver_precision",{})
    if sp.get("requested")!=physical_solver_profile(ROOT) or sp.get("contract_identity_pass") is not True or sp.get("solver_success_pass") is not True:errs.append("precision")
    sol=r.get("solver_status",{})
    if not sol or any(v.get("success") is not True for v in sol.values()):errs.append("solver")
    if pf.get("pass") is not True:errs.append("proof")
    if row["kind"]=="perturbed":
        if pf.get("reaction")!=row["reaction"] or float(pf.get("requested_factor"))!=float(row["rate_factor"]) or float(pf.get("worst_relative_error",999))>2e-11:errs.append("rate_proof")
    if require_scaled:
        recs=r.get("scaled_shifted_records",[])
        if not (len(recs)==1 and recs[0].get("success") is True and float(recs[0].get("rtol"))==2e-9 and
                float(recs[0].get("atol_y_min"))==1e-16 and float(recs[0].get("atol_y_max"))==1e-16):errs.append("scaled_record")
    return not errs,errs

def publish(srcres,srcproof,outres,outproof,path,primary_meta=None,total_elapsed=None):
    r=load_json(srcres);r["cr_profile_id"]="candidate_C_R";r["cr_accepted_path"]=path;r["cr_primary_refusal"]=primary_meta
    if total_elapsed is not None:r["cr_total_elapsed_s"]=total_elapsed
    write_atomic(outres,r);write_atomic(outproof,load_json(srcproof))

def main():
    ap=argparse.ArgumentParser();ap.add_argument("--request",required=True);ap.add_argument("--result",required=True);ap.add_argument("--proof",required=True);a=ap.parse_args()
    reqp=Path(a.request).resolve();outres=Path(a.result).resolve();outproof=Path(a.proof).resolve();row=load_json(reqp);base=outres.parent/"CR_INTERNAL";start=time.time()
    rc,res,pf,so,se=run_profile("CANDIDATE_CS",reqp,base/"CANDIDATE_CS_PRIMARY")
    ok,errs=validate_success(row,"CANDIDATE_CS",rc,res,pf,True)
    if ok:
        publish(res,pf,outres,outproof,"CANDIDATE_CS_PRIMARY",None,time.time()-start)
        print("PRYM_CR_ROW",row["run_id"],row.get("reaction") or "baseline","PASS","PATH","CANDIDATE_CS_PRIMARY",flush=True);return 0
    elig,eerrs=eligible_cs_refusal(row,rc,res,pf)
    if not elig:
        fail=load_json(res) if res.is_file() else {"schema":"cptg-prymordial-row-result-v2","request":row,"ok":False}
        fail.update({"cr_profile_id":"candidate_C_R","cr_accepted_path":None,"cr_primary_refusal_eligible":False,
                     "cr_failure_stage":"CANDIDATE_CS_PRIMARY","cr_validation_errors":errs,"cr_eligibility_errors":eerrs})
        write_atomic(outres,fail)
        if pf.is_file():write_atomic(outproof,load_json(pf))
        print("PRYM_CR_ROW",row["run_id"],row.get("reaction") or "baseline","FAIL_NONELIGIBLE_PRIMARY",errs,eerrs,flush=True);return 10
    primary_meta={"eligible":True,
        "request_relpath":reqp.relative_to(ROOT).as_posix(),
        "result_relpath":res.relative_to(ROOT).as_posix(),"result_sha256":sha_file(res),
        "proof_relpath":pf.relative_to(ROOT).as_posix(),"proof_sha256":sha_file(pf),
        "request_sha256":sha_file(reqp),
        "stdout_relpath":so.relative_to(ROOT).as_posix(),"stdout_sha256":sha_file(so),
        "stderr_relpath":se.relative_to(ROOT).as_posix(),"stderr_sha256":sha_file(se)}
    rc2,res2,pf2,so2,se2=run_profile("CANDIDATE_C",reqp,base/"CANDIDATE_C_NATIVE_FALLBACK")
    ok2,errs2=validate_success(row,"CANDIDATE_C",rc2,res2,pf2,False)
    if not ok2:
        fail=load_json(res2) if res2.is_file() else {"schema":"cptg-prymordial-row-result-v2","request":row,"ok":False}
        fail.update({"cr_profile_id":"candidate_C_R","cr_accepted_path":None,"cr_primary_refusal":primary_meta,
                     "cr_failure_stage":"CANDIDATE_C_NATIVE_FALLBACK","cr_validation_errors":errs2})
        write_atomic(outres,fail)
        if pf2.is_file():write_atomic(outproof,load_json(pf2))
        print("PRYM_CR_ROW",row["run_id"],row.get("reaction") or "baseline","FAIL_NATIVE_FALLBACK",errs2,flush=True);return 10
    publish(res2,pf2,outres,outproof,"CANDIDATE_C_NATIVE_FALLBACK",primary_meta,time.time()-start)
    print("PRYM_CR_ROW",row["run_id"],row.get("reaction") or "baseline","PASS","PATH","CANDIDATE_C_NATIVE_FALLBACK",flush=True);return 0

if __name__=="__main__":raise SystemExit(main())
