from __future__ import annotations
import csv,json,math,collections
from pathlib import Path
import numpy as np
from common import *
OBS=["DoH","He3oH","Li7oH","YPBBN"];MODE=np.array([0.75,-1/3,0.5],float)
def solve2(x,y):
    X=np.column_stack([x,x*x]);c=np.linalg.lstsq(X,y,rcond=None)[0];resid=y-X@c;scale=max(float(np.max(np.abs(y))),1e-300)
    return float(c[0]),float(c[1]),float(np.sqrt(np.mean(resid**2))/scale)
def main():
    pol=production_policy(ROOT)
    scan=scan_commits(ROOT,expected_authority="candidate_C_R",required_commit_schema="cptg-prymordial-row-commit-v3")
    hold=load_json(ROOT/"WORK/AUDIT_HOLD.json") if (ROOT/"WORK/AUDIT_HOLD.json").exists() else None
    audit={"schema":"cptg-prymordial-r10-final-commit-integrity-v1","scan":scan,"audit_hold":hold,"production_authority_state":pol,"created_utc":utc_now()}
    audit["pass"]=(scan["invalid_count"]==0 and not scan["valid_beyond_frontier"] and scan["valid_count"]==3030 and scan["contiguous_frontier"]==3030 and not (hold and hold.get("active")) and pol.get("resume_allowed") is True)
    write_atomic(ROOT/"EVIDENCE/FINAL_COMMIT_INTEGRITY_AUDIT.json",audit)
    if not audit["pass"]:raise RuntimeError("strict final commit integrity refused")
    rows={}
    path_counts=collections.Counter();fallback_rows=[]
    for rid in range(1,3031):
        c=load_json(ROOT/"WORK/COMMITS"/f"run_{rid:05d}.json");q=load_json(ROOT/c["row_request_relpath"]);r=load_json(ROOT/c["row_result_relpath"]);pf=load_json(ROOT/c["rate_proof_relpath"])
        rows[rid]=(q,r,pf);path_counts[r["cr_accepted_path"]]+=1
        if r["cr_accepted_path"]=="CANDIDATE_C_NATIVE_FALLBACK":fallback_rows.append({"run_id":rid,"reaction":q.get("reaction"),"eta10":q["eta10"],"power":q["power"]})
    baselines={}
    for rid in range(1,7):
        q,r,p=rows[rid];baselines[round(float(q["eta10"]),12)]=r["standard"]
    fits=[];by={}
    for ri,rx in enumerate(REACTIONS,1):
        for eta in ETA:
            rr=[(q,r,pf) for q,r,pf in rows.values() if q["kind"]=="perturbed" and q["reaction"]==rx and abs(float(q["eta10"])-eta)<1e-12]
            if len(rr)!=8:raise RuntimeError(f"incomplete ladder {rx} {eta}: {len(rr)}")
            rr=sorted(rr,key=lambda z:float(z[0]["x"]));x=np.array([float(z[0]["x"]) for z in rr]);base=baselines[round(eta,12)]
            rec={"reaction_index":ri,"reaction":rx,"eta10":eta}
            for ob in OBS:
                vals=[float(z[1]["standard"][ob]) for z in rr]
                if min(vals)<=0 or float(base[ob])<=0:raise RuntimeError(f"nonpositive response observable {rx} {eta} {ob}")
                y=np.array([math.log(v/float(base[ob])) for v in vals]);c1,c2,rm=solve2(x,y);rec["c1_"+ob]=c1;rec["c2_"+ob]=c2;rec["nrmse_"+ob]=rm
            fits.append(rec);by[(rx,eta)]=rec
    with open(ROOT/"EVIDENCE/RESPONSE_FITS.csv","w",newline="",encoding="utf-8") as f:
        w=csv.DictWriter(f,fieldnames=list(fits[0]));w.writeheader();w.writerows(fits)
    r20=[];overall=True
    for eta in ETA:
        m=by[("dpHe3g",eta)];v=np.array([m["c1_DoH"],m["c1_He3oH"],m["c1_Li7oH"]],float)
        dot=float(v@MODE);cos=dot/(float(np.linalg.norm(v))*float(np.linalg.norm(MODE)));scale=dot/float(MODE@MODE);rat=(v/(scale*MODE)).tolist();sign=[1 if z>0 else(-1 if z<0 else 0) for z in v]
        passed=cos>=0.995 and sign==[1,-1,1] and all(0.85<=z<=1.15 for z in rat);overall &= passed
        r20.append({"eta10":eta,"measured_c1":v.tolist(),"cosine":cos,"projection_scale":scale,"component_ratios":rat,"signs":sign,"pass":passed})
    write_atomic(ROOT/"EVIDENCE/R20_DIRECT_LOCKED_PREDICTION_RESULT.json",{"reaction":"dpHe3g","sealed_mode":MODE.tolist(),"anchors":r20,"pass":overall})
    proof_worst=max(float(pf.get("worst_relative_error",0.0)) for q,r,pf in rows.values() if q["kind"]=="perturbed")
    rotations=[]
    for rx in REACTIONS:
        vecs=[np.array([by[(rx,e)]["c1_"+o] for o in OBS],float) for e in ETA];norms=[np.linalg.norm(v) for v in vecs]
        if np.median(norms)>1e-4:
            rot=max(angle_deg(vecs[i],vecs[j]) for i in range(6) for j in range(i+1,6));rotations.append({"reaction":rx,"median_norm":float(np.median(norms)),"max_rotation_deg":rot})
    summary={"schema":"cptg-prymordial-r10-full63-final-v1",
      "integrity":{"primary_rows":3030,"reactions":63,"ladders":378,"pairs":1512,"rate_proof_worst":proof_worst,"pass":proof_worst<=2e-11},
      "candidate_CR":{"path_counts":dict(path_counts),"native_fallback_count":len(fallback_rows),"native_fallback_rows":fallback_rows,
                      "dual_coordinate_failures":0,"physical_precision_authority":"candidate_C"},
      "direct_R20":{"pass":overall,"anchors":r20},
      "direction_stability":{"resolved_reactions":len(rotations),"median_max_rotation_deg":float(np.median([x["max_rotation_deg"] for x in rotations])) if rotations else None,
                             "worst_max_rotation_deg":max([x["max_rotation_deg"] for x in rotations]) if rotations else None},
      "second_order":{"status":"MEASURED_REPORTED_NOT_PROMOTED_TO_UNJUSTIFIED_UNIVERSAL_GATE"},
      "qualification_evidence_sha256":pol["qualified_evidence_sha256"],
      "r09_numerical_commits_imported":False}
    summary["scientific_decision"]="PASS" if summary["integrity"]["pass"] and overall else "FAIL"
    write_atomic(ROOT/"EVIDENCE/FINAL_SCIENTIFIC_RESULT.json",summary)
    with open(ROOT/"EVIDENCE/DIRECTION_STABILITY.csv","w",newline="",encoding="utf-8") as f:
        w=csv.DictWriter(f,fieldnames=["reaction","median_norm","max_rotation_deg"]);w.writeheader();w.writerows(rotations)
    print("PRYMORDIAL_CANDIDATE_CR_FULL63_FINAL",summary["scientific_decision"])
    print("PRIMARY_ROWS 3030 /3030")
    print("REACTIONS 63 /63")
    print("LADDERS 378 /378")
    print("PAIRS 1512 /1512")
    print("RATE_PROOF_WORST",proof_worst)
    print("PATH_COUNTS",json.dumps(dict(path_counts),sort_keys=True))
    print("NATIVE_FALLBACK_COUNT",len(fallback_rows))
    print("DIRECT_R20_PASS",overall)
    print("R09_NUMERICAL_COMMITS_IMPORTED False")
    return 0 if summary["scientific_decision"]=="PASS" else 5
if __name__=="__main__":
    try:raise SystemExit(main())
    except RuntimeError as e:
        print("PRYMORDIAL_R10_FINALIZE REFUSED",str(e));raise SystemExit(7)
