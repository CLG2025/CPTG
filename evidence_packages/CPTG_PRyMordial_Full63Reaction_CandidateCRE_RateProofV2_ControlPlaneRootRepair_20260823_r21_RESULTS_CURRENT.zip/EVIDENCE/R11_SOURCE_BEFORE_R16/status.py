from pathlib import Path
import json,collections,time
from common import ROOT,load_json,scan_commits,production_policy
def main():
    pol=production_policy(ROOT)
    scan=scan_commits(ROOT,expected_authority="candidate_C_R",required_commit_schema="cptg-prymordial-row-commit-v3")
    paths=collections.Counter()
    for rid in scan["valid"]:
        c=load_json(ROOT/"WORK/COMMITS"/f"run_{rid:05d}.json");paths[c.get("accepted_path","UNKNOWN")]+=1
    print("PRYMORDIAL_CANDIDATE_CR_FULL63_STATUS")
    print("STRICT_VALID_COMMITS",scan["valid_count"],"/",scan["total"])
    print("CONTIGUOUS_COMMIT_FRONTIER",scan["contiguous_frontier"],"/",scan["total"])
    print("INVALID_COMMITS",scan["invalid_count"])
    print("VALID_BEYOND_FRONTIER",len(scan["valid_beyond_frontier"]),scan["valid_beyond_frontier"][:20])
    print("PATH_COUNTS",json.dumps(dict(paths),sort_keys=True))
    print("PRODUCTION_AUTHORITY_STATUS",pol.get("status"),"RESUME_ALLOWED",pol.get("resume_allowed"))
    hold=ROOT/"WORK/AUDIT_HOLD.json"
    if hold.exists():
        h=load_json(hold);print("AUDIT_HOLD","ACTIVE" if h.get("active") else "INACTIVE","RUN",h.get("run_id"),"REASON",h.get("reason"))
    else: print("AUDIT_HOLD NONE")
    live=ROOT/"WORK/LIVE_STATUS.json"
    if live.exists():
        x=load_json(live);print("LIVE_STATE",x.get("state"),"ACTIVE",x.get("active_count"),"PERCENT",x.get("percent"),"UPDATED_UTC",x.get("updated_utc"))
if __name__=="__main__":main()
