from __future__ import annotations

SOLVER_PROFILES = {
    "candidate_C": {
        "MT": {"method":"BDF","rtol":2e-9,"atol":2e-15},
        "LT": {"method":"BDF","rtol":2e-9,"atol":1e-16},
    },
    "candidate_V": {
        "MT": {"method":"BDF","rtol":1e-9,"atol":1e-15},
        "LT": {"method":"BDF","rtol":1e-9,"atol":1e-16},
    },
}
SOURCE_PROFILE_AUTHORITY={"CANDIDATE_C":"candidate_C","CANDIDATE_CS":"candidate_C","VERIFY_V":"candidate_V"}

def authority_for_source(source_root):
    name=getattr(source_root,"name",str(source_root).replace("\\","/").rstrip("/").split("/")[-1]).upper()
    if name not in SOURCE_PROFILE_AUTHORITY: raise KeyError(f"unknown source profile {name!r}")
    return SOURCE_PROFILE_AUTHORITY[name]

def apply_precision(init_module,authority_id:str):
    p=SOLVER_PROFILES[authority_id]
    for phase in ("MT","LT"):
        setattr(init_module,f"CPTG_{phase}_RTOL",float(p[phase]["rtol"]))
        setattr(init_module,f"CPTG_{phase}_ATOL",float(p[phase]["atol"]))
    return p

def observed_precision(obj):
    return {phase:dict(getattr(obj,f"CPTG_precision_contract_{phase}",{})) for phase in ("MT","LT")}

def precision_identity(observed,authority_id:str):
    p=SOLVER_PROFILES[authority_id]
    return all(observed.get(ph)=={"phase":ph,**p[ph]} for ph in ("MT","LT"))
