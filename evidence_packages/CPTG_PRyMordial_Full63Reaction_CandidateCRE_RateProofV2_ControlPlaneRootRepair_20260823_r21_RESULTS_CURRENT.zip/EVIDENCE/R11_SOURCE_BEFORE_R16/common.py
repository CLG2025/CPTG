from __future__ import annotations
import csv, hashlib, json, math, os, re, shutil, tempfile, time, subprocess, signal, datetime as dt, threading
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
ETA=[6.044,6.080,6.094,6.106,6.128,6.134]
POWERS=[-2.0,-1.5,-1.0,-0.5,0.5,1.0,1.5,2.0]
LOGSTEP=0.02431326375999472
REACTIONS=[
"npdg","dpHe3g","ddHe3n","ddtp","tpag","tdan","taLi7g","He3ntp","He3dap","He3aBe7g",
"Be7nLi7p","Li7paa","Li7paag","Be7naa","Be7daap","daLi6g","Li6pBe7g","Li6pHe3a",
"B8naap","Li6He3aap","Li6taan","Li6tLi8p","Li7He3Li6a","Li8He3Li7a","Be7tLi6a",
"B8tBe7a","B8nLi6He3","B8nBe7d","Li6tLi7d","Li6He3Be7d","Li7He3aad","Li8He3aat",
"Be7taad","Be7tLi7He3","B8dBe7He3","B8taaHe3","Be7He3ppaa","ddag","He3He3app",
"Be7pB8g","Li7daan","dntg","ttann","He3nag","He3tad","He3tanp","Li7taan",
"Li7He3aanp","Li8dLi7t","Be7taanp","Be7He3aapp","Li6nta","He3tLi6g","anpLi6g",
"Li6nLi7g","Li6dLi7p","Li6dBe7n","Li7nLi8g","Li7dLi8p","Li8paan","annHe6g","ppndp","Li7taann"]
KNOWN_ROOTS=[
r"C:\Users\myuser\Downloads\PRyMordial",
r"D:\Downloads\ChatGPT\SPARC_Python\Master Action Scripts\PRyMordial",
r"D:\Downloads\PRyMordial",
r"D:\Downloads\ChatGPT\PRyMordial",
]
REQUIRED=["PRyM/PRyM_init.py","PRyM/PRyM_main.py","PRyM/PRyM_nuclear_net63.py","PRyM/PRyM_nuclear_net12.py","PRyM/PRyM_nTOp.py","PRyM/PRyM_thermo.py","PRyMrates"]
INT_FIELDS=("run_id","eta_index","reaction_index","branch_index")
FLOAT_FIELDS=("eta10","power","x","rate_factor","NP_delta")
ROW_FIELDS=("run_id","kind","reaction_index","reaction","eta_index","eta10","branch_index","power","x","rate_factor","NP_delta")


def sha_file(p:Path)->str:
    h=hashlib.sha256()
    with open(p,"rb") as f:
        for b in iter(lambda:f.read(1<<20),b""): h.update(b)
    return h.hexdigest()


_ATOMIC_LOCKS_GUARD=threading.Lock()
_ATOMIC_PATH_LOCKS={}
_ATOMIC_REPLACE_RETRY_SECONDS=2.0
_ATOMIC_REPLACE_RETRY_INITIAL_SLEEP=0.005
_ATOMIC_REPLACE_RETRY_MAX_SLEEP=0.050
_ATOMIC_READ_RETRY_SECONDS=2.0
_ATOMIC_READ_RETRY_INITIAL_SLEEP=0.002
_ATOMIC_READ_RETRY_MAX_SLEEP=0.050


def _atomic_path_lock(path:Path):
    # Serialize same-path readers and writers inside this Python process. This does
    # not replace OS atomicity; it prevents our own threads from creating avoidable
    # Windows sharing races while external-process readers are protected by the
    # bounded read retry below.
    key=os.path.normcase(os.path.abspath(str(Path(path))))
    with _ATOMIC_LOCKS_GUARD:
        lock=_ATOMIC_PATH_LOCKS.get(key)
        if lock is None:
            lock=threading.RLock(); _ATOMIC_PATH_LOCKS[key]=lock
        return lock


def _windows_share_error(exc:BaseException)->bool:
    # PermissionError is treated as a potentially transient access/share denial on
    # every platform so the regression tests can inject the Windows behavior.
    if isinstance(exc,PermissionError): return True
    winerr=getattr(exc,"winerror",None)
    return os.name=="nt" and winerr in (5,32,33)


def _replace_with_retry(src:Path,dst:Path):
    # Preserve atomic replace semantics. On Windows, transient WinError 5/32/33 may
    # occur because another process or scanner briefly holds the target. Retry only
    # those access/share denials for a bounded interval. Persistent refusal propagates.
    deadline=time.monotonic()+_ATOMIC_REPLACE_RETRY_SECONDS
    delay=_ATOMIC_REPLACE_RETRY_INITIAL_SLEEP
    while True:
        try:
            os.replace(src,dst); return
        except OSError as e:
            if not _windows_share_error(e) or time.monotonic()>=deadline: raise
        time.sleep(delay)
        delay=min(_ATOMIC_REPLACE_RETRY_MAX_SLEEP,delay*1.5)


def replace_path_with_retry(src:Path,dst:Path):
    """Atomic filesystem rename/replace with the same bounded Windows sharing retry."""
    src=Path(src); dst=Path(dst); dst.parent.mkdir(parents=True,exist_ok=True)
    with _atomic_path_lock(dst):
        _replace_with_retry(src,dst)


def unlink_with_retry(path:Path,missing_ok:bool=True):
    """Bounded retry for transient Windows access/share denial when removing control files."""
    path=Path(path)
    deadline=time.monotonic()+_ATOMIC_REPLACE_RETRY_SECONDS
    delay=_ATOMIC_REPLACE_RETRY_INITIAL_SLEEP
    while True:
        try:
            path.unlink(missing_ok=missing_ok); return
        except FileNotFoundError:
            if missing_ok: return
            raise
        except OSError as e:
            if not _windows_share_error(e) or time.monotonic()>=deadline: raise
        time.sleep(delay)
        delay=min(_ATOMIC_REPLACE_RETRY_MAX_SLEEP,delay*1.5)


def write_atomic(path:Path,obj):
    """Atomic JSON replacement with per-path serialization and bounded Windows retry."""
    path=Path(path); path.parent.mkdir(parents=True,exist_ok=True)
    with _atomic_path_lock(path):
        fd,tmp_name=tempfile.mkstemp(prefix=path.name+f".tmp.{os.getpid()}.",dir=str(path.parent))
        tmp=Path(tmp_name)
        try:
            with os.fdopen(fd,"w",encoding="utf-8",newline="\n") as f:
                json.dump(obj,f,indent=2,sort_keys=True,allow_nan=False); f.write("\n"); f.flush(); os.fsync(f.fileno())
            _replace_with_retry(tmp,path)
        finally:
            try:
                if tmp.exists(): unlink_with_retry(tmp,missing_ok=True)
            except Exception: pass


def _read_text_once(path:Path)->str:
    return Path(path).read_text(encoding="utf-8")


def read_text_stable(path:Path)->str:
    """Read a control JSON text atomically enough for Windows sharing semantics.

    Same-process reads serialize with same-path writes. Cross-process transient
    WinError 5/32/33/PermissionError is retried for a bounded interval. The
    function does NOT retry Unicode/JSON parse errors; malformed content remains a
    fail-closed integrity error rather than being reinterpreted as contention.
    """
    path=Path(path)
    deadline=time.monotonic()+_ATOMIC_READ_RETRY_SECONDS
    delay=_ATOMIC_READ_RETRY_INITIAL_SLEEP
    with _atomic_path_lock(path):
        while True:
            try:
                return _read_text_once(path)
            except OSError as e:
                if not _windows_share_error(e) or time.monotonic()>=deadline: raise
            time.sleep(delay)
            delay=min(_ATOMIC_READ_RETRY_MAX_SLEEP,delay*1.5)


def load_json(p):
    # JSON decoding is intentionally outside the retry exception handler. A complete
    # but malformed document is corruption and must fail immediately.
    return json.loads(read_text_stable(Path(p)))

def valid_root(p:Path): return all((p/x).exists() for x in REQUIRED)

def locate_root(explicit=None):
    cand=[]
    if explicit: cand.append(Path(explicit))
    env=os.environ.get("CPTG_PRYM_ROOT","").strip()
    if env: cand.append(Path(env))
    cand += [Path(x) for x in KNOWN_ROOTS]
    seen=set()
    for p in cand:
        q=str(p).lower()
        if q in seen: continue
        seen.add(q)
        if valid_root(p): return p.resolve()
    raise RuntimeError("PRyMordial source root not found. Set CPTG_PRYM_ROOT to a known root containing PRyM/PRyM_main.py and PRyMrates.")

def tree_manifest(p:Path):
    out=[]
    for x in sorted(p.rglob("*")):
        if not x.is_file(): continue
        if ".git" in x.parts or "__pycache__" in x.parts: continue
        out.append({"path":x.relative_to(p).as_posix(),"sha256":sha_file(x),"size_bytes":x.stat().st_size})
    return out

def utc_now(): return dt.datetime.now(dt.timezone.utc).isoformat()

def free_disk_gib(path:Path)->float: return shutil.disk_usage(path).free/(1024**3)

def tail_text(path:Path,limit:int=12000)->str:
    if not path.exists(): return ""
    return path.read_bytes()[-limit:].decode("utf-8","replace")

def _windows_system_executable(name:str)->str|None:
    """Resolve standard Windows utilities even when System32 is absent from PATH."""
    import shutil as _shutil
    hit=_shutil.which(name)
    if hit: return hit
    root=Path(os.environ.get("SystemRoot") or os.environ.get("WINDIR") or r"C:\Windows")
    low=name.lower()
    candidates=[]
    if low in ("powershell","powershell.exe"):
        candidates.append(root/"System32/WindowsPowerShell/v1.0/powershell.exe")
    elif low in ("taskkill","taskkill.exe"):
        candidates.append(root/"System32/taskkill.exe")
    elif low in ("tasklist","tasklist.exe"):
        candidates.append(root/"System32/tasklist.exe")
    else:
        candidates.append(root/"System32"/name)
    for p in candidates:
        if p.is_file(): return str(p)
    return None

def kill_process_tree(proc:subprocess.Popen)->None:
    if proc.poll() is not None: return
    if os.name=="nt":
        exe=_windows_system_executable("taskkill.exe")
        if exe:
            try:
                subprocess.run([exe,"/PID",str(proc.pid),"/T","/F"],
                               stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=30)
                return
            except Exception:
                pass
        try: proc.kill()
        except Exception: pass
    else:
        try: os.killpg(os.getpgid(proc.pid),signal.SIGKILL)
        except Exception:
            try: proc.kill()
            except Exception: pass

def pid_alive(pid:int)->bool:
    if pid<=0: return False
    if os.name=="nt":
        # Primary path: native process handle. Independent of PATH and PowerShell.
        try:
            import ctypes
            from ctypes import wintypes
            PROCESS_QUERY_LIMITED_INFORMATION=0x1000
            STILL_ACTIVE=259
            k32=ctypes.WinDLL("kernel32",use_last_error=True)
            k32.OpenProcess.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.DWORD]
            k32.OpenProcess.restype=wintypes.HANDLE
            k32.GetExitCodeProcess.argtypes=[wintypes.HANDLE,ctypes.POINTER(wintypes.DWORD)]
            k32.GetExitCodeProcess.restype=wintypes.BOOL
            k32.CloseHandle.argtypes=[wintypes.HANDLE]
            h=k32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION,False,int(pid))
            if h:
                code=wintypes.DWORD()
                ok=bool(k32.GetExitCodeProcess(h,ctypes.byref(code)))
                k32.CloseHandle(h)
                if ok: return int(code.value)==STILL_ACTIVE
        except Exception:
            pass
        exe=_windows_system_executable("tasklist.exe")
        if exe:
            try:
                r=subprocess.run([exe,"/FI",f"PID eq {pid}","/FO","CSV","/NH"],
                                 capture_output=True,text=True,timeout=10)
                return r.returncode==0 and str(pid) in r.stdout and "No tasks" not in r.stdout
            except Exception:
                return False
        return False
    try:
        os.kill(pid,0); return True
    except ProcessLookupError: return False
    except PermissionError: return True
    except Exception: return False

def _windows_tree_private_bytes_native(pid:int):
    """Observe one Windows process tree and PrivateUsage using Win32 APIs only."""
    try:
        import ctypes
        from ctypes import wintypes
        TH32CS_SNAPPROCESS=0x00000002
        PROCESS_QUERY_LIMITED_INFORMATION=0x1000
        PROCESS_QUERY_INFORMATION=0x0400
        PROCESS_VM_READ=0x0010
        INVALID_HANDLE_VALUE=ctypes.c_void_p(-1).value

        class PROCESSENTRY32W(ctypes.Structure):
            _fields_=[
                ("dwSize",wintypes.DWORD),
                ("cntUsage",wintypes.DWORD),
                ("th32ProcessID",wintypes.DWORD),
                ("th32DefaultHeapID",ctypes.c_size_t),
                ("th32ModuleID",wintypes.DWORD),
                ("cntThreads",wintypes.DWORD),
                ("th32ParentProcessID",wintypes.DWORD),
                ("pcPriClassBase",ctypes.c_long),
                ("dwFlags",wintypes.DWORD),
                ("szExeFile",wintypes.WCHAR*260),
            ]

        class PROCESS_MEMORY_COUNTERS_EX(ctypes.Structure):
            _fields_=[
                ("cb",wintypes.DWORD),
                ("PageFaultCount",wintypes.DWORD),
                ("PeakWorkingSetSize",ctypes.c_size_t),
                ("WorkingSetSize",ctypes.c_size_t),
                ("QuotaPeakPagedPoolUsage",ctypes.c_size_t),
                ("QuotaPagedPoolUsage",ctypes.c_size_t),
                ("QuotaPeakNonPagedPoolUsage",ctypes.c_size_t),
                ("QuotaNonPagedPoolUsage",ctypes.c_size_t),
                ("PagefileUsage",ctypes.c_size_t),
                ("PeakPagefileUsage",ctypes.c_size_t),
                ("PrivateUsage",ctypes.c_size_t),
            ]

        k32=ctypes.WinDLL("kernel32",use_last_error=True)
        psapi=ctypes.WinDLL("psapi",use_last_error=True)
        k32.CreateToolhelp32Snapshot.argtypes=[wintypes.DWORD,wintypes.DWORD]
        k32.CreateToolhelp32Snapshot.restype=wintypes.HANDLE
        k32.Process32FirstW.argtypes=[wintypes.HANDLE,ctypes.POINTER(PROCESSENTRY32W)]
        k32.Process32FirstW.restype=wintypes.BOOL
        k32.Process32NextW.argtypes=[wintypes.HANDLE,ctypes.POINTER(PROCESSENTRY32W)]
        k32.Process32NextW.restype=wintypes.BOOL
        k32.OpenProcess.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.DWORD]
        k32.OpenProcess.restype=wintypes.HANDLE
        k32.CloseHandle.argtypes=[wintypes.HANDLE]
        psapi.GetProcessMemoryInfo.argtypes=[wintypes.HANDLE,ctypes.POINTER(PROCESS_MEMORY_COUNTERS_EX),wintypes.DWORD]
        psapi.GetProcessMemoryInfo.restype=wintypes.BOOL

        snap=k32.CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS,0)
        if not snap or snap==INVALID_HANDLE_VALUE:
            return None,[]
        rows={}
        try:
            e=PROCESSENTRY32W(); e.dwSize=ctypes.sizeof(e)
            ok=bool(k32.Process32FirstW(snap,ctypes.byref(e)))
            while ok:
                rows[int(e.th32ProcessID)]=(int(e.th32ParentProcessID),str(e.szExeFile))
                e.dwSize=ctypes.sizeof(e)
                ok=bool(k32.Process32NextW(snap,ctypes.byref(e)))
        finally:
            k32.CloseHandle(snap)

        root=int(pid)
        if root not in rows:
            return None,[]
        wanted={root}
        changed=True
        while changed:
            changed=False
            for p,(pp,name) in rows.items():
                if pp in wanted and p not in wanted:
                    wanted.add(p); changed=True

        records=[]; total=0
        for p in sorted(wanted):
            pp,name=rows[p]
            h=k32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION|PROCESS_VM_READ,False,p)
            if not h:
                h=k32.OpenProcess(PROCESS_QUERY_INFORMATION|PROCESS_VM_READ,False,p)
            if not h:
                return None,[]
            try:
                m=PROCESS_MEMORY_COUNTERS_EX(); m.cb=ctypes.sizeof(m)
                if not psapi.GetProcessMemoryInfo(h,ctypes.byref(m),m.cb):
                    return None,[]
                private=int(m.PrivateUsage); working=int(m.WorkingSetSize)
            finally:
                k32.CloseHandle(h)
            total+=private
            records.append({
                "pid":p,"parent_pid":pp,"name":name,
                "private_bytes":private,"working_set_bytes":working,
                "command_line":None,"observer":"win32_ctypes"
            })
        return total,records
    except Exception:
        return None,[]

def _windows_tree_private_bytes_psutil(pid:int):
    """Optional fallback when psutil is available."""
    try:
        import psutil
        root=psutil.Process(int(pid))
        procs=[root]+root.children(recursive=True)
        records=[]; total=0
        for p in procs:
            try:
                mi=p.memory_info()
                private=getattr(mi,"private",None)
                if private is None:
                    mfi=p.memory_full_info()
                    private=getattr(mfi,"private",None)
                if private is None: return None,[]
                private=int(private); total+=private
                records.append({
                    "pid":int(p.pid),"parent_pid":int(p.ppid()),"name":p.name(),
                    "private_bytes":private,"working_set_bytes":int(getattr(mi,"rss",0)),
                    "command_line":None,"observer":"psutil"
                })
            except (psutil.NoSuchProcess,psutil.ZombieProcess):
                continue
            except Exception:
                return None,[]
        if not any(int(x["pid"])==int(pid) for x in records):
            return None,[]
        return total,records
    except Exception:
        return None,[]

def _windows_tree_private_bytes_powershell(pid:int,script:Path):
    """Tertiary compatibility fallback using an absolute PowerShell path."""
    exe=_windows_system_executable("powershell.exe")
    if not exe: return None,[]
    try:
        run=subprocess.run([exe,"-NoProfile","-ExecutionPolicy","Bypass","-File",str(script),"-RootPid",str(pid)],
                           capture_output=True,text=True,timeout=20)
        if run.returncode!=0 or not run.stdout.strip(): return None,[]
        data=json.loads(run.stdout)
        if isinstance(data,dict): data=[data]
        if not data: return None,[]
        for x in data: x.setdefault("observer","powershell_cim")
        return sum(int(x.get("private_bytes") or 0) for x in data),data
    except Exception:
        return None,[]

def _windows_tree_private_bytes(pid:int,script:Path):
    total,records=_windows_tree_private_bytes_native(pid)
    if total is not None: return total,records
    total,records=_windows_tree_private_bytes_psutil(pid)
    if total is not None: return total,records
    return _windows_tree_private_bytes_powershell(pid,script)

def _windows_forest_private_bytes(pids:list[int],script:Path):
    """
    Observe multiple active controller roots without a PATH-dependent PowerShell call.
    Each root is independently sampled through the same Win32-primary tree observer
    that passed Candidate C-R qualification.
    """
    roots=[int(x) for x in pids if int(x)>0]
    out={}
    for pid in roots:
        out[pid]=_windows_tree_private_bytes(pid,script)
    return out


def _unix_private_bytes(pid:int):
    status=Path(f"/proc/{pid}/status")
    try:
        kb=0
        for line in status.read_text().splitlines():
            if line.startswith("VmRSS:"): kb=int(line.split()[1]); break
        return kb*1024,[{"pid":pid,"private_bytes":kb*1024}]
    except Exception: return None,[]

def run_monitored(command:list[str],cwd:Path,stdout_path:Path,stderr_path:Path,*,timeout_seconds:int,poll_seconds:float,max_private_gib:float,min_free_disk_gib:float,consecutive_breaches:int,stalled_output_seconds:int,environment:dict|None=None)->dict:
    stdout_path.parent.mkdir(parents=True,exist_ok=True); stderr_path.parent.mkdir(parents=True,exist_ok=True)
    start=time.monotonic(); started=utc_now(); breach_count=0; samples=[]; reason=None; timeout=False; resource=False; stalled=False
    flags=subprocess.CREATE_NEW_PROCESS_GROUP if os.name=="nt" else 0
    preexec=None if os.name=="nt" else os.setsid
    with stdout_path.open("wb") as out, stderr_path.open("wb") as err:
        proc=subprocess.Popen(command,cwd=str(cwd),stdout=out,stderr=err,env=environment,creationflags=flags,preexec_fn=preexec)
        last_output_time=time.monotonic(); last_sizes=(0,0)
        try:
            while proc.poll() is None:
                time.sleep(max(0.05,poll_seconds)); elapsed=time.monotonic()-start
                sizes=(stdout_path.stat().st_size if stdout_path.exists() else 0,stderr_path.stat().st_size if stderr_path.exists() else 0)
                if sizes!=last_sizes: last_output_time=time.monotonic(); last_sizes=sizes
                if elapsed>timeout_seconds:
                    timeout=True; reason=f"timeout>{timeout_seconds}s"; kill_process_tree(proc); break
                if stalled_output_seconds>0 and time.monotonic()-last_output_time>stalled_output_seconds:
                    stalled=True; reason=f"stalled_output>{stalled_output_seconds}s"; kill_process_tree(proc); break
                tree_bytes,records=(_windows_tree_private_bytes(proc.pid,ROOT/"SOURCE/process_tree_sample.ps1") if os.name=="nt" else _unix_private_bytes(proc.pid))
                disk=free_disk_gib(cwd); observation_failed=tree_bytes is None
                exceeds=observation_failed or (max_private_gib>0 and tree_bytes/(1024**3)>max_private_gib) or disk<min_free_disk_gib
                breach_count=breach_count+1 if exceeds else 0
                samples.append({"utc":utc_now(),"elapsed_seconds":elapsed,"tree_private_bytes":tree_bytes,"free_disk_gib":disk,"processes":records,"observation_failed":observation_failed,"breach":exceeds})
                if breach_count>=consecutive_breaches:
                    resource=True; reason="resource_observation_failure" if observation_failed else "resource_threshold_breach"; kill_process_tree(proc); break
        except KeyboardInterrupt:
            kill_process_tree(proc)
            try: proc.wait(timeout=30)
            except Exception: pass
            raise
        try: rc=proc.wait(timeout=30)
        except Exception: kill_process_tree(proc); rc=proc.wait()
    return {"command":command,"cwd":str(cwd),"started_utc":started,"ended_utc":utc_now(),"elapsed_seconds":time.monotonic()-start,"returncode":rc,"timeout":timeout,"resource_breach":resource,"stalled_output":stalled,"stop_reason":reason,"stdout_path":str(stdout_path),"stderr_path":str(stderr_path),"stdout_sha256":sha_file(stdout_path),"stderr_sha256":sha_file(stderr_path),"stdout_tail":tail_text(stdout_path),"stderr_tail":tail_text(stderr_path),"resource_samples":samples}

def angle_deg(a,b):
    import numpy as np
    a=np.asarray(a,float); b=np.asarray(b,float); na=float(np.linalg.norm(a)); nb=float(np.linalg.norm(b))
    if na==0 or nb==0: return float("nan")
    c=float(np.dot(a,b)/(na*nb)); c=max(-1.0,min(1.0,c)); return math.degrees(math.acos(c))

# ---------- Frozen ledger and unified commit validation ----------
def normalize_ledger_row(r:dict)->dict:
    out={k:r.get(k,"") for k in ROW_FIELDS}
    for k in INT_FIELDS:
        v=out[k]; out[k]="" if v in (None,"") else int(v)
    for k in FLOAT_FIELDS: out[k]=float(out[k])
    out["kind"]=str(out["kind"]); out["reaction"]=str(out["reaction"] or "")
    return out

def read_primary_ledger(root:Path=ROOT):
    with open(root/"CONFIG/PRIMARY_EXECUTION_LEDGER.csv",newline="",encoding="utf-8") as f: return [normalize_ledger_row(r) for r in csv.DictReader(f)]

def ledger_map(root:Path=ROOT): return {int(r["run_id"]):r for r in read_primary_ledger(root)}

def requests_equal(a:dict,b:dict)->bool:
    try:
        if set(a.keys())!=set(ROW_FIELDS) or set(b.keys())!=set(ROW_FIELDS): return False
        aa=normalize_ledger_row(a); bb=normalize_ledger_row(b)
        return all(aa[k]==bb[k] for k in ROW_FIELDS)
    except Exception: return False

def _safe_rel(root:Path,rel:str)->Path:
    p=(root/rel).resolve(); rr=root.resolve()
    if p!=rr and rr not in p.parents: raise ValueError("relative path escapes package root")
    return p

def production_policy(root:Path=ROOT)->dict:
    p=root/"CONFIG/PRODUCTION_AUTHORITY_STATE.json"
    return load_json(p) if p.exists() else {}

def expected_profile(root:Path,authority_id:str)->dict:
    auth=load_json(root/"CONFIG/HISTORICAL_SOLVER_AUTHORITY.json")
    return auth["profiles"][authority_id]

def strict_validate_artifacts(root:Path,expected_row:dict,request_path:Path,result_path:Path,proof_path:Path,*,expected_authority:str,expected_source_sha256:str|None=None):
    errors=[]; details={}
    try: q=load_json(request_path)
    except Exception as e: return False,["request_unreadable:"+repr(e)],details
    if not requests_equal(q,expected_row): errors.append("request_not_exact_frozen_ledger_row")
    try: r=load_json(result_path)
    except Exception as e: return False,errors+["result_unreadable:"+repr(e)],details
    try: pf=load_json(proof_path)
    except Exception as e: return False,errors+["proof_unreadable:"+repr(e)],details
    if r.get("schema")!="cptg-prymordial-row-result-v2": errors.append("result_schema_mismatch")
    if r.get("ok") is not True: errors.append("result_ok_false")
    if not requests_equal(r.get("request",{}),expected_row): errors.append("result_embedded_request_mismatch")
    if r.get("precision_authority_id")!=expected_authority: errors.append("wrong_precision_authority")
    if expected_source_sha256 and r.get("source_main_sha256")!=expected_source_sha256: errors.append("wrong_source_main_sha256")
    sp=r.get("solver_precision",{})
    if sp.get("contract_identity_pass") is not True: errors.append("precision_contract_identity_fail")
    if sp.get("solver_success_pass") is not True: errors.append("solver_success_fail")
    try:
        reqprof=expected_profile(root,expected_authority)
        if sp.get("requested")!=reqprof: errors.append("requested_precision_profile_mismatch")
        obs=sp.get("observed",{})
        for ph in ("MT","LT"):
            exp={"phase":ph,**reqprof[ph]}
            if obs.get(ph)!=exp: errors.append(f"observed_precision_{ph}_mismatch")
    except Exception as e: errors.append("precision_profile_audit_error:"+repr(e))
    solver=r.get("solver_status",{})
    if not solver or any(v.get("success") is not True for v in solver.values()): errors.append("native_solver_phase_failure")
    off=r.get("official_PRyMresults")
    if not isinstance(off,list) or len(off)!=8 or not all(math.isfinite(float(v)) for v in off): errors.append("official_PRyMresults_invalid")
    std=r.get("standard",{})
    for k in ("Neff","Omeganurel","OneOverOmeganunr","YPCMB","YPBBN","DoH","He3oH","Li7oH"):
        try:
            if not math.isfinite(float(std[k])): errors.append("standard_nonfinite_"+k)
        except Exception: errors.append("standard_missing_"+k)
    try:
        if abs(float(r.get("eta0b_used"))-float(expected_row["eta10"])*1e-10)>1e-22: errors.append("eta0b_used_mismatch")
    except Exception: errors.append("eta0b_used_invalid")
    if bool(r.get("NP_nuclear_flag")) != (expected_row["kind"]=="perturbed"): errors.append("NP_nuclear_flag_mismatch")
    gates=load_json(root/"CONFIG/ACCEPTANCE_GATES.json"); rate_lim=float(gates["integrity"]["native_rate_proof_max_relative_error"])
    if expected_row["kind"]=="baseline":
        if pf.get("pass") is not True or pf.get("kind")!="baseline": errors.append("baseline_proof_invalid")
    else:
        if pf.get("pass") is not True: errors.append("rate_proof_pass_false")
        if pf.get("reaction")!=expected_row["reaction"]: errors.append("rate_proof_reaction_mismatch")
        try:
            if float(pf.get("requested_factor"))!=float(expected_row["rate_factor"]): errors.append("rate_proof_factor_mismatch")
            if float(pf.get("worst_relative_error"))>rate_lim: errors.append("rate_proof_error_exceeds_gate")
        except Exception: errors.append("rate_proof_numeric_invalid")
    details={"authority":r.get("precision_authority_id"),"source_main_sha256":r.get("source_main_sha256"),"elapsed_s":r.get("elapsed_s"),"proof_worst":pf.get("worst_relative_error",0.0)}
    return not errors,errors,details

def strict_validate_commit(root:Path,run_id:int,rows_by_id:dict|None=None,*,expected_authority:str|None=None,expected_source_sha256:str|None=None,required_commit_schema:str|None=None):
    rows_by_id=rows_by_id or ledger_map(root); expected=rows_by_id.get(int(run_id)); errors=[]; details={}
    if expected is None: return False,["run_id_not_in_ledger"],details
    p=root/"WORK/COMMITS"/f"run_{int(run_id):05d}.json"
    if not p.is_file(): return False,["commit_missing"],details
    try: c=load_json(p)
    except Exception as e: return False,["commit_unreadable:"+repr(e)],details
    if int(c.get("run_id",-1))!=int(run_id): errors.append("commit_run_id_mismatch")
    if required_commit_schema and c.get("schema")!=required_commit_schema: errors.append("commit_schema_mismatch")
    try:
        qp=_safe_rel(root,c["row_request_relpath"]); rp=_safe_rel(root,c["row_result_relpath"]); pp=_safe_rel(root,c["rate_proof_relpath"])
    except Exception as e: return False,errors+["commit_path_invalid:"+repr(e)],details
    for label,path,hkey in (("request",qp,"row_request_sha256"),("result",rp,"row_result_sha256"),("proof",pp,"rate_proof_sha256")):
        if not path.is_file(): errors.append(label+"_file_missing")
        else:
            try:
                if sha_file(path)!=c.get(hkey): errors.append(label+"_sha256_mismatch")
            except Exception as e: errors.append(label+"_hash_error:"+repr(e))
    if errors: return False,errors,details
    pol=production_policy(root)
    authority=expected_authority or c.get("authority_id") or pol.get("legacy_import_authority") or pol.get("authority_id") or "candidate_C"
    source_sha=expected_source_sha256 or c.get("source_main_sha256") or pol.get("accepted_source_main_sha256")
    ok,aerr,adetails=strict_validate_artifacts(root,expected,qp,rp,pp,expected_authority=authority,expected_source_sha256=source_sha)
    errors.extend(aerr); details.update(adetails); details["commit_schema"]=c.get("schema")
    if c.get("schema")=="cptg-prymordial-row-commit-v2":
        if c.get("authority_id")!=authority: errors.append("commit_authority_id_mismatch")
        if source_sha and c.get("source_main_sha256")!=source_sha: errors.append("commit_source_sha256_mismatch")
        if int(c.get("promotion_sequence",-1))!=int(run_id): errors.append("promotion_sequence_not_run_id")
        if run_id>1:
            prev=root/"WORK/COMMITS"/f"run_{run_id-1:05d}.json"
            if not prev.is_file(): errors.append("previous_commit_missing_for_chain")
            elif c.get("previous_commit_sha256")!=sha_file(prev): errors.append("previous_commit_chain_mismatch")
        elif c.get("previous_commit_sha256") not in (None,""): errors.append("run1_previous_commit_not_empty")
    return not errors,errors,details

def scan_commits(root:Path=ROOT,*,expected_authority:str|None=None,expected_source_sha256:str|None=None,required_commit_schema:str|None=None):
    rows=ledger_map(root); present={}
    cdir=root/"WORK/COMMITS"
    if cdir.exists():
        for p in cdir.glob("run_*.json"):
            m=re.fullmatch(r"run_(\d{5})\.json",p.name)
            if m: present[int(m.group(1))]=p
    valid=[]; invalid=[]
    for rid in sorted(present):
        ok,errs,details=strict_validate_commit(root,rid,rows,expected_authority=expected_authority,expected_source_sha256=expected_source_sha256,required_commit_schema=required_commit_schema)
        (valid if ok else invalid).append(rid if ok else {"run_id":rid,"errors":errs,"details":details})
    frontier=0
    validset=set(valid)
    for rid in range(1,len(rows)+1):
        if rid in validset: frontier=rid
        else: break
    extras=[rid for rid in valid if rid>frontier]
    return {"total":len(rows),"present":len(present),"valid":valid,"valid_count":len(valid),"invalid":invalid,"invalid_count":len(invalid),"contiguous_frontier":frontier,"valid_beyond_frontier":extras}


# ==================== r10 Candidate C-R authority overrides ====================

def physical_solver_profile(root:Path=ROOT):
    return load_json(root/"CONFIG/PHYSICAL_SOLVER_AUTHORITY.json")["profiles"]["candidate_C"]

def _cr_source_identity(root:Path=ROOT):
    return load_json(root/"WORK/SOURCE_IDENTITY.json")

def _validate_scaled_record(r):
    recs=r.get("scaled_shifted_records",[])
    return (len(recs)==1 and recs[0].get("success") is True and
            float(recs[0].get("rtol"))==2e-9 and
            float(recs[0].get("atol_y_min"))==1e-16 and
            float(recs[0].get("atol_y_max"))==1e-16)

def _eligible_primary_refusal_artifacts(root:Path,expected_row:dict,meta:dict):
    errors=[]
    try:
        for key in ("request_relpath","result_relpath","proof_relpath"):
            if key not in meta: errors.append("primary_refusal_missing_"+key)
        if errors: return False,errors
        qp=_safe_rel(root,meta["request_relpath"]); rp=_safe_rel(root,meta["result_relpath"]); pp=_safe_rel(root,meta["proof_relpath"])
        for p,key in ((qp,"request_sha256"),(rp,"result_sha256"),(pp,"proof_sha256")):
            if not p.is_file(): errors.append("primary_refusal_file_missing")
            elif sha_file(p)!=meta.get(key): errors.append("primary_refusal_hash_mismatch_"+key)
        if errors: return False,errors
        q=load_json(qp); r=load_json(rp); pf=load_json(pp)
        if not requests_equal(q,expected_row) or not requests_equal(r.get("request",{}),expected_row): errors.append("primary_refusal_physics_mismatch")
        if r.get("ok") is not False or r.get("error_classification")!="SOLVER_PRECISION_OR_SUCCESS_REFUSAL": errors.append("primary_refusal_wrong_classification")
        if r.get("precision_authority_id")!="candidate_C": errors.append("primary_refusal_wrong_precision_authority")
        sid=_cr_source_identity(root)
        if r.get("source_main_sha256")!=sid["candidate_cs"]["PRyM_main_sha256"]: errors.append("primary_refusal_wrong_source")
        sp=r.get("solver_precision",{})
        if sp.get("requested")!=physical_solver_profile(root) or sp.get("contract_identity_pass") is not True or sp.get("solver_success_pass") is not False:
            errors.append("primary_refusal_precision_contract")
        solver=r.get("solver_status",{})
        if not solver or solver.get("HT",{}).get("success") is not True or solver.get("MT",{}).get("success") is not True or solver.get("LT",{}).get("success") is not False:
            errors.append("primary_refusal_solver_pattern")
        off=r.get("official_PRyMresults")
        if not isinstance(off,list) or len(off)!=8 or not all(math.isfinite(float(v)) for v in off): errors.append("primary_refusal_outputs")
        if pf.get("pass") is not True: errors.append("primary_refusal_proof")
        if expected_row["kind"]=="perturbed":
            if pf.get("reaction")!=expected_row["reaction"]: errors.append("primary_refusal_proof_reaction")
            try:
                if float(pf.get("requested_factor"))!=float(expected_row["rate_factor"]): errors.append("primary_refusal_proof_factor")
                if float(pf.get("worst_relative_error",999))>float(load_json(root/"CONFIG/ACCEPTANCE_GATES.json")["integrity"]["native_rate_proof_max_relative_error"]):
                    errors.append("primary_refusal_proof_error")
            except Exception: errors.append("primary_refusal_proof_numeric")
        recs=r.get("scaled_shifted_records",[])
        if not (len(recs)==1 and recs[0].get("success") is False and float(recs[0].get("rtol"))==2e-9 and
                float(recs[0].get("atol_y_min"))==1e-16 and float(recs[0].get("atol_y_max"))==1e-16):
            errors.append("primary_refusal_scaled_record")
    except Exception as e:
        errors.append("primary_refusal_audit_exception:"+repr(e))
    return not errors,errors

def strict_validate_artifacts(root:Path,expected_row:dict,request_path:Path,result_path:Path,proof_path:Path,*,expected_authority:str="candidate_C_R",expected_source_sha256:str|None=None):
    errors=[]; details={}
    try: q=load_json(request_path)
    except Exception as e: return False,["request_unreadable:"+repr(e)],details
    if not requests_equal(q,expected_row): errors.append("request_not_exact_frozen_ledger_row")
    try: r=load_json(result_path)
    except Exception as e: return False,errors+["result_unreadable:"+repr(e)],details
    try: pf=load_json(proof_path)
    except Exception as e: return False,errors+["proof_unreadable:"+repr(e)],details
    if r.get("schema")!="cptg-prymordial-row-result-v2": errors.append("result_schema_mismatch")
    if r.get("ok") is not True: errors.append("result_ok_false")
    if not requests_equal(r.get("request",{}),expected_row): errors.append("result_embedded_request_mismatch")
    if expected_authority!="candidate_C_R": errors.append("wrong_campaign_authority")
    if r.get("precision_authority_id")!="candidate_C": errors.append("wrong_physical_precision_authority")
    if r.get("cr_profile_id")!="candidate_C_R": errors.append("missing_candidate_CR_profile")
    path=r.get("cr_accepted_path")
    if path not in ("CANDIDATE_CS_PRIMARY","CANDIDATE_C_NATIVE_FALLBACK"): errors.append("invalid_CR_path")
    try:
        sid=_cr_source_identity(root)
        expected_sha=sid["candidate_cs"]["PRyM_main_sha256"] if path=="CANDIDATE_CS_PRIMARY" else sid["candidate_c"]["PRyM_main_sha256"]
        if r.get("source_main_sha256")!=expected_sha: errors.append("wrong_source_main_sha256_for_CR_path")
    except Exception as e: errors.append("source_identity_audit:"+repr(e))
    sp=r.get("solver_precision",{})
    if sp.get("requested")!=physical_solver_profile(root): errors.append("requested_precision_profile_mismatch")
    if sp.get("contract_identity_pass") is not True: errors.append("precision_contract_identity_fail")
    if sp.get("solver_success_pass") is not True: errors.append("solver_success_fail")
    obs=sp.get("observed",{})
    for ph in ("MT","LT"):
        exp={"phase":ph,**physical_solver_profile(root)[ph]}
        if obs.get(ph)!=exp: errors.append(f"observed_precision_{ph}_mismatch")
    solver=r.get("solver_status",{})
    if not solver or any(v.get("success") is not True for v in solver.values()): errors.append("native_solver_phase_failure")
    off=r.get("official_PRyMresults")
    if not isinstance(off,list) or len(off)!=8 or not all(math.isfinite(float(v)) for v in off): errors.append("official_PRyMresults_invalid")
    std=r.get("standard",{})
    for k in ("Neff","Omeganurel","OneOverOmeganunr","YPCMB","YPBBN","DoH","He3oH","Li7oH"):
        try:
            if not math.isfinite(float(std[k])): errors.append("standard_nonfinite_"+k)
        except Exception: errors.append("standard_missing_"+k)
    try:
        if abs(float(r.get("eta0b_used"))-float(expected_row["eta10"])*1e-10)>1e-22: errors.append("eta0b_used_mismatch")
    except Exception: errors.append("eta0b_used_invalid")
    if bool(r.get("NP_nuclear_flag")) != (expected_row["kind"]=="perturbed"): errors.append("NP_nuclear_flag_mismatch")
    rate_lim=float(load_json(root/"CONFIG/ACCEPTANCE_GATES.json")["integrity"]["native_rate_proof_max_relative_error"])
    if expected_row["kind"]=="baseline":
        if pf.get("pass") is not True or pf.get("kind")!="baseline": errors.append("baseline_proof_invalid")
    else:
        if pf.get("pass") is not True: errors.append("rate_proof_pass_false")
        if pf.get("reaction")!=expected_row["reaction"]: errors.append("rate_proof_reaction_mismatch")
        try:
            if float(pf.get("requested_factor"))!=float(expected_row["rate_factor"]): errors.append("rate_proof_factor_mismatch")
            if float(pf.get("worst_relative_error"))>rate_lim: errors.append("rate_proof_error_exceeds_gate")
        except Exception: errors.append("rate_proof_numeric_invalid")
    if path=="CANDIDATE_CS_PRIMARY":
        if not _validate_scaled_record(r): errors.append("scaled_coordinate_success_record_invalid")
        if r.get("cr_primary_refusal") not in (None,{}): errors.append("primary_path_should_not_have_refusal")
    elif path=="CANDIDATE_C_NATIVE_FALLBACK":
        meta=r.get("cr_primary_refusal")
        if not isinstance(meta,dict) or meta.get("eligible") is not True: errors.append("native_fallback_missing_eligible_primary_refusal")
        else:
            ok,e=_eligible_primary_refusal_artifacts(root,expected_row,meta)
            if not ok: errors.extend(e)
    details={"campaign_authority":"candidate_C_R","physical_authority":"candidate_C","accepted_path":path,
             "source_main_sha256":r.get("source_main_sha256"),"elapsed_s":r.get("elapsed_s"),
             "proof_worst":pf.get("worst_relative_error",0.0)}
    return not errors,errors,details

def strict_validate_commit(root:Path,run_id:int,rows_by_id:dict|None=None,*,expected_authority:str|None=None,expected_source_sha256:str|None=None,required_commit_schema:str|None=None):
    rows_by_id=rows_by_id or ledger_map(root); expected=rows_by_id.get(int(run_id)); errors=[]; details={}
    if expected is None: return False,["run_id_not_in_ledger"],details
    p=root/"WORK/COMMITS"/f"run_{int(run_id):05d}.json"
    if not p.is_file(): return False,["commit_missing"],details
    try:c=load_json(p)
    except Exception as e:return False,["commit_unreadable:"+repr(e)],details
    if int(c.get("run_id",-1))!=int(run_id): errors.append("commit_run_id_mismatch")
    if required_commit_schema and c.get("schema")!=required_commit_schema: errors.append("commit_schema_mismatch")
    try:
        qp=_safe_rel(root,c["row_request_relpath"]);rp=_safe_rel(root,c["row_result_relpath"]);pp=_safe_rel(root,c["rate_proof_relpath"])
    except Exception as e:return False,errors+["commit_path_invalid:"+repr(e)],details
    for label,path,hkey in (("request",qp,"row_request_sha256"),("result",rp,"row_result_sha256"),("proof",pp,"rate_proof_sha256")):
        if not path.is_file():errors.append(label+"_file_missing")
        elif sha_file(path)!=c.get(hkey):errors.append(label+"_sha256_mismatch")
    if errors:return False,errors,details
    authority=expected_authority or c.get("authority_id") or production_policy(root).get("authority_id")
    ok,aerr,adetails=strict_validate_artifacts(root,expected,qp,rp,pp,expected_authority=authority)
    errors.extend(aerr);details.update(adetails)
    r=load_json(rp)
    if c.get("schema")=="cptg-prymordial-row-commit-v3":
        if c.get("authority_id")!="candidate_C_R": errors.append("commit_authority_id_mismatch")
        if c.get("accepted_path")!=r.get("cr_accepted_path"): errors.append("commit_accepted_path_mismatch")
        if c.get("accepted_source_main_sha256")!=r.get("source_main_sha256"): errors.append("commit_source_sha_mismatch")
        if int(c.get("promotion_sequence",-1))!=int(run_id): errors.append("promotion_sequence_not_run_id")
        if run_id>1:
            prev=root/"WORK/COMMITS"/f"run_{run_id-1:05d}.json"
            if not prev.is_file():errors.append("previous_commit_missing_for_chain")
            elif c.get("previous_commit_sha256")!=sha_file(prev):errors.append("previous_commit_chain_mismatch")
        elif c.get("previous_commit_sha256") not in (None,""):errors.append("run1_previous_commit_not_empty")
    return not errors,errors,details

def scan_commits(root:Path=ROOT,*,expected_authority:str|None=None,expected_source_sha256:str|None=None,required_commit_schema:str|None=None):
    rows=ledger_map(root);present={};cdir=root/"WORK/COMMITS"
    if cdir.exists():
        for p in cdir.glob("run_*.json"):
            m=re.fullmatch(r"run_(\d{5})\.json",p.name)
            if m:present[int(m.group(1))]=p
    valid=[];invalid=[]
    for rid in sorted(present):
        ok,errs,details=strict_validate_commit(root,rid,rows,expected_authority=expected_authority,required_commit_schema=required_commit_schema)
        (valid if ok else invalid).append(rid if ok else {"run_id":rid,"errors":errs,"details":details})
    frontier=0;validset=set(valid)
    for rid in range(1,len(rows)+1):
        if rid in validset:frontier=rid
        else:break
    return {"total":len(rows),"present":len(present),"valid":valid,"valid_count":len(valid),"invalid":invalid,
            "invalid_count":len(invalid),"contiguous_frontier":frontier,"valid_beyond_frontier":[rid for rid in valid if rid>frontier]}
