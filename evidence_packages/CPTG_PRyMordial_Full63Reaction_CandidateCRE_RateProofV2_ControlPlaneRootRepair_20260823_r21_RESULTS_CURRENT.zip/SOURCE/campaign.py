from __future__ import annotations
import argparse, json, os, subprocess, sys, time, uuid
from pathlib import Path
from common import *
from common import _windows_tree_private_bytes, _windows_forest_private_bytes, _unix_private_bytes

POLL_SECONDS=1.0
HEARTBEAT_SECONDS=30.0
ROW_TIMEOUT_SECONDS=1800

class CampaignRefusal(RuntimeError): pass

class CampaignLock:
    def __init__(self,root:Path,session_id:str): self.root=root; self.session_id=session_id; self.path=root/"WORK/CAMPAIGN.lock"
    def acquire(self):
        self.path.parent.mkdir(parents=True,exist_ok=True)
        if self.path.exists():
            try: old=load_json(self.path); pid=int(old.get("pid",-1))
            except Exception: old={}; pid=-1
            if pid_alive(pid): raise CampaignRefusal(f"another campaign controller is active: pid={pid}")
            arch=self.root/"WORK/LOCK_ARCHIVE"; arch.mkdir(parents=True,exist_ok=True)
            stale=arch/f"stale_{int(time.time())}_{self.path.name}"
            try: replace_path_with_retry(self.path,stale)
            except Exception: raise CampaignRefusal("stale campaign lock could not be archived")
        payload={"schema":"cptg-prymordial-controller-lock-v1","pid":os.getpid(),"session_id":self.session_id,"started_utc":utc_now()}
        flags=os.O_WRONLY|os.O_CREAT|os.O_EXCL
        try:
            fd=os.open(self.path,flags)
        except FileExistsError: raise CampaignRefusal("campaign lock race: another controller acquired the lock")
        with os.fdopen(fd,"w",encoding="utf-8",newline="\n") as f:
            json.dump(payload,f,indent=2,sort_keys=True); f.write("\n"); f.flush(); os.fsync(f.fileno())
    def release(self):
        try:
            if self.path.exists() and load_json(self.path).get("session_id")==self.session_id: unlink_with_retry(self.path,missing_ok=True)
        except Exception: pass

class Controller:
    def __init__(self,root:Path,workers:int):
        self.root=root; self.workers=max(1,min(8,int(workers))); self.rows=read_primary_ledger(root); self.byid={r["run_id"]:r for r in self.rows}
        self.policy=production_policy(root); self.authority=self.policy.get("authority_id","candidate_C_R")
        cpp=root/"CONFIG/CONTROL_PLANE_POLICY.json"; self.control_policy=load_json(cpp) if cpp.exists() else {}
        self.poll_seconds=float(self.control_policy.get("controller_poll_seconds",POLL_SECONDS)); self.heartbeat_seconds=float(self.control_policy.get("heartbeat_seconds",HEARTBEAT_SECONDS)); self.row_timeout_seconds=float(self.control_policy.get("row_timeout_seconds",ROW_TIMEOUT_SECONDS))
        self.health_enabled=bool(self.control_policy.get("process_health_monitor_enabled",False)); self.health_poll_seconds=float(self.control_policy.get("process_health_poll_seconds",5.0)); self.max_private_gib=float(self.control_policy.get("maximum_process_tree_private_gib",0.0)); self.min_free_disk_gib=float(self.control_policy.get("minimum_free_disk_gib",0.0)); self.health_breaches_required=int(self.control_policy.get("consecutive_resource_breaches",3)); self.observation_fail_closed=bool(self.control_policy.get("resource_observation_fail_closed",False)); self.stalled_output_seconds=float(self.control_policy.get("stalled_output_seconds",0.0))
        self.session_id=str(uuid.uuid4()); self.lock=CampaignLock(root,self.session_id); self.active={}; self.staged={}; self.frontier=0
        self.elapsed_sum=0.0; self.elapsed_count=0; self.last_heartbeat=0.0; self.stop_requested=False
        self.source_root=None

    def preflight(self):
        if self.root.name!="CPTG_PRyMordial_Full63Reaction_CandidateCRE_RateProofV2_ControlPlaneRootRepair_20260823_r21": raise CampaignRefusal("R21 distribution root identity mismatch")
        if self.policy.get("resume_allowed") is not True:
            raise CampaignRefusal("Candidate C-R production authority is not enabled")
        hold=self.root/"WORK/AUDIT_HOLD.json"
        if hold.exists() and load_json(hold).get("active") is True: raise CampaignRefusal("active AUDIT_HOLD exists; production resume is prohibited")
        cachep=self.root/"EVIDENCE/RUNTIME_CACHE_QUALIFICATION.json"
        if not cachep.exists() or load_json(cachep).get("pass") is not True: raise CampaignRefusal("runtime-cache qualification PASS required")
        wp=self.root/"EVIDENCE/WINDOWS_RESOURCE_OBSERVER_PREFLIGHT.json"
        if os.name=="nt" and (not wp.exists() or load_json(wp).get("pass") is not True):
            raise CampaignRefusal("Windows resource-observer preflight PASS required before production")
        bind=self.root/"EVIDENCE/CANDIDATE_CR_PRODUCTION_AUTHORITY_BINDING.json"
        if not bind.exists() or load_json(bind).get("pass") is not True: raise CampaignRefusal("Candidate C-R production authority binding PASS required")
        sid=self.root/"WORK/SOURCE_IDENTITY.json"
        if not sid.exists(): raise CampaignRefusal("prepared/adopted Candidate C-R source identity missing")
        s=load_json(sid); locks=self.policy.get("accepted_source_main_sha256s",{})
        if s.get("candidate_cs",{}).get("PRyM_main_sha256")!=locks.get("CANDIDATE_CS_PRIMARY"): raise CampaignRefusal("Candidate C-S source hash mismatch")
        if s.get("candidate_c",{}).get("PRyM_main_sha256")!=locks.get("CANDIDATE_C_NATIVE_FALLBACK"): raise CampaignRefusal("native Candidate C source hash mismatch")
        if s.get("candidate_e",{}).get("PRyM_main_sha256")!=locks.get("CANDIDATE_E_TERTIARY",locks.get("CANDIDATE_C_NATIVE_FALLBACK")): raise CampaignRefusal("Candidate E source hash mismatch")
        if sha_file(self.root/"WORK/SOURCE/CANDIDATE_E/PRyM/PRyM_main.py")!=s.get("candidate_e",{}).get("PRyM_main_sha256"): raise CampaignRefusal("Candidate E live main-file hash mismatch")
        for prof in ("CANDIDATE_CS","CANDIDATE_C","CANDIDATE_E"):
            if not (self.root/"WORK/SOURCE"/prof).is_dir(): raise CampaignRefusal("WORK/SOURCE/"+prof+" missing")
        scan=scan_commits(self.root,expected_authority=self.authority,required_commit_schema="cptg-prymordial-row-commit-v3")
        if scan["invalid_count"]: raise CampaignRefusal(f"invalid commit evidence present: {scan['invalid'][:3]}")
        if scan["valid_beyond_frontier"]: raise CampaignRefusal(f"noncontiguous authoritative commits are forbidden in r10: {scan['valid_beyond_frontier'][:10]}")
        self.frontier=scan["contiguous_frontier"]
        for rid in range(1,self.frontier+1):
            try:
                c=load_json(self.root/"WORK/COMMITS"/f"run_{rid:05d}.json"); rr=load_json(self.root/c["row_result_relpath"]); e=float(rr["elapsed_s"])
                self.elapsed_sum+=e; self.elapsed_count+=1
            except Exception: pass
        self._check_orphan_registry()

    def _check_orphan_registry(self):
        p=self.root/"WORK/ACTIVE_PROCESSES.json"
        if not p.exists(): return
        try: rec=load_json(p).get("processes",[])
        except Exception: rec=[]
        live=[x for x in rec if pid_alive(int(x.get("pid",-1)))]
        if live: raise CampaignRefusal(f"orphan/native processes still alive from previous controller: {live}")
        if rec:
            arch=self.root/"WORK/PROCESS_REGISTRY_ARCHIVE"; arch.mkdir(parents=True,exist_ok=True)
            replace_path_with_retry(p,arch/f"stale_{int(time.time())}_ACTIVE_PROCESSES.json")

    def _next_attempt_dir(self,row):
        rid=row["run_id"]; rdir=self.root/"WORK/ROWS"/f"run_{rid:05d}"; rdir.mkdir(parents=True,exist_ok=True)
        n=1
        while (rdir/f"attempt_{n:03d}").exists(): n+=1
        d=rdir/f"attempt_{n:03d}"; d.mkdir(); return n,d

    def launch(self,row):
        attempt,adir=self._next_attempt_dir(row); reqp=adir/"request.json"; resp=adir/"result.json"; proof=adir/"rate_proof.json"
        write_atomic(reqp,row)
        outp=adir/"stdout.txt"; errp=adir/"stderr.txt"; out=outp.open("wb"); err=errp.open("wb")
        env=os.environ.copy(); env.update({"PYTHONDONTWRITEBYTECODE":"1","OMP_NUM_THREADS":"1","OPENBLAS_NUM_THREADS":"1","MKL_NUM_THREADS":"1","PYTHONPYCACHEPREFIX":str(self.root/"WORK/PYCACHE"),"NUMBA_CACHE_DIR":str(self.root/"WORK/NUMBA_CACHE")})
        cmd=[sys.executable,str(self.root/"SOURCE/prymordial_cr_row_worker.py"),"--request",str(reqp),"--result",str(resp),"--proof",str(proof)]
        flags=subprocess.CREATE_NEW_PROCESS_GROUP if os.name=="nt" else 0; preexec=None if os.name=="nt" else os.setsid
        start=time.time(); proc=subprocess.Popen(cmd,cwd=str(self.root),env=env,stdout=out,stderr=err,creationflags=flags,preexec_fn=preexec)
        a={"run_id":row["run_id"],"row":row,"attempt":attempt,"adir":adir,"request":reqp,"result":resp,"proof":proof,"stdout":outp,"stderr":errp,"out_handle":out,"err_handle":err,"proc":proc,"started_epoch":start,"last_health_epoch":start,"last_output_sizes":(0,0),"last_output_change_epoch":start,"health_breach_count":0,"health_summary":{"samples":0,"max_tree_private_bytes":0,"min_free_disk_gib":None,"observation_failures":0,"breach_samples":0}}
        self.active[row["run_id"]]=a; self._write_process_registry(); print("PRYMORDIAL_ROW_START",row["run_id"],row.get("reaction") or "baseline","attempt",attempt,"pid",proc.pid,flush=True)

    def _close_handles(self,a):
        for k in ("out_handle","err_handle"):
            try: a[k].flush(); a[k].close()
            except Exception: pass

    def _write_process_registry(self):
        rows=[]
        for rid,a in sorted(self.active.items()): rows.append({"run_id":rid,"reaction":a["row"].get("reaction") or "baseline","attempt":a["attempt"],"pid":a["proc"].pid,"started_epoch":a["started_epoch"],"session_id":self.session_id})
        write_atomic(self.root/"WORK/ACTIVE_PROCESSES.json",{"schema":"cptg-prymordial-active-processes-v1","controller_pid":os.getpid(),"session_id":self.session_id,"processes":rows,"updated_utc":utc_now()})

    def _terminate_attempt(self,a):
        """Bounded process-tree termination; never block indefinitely waiting for a failed row."""
        kill_process_tree(a["proc"])
        try: a["proc"].wait(timeout=30)
        except Exception:
            kill_process_tree(a["proc"])
            try: a["proc"].wait(timeout=10)
            except Exception: pass
        self._close_handles(a)
        return not pid_alive(a["proc"].pid)

    def _failure_record(self,a,reason,returncode=None,extra=None):
        rr={}
        try:
            if a["result"].exists(): rr=load_json(a["result"])
        except Exception: pass
        obj={"schema":"cptg-prymordial-row-failure-v2","run_id":a["run_id"],"attempt":a["attempt"],"reason":reason,"returncode":returncode,"elapsed_s":time.time()-a["started_epoch"],"utc":utc_now(),"result_error":rr.get("error"),"error_classification":rr.get("error_classification"),"stdout_tail":tail_text(a["stdout"]),"stderr_tail":tail_text(a["stderr"])}
        if extra: obj["details"]=extra
        write_atomic(a["adir"]/"FAILURE.json",obj); return obj

    def evaluate_finished(self,a):
        self._close_handles(a); rc=a["proc"].returncode; elapsed=time.time()-a["started_epoch"]
        write_atomic(a["adir"]/"PROCESS.json",{"schema":"cptg-prymordial-process-result-v1","pid":a["proc"].pid,"returncode":rc,"started_epoch":a["started_epoch"],"finished_epoch":time.time(),"elapsed_s":elapsed,"health_summary":a.get("health_summary")})
        if rc!=0: return False,self._failure_record(a,"NATIVE_FAIL",rc)
        if not (a["result"].is_file() and a["proof"].is_file()): return False,self._failure_record(a,"MISSING_OUTPUT",rc)
        ok,errs,details=strict_validate_artifacts(self.root,a["row"],a["request"],a["result"],a["proof"],expected_authority=self.authority)
        if not ok: return False,self._failure_record(a,"STRICT_ATTEMPT_VALIDATION_FAIL",rc,{"errors":errs,"audit":details})
        rr=load_json(a["result"]); stage={"schema":"cptg-prymordial-staged-success-v1","run_id":a["run_id"],"attempt":a["attempt"],"completed_epoch":time.time(),"elapsed_s":float(rr.get("elapsed_s",elapsed)),"session_id":self.session_id}
        write_atomic(a["adir"]/"STAGED_SUCCESS.json",stage); a["stage"]=stage; return True,a

    def promote(self,a):
        rid=a["run_id"]
        if rid!=self.frontier+1: raise RuntimeError(f"ordered promotion violation: frontier={self.frontier}, rid={rid}")
        if (self.root/"WORK/AUDIT_HOLD.json").exists() and load_json(self.root/"WORK/AUDIT_HOLD.json").get("active") is True: raise RuntimeError("cannot promote while audit hold is active")
        prev=None if rid==1 else sha_file(self.root/"WORK/COMMITS"/f"run_{rid-1:05d}.json")
        rr=load_json(a["result"])
        c={"schema":"cptg-prymordial-row-commit-v3","run_id":rid,"promotion_sequence":rid,"attempt":a["attempt"],"authority_id":self.authority,
           "accepted_path":rr.get("cr_accepted_path"),"accepted_source_main_sha256":rr.get("source_main_sha256"),
           "controller_session_id":self.session_id,"previous_commit_sha256":prev,
           "row_request_relpath":a["request"].relative_to(self.root).as_posix(),"row_request_sha256":sha_file(a["request"]),"row_result_relpath":a["result"].relative_to(self.root).as_posix(),"row_result_sha256":sha_file(a["result"]),"rate_proof_relpath":a["proof"].relative_to(self.root).as_posix(),"rate_proof_sha256":sha_file(a["proof"]),"stdout_relpath":a["stdout"].relative_to(self.root).as_posix(),"stderr_relpath":a["stderr"].relative_to(self.root).as_posix(),"attempt_completed_epoch":a["stage"]["completed_epoch"],"promoted_epoch":time.time()}
        cp=self.root/"WORK/COMMITS"/f"run_{rid:05d}.json"; cp.parent.mkdir(parents=True,exist_ok=True); write_atomic(cp,c)
        ok,errs,_=strict_validate_commit(self.root,rid,self.byid,expected_authority=self.authority,required_commit_schema="cptg-prymordial-row-commit-v3")
        if not ok:
            try: unlink_with_retry(cp,missing_ok=True)
            except Exception: pass
            raise RuntimeError("post-promotion strict validation failed: "+repr(errs))
        self.frontier=rid; self.elapsed_sum+=float(a["stage"].get("elapsed_s",0.0)); self.elapsed_count+=1
        write_atomic(self.root/"WORK/COMMIT_FRONTIER.json",{"schema":"cptg-prymordial-commit-frontier-v1","frontier":self.frontier,"last_commit_sha256":sha_file(cp),"session_id":self.session_id,"updated_utc":utc_now()})
        print("PRYMORDIAL_ROW_COMMIT",rid,a["row"].get("reaction") or "baseline","PASS","PATH",rr.get("cr_accepted_path"),f"{self.frontier}/{len(self.rows)}",flush=True)

    def promote_ready(self):
        while self.frontier+1 in self.staged:
            a=self.staged.pop(self.frontier+1); self.promote(a)

    def _set_hold(self,a,failure):
        hold={"schema":"cptg-prymordial-audit-hold-v1","active":True,"run_id":a["run_id"],"reaction":a["row"].get("reaction") or "baseline","attempt":a["attempt"],"failure_relpath":(a["adir"]/"FAILURE.json").relative_to(self.root).as_posix(),"failure_sha256":sha_file(a["adir"]/"FAILURE.json"),"frontier_at_failure":self.frontier,"controller_session_id":self.session_id,"created_utc":utc_now(),"reason":failure.get("reason")}
        write_atomic(self.root/"WORK/AUDIT_HOLD.json",hold); return hold

    def abort_peers(self,reason):
        survivors=[]
        for rid,a in list(self.active.items()):
            kill_process_tree(a["proc"])
        for rid,a in list(self.active.items()):
            try: a["proc"].wait(timeout=30)
            except Exception:
                kill_process_tree(a["proc"])
                try: a["proc"].wait(timeout=10)
                except Exception: pass
            self._close_handles(a)
            if pid_alive(a["proc"].pid): survivors.append({"run_id":rid,"pid":a["proc"].pid})
            write_atomic(a["adir"]/"ABORTED_UNCOMMITTED.json",{"schema":"cptg-prymordial-aborted-attempt-v1","run_id":rid,"attempt":a["attempt"],"reason":reason,"utc":utc_now(),"controller_session_id":self.session_id})
        self.active.clear(); self._write_process_registry()
        for rid,a in list(self.staged.items()):
            write_atomic(a["adir"]/"UNCOMMITTED_STAGED_SUCCESS.json",{"schema":"cptg-prymordial-uncommitted-stage-v1","run_id":rid,"attempt":a["attempt"],"reason":reason,"utc":utc_now()})
        self.staged.clear()
        if survivors:
            write_atomic(self.root/"WORK/ORPHAN_PROCESS_ALERT.json",{"schema":"cptg-prymordial-orphan-process-alert-v1","survivors":survivors,"reason":reason,"utc":utc_now()})
            raise RuntimeError("native process tree survived forced abort: "+repr(survivors))

    def _mean(self): return self.elapsed_sum/self.elapsed_count if self.elapsed_count else None
    def write_status(self,state="RUNNING",event=None):
        avg=self._mean(); active=[]
        for rid,a in sorted(self.active.items()): active.append({"run_id":rid,"reaction":a["row"].get("reaction") or "baseline","attempt":a["attempt"],"pid":a["proc"].pid,"elapsed_s":time.time()-a["started_epoch"]})
        obj={"schema":"cptg-prymordial-live-status-v2","state":state,"session_id":self.session_id,"controller_pid":os.getpid(),"workers_configured":self.workers,"committed":self.frontier,"contiguous_frontier":self.frontier,"total":len(self.rows),"percent":100*self.frontier/len(self.rows),"active_workers":active,"active_count":len(active),"staged_success_run_ids":sorted(self.staged),"mean_elapsed_s":avg,"estimated_remaining_compute_s":((len(self.rows)-self.frontier)*avg if avg else None),"stop_requested":self.stop_requested,"event":event,"updated_epoch":time.time(),"updated_utc":utc_now()}
        write_atomic(self.root/"WORK/LIVE_STATUS.json",obj); self.last_heartbeat=time.time(); return obj

    def check_stop_request(self):
        p=self.root/"WORK/STOP_REQUEST.json"
        if p.exists() and not self.stop_requested:
            try: req=load_json(p)
            except Exception: req={}
            if req.get("controller_session_id")!=self.session_id or req.get("mode")!="DRAIN_AND_STOP":
                arch=self.root/"WORK/STOP_ARCHIVE"; arch.mkdir(parents=True,exist_ok=True)
                replace_path_with_retry(p,arch/f"rejected_{int(time.time())}_STOP_REQUEST.json")
                print("PRYMORDIAL_STOP_REQUEST REJECTED_STALE_OR_INVALID",flush=True)
                return
            self.stop_requested=True
            write_atomic(self.root/"WORK/STOP_ACKNOWLEDGED.json",{"schema":"cptg-prymordial-stop-ack-v1","session_id":self.session_id,"requested":req,"acknowledged_utc":utc_now(),"frontier":self.frontier})
            print("PRYMORDIAL_STOP_REQUEST ACKNOWLEDGED","frontier",self.frontier,"draining",len(self.active),flush=True)

    def check_process_health(self,now):
        if not self.health_enabled: return None
        due=[]
        for rid,a in sorted(self.active.items()):
            # Finished processes are evaluated as native results, never as failed resource observations.
            if a["proc"].poll() is not None: continue
            if now-a.get("last_health_epoch",0.0)<self.health_poll_seconds: continue
            a["last_health_epoch"]=now; due.append((rid,a))
        if not due: return None
        win={}
        if os.name=="nt":
            win=_windows_forest_private_bytes([a["proc"].pid for _,a in due],self.root/"SOURCE/process_forest_sample.ps1")
        for rid,a in due:
            # A native process can finish while the process-forest sample is being collected.
            if a["proc"].poll() is not None: continue
            sizes=(a["stdout"].stat().st_size if a["stdout"].exists() else 0,a["stderr"].stat().st_size if a["stderr"].exists() else 0)
            if sizes!=a.get("last_output_sizes"):
                a["last_output_sizes"]=sizes; a["last_output_change_epoch"]=now
            tree_bytes,records=(win.get(a["proc"].pid,(None,[])) if os.name=="nt" else _unix_private_bytes(a["proc"].pid))
            # Do not convert a normal exit racing with observation into a resource failure.
            if a["proc"].poll() is not None: continue
            disk=free_disk_gib(self.root); obs_failed=tree_bytes is None; reasons=[]
            if obs_failed and self.observation_fail_closed: reasons.append("process_tree_memory_observation_failed")
            if tree_bytes is not None and self.max_private_gib>0 and tree_bytes/(1024**3)>self.max_private_gib: reasons.append("process_tree_private_memory_exceeded")
            if self.min_free_disk_gib>0 and disk<self.min_free_disk_gib: reasons.append("free_disk_below_minimum")
            if self.stalled_output_seconds>0 and now-a.get("last_output_change_epoch",now)>self.stalled_output_seconds: reasons.append("stalled_output")
            summary=a["health_summary"]; summary["samples"]+=1; summary["max_tree_private_bytes"]=max(int(summary.get("max_tree_private_bytes") or 0),int(tree_bytes or 0)); summary["min_free_disk_gib"]=disk if summary.get("min_free_disk_gib") is None else min(float(summary["min_free_disk_gib"]),disk); summary["observation_failures"]+=1 if obs_failed else 0; summary["breach_samples"]+=1 if reasons else 0
            a["health_breach_count"]=a.get("health_breach_count",0)+1 if reasons else 0
            if reasons:
                write_atomic(a["adir"]/"HEALTH_BREACH_LATEST.json",{"schema":"cptg-prymordial-health-breach-v1","run_id":rid,"pid":a["proc"].pid,"reasons":reasons,"consecutive_breaches":a["health_breach_count"],"required":self.health_breaches_required,"tree_private_bytes":tree_bytes,"free_disk_gib":disk,"processes":records,"utc":utc_now()})
            if a["health_breach_count"]>=self.health_breaches_required:
                return rid,{"reasons":reasons,"tree_private_bytes":tree_bytes,"free_disk_gib":disk,"processes":records,"health_summary":summary}
        return None

    def prepare_stop_files(self):
        arch=self.root/"WORK/STOP_ARCHIVE"; arch.mkdir(parents=True,exist_ok=True)
        reqp=self.root/"WORK/STOP_REQUEST.json"
        if reqp.exists():
            try: req=load_json(reqp)
            except Exception: req={}
            # A request naming this just-created controller session is live and must not be erased.
            if req.get("controller_session_id")!=self.session_id:
                replace_path_with_retry(reqp,arch/f"stale_{int(time.time())}_STOP_REQUEST.json")
        ack=self.root/"WORK/STOP_ACKNOWLEDGED.json"
        if ack.exists(): replace_path_with_retry(ack,arch/f"stale_{int(time.time())}_STOP_ACKNOWLEDGED.json")

    def fill_window(self):
        if self.stop_requested: return
        # Strict bounded speculation: never launch beyond frontier + workers.
        upper=min(len(self.rows),self.frontier+self.workers)
        occupied=set(self.active)|set(self.staged)
        for rid in range(self.frontier+1,upper+1):
            if len(self.active)>=self.workers: break
            if rid not in occupied: self.launch(self.byid[rid])

    def run(self):
        self.lock.acquire()
        try:
            self.preflight(); (self.root/"WORK/COMMITS").mkdir(parents=True,exist_ok=True)
            self.prepare_stop_files()
            print("PRYMORDIAL_CANDIDATE_CRE_CAMPAIGN_START","committed",self.frontier,"remaining",len(self.rows)-self.frontier,"workers",self.workers,"ordered_commits",True,flush=True)
            self.write_status("RUNNING","START")
            if self.frontier==len(self.rows): self.write_status("COMPLETE","ALREADY_COMPLETE"); print("PRYMORDIAL_CANDIDATE_CRE_CAMPAIGN COMPLETE",self.frontier,"/",len(self.rows)); return 0
            self.fill_window()
            while self.active or self.staged or self.frontier<len(self.rows):
                self.check_stop_request()
                now=time.time(); finished=[]; timeout=[]
                for rid,a in list(self.active.items()):
                    if a["proc"].poll() is not None: finished.append(rid)
                    elif now-a["started_epoch"]>self.row_timeout_seconds: timeout.append(rid)
                health_failure=self.check_process_health(now)
                if health_failure:
                    rid,details=health_failure; a=self.active.pop(rid); terminated=self._terminate_attempt(a)
                    if not terminated:
                        self.active[rid]=a
                        details={**details,"failed_root_process_survived_termination":True}
                    failure=self._failure_record(a,"RESOURCE_POLICY_FAIL",a["proc"].returncode,details); self._set_hold(a,failure); self.abort_peers("PEER_FAILURE_RESOURCE_POLICY")
                    self.write_status("FAILED_NEEDS_AUDIT",f"run {rid} RESOURCE_POLICY_FAIL"); print("PRYMORDIAL_ROW_FAILURE",rid,a["row"].get("reaction") or "baseline","RESOURCE_POLICY_FAIL",f"{self.frontier}/{len(self.rows)}"); print("PRYMORDIAL_CAMPAIGN STOPPED_FOR_AUDIT"); return 3
                if timeout:
                    rid=min(timeout); a=self.active.pop(rid); terminated=self._terminate_attempt(a)
                    extra={"failed_root_process_survived_termination":True} if not terminated else None
                    if not terminated: self.active[rid]=a
                    failure=self._failure_record(a,"TIMEOUT",a["proc"].returncode,extra); self._set_hold(a,failure); self.abort_peers("PEER_FAILURE_TIMEOUT")
                    self.write_status("FAILED_NEEDS_AUDIT",f"run {rid} TIMEOUT"); print("PRYMORDIAL_ROW_FAILURE",rid,a["row"].get("reaction") or "baseline","TIMEOUT",f"{self.frontier}/{len(self.rows)}"); print("PRYMORDIAL_CAMPAIGN STOPPED_FOR_AUDIT"); return 3
                if finished:
                    outcomes=[]
                    for rid in sorted(finished):
                        a=self.active.pop(rid); ok,obj=self.evaluate_finished(a); outcomes.append((rid,ok,obj,a))
                    self._write_process_registry()
                    failures=[x for x in outcomes if not x[1]]
                    if failures:
                        rid,_,failure,a=min(failures,key=lambda x:x[0]); self._set_hold(a,failure)
                        # No success observed in this same controller poll is promoted after a peer failure.
                        for srid,ok,obj,sa in outcomes:
                            if ok:
                                write_atomic(sa["adir"]/"UNCOMMITTED_STAGED_SUCCESS.json",{"schema":"cptg-prymordial-uncommitted-stage-v1","run_id":srid,"attempt":sa["attempt"],"reason":"SAME_POLL_AS_PEER_FAILURE","utc":utc_now()})
                        self.abort_peers("PEER_FAILURE")
                        self.write_status("FAILED_NEEDS_AUDIT",f"run {rid} {failure.get('reason')}"); print("PRYMORDIAL_ROW_FAILURE",rid,a["row"].get("reaction") or "baseline",failure.get("reason"),f"{self.frontier}/{len(self.rows)}"); print("PRYMORDIAL_CAMPAIGN STOPPED_FOR_AUDIT"); return 3
                    for rid,ok,obj,a in outcomes: self.staged[rid]=a
                    self.promote_ready(); self.fill_window()
                    self.write_status("DRAINING" if self.stop_requested else "RUNNING","ROWS_COMPLETED")
                elif self.stop_requested and not self.active:
                    self.promote_ready()
                    if self.staged: raise RuntimeError("drain ended with noncontiguous staged successes")
                    self.write_status("STOPPED_CLEANLY","DRAIN_COMPLETE")
                    try: unlink_with_retry(self.root/"WORK/STOP_REQUEST.json",missing_ok=True)
                    except Exception: pass
                    print("PRYMORDIAL_CAMPAIGN STOPPED_CLEANLY",self.frontier,"/",len(self.rows)); return 0
                elif self.frontier==len(self.rows):
                    self.write_status("COMPLETE","ALL_ROWS_COMMITTED"); print("PRYMORDIAL_CANDIDATE_CRE_CAMPAIGN COMPLETE",self.frontier,"/",len(self.rows)); return 0
                if time.time()-self.last_heartbeat>=self.heartbeat_seconds: self.write_status("DRAINING" if self.stop_requested else "RUNNING","HEARTBEAT")
                time.sleep(self.poll_seconds)
            # Loop can terminate immediately after the final promotion.
            if self.frontier==len(self.rows):
                self.write_status("COMPLETE","ALL_ROWS_COMMITTED"); print("PRYMORDIAL_CANDIDATE_CRE_CAMPAIGN COMPLETE",self.frontier,"/",len(self.rows)); return 0
            raise RuntimeError("controller loop exited without COMPLETE, clean stop, or audit hold")
        except KeyboardInterrupt:
            self.abort_peers("OPERATOR_KEYBOARD_INTERRUPT"); self.write_status("STOPPED_EMERGENCY","KEYBOARD_INTERRUPT"); print("PRYMORDIAL_CAMPAIGN STOPPED_EMERGENCY","frontier",self.frontier); return 130
        except CampaignRefusal:
            raise
        except Exception as exc:
            try: self.abort_peers("CONTROL_PLANE_EXCEPTION")
            except Exception: pass
            failure={"schema":"cptg-prymordial-control-plane-failure-v1","frontier":self.frontier,"controller_session_id":self.session_id,"created_utc":utc_now(),"exception_class":type(exc).__name__,"exception_message":str(exc)}
            try: write_atomic(self.root/"WORK/CONTROL_PLANE_FAILURE.json",failure)
            except Exception: pass
            hp=self.root/"WORK/AUDIT_HOLD.json"
            try:
                existing=load_json(hp) if hp.exists() else None
                if not (existing and existing.get("active") is True):
                    hold={"schema":"cptg-prymordial-audit-hold-v1","active":True,"run_id":self.frontier+1 if self.frontier<len(self.rows) else None,"reaction":self.byid.get(self.frontier+1,{}).get("reaction") if self.frontier<len(self.rows) else None,"reason":"CONTROL_PLANE_EXCEPTION","frontier_at_failure":self.frontier,"controller_session_id":self.session_id,"created_utc":utc_now(),"exception_class":type(exc).__name__,"exception_message":str(exc)}
                    write_atomic(hp,hold)
            except Exception: pass
            try: self.write_status("FAILED_CONTROL_PLANE",str(exc))
            except Exception: pass
            print("PRYMORDIAL_CAMPAIGN CONTROL_PLANE_FAILURE",type(exc).__name__,str(exc),flush=True); print("PRYMORDIAL_CAMPAIGN STOPPED_FOR_AUDIT",flush=True); return 9
        finally:
            self.lock.release()


def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--workers",type=int,default=int(os.environ.get("CPTG_PRYM_WORKERS","2"))); a=ap.parse_args()
    try: return Controller(ROOT,a.workers).run()
    except CampaignRefusal as e:
        print("PRYMORDIAL_CAMPAIGN REFUSED",str(e)); return 7

if __name__=="__main__": raise SystemExit(main())
