from __future__ import annotations
import argparse,difflib,shutil,json
from pathlib import Path
from common import *
from precision_patch import patch_main as apply_historical_precision_patch
from solver_authority import SOLVER_PROFILES
from patch_scaled_shifted_lt import patch as apply_scaled_shifted_lt

def instrument_main(text:str):
    original=text
    if "CPTG_STANDALONE_INSTRUMENTATION_V1" in text: raise RuntimeError("source already instrumented")
    needle="        self.res = np.array([self.Neff_f,self.Omeganurel_f,self.OneOverOmeganunr_f,self.YPCMB_f,self.YPBBN_f,self.DoHx1e5_f,self.He3oHx1e5_f,self.Li7oHx1e10_f])"
    if needle not in text: raise RuntimeError("PRyM_main.py output anchor not found")
    inject=r'''
        # CPTG_STANDALONE_INSTRUMENTATION_V1
        self.CPTG_solver_status = {
            "HT": {"success": bool(getattr(sol_at_HT,"success",True)), "status": int(getattr(sol_at_HT,"status",0)), "message": str(getattr(sol_at_HT,"message",""))},
            "MT": {"success": bool(getattr(sol_at_MT,"success",True)), "status": int(getattr(sol_at_MT,"status",0)), "message": str(getattr(sol_at_MT,"message",""))},
            "LT": {"success": bool(getattr(sol_at_LT,"success",True)), "status": int(getattr(sol_at_LT,"status",0)), "message": str(getattr(sol_at_LT,"message",""))}
        }
        self.CPTG_scaled_shifted_records = list(globals().get("_CPTG_SCALED_SHIFTED_RECORDS", []))
'''
    text=text.replace(needle,needle+"\n"+inject,1)
    return text,"".join(difflib.unified_diff(original.splitlines(True),text.splitlines(True),fromfile="PRyM_main.py.original",tofile="PRyM_main.py.instrumented"))

def copy_clean(src,dst):
    if dst.exists(): shutil.rmtree(dst)
    shutil.copytree(src,dst,ignore=shutil.ignore_patterns(".git","__pycache__","*.pyc"))

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--source-root",default=None); a=ap.parse_args()
    src=locate_root(a.source_root); work=ROOT/"WORK"; work.mkdir(exist_ok=True); sroot=work/"SOURCE"; sroot.mkdir(exist_ok=True)
    orig_manifest=tree_manifest(src); frozen=load_json(ROOT/"REFERENCE/R06_ORIGINAL_SOURCE_IDENTITY.json")
    if orig_manifest!=frozen["original_manifest"]: raise RuntimeError("installed PRyMordial source identity differs from frozen r06 original")
    print("R06_ORIGINAL_SOURCE_IDENTITY 103/103 PASS")
    ident={"schema":"cptg-prymordial-candidate-cs-source-identity-v1","original_root":str(src),"original_manifest":orig_manifest}
    for profile in ("CANDIDATE_C","CANDIDATE_CS"):
        dst=sroot/profile; copy_clean(src,dst); mainp=dst/"PRyM/PRyM_main.py"
        txt=mainp.read_text(encoding="utf-8",errors="strict"); inst,diff=instrument_main(txt); mainp.write_text(inst,encoding="utf-8",newline="\n")
        (ROOT/"EVIDENCE"/f"{profile}_INSTRUMENTATION.patch").write_text(diff,encoding="utf-8",newline="\n")
        auth="candidate_C"
        prec=apply_historical_precision_patch(mainp,{"primary":SOLVER_PROFILES[auth]},ROOT/"EVIDENCE"/f"{profile}_PRECISION_PATCH_RECORD.json")
        scale_rec=None
        if profile=="CANDIDATE_CS":
            scale_rec=apply_scaled_shifted_lt(mainp); write_atomic(ROOT/"EVIDENCE/CANDIDATE_CS_COORDINATE_PATCH_RECORD.json",scale_rec)
        ident[profile.lower()]={"root":str(dst),"manifest":tree_manifest(dst),"PRyM_main_sha256":sha_file(mainp),"precision_authority":auth,"coordinate_conditioned":profile=="CANDIDATE_CS","precision_patch_diff_sha256":prec["diff_sha256"],"coordinate_patch":scale_rec}
    write_atomic(work/"SOURCE_IDENTITY.json",ident)
    print("PRYMORDIAL_CANDIDATE_CS_SOURCE_PREPARE PASS")
    print("CANDIDATE_C PHYSICAL_PROFILE candidate_C")
    print("CANDIDATE_CS PHYSICAL_PROFILE candidate_C COORDINATE_CONDITIONING LT_ONLY")
    print("CANDIDATE_CR_SOURCE_PREPARE FRESH_PASS")
if __name__=="__main__": main()
