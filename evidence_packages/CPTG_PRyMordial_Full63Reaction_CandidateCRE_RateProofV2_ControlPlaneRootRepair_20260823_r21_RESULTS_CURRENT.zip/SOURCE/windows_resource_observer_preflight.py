from __future__ import annotations
import json,os,sys
from common import ROOT,load_json,run_monitored,write_atomic

def main():
    if os.name!="nt":
        print("WINDOWS_RESOURCE_OBSERVER_PREFLIGHT SKIP_NONWINDOWS")
        return
    pol=load_json(ROOT/"CONFIG/CONTROL_PLANE_POLICY.json")
    d=ROOT/"WORK/WINDOWS_RESOURCE_OBSERVER_PREFLIGHT"
    d.mkdir(parents=True,exist_ok=True)
    cmd=[sys.executable,"-c","import time; x=bytearray(16*1024*1024); time.sleep(4)"]
    rec=run_monitored(
        cmd,ROOT,d/"stdout.txt",d/"stderr.txt",
        timeout_seconds=30,
        poll_seconds=0.5,
        max_private_gib=float(pol["maximum_process_tree_private_gib"]),
        min_free_disk_gib=float(pol["minimum_free_disk_gib"]),
        consecutive_breaches=int(pol["consecutive_resource_breaches"]),
        stalled_output_seconds=20,
        environment=os.environ.copy(),
    )
    samples=rec.get("resource_samples") or []
    good=[s for s in samples if not s.get("observation_failed")
          and s.get("tree_private_bytes") is not None and (s.get("processes") or [])]
    observers=sorted({str(p.get("observer")) for s in good
                      for p in (s.get("processes") or []) if p.get("observer")})
    passed=(
        rec.get("returncode")==0
        and rec.get("resource_breach") is False
        and rec.get("timeout") is False
        and rec.get("stalled_output") is False
        and len(good)>=3
        and all(float(s.get("free_disk_gib",0))>=float(pol["minimum_free_disk_gib"]) for s in good)
        and all(int(s.get("tree_private_bytes") or 0)>0 for s in good)
        and "win32_ctypes" in observers
    )
    out={
        "schema":"cptg-prymordial-r11-windows-resource-observer-preflight-v1",
        "pass":passed,"policy":pol,"monitor_result":rec,
        "good_observation_samples":len(good),"observers":observers,
        "scientific_run_performed":False,"production_row_committed":False,
    }
    write_atomic(ROOT/"EVIDENCE/WINDOWS_RESOURCE_OBSERVER_PREFLIGHT.json",out)
    print("WINDOWS_RESOURCE_OBSERVER_SAMPLES",len(good))
    print("WINDOWS_RESOURCE_OBSERVER_BACKENDS",",".join(observers) if observers else "NONE")
    if good:
        print("WINDOWS_RESOURCE_LAST_PRIVATE_GIB",good[-1]["tree_private_bytes"]/(1024**3))
        print("WINDOWS_RESOURCE_LAST_FREE_DISK_GIB",good[-1]["free_disk_gib"])
    print("RESOURCE_LIMIT_PRIVATE_GIB",pol["maximum_process_tree_private_gib"])
    print("RESOURCE_LIMIT_MIN_FREE_DISK_GIB",pol["minimum_free_disk_gib"])
    print("SCIENTIFIC_RUN_PERFORMED False")
    print("PRODUCTION_ROW_COMMITTED False")
    if not passed:
        print("WINDOWS_RESOURCE_OBSERVER_PREFLIGHT FAIL")
        raise SystemExit(2)
    print("WINDOWS_RESOURCE_OBSERVER_PREFLIGHT PASS")

if __name__=="__main__":
    main()
