from __future__ import annotations
import os
from common import *
def main():
    lock=ROOT/"WORK/CAMPAIGN.lock"
    if not lock.exists():
        print("PRYMORDIAL_STOP_REQUEST NO_ACTIVE_CONTROLLER"); return 1
    try:
        info=load_json(lock); pid=int(info.get("pid",-1))
    except Exception:
        print("PRYMORDIAL_STOP_REQUEST INVALID_LOCK"); return 2
    if not pid_alive(pid):
        print("PRYMORDIAL_STOP_REQUEST STALE_CONTROLLER_LOCK",pid); return 3
    req={"schema":"cptg-prymordial-stop-request-v1","requested_utc":utc_now(),"requester_pid":os.getpid(),"controller_pid":pid,"controller_session_id":info.get("session_id"),"mode":"DRAIN_AND_STOP"}
    write_atomic(ROOT/"WORK/STOP_REQUEST.json",req)
    print("PRYMORDIAL_STOP_REQUEST PASS")
    print("MODE DRAIN_AND_STOP")
    print("CONTROLLER_PID",pid)
    print("The controller will stop launching new rows, let already-running rows finish, promote only the contiguous successful prefix, then exit STOPPED_CLEANLY.")
    return 0
if __name__=="__main__": raise SystemExit(main())
