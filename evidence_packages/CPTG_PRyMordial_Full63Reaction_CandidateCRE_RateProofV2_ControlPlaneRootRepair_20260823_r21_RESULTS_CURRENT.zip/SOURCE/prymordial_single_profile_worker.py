from __future__ import annotations
import argparse, json, math, os, sys, time, traceback
from pathlib import Path
import numpy as np
HERE=Path(__file__).resolve().parent; sys.path.insert(0,str(HERE))
from common import ROOT, REACTIONS, write_atomic, sha_file
from solver_authority import SOLVER_PROFILES, authority_for_source, apply_precision, observed_precision, precision_identity
CACHE_FILES=["PRyMrates/thermo/Tgamma_Tnu.txt","PRyMrates/nTOp/nTOp_frwrd_HT.txt","PRyMrates/nTOp/nTOp_bkwrd_HT.txt","PRyMrates/nTOp/nTOp_frwrd_MT.txt","PRyMrates/nTOp/nTOp_bkwrd_MT.txt","PRyMrates/nTOp/nTOp_frwrd_LT.txt","PRyMrates/nTOp/nTOp_bkwrd_LT.txt"]
def require_runtime_cache(source_root:Path):
    missing=[rel for rel in CACHE_FILES if not (source_root/rel).is_file()]
    if missing: raise RuntimeError("PRyMordial runtime cache is not qualified; missing: "+", ".join(missing))
def configure(source_root:Path,req,authority_id):
    os.chdir(source_root); sys.path.insert(0,str(source_root)); import PRyM.PRyM_init as I
    I.verbose_flag=False; I.smallnet_flag=False; I.julia_flag=False; I.NP_nuclear_flag=(req.get("kind")=="perturbed")
    for name in ["compute_bckg_flag","compute_nTOp_flag","compute_nTOp_thermal_flag","save_bckg_flag","save_nTOp_flag"]:
        if hasattr(I,name): setattr(I,name,False)
    eta=float(req["eta10"])*1e-10; I.eta0b=eta
    if hasattr(I,"Omegabh2_to_eta0b") and I.Omegabh2_to_eta0b!=0: I.Omegabh2=eta/float(I.Omegabh2_to_eta0b)
    for r in REACTIONS: setattr(I,"p_"+r,0.0); setattr(I,"NP_delta_"+r,0.0)
    if req.get("kind")=="perturbed": setattr(I,"NP_delta_"+req["reaction"],float(req["NP_delta"]))
    requested=apply_precision(I,authority_id)
    return I,requested
def make_rates(I):
    from PRyM.PRyM_nuclear_net63 import UpdateNuclearRates
    return UpdateNuclearRates(*[float(getattr(I,"p_"+r)) for r in REACTIONS])
def rate_proof(I,reaction,factor):
    policy=json.loads((ROOT/"CONFIG/R20_RATE_PROOF_POLICY.json").read_text(encoding="utf-8"))
    saved={r:float(getattr(I,"NP_delta_"+r)) for r in REACTIONS}; flag=bool(I.NP_nuclear_flag)
    try:
        I.NP_nuclear_flag=True
        for r in REACTIONS: setattr(I,"NP_delta_"+r,0.0)
        med=np.asarray(getattr(I,reaction+"_median"),dtype=float).reshape(-1)
        knots=np.asarray(getattr(I,reaction+"_T9"),dtype=float).reshape(-1)
        if med.shape!=knots.shape or med.size<2 or not np.all(np.isfinite(med)) or not np.all(np.isfinite(knots)):
            raise RuntimeError("invalid native rate arrays")
        delta=float(factor)-1.0
        mu=med+delta*med
        expected_array=float(factor)*med
        denom=np.maximum(np.abs(expected_array),np.abs(mu))
        src_rel=np.zeros_like(denom)
        nz=denom>0
        src_rel[nz]=np.abs(mu[nz]-expected_array[nz])/denom[nz]
        src_worst=float(np.max(src_rel)) if src_rel.size else 0.0
        source_limit=float(policy["source_array_relative_limit"])
        source_pass=bool(src_worst<=source_limit)

        base=make_rates(I); setattr(I,"NP_delta_"+reaction,delta); pert=make_rates(I)
        f0=getattr(base,reaction+"_spline"); f1=getattr(pert,reaction+"_spline")
        vals=[float(v) for v in knots]
        for a,b in zip(knots[:-1],knots[1:]):
            for q in policy["interior_fraction_samples"]:
                vals.append(float(a+(b-a)*float(q)))
        grid=np.asarray(sorted(set(vals)),dtype=float)
        a=np.asarray(f0(grid),dtype=float); b=np.asarray(f1(grid),dtype=float); exp=float(factor)*a
        if not (np.all(np.isfinite(a)) and np.all(np.isfinite(b)) and np.all(np.isfinite(exp))):
            raise RuntimeError("nonfinite native spline evaluation")
        tiny=np.finfo(float).tiny
        scale=max(float(np.max(np.abs(a))),float(np.max(np.abs(b)))/max(abs(float(factor)),tiny),tiny)
        abs_err=np.abs(b-exp)
        bound=float(policy["spline_absolute_roundoff_factor_eps"])*float(np.finfo(float).eps)*max(1.0,abs(float(factor)))*scale
        spline_worst=float(np.max(abs_err))
        spline_pass=bool(spline_worst<=bound)

        legacy_limit=float(policy["legacy_relative_diagnostic_limit"])
        rel=np.full(exp.shape,np.nan,dtype=float)
        nzexp=exp!=0
        rel[nzexp]=np.abs(b[nzexp]/exp[nzexp]-1.0)
        legacy_count=int(np.sum(np.isfinite(rel)&(rel>legacy_limit)))
        legacy_worst=float(np.nanmax(rel)) if np.any(np.isfinite(rel)) else 0.0

        ids=np.unique(np.clip(np.array([0,len(knots)//4,len(knots)//2,3*len(knots)//4,len(knots)-1]),0,len(knots)-1))
        samples=[]
        for i in ids:
            T9=float(knots[i]); av=float(f0(T9)); bv=float(f1(T9)); ev=float(factor)*av
            ratio=(bv/av) if av!=0 else None
            rerr=(abs(bv/ev-1.0) if ev!=0 else None)
            samples.append({"T9":T9,"baseline":av,"perturbed":bv,"expected":ev,"ratio":ratio,"relative_error":rerr,"absolute_error":abs(bv-ev)})

        passed=source_pass and spline_pass
        return {
            "schema":"cptg-prymordial-native-rate-proof-v2",
            "method":"source_array_linearity_plus_spline_absolute_roundoff",
            "qualification_authority_sha256":policy["r19_results_sha256"],
            "reaction":reaction,
            "requested_factor":float(factor),
            "source_array_worst_relative":src_worst,
            "source_array_relative_limit":source_limit,
            "source_array_pass":source_pass,
            "eval_points":int(grid.size),
            "global_rate_scale":scale,
            "spline_max_absolute_error":spline_worst,
            "spline_absolute_bound":bound,
            "spline_absolute_pass":spline_pass,
            "legacy_relative_diagnostic_limit":legacy_limit,
            "legacy_relative_failure_points":legacy_count,
            "legacy_worst_relative_error":legacy_worst,
            "samples":samples,
            "pass":passed
        }
    finally:
        I.NP_nuclear_flag=flag
        for r,v in saved.items(): setattr(I,"NP_delta_"+r,v)

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--source-root",required=True); ap.add_argument("--request",required=True); ap.add_argument("--result",required=True); ap.add_argument("--proof",required=True); a=ap.parse_args()
    req=json.loads(Path(a.request).read_text(encoding="utf-8")); source=Path(a.source_root).resolve(); start=time.time()
    authority_id=req.get("precision_authority_id") or authority_for_source(source)
    result={"schema":"cptg-prymordial-row-result-v2","request":req,"source_root":str(source),"source_main_sha256":sha_file(source/"PRyM/PRyM_main.py"),"precision_authority_id":authority_id}
    proof={"kind":"baseline","pass":True}; x=None
    try:
        require_runtime_cache(source); I,requested=configure(source,req,authority_id)
        if req.get("kind")=="perturbed":
            proof=rate_proof(I,req["reaction"],float(req["rate_factor"]))
            if not proof["pass"]: raise RuntimeError("native rate proof failed")
            I.NP_nuclear_flag=True
            for r in REACTIONS: setattr(I,"NP_delta_"+r,0.0)
            setattr(I,"NP_delta_"+req["reaction"],float(req["NP_delta"]))
        from PRyM.PRyM_main import PRyMclass
        x=PRyMclass(); solver=getattr(x,"CPTG_solver_status",{}); observed=observed_precision(x)
        official=np.asarray(x.PRyMresults(),dtype=float).reshape(-1); finite=bool(official.size==8 and np.all(np.isfinite(official)))
        precision_ok=precision_identity(observed,authority_id)
        result.update({"official_PRyMresults":[float(v) for v in official.tolist()],"official_results_finite":finite,"solver_status":solver,
                       "solver_precision":{"requested":requested,"observed":observed,"contract_identity_pass":precision_ok,
                                           "solver_success_pass":bool(solver) and all(bool(v.get("success")) for v in solver.values())},
                       "eta0b_used":float(I.eta0b),"Omegabh2_used":float(I.Omegabh2),"NP_nuclear_flag":bool(I.NP_nuclear_flag),
                       "scaled_shifted_records":list(getattr(x,"CPTG_scaled_shifted_records",[]))})
        if not precision_ok or not solver or not all(bool(v.get("success")) for v in solver.values()):
            result["error_classification"]="SOLVER_PRECISION_OR_SUCCESS_REFUSAL"
            raise RuntimeError("solver precision contract or solver success audit failed")
        if not finite: raise RuntimeError(f"invalid official PRyMresults: length={official.size} finite={finite}")
        standard={"Neff":float(official[0]),"Omeganurel":float(official[1]),"OneOverOmeganunr":float(official[2]),"YPCMB":float(official[3]),"YPBBN":float(official[4]),"DoH":float(official[5])*1e-5,"He3oH":float(official[6])*1e-5,"Li7oH":float(official[7])*1e-10}
        result.update({"ok":True,"standard":standard})
    except Exception as exc:
        result.update({"ok":False,"error":repr(exc),"exception_class":type(exc).__name__,"exception_message":str(exc),"traceback":traceback.format_exc()})
    result["elapsed_s"]=time.time()-start; write_atomic(Path(a.proof),proof); write_atomic(Path(a.result),result)
    print("PRYM_ROW",req.get("run_id"),authority_id,"PASS" if result.get("ok") else "FAIL",f'{result["elapsed_s"]:.3f}s')
    raise SystemExit(0 if result.get("ok") else 10)
if __name__=="__main__": main()
