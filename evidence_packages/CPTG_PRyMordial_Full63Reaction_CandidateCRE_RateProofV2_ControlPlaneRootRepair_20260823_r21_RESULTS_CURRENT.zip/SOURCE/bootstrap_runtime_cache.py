from __future__ import annotations
import json,os,sys,shutil,traceback
from pathlib import Path
import numpy as np
from common import ROOT,REACTIONS,load_json,write_atomic,sha_file,tree_manifest
from solver_authority import authority_for_source,apply_precision,observed_precision,precision_identity
CACHE_FILES=[
"PRyMrates/thermo/Tgamma_Tnu.txt","PRyMrates/nTOp/nTOp_frwrd_HT.txt","PRyMrates/nTOp/nTOp_bkwrd_HT.txt",
"PRyMrates/nTOp/nTOp_frwrd_MT.txt","PRyMrates/nTOp/nTOp_bkwrd_MT.txt","PRyMrates/nTOp/nTOp_frwrd_LT.txt","PRyMrates/nTOp/nTOp_bkwrd_LT.txt"]

def clear_prym():
    for k in list(sys.modules):
        if k=="PRyM" or k.startswith("PRyM."): del sys.modules[k]

def configure(source,use_cache):
    clear_prym(); os.chdir(source); sys.path.insert(0,str(source))
    import PRyM.PRyM_init as I
    I.verbose_flag=False; I.smallnet_flag=False; I.julia_flag=False; I.NP_nuclear_flag=False; I.NP_thermo_flag=False; I.NP_nu_flag=False; I.NP_e_flag=False; I.NP_nTOp_flag=False
    I.compute_nTOp_thermal_flag=False; I.save_nTOp_thermal_flag=False
    I.compute_bckg_flag=not use_cache; I.save_bckg_flag=not use_cache; I.compute_nTOp_flag=not use_cache; I.save_nTOp_flag=not use_cache
    I.eta0b=6.094e-10; I.Omegabh2=I.eta0b/float(I.Omegabh2_to_eta0b)
    for r in REACTIONS: setattr(I,"p_"+r,0.0); setattr(I,"NP_delta_"+r,0.0)
    auth=authority_for_source(source); req=apply_precision(I,auth); return I,auth,req

def run(source,use_cache):
    I,auth,req=configure(source,use_cache)
    from PRyM.PRyM_main import PRyMclass
    x=PRyMclass(); off=np.asarray(x.PRyMresults(),float).reshape(-1); solver=getattr(x,"CPTG_solver_status",{}); obs=observed_precision(x)
    if off.size!=8 or not np.all(np.isfinite(off)): raise RuntimeError("invalid baseline output")
    if not precision_identity(obs,auth): raise RuntimeError("precision contract mismatch")
    if not solver or any(not bool(v.get("success")) for v in solver.values()): raise RuntimeError("solver failure "+json.dumps(solver))
    return {"official_PRyMresults":[float(v) for v in off],"authority":auth,"solver_status":solver,"observed_precision":obs,"scaled_shifted_records":list(getattr(x,"CPTG_scaled_shifted_records",[]))}

def relmax(a,b): return float(np.max(np.abs(np.asarray(a)-np.asarray(b))/np.maximum(np.maximum(np.abs(a),np.abs(b)),1e-300)))
def validate_cache(source):
    for rel in CACHE_FILES:
        p=source/rel
        if not p.is_file(): raise RuntimeError("missing cache "+rel)
        a=np.loadtxt(p)
        if np.asarray(a).ndim!=2 or np.asarray(a).shape[0]<10 or not np.all(np.isfinite(a)): raise RuntimeError("bad cache "+rel)

def main():
    identp=ROOT/"WORK/SOURCE_IDENTITY.json"
    if not identp.exists(): raise RuntimeError("Run RUN_PREPARE_WINDOWS.cmd first")
    out={"schema":"cptg-prymordial-candidate-cs-runtime-cache-v1","pass":False}
    try:
        C=ROOT/"WORK/SOURCE/CANDIDATE_C"; CS=ROOT/"WORK/SOURCE/CANDIDATE_CS"
        for s in (C,CS):
            for rel in CACHE_FILES:
                p=s/rel
                if p.exists(): p.unlink()
        print("PRYMORDIAL_RUNTIME_CACHE_START CANDIDATE_C",flush=True)
        generated=run(C,False); validate_cache(C)
        for dest in (CS,):
            for rel in CACHE_FILES:
                src=C/rel; dst=dest/rel; dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(src,dst)
        replayC=run(C,True); replayCS=run(CS,True)
        for s in (C,CS): validate_cache(s)
        c_replay=relmax(generated["official_PRyMresults"],replayC["official_PRyMresults"])
        cs_rel=relmax(replayC["official_PRyMresults"],replayCS["official_PRyMresults"])
        csrecs=replayCS["scaled_shifted_records"]
        cs_record_ok=(len(csrecs)==1 and csrecs[0].get("success") is True and float(csrecs[0].get("rtol"))==2e-9 and float(csrecs[0].get("atol_y_min"))==1e-16 and float(csrecs[0].get("atol_y_max"))==1e-16)
        gates={"endpoint_component_relative_limit":1e-6,"repeat_baseline_relative_limit":1e-9}
        cache_replay_limit=1e-8
        cs_equivalence_limit=float(gates["endpoint_component_relative_limit"])
        repeat_baseline_limit=float(gates["repeat_baseline_relative_limit"])
        subgates={
            "candidate_C_generation_replay": c_replay<=cache_replay_limit,
            "candidate_CS_vs_C_endpoint_equivalence": cs_rel<=cs_equivalence_limit,
            "candidate_CS_coordinate_record": cs_record_ok,
        }
        passed=all(subgates.values())
        out.update({
            "pass":passed,
            "candidate_C_generated":generated,
            "candidate_C_replay":replayC,
            "candidate_CS_replay":replayCS,
            "candidate_C_generation_replay_max_relative":c_replay,
            "candidate_C_generation_replay_limit":cache_replay_limit,
            "candidate_CS_vs_C_baseline_max_relative":cs_rel,
            "candidate_CS_vs_C_endpoint_equivalence_limit":cs_equivalence_limit,
            "candidate_CS_coordinate_record_pass":cs_record_ok,
            "repeat_baseline_relative_limit":repeat_baseline_limit,
            "repeat_baseline_gate_location":"30-row evaluator rows 6 and 30; not Candidate C-S vs Candidate C bootstrap equivalence",
            "subgates":subgates,
        })
        print("PRYMORDIAL_RUNTIME_CACHE_METRIC C_GENERATION_REPLAY_MAX_REL",c_replay,"LIMIT",cache_replay_limit,"PASS" if subgates["candidate_C_generation_replay"] else "FAIL",flush=True)
        print("PRYMORDIAL_RUNTIME_CACHE_METRIC CS_VS_C_BASELINE_MAX_REL",cs_rel,"LIMIT",cs_equivalence_limit,"PASS" if subgates["candidate_CS_vs_C_endpoint_equivalence"] else "FAIL",flush=True)
        print("PRYMORDIAL_RUNTIME_CACHE_METRIC CS_COORDINATE_RECORD","PASS" if cs_record_ok else "FAIL",flush=True)
        print("REPEAT_BASELINE_GATE_DEFERRED_TO_30_ROW_EVALUATOR",repeat_baseline_limit,flush=True)
        if not passed: raise RuntimeError("runtime cache qualification gate failed: "+json.dumps(subgates,sort_keys=True))
    except Exception as e:
        out["error"]=repr(e); out["traceback"]=traceback.format_exc(); write_atomic(ROOT/"EVIDENCE/RUNTIME_CACHE_QUALIFICATION.json",out); print("PRYMORDIAL_RUNTIME_CACHE_QUALIFICATION FAIL"); raise
    write_atomic(ROOT/"EVIDENCE/RUNTIME_CACHE_QUALIFICATION.json",out)
    print("PRYMORDIAL_RUNTIME_CACHE_QUALIFICATION PASS")
    print("CANDIDATE_CS_VS_C_BASELINE_MAX_REL",out["candidate_CS_vs_C_baseline_max_relative"])
    print("CANDIDATE_CR_RUNTIME_CACHE FRESH_PASS")
if __name__=="__main__": main()
