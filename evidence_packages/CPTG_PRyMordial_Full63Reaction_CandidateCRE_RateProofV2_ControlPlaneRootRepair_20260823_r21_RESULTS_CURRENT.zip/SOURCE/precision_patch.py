from __future__ import annotations
import ast,copy,difflib,hashlib,json,py_compile
from pathlib import Path

def sha_bytes(b:bytes): return hashlib.sha256(b).hexdigest()
def target_name(node):
    if isinstance(node,ast.Name): return node.id
    if isinstance(node,ast.Attribute): return node.attr
    return None
def leaf(node):
    if isinstance(node,ast.Name): return node.id
    if isinstance(node,ast.Attribute): return node.attr
    return None
def rhs_name(call):
    if not isinstance(call,ast.Call) or leaf(call.func)!='solve_ivp': return None
    rhs=call.args[0] if call.args else None
    if rhs is None:
        for kw in call.keywords:
            if kw.arg in ('fun','f'): rhs=kw.value; break
    return leaf(rhs)
def patched_call(call,phase,fallback):
    node=copy.deepcopy(call); node.keywords=[kw for kw in node.keywords if kw.arg not in ('rtol','atol')]
    for key in ('rtol','atol'):
        value=ast.Call(func=ast.Name(id='getattr',ctx=ast.Load()),args=[ast.Name(id='PRyMini',ctx=ast.Load()),ast.Constant(value=f'CPTG_{phase}_{key.upper()}'),ast.Constant(value=float(fallback[key]))],keywords=[])
        node.keywords.append(ast.keyword(arg=key,value=value))
    ast.fix_missing_locations(node); return node

def patch_main(path:Path,profiles:dict,record_path:Path):
    path=Path(path); original=path.read_text(encoding='utf-8'); tree=ast.parse(original,filename=str(path)); selected={}
    for node in ast.walk(tree):
        if isinstance(node,ast.Assign) and len(node.targets)==1 and isinstance(node.value,ast.Call):
            tgt=target_name(node.targets[0]); rn=rhs_name(node.value)
            if tgt=='sol_at_MT' and rn=='Y_prime_MT': selected['MT']=node
            if tgt=='sol_at_LT' and rn=='Y_prime_LT': selected['LT']=node
    if set(selected)!={'MT','LT'}: raise RuntimeError(f'precision AST anchors expected MT/LT exactly once, got {sorted(selected)}')
    lines=original.splitlines(True); replacements={}; rows=[]
    for phase in ('MT','LT'):
        node=selected[phase]; indent=lines[node.lineno-1][:len(lines[node.lineno-1])-len(lines[node.lineno-1].lstrip())]
        call=patched_call(node.value,phase,profiles['primary'][phase]); assignment=indent+f"{target_name(node.targets[0])} = {ast.unparse(call)}\n"
        diag=indent+f"self.CPTG_precision_contract_{phase} = {{'phase': '{phase}', 'method': 'BDF', 'rtol': float(getattr(PRyMini, 'CPTG_{phase}_RTOL', {profiles['primary'][phase]['rtol']!r})), 'atol': float(getattr(PRyMini, 'CPTG_{phase}_ATOL', {profiles['primary'][phase]['atol']!r}))}}\n"
        replacements[node.lineno]=(node.end_lineno,[assignment,diag])
        rows.append({'phase':phase,'start_line':node.lineno,'end_line':node.end_lineno,'rhs':rhs_name(node.value),'target':target_name(node.targets[0]),'original':ast.get_source_segment(original,node.value),'patched':ast.unparse(call)})
    out=[]; i=1
    while i<=len(lines):
        if i in replacements:
            end,block=replacements[i]; out.extend(block); i=end+1
        else: out.append(lines[i-1]); i+=1
    patched=''.join(out)
    backup=path.with_suffix(path.suffix+'.pre_precision')
    original_bytes=original.encode('utf-8')
    patched_bytes=patched.encode('utf-8')
    # Byte-exact writes are mandatory. Path.write_text performs host newline
    # translation on Windows and caused the r117 LF/CRLF fingerprint refusal.
    backup.write_bytes(original_bytes)
    path.write_bytes(patched_bytes)
    py_compile.compile(str(path),doraise=True)
    diff=''.join(difflib.unified_diff(original.splitlines(True),patched.splitlines(True),fromfile='PRyM_main.instrumented',tofile='PRyM_main.high_precision'))
    # Post-patch AST audit.
    pt=ast.parse(patched); observed={}
    for node in ast.walk(pt):
        if isinstance(node,ast.Assign) and len(node.targets)==1 and isinstance(node.value,ast.Call):
            tgt=target_name(node.targets[0]); rn=rhs_name(node.value)
            if (tgt,rn) in (('sol_at_MT','Y_prime_MT'),('sol_at_LT','Y_prime_LT')):
                kws={kw.arg:ast.unparse(kw.value) for kw in node.value.keywords}; observed[tgt]={'rhs':rn,'method':kws.get('method'),'jac':kws.get('jac'),'rtol':kws.get('rtol'),'atol':kws.get('atol')}
    checks={
      'two_exact_fullnet_calls':set(observed)=={'sol_at_MT','sol_at_LT'},
      'native_rhs_preserved':observed.get('sol_at_MT',{}).get('rhs')=='Y_prime_MT' and observed.get('sol_at_LT',{}).get('rhs')=='Y_prime_LT',
      'native_jacobians_preserved':'Jacobian_MT' in str(observed.get('sol_at_MT',{}).get('jac')) and 'Jacobian_LT' in str(observed.get('sol_at_LT',{}).get('jac')),
      'BDF_preserved':all('BDF' in str(v.get('method')) for v in observed.values()),
      'explicit_dynamic_rtol_atol':all('CPTG_' in str(v.get('rtol')) and 'CPTG_' in str(v.get('atol')) for v in observed.values()),
      'precision_contract_attributes':all(f'CPTG_precision_contract_{p}' in patched for p in ('MT','LT')),
      'post_file_bytes_exact':path.read_bytes()==patched_bytes,
      'backup_file_bytes_exact':backup.read_bytes()==original_bytes,
      'canonical_LF_output':b'\r\n' not in patched_bytes and b'\r' not in patched_bytes,
      'canonical_LF_backup':b'\r\n' not in original_bytes and b'\r' not in original_bytes
    }
    record={'schema':'cptg-r118-prymordial-precision-patch-v1','path':str(path),'pre_sha256':sha_bytes(original_bytes),'post_sha256':sha_bytes(patched_bytes),'post_file_sha256':sha_bytes(path.read_bytes()),'backup_file_sha256':sha_bytes(backup.read_bytes()),'encoding':'utf-8','newline_contract':'LF','diff_sha256':sha_bytes(diff.encode()),'diff':diff,'rows':rows,'observed':observed,'checks':checks,'pass':all(checks.values())}
    record_path.parent.mkdir(parents=True,exist_ok=True); record_path.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
    if not record['pass']: raise RuntimeError('precision patch post-audit failed')
    return record
