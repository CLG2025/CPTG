from __future__ import annotations
import hashlib,json,py_compile,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
EXPECTED_ROOT="CPTG_PRyMordial_Full63Reaction_CandidateCRE_RateProofV2_ControlPlaneRootRepair_20260823_r21"
LEDGER_SHA="e93e10f04ffe509e14983fbd04ae76fc5a55bdbed18580bf0a0b22e7571fd1d9"
def sha(p):
    h=hashlib.sha256()
    with p.open("rb") as f:
        for b in iter(lambda:f.read(1<<20),b""):h.update(b)
    return h.hexdigest()
def main():
    errs=[]
    if ROOT.name!=EXPECTED_ROOT:errs.append("distribution root identity")
    if sha(ROOT/"CONFIG/PRIMARY_EXECUTION_LEDGER.csv")!=LEDGER_SHA:errs.append("scientific ledger identity")
    if (ROOT/"WORK/AUDIT_HOLD.json").exists():errs.append("active audit hold")
    if (ROOT/"WORK/CAMPAIGN.lock").exists():errs.append("campaign lock exists")
    for p in (ROOT/"SOURCE").glob("*.py"):
        try:py_compile.compile(str(p),doraise=True)
        except Exception as e:errs.append("compile "+p.name+": "+repr(e))
    sys.path.insert(0,str(ROOT/"SOURCE"))
    import common
    scan=common.scan_commits(ROOT,expected_authority="candidate_C_R",required_commit_schema="cptg-prymordial-row-commit-v3")
    if scan["invalid_count"]!=0:errs.append("invalid commit evidence")
    if scan["valid_beyond_frontier"]:errs.append("noncontiguous authoritative commits")
    if scan["contiguous_frontier"]<2549:errs.append("frontier regressed below inherited authority")
    print("R21_RUNTIME_ROOT_IDENTITY","PASS" if ROOT.name==EXPECTED_ROOT else "FAIL")
    print("R21_RUNTIME_LEDGER_IDENTITY","PASS" if sha(ROOT/"CONFIG/PRIMARY_EXECUTION_LEDGER.csv")==LEDGER_SHA else "FAIL")
    print("R21_RUNTIME_FRONTIER",scan["contiguous_frontier"],"/ 3030")
    print("R21_RUNTIME_INVALID",scan["invalid_count"])
    print("R21_RUNTIME_STATIC_VERIFY","PASS" if not errs else "FAIL")
    for e in errs:print("  -",e)
    return 0 if not errs else 2
if __name__=="__main__":raise SystemExit(main())
