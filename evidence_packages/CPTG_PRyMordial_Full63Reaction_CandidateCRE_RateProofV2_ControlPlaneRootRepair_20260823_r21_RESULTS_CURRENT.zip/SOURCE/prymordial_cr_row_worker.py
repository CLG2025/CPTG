from __future__ import annotations
import argparse,json,math,os,subprocess,sys,time
from pathlib import Path
from common import ROOT,load_json,write_atomic,sha_file,requests_equal,solver_profile

def run_profile(profile,request,base):
    base.mkdir(parents=True,exist_ok=True)
    res=base/"result.json";proof=base/"proof.json";out=base/"stdout.txt";err=base/"stderr.txt"
    cmd=[sys.executable,str(ROOT/"SOURCE/prymordial_single_profile_worker.py"),"--source-root",str(ROOT/"WORK/SOURCE"/profile),"--request",str(request),"--result",str(res),"--proof",str(proof)]
    env=os.environ.copy();env.update({"PYTHONDONTWRITEBYTECODE":"1","OMP_NUM_THREADS":"1","OPENBLAS_NUM_THREADS":"1","MKL_NUM_THREADS":"1","PYTHONPYCACHEPREFIX":str(ROOT/"WORK/PYCACHE"),"NUMBA_CACHE_DIR":str(ROOT/"WORK/NUMBA_CACHE")})
    with out.open("wb") as fo,err.open("wb") as fe:p=subprocess.run(cmd,cwd=str(ROOT),env=env,stdout=fo,stderr=fe)
    return p.returncode,res,proof,out,err

def _rate_ok(row,pf):
    if pf.get("pass") is not True:return False
    if row["kind"]=="baseline":return pf.get("kind")=="baseline"
    try:
        if pf.get("reaction")!=row["reaction"] or float(pf.get("requested_factor"))!=float(row["rate_factor"]):return False
        if pf.get("schema")=="cptg-prymordial-native-rate-proof-v2":
            pol=load_json(ROOT/"CONFIG/R20_RATE_PROOF_POLICY.json")
            return (pf.get("qualification_authority_sha256")==pol["r19_results_sha256"] and
                    pf.get("source_array_pass") is True and pf.get("spline_absolute_pass") is True and
                    float(pf.get("source_array_worst_relative",999))<=float(pol["source_array_relative_limit"]) and
                    float(pf.get("spline_max_absolute_error",math.inf))<=float(pf.get("spline_absolute_bound",-1)))
        return float(pf.get("worst_relative_error",999))<=2e-11
    except Exception:return False

def _refusal_common(row,rc,res,proof,source_key,require_scaled):
    if rc!=10 or not res.is_file() or not proof.is_file():return False,[f"returncode={rc}"]
    r=load_json(res);pf=load_json(proof);errs=[]
    if r.get("ok") is not False or r.get("error_classification")!="SOLVER_PRECISION_OR_SUCCESS_REFUSAL":errs.append("classification")
    if r.get("precision_authority_id")!="candidate_C":errs.append("precision_authority")
    if not requests_equal(r.get("request",{}),row):errs.append("request")
    sid=load_json(ROOT/"WORK/SOURCE_IDENTITY.json")
    if r.get("source_main_sha256")!=sid[source_key]["PRyM_main_sha256"]:errs.append("source")
    sp=r.get("solver_precision",{});prof=solver_profile(ROOT,"candidate_C")
    if sp.get("requested")!=prof or sp.get("contract_identity_pass") is not True or sp.get("solver_success_pass") is not False:errs.append("precision")
    obs=sp.get("observed",{})
    for ph in ("MT","LT"):
        if obs.get(ph)!={"phase":ph,**prof[ph]}:errs.append("observed_precision_"+ph)
    sol=r.get("solver_status",{})
    if not sol or sol.get("HT",{}).get("success") is not True or sol.get("MT",{}).get("success") is not True or sol.get("LT",{}).get("success") is not False or int(sol.get("LT",{}).get("status",0))!=-1:errs.append("solver_pattern")
    off=r.get("official_PRyMresults")
    if not isinstance(off,list) or len(off)!=8 or not all(math.isfinite(float(v)) for v in off):errs.append("outputs")
    if not _rate_ok(row,pf):errs.append("proof")
    recs=r.get("scaled_shifted_records",[])
    if require_scaled:
        if not (len(recs)==1 and recs[0].get("success") is False and float(recs[0].get("rtol"))==2e-9 and float(recs[0].get("atol_y_min"))==1e-16 and float(recs[0].get("atol_y_max"))==1e-16):errs.append("scaled_record")
    elif recs not in ([],None):errs.append("unexpected_scaled_record")
    return not errs,errs

def eligible_cs_refusal(row,rc,res,proof):return _refusal_common(row,rc,res,proof,"candidate_cs",True)
def eligible_c_refusal(row,rc,res,proof):return _refusal_common(row,rc,res,proof,"candidate_c",False)

def validate_success(row,profile,rc,res,proof,require_scaled):
    if rc!=0 or not res.is_file() or not proof.is_file():return False,["process_or_output"]
    r=load_json(res);pf=load_json(proof);errs=[]
    phys="candidate_E" if profile=="CANDIDATE_E" else "candidate_C"
    key={"CANDIDATE_CS":"candidate_cs","CANDIDATE_C":"candidate_c","CANDIDATE_E":"candidate_e"}[profile]
    if r.get("ok") is not True:errs.append("result")
    if r.get("precision_authority_id")!=phys:errs.append("precision_authority")
    if not requests_equal(r.get("request",{}),row):errs.append("request")
    sid=load_json(ROOT/"WORK/SOURCE_IDENTITY.json")
    if r.get("source_main_sha256")!=sid[key]["PRyM_main_sha256"]:errs.append("source")
    sp=r.get("solver_precision",{});prof=solver_profile(ROOT,phys)
    if sp.get("requested")!=prof or sp.get("contract_identity_pass") is not True or sp.get("solver_success_pass") is not True:errs.append("precision")
    obs=sp.get("observed",{})
    for ph in ("MT","LT"):
        if obs.get(ph)!={"phase":ph,**prof[ph]}:errs.append("observed_precision_"+ph)
    sol=r.get("solver_status",{})
    if not sol or any(v.get("success") is not True or int(v.get("status",-99))!=0 for v in sol.values()):errs.append("solver")
    if not _rate_ok(row,pf):errs.append("rate_proof")
    if require_scaled:
        recs=r.get("scaled_shifted_records",[])
        if not (len(recs)==1 and recs[0].get("success") is True and float(recs[0].get("rtol"))==2e-9 and float(recs[0].get("atol_y_min"))==1e-16 and float(recs[0].get("atol_y_max"))==1e-16):errs.append("scaled_record")
    return not errs,errs

def refusal_meta(reqp,res,pf,so,se):
    return {"eligible":True,"request_relpath":reqp.relative_to(ROOT).as_posix(),"request_sha256":sha_file(reqp),"result_relpath":res.relative_to(ROOT).as_posix(),"result_sha256":sha_file(res),"proof_relpath":pf.relative_to(ROOT).as_posix(),"proof_sha256":sha_file(pf),"stdout_relpath":so.relative_to(ROOT).as_posix(),"stdout_sha256":sha_file(so),"stderr_relpath":se.relative_to(ROOT).as_posix(),"stderr_sha256":sha_file(se)}

def publish(srcres,srcproof,outres,outproof,path,primary_meta=None,native_meta=None,total_elapsed=None):
    r=load_json(srcres);r["cr_profile_id"]="candidate_C_R";r["cr_accepted_path"]=path;r["cr_primary_refusal"]=primary_meta;r["cr_native_refusal"]=native_meta
    if total_elapsed is not None:r["cr_total_elapsed_s"]=total_elapsed
    write_atomic(outres,r);write_atomic(outproof,load_json(srcproof))

def preserved_row2413_refusals(row):
    seedp=ROOT/"EVIDENCE/R16_ROW2413_RESUME_SEED.json"
    if row.get("run_id")!=2413 or not seedp.is_file():return None
    seed=load_json(seedp)
    if seed.get("authorized") is not True:return None
    req=ROOT/seed["request_relpath"]
    csb=ROOT/seed["candidate_cs_refusal_relpath"]; cb=ROOT/seed["candidate_c_refusal_relpath"]
    csr=csb/"result.json";csp=csb/"proof.json";cso=csb/"stdout.txt";cse=csb/"stderr.txt"
    cr=cb/"result.json";cp=cb/"proof.json";co=cb/"stdout.txt";ce=cb/"stderr.txt"
    ok1,e1=eligible_cs_refusal(row,10,csr,csp);ok2,e2=eligible_c_refusal(row,10,cr,cp)
    if not ok1 or not ok2:raise RuntimeError("r16 preserved row2413 refusal seed failed eligibility: "+repr({"cs":e1,"c":e2}))
    return refusal_meta(req,csr,csp,cso,cse),refusal_meta(req,cr,cp,co,ce)

def main():
    ap=argparse.ArgumentParser();ap.add_argument("--request",required=True);ap.add_argument("--result",required=True);ap.add_argument("--proof",required=True);a=ap.parse_args()
    reqp=Path(a.request).resolve();outres=Path(a.result).resolve();outproof=Path(a.proof).resolve();row=load_json(reqp);base=outres.parent/"CR_INTERNAL";start=time.time()
    preserved=preserved_row2413_refusals(row)
    if preserved is not None:
        pm,nm=preserved
        rc3,res3,pf3,so3,se3=run_profile("CANDIDATE_E",reqp,base/"CANDIDATE_E_TERTIARY")
        ok3,e3=validate_success(row,"CANDIDATE_E",rc3,res3,pf3,False)
        if not ok3:
            fail=load_json(res3) if res3.is_file() else {"schema":"cptg-prymordial-row-result-v2","request":row,"ok":False}
            fail.update({"cr_profile_id":"candidate_C_R","cr_accepted_path":None,"cr_primary_refusal":pm,"cr_native_refusal":nm,"cr_failure_stage":"CANDIDATE_E_TERTIARY","cr_validation_errors":e3,"cr_row2413_preserved_refusal_seed":True})
            write_atomic(outres,fail)
            if pf3.is_file():write_atomic(outproof,load_json(pf3))
            print("PRYM_CRE_ROW",row["run_id"],row.get("reaction") or "baseline","FAIL_CANDIDATE_E_TERTIARY",e3,flush=True);return 10
        publish(res3,pf3,outres,outproof,"CANDIDATE_E_TERTIARY",pm,nm,time.time()-start)
        r=load_json(outres);r["cr_row2413_preserved_refusal_seed"]=True;write_atomic(outres,r)
        print("PRYM_CRE_ROW",row["run_id"],row.get("reaction") or "baseline","PASS","PATH","CANDIDATE_E_TERTIARY","PRESERVED_R11_REFUSAL_SEED",flush=True);return 0
    rc,res,pf,so,se=run_profile("CANDIDATE_CS",reqp,base/"CANDIDATE_CS_PRIMARY")
    ok,errs=validate_success(row,"CANDIDATE_CS",rc,res,pf,True)
    if ok:
        publish(res,pf,outres,outproof,"CANDIDATE_CS_PRIMARY",None,None,time.time()-start);print("PRYM_CRE_ROW",row["run_id"],row.get("reaction") or "baseline","PASS","PATH","CANDIDATE_CS_PRIMARY",flush=True);return 0
    elig,eerrs=eligible_cs_refusal(row,rc,res,pf)
    if not elig:
        fail=load_json(res) if res.is_file() else {"schema":"cptg-prymordial-row-result-v2","request":row,"ok":False};fail.update({"cr_profile_id":"candidate_C_R","cr_accepted_path":None,"cr_primary_refusal_eligible":False,"cr_failure_stage":"CANDIDATE_CS_PRIMARY","cr_validation_errors":errs,"cr_eligibility_errors":eerrs});write_atomic(outres,fail)
        if pf.is_file():write_atomic(outproof,load_json(pf))
        print("PRYM_CRE_ROW",row["run_id"],row.get("reaction") or "baseline","FAIL_NONELIGIBLE_PRIMARY",errs,eerrs,flush=True);return 10
    pm=refusal_meta(reqp,res,pf,so,se)
    rc2,res2,pf2,so2,se2=run_profile("CANDIDATE_C",reqp,base/"CANDIDATE_C_NATIVE_FALLBACK")
    ok2,errs2=validate_success(row,"CANDIDATE_C",rc2,res2,pf2,False)
    if ok2:
        publish(res2,pf2,outres,outproof,"CANDIDATE_C_NATIVE_FALLBACK",pm,None,time.time()-start);print("PRYM_CRE_ROW",row["run_id"],row.get("reaction") or "baseline","PASS","PATH","CANDIDATE_C_NATIVE_FALLBACK",flush=True);return 0
    elig2,eerrs2=eligible_c_refusal(row,rc2,res2,pf2)
    if not elig2:
        fail=load_json(res2) if res2.is_file() else {"schema":"cptg-prymordial-row-result-v2","request":row,"ok":False};fail.update({"cr_profile_id":"candidate_C_R","cr_accepted_path":None,"cr_primary_refusal":pm,"cr_native_refusal_eligible":False,"cr_failure_stage":"CANDIDATE_C_NATIVE_FALLBACK","cr_validation_errors":errs2,"cr_eligibility_errors":eerrs2});write_atomic(outres,fail)
        if pf2.is_file():write_atomic(outproof,load_json(pf2))
        print("PRYM_CRE_ROW",row["run_id"],row.get("reaction") or "baseline","FAIL_NONELIGIBLE_NATIVE_FALLBACK",errs2,eerrs2,flush=True);return 10
    nm=refusal_meta(reqp,res2,pf2,so2,se2)
    rc3,res3,pf3,so3,se3=run_profile("CANDIDATE_E",reqp,base/"CANDIDATE_E_TERTIARY")
    ok3,errs3=validate_success(row,"CANDIDATE_E",rc3,res3,pf3,False)
    if not ok3:
        fail=load_json(res3) if res3.is_file() else {"schema":"cptg-prymordial-row-result-v2","request":row,"ok":False};fail.update({"cr_profile_id":"candidate_C_R","cr_accepted_path":None,"cr_primary_refusal":pm,"cr_native_refusal":nm,"cr_failure_stage":"CANDIDATE_E_TERTIARY","cr_validation_errors":errs3});write_atomic(outres,fail)
        if pf3.is_file():write_atomic(outproof,load_json(pf3))
        print("PRYM_CRE_ROW",row["run_id"],row.get("reaction") or "baseline","FAIL_CANDIDATE_E_TERTIARY",errs3,flush=True);return 10
    publish(res3,pf3,outres,outproof,"CANDIDATE_E_TERTIARY",pm,nm,time.time()-start)
    print("PRYM_CRE_ROW",row["run_id"],row.get("reaction") or "baseline","PASS","PATH","CANDIDATE_E_TERTIARY",flush=True);return 0

if __name__=="__main__":raise SystemExit(main())
