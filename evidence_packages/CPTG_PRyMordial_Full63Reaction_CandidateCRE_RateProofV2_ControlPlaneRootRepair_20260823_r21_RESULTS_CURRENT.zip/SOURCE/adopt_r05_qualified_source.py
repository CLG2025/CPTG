from __future__ import annotations
import json,hashlib,shutil,sys
from pathlib import Path
import numpy as np
from common import ROOT,write_atomic,sha_file,tree_manifest

R05=Path(r"D:\Downloads\CPTG_PRyMordial_CandidateCR_CoordinateRedundantProductionQualification_20260817_r05")
FINAL=Path(r"D:\Downloads\CPTG_PRyMordial_CANDIDATE_CR_FINAL_QUALIFICATION_EVIDENCE_20260817_r01.zip")
FINAL_SHA="a5139f710d1438ddac205ac611c86a9a09c25f81f997e25f5b3ae71b7e4af830"
CS_SHA="1e18692599414fd8409c3991dbc04a5829f7066f28b56ffcc76b10181712177d"
C_SHA="ac2de65ea56b9233bc0b1ea66fb862efb7f056ea1e3d4d9f867e9ff749b28aa1"
FREEZE="5c99f23a998a131c5894da53b35aef55d02a9faf31d54a524af31517e3463bf0"
CACHE=[
"PRyMrates/thermo/Tgamma_Tnu.txt","PRyMrates/nTOp/nTOp_frwrd_HT.txt","PRyMrates/nTOp/nTOp_bkwrd_HT.txt",
"PRyMrates/nTOp/nTOp_frwrd_MT.txt","PRyMrates/nTOp/nTOp_bkwrd_MT.txt","PRyMrates/nTOp/nTOp_frwrd_LT.txt","PRyMrates/nTOp/nTOp_bkwrd_LT.txt"]

def load(p):return json.loads(p.read_text(encoding="utf-8"))
def main():
    if not R05.is_dir():raise RuntimeError("completed r05 root not found: "+str(R05))
    if not FINAL.is_file() or sha_file(FINAL)!=FINAL_SHA:raise RuntimeError("final C-R qualification evidence archive missing/hash mismatch")
    q=load(R05/"EVIDENCE/CANDIDATE_CR_QUALIFICATION_RESULT.json")
    f=load(R05/"OUTPUT/PREDICTION_FREEZE.json")
    if q.get("decision")!="PASS" or q.get("rows_passed")!=30 or q.get("prediction_freeze_sha256")!=FREEZE or f.get("sha256")!=FREEZE:
        raise RuntimeError("local r05 qualification state is not the sealed 30/30 PASS")
    sid=load(R05/"WORK/SOURCE_IDENTITY.json")
    if sid["candidate_cs"]["PRyM_main_sha256"]!=CS_SHA or sid["candidate_c"]["PRyM_main_sha256"]!=C_SHA:
        raise RuntimeError("r05 qualified source identity mismatch")
    dstroot=ROOT/"WORK/SOURCE";dstroot.mkdir(parents=True,exist_ok=True)
    cache_records={}
    for prof,key,expect in (("CANDIDATE_CS","candidate_cs",CS_SHA),("CANDIDATE_C","candidate_c",C_SHA)):
        src=R05/"WORK/SOURCE"/prof;dst=dstroot/prof
        if not src.is_dir():raise RuntimeError("r05 prepared source missing: "+str(src))
        if sha_file(src/"PRyM/PRyM_main.py")!=expect:raise RuntimeError(prof+" main hash mismatch before adoption")
        for rel in CACHE:
            p=src/rel
            if not p.is_file():raise RuntimeError(prof+" cache missing "+rel)
            a=np.loadtxt(p)
            if np.asarray(a).ndim!=2 or np.asarray(a).shape[0]<10 or not np.all(np.isfinite(a)):
                raise RuntimeError(prof+" cache invalid "+rel)
        if dst.exists():shutil.rmtree(dst)
        shutil.copytree(src,dst,ignore=shutil.ignore_patterns("__pycache__","*.pyc"))
        if sha_file(dst/"PRyM/PRyM_main.py")!=expect:raise RuntimeError(prof+" main hash mismatch after copy")
        cache_records[prof]=[{"path":rel,"sha256":sha_file(dst/rel),"size_bytes":(dst/rel).stat().st_size} for rel in CACHE]
    ident={"schema":"cptg-prymordial-r10-adopted-qualified-source-identity-v1",
           "adoption_source":str(R05),"qualification_archive":str(FINAL),"qualification_archive_sha256":FINAL_SHA,
           "original_root":sid["original_root"],"original_manifest":sid["original_manifest"],
           "candidate_cs":{"root":str(dstroot/"CANDIDATE_CS"),"PRyM_main_sha256":CS_SHA,"precision_authority":"candidate_C","coordinate_conditioned":True,
                           "manifest":tree_manifest(dstroot/"CANDIDATE_CS")},
           "candidate_c":{"root":str(dstroot/"CANDIDATE_C"),"PRyM_main_sha256":C_SHA,"precision_authority":"candidate_C","coordinate_conditioned":False,
                          "manifest":tree_manifest(dstroot/"CANDIDATE_C")}}
    write_atomic(ROOT/"WORK/SOURCE_IDENTITY.json",ident)
    write_atomic(ROOT/"EVIDENCE/RUNTIME_CACHE_QUALIFICATION.json",{
        "schema":"cptg-prymordial-r10-adopted-runtime-cache-v1","pass":True,"mode":"ADOPTED_FROM_QUALIFIED_R05",
        "qualification_archive_sha256":FINAL_SHA,"prediction_freeze_sha256":FREEZE,"cache_records":cache_records,
        "native_rerun_performed":False})
    write_atomic(ROOT/"EVIDENCE/CANDIDATE_CR_PRODUCTION_AUTHORITY_BINDING.json",{
        "schema":"cptg-prymordial-r10-production-authority-binding-v1","pass":True,"authority_id":"candidate_C_R",
        "physical_precision_authority":"candidate_C","candidate_CS_main_sha256":CS_SHA,"candidate_C_main_sha256":C_SHA,
        "qualification_archive_sha256":FINAL_SHA,"prediction_freeze_sha256":FREEZE,"r09_numerical_commits_imported":False})
    print("PRYMORDIAL_R10_ADOPT_R05_QUALIFIED_SOURCE PASS")
    print("CANDIDATE_CS_MAIN",CS_SHA)
    print("CANDIDATE_C_MAIN",C_SHA)
    print("RUNTIME_CACHE 14/14 FILES PASS")
    print("NATIVE_RERUN_PERFORMED False")
    print("R09_NUMERICAL_COMMITS_IMPORTED False")
    print("PRODUCTION_AUTHORITY candidate_C_R")
if __name__=="__main__":main()
