from __future__ import annotations
import ast, hashlib
from pathlib import Path
MARKER='CPTG_PRIMAT_INFORMED_SCALED_SHIFTED_LT_V1'
BLOCK=r'''
# CPTG_PRIMAT_INFORMED_SCALED_SHIFTED_LT_V1
_CPTG_SCALED_SHIFTED_RECORDS=[]
def _CPTG_scaled_shifted_solve_ivp(_fun,_t_span,_y0,*_args,**_kwargs):
    import numpy as _np
    from scipy.integrate import solve_ivp as _solve_ivp
    _y0=_np.asarray(_y0,dtype=float).reshape(-1)
    _rtol=float(_kwargs.get('rtol',1e-3))
    _atol_raw=_np.asarray(_kwargs.get('atol',1e-6),dtype=float)
    _atol_y=_np.full(_y0.size,float(_atol_raw),dtype=float) if _atol_raw.ndim==0 else _atol_raw.reshape(-1).copy()
    if _atol_y.size!=_y0.size: raise RuntimeError('CPTG scaled-shifted atol size mismatch')
    _scale=_np.maximum(_np.abs(_y0),_np.maximum(_atol_y/max(_rtol,1e-300),1e-300))
    if _np.any(~_np.isfinite(_scale)) or _np.any(_scale<=0): raise RuntimeError('CPTG scaled-shifted invalid scale')
    _t0=float(_t_span[0]); _t1=float(_t_span[1]); _dt=_t1-_t0
    if not _np.isfinite(_dt) or _dt<=0: raise RuntimeError('CPTG scaled-shifted invalid time span')
    _jac=_kwargs.get('jac',None)
    def _fun_u(_tau,_u):
        _y=_scale*_np.asarray(_u,dtype=float)
        return _np.asarray(_fun(_t0+float(_tau),_y),dtype=float)/_scale
    if callable(_jac):
        def _jac_u(_tau,_u):
            _y=_scale*_np.asarray(_u,dtype=float)
            _J=_np.asarray(_jac(_t0+float(_tau),_y),dtype=float)
            return (_J*_scale[_np.newaxis,:])/_scale[:,_np.newaxis]
        _jac_use=_jac_u
    elif _jac is None:
        _jac_use=None
    else:
        _J=_np.asarray(_jac,dtype=float); _jac_use=(_J*_scale[_np.newaxis,:])/_scale[:,_np.newaxis]
    _kw=dict(_kwargs); _kw['atol']=_atol_y/_scale
    if 'jac' in _kw: _kw['jac']=_jac_use
    _sol=_solve_ivp(_fun_u,[0.0,_dt],_y0/_scale,*_args,**_kw)
    _sol.t=_np.asarray(_sol.t,dtype=float)+_t0
    _sol.y=_scale[:,_np.newaxis]*_np.asarray(_sol.y,dtype=float)
    _CPTG_SCALED_SHIFTED_RECORDS.append({'t0':_t0,'t1':_t1,'dt':_dt,'rtol':_rtol,'atol_y_min':float(_atol_y.min()),'atol_y_max':float(_atol_y.max()),'atol_u_min':float((_atol_y/_scale).min()),'atol_u_max':float((_atol_y/_scale).max()),'scale_min':float(_scale.min()),'scale_max':float(_scale.max()),'success':bool(_sol.success),'message':str(_sol.message),'nfev':int(_sol.nfev),'njev':int(getattr(_sol,'njev',0)),'nlu':int(getattr(_sol,'nlu',0))})
    return _sol
'''
def leaf(n):
    if isinstance(n,ast.Name): return n.id
    if isinstance(n,ast.Attribute): return n.attr
    return None
def patch(path:Path):
    b=path.read_bytes(); text=b.decode('utf-8'); pre=hashlib.sha256(b).hexdigest()
    if MARKER in text: raise RuntimeError('already scaled-shifted patched')
    tree=ast.parse(text); found=[]
    for node in ast.walk(tree):
        if isinstance(node,ast.Assign) and len(node.targets)==1 and isinstance(node.value,ast.Call) and leaf(node.value.func)=='solve_ivp':
            tgt=leaf(node.targets[0]); rhs=leaf(node.value.args[0]) if node.value.args else None
            if tgt=='sol_at_LT' and rhs=='Y_prime_LT': found.append(node)
    if len(found)!=1: raise RuntimeError(f'expected exactly one LT solve_ivp anchor, got {len(found)}')
    node=found[0]; lines=text.splitlines(True); call=ast.parse(ast.unparse(node.value),mode='eval').body
    call.func=ast.Name(id='_CPTG_scaled_shifted_solve_ivp',ctx=ast.Load())
    indent=lines[node.lineno-1][:len(lines[node.lineno-1])-len(lines[node.lineno-1].lstrip())]
    lines[node.lineno-1:node.end_lineno]=[indent+f'{leaf(node.targets[0])} = {ast.unparse(call)}\n']
    tmp=''.join(lines); t2=ast.parse(tmp); ins=0
    for n in t2.body:
        if isinstance(n,(ast.Import,ast.ImportFrom)) or (isinstance(n,ast.Expr) and isinstance(n.value,ast.Constant) and isinstance(n.value.value,str)): ins=n.end_lineno
        else: break
    bl=tmp.splitlines(True); out=''.join(bl[:ins])+BLOCK+'\n'+''.join(bl[ins:]); path.write_bytes(out.encode('utf-8'))
    return {'pre_sha256':pre,'post_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'anchor':'LT','coordinate_transform':'u=y/scale; tau=t-t0','physical_error_weight_identity':'scale*(atol_u+rtol*abs(u)) == atol_y+rtol*abs(y)'}
