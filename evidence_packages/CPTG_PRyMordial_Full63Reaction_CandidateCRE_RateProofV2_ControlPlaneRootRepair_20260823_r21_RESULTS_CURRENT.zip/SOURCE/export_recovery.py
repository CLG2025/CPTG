from __future__ import annotations
from pathlib import Path
import zipfile,hashlib,datetime,json,sys
from common import ROOT,load_json,scan_commits,sha_file
def main():
    scan=scan_commits(ROOT,expected_authority="candidate_C_R",required_commit_schema="cptg-prymordial-row-commit-v3")
    if scan["invalid_count"] or scan["valid_beyond_frontier"]:raise RuntimeError("cannot export recovery with invalid/noncontiguous commits")
    frontier=scan["contiguous_frontier"];stamp=datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    out=ROOT.parent/f"{ROOT.name}_RECOVERY_CHECKPOINT_{stamp}.zip"
    include=[]
    for rel in ["CONFIG","REFERENCE","EVIDENCE","SOURCE"]:
        d=ROOT/rel
        include.extend(p for p in d.rglob("*") if p.is_file())
    for rid in range(1,frontier+1):
        cp=ROOT/"WORK/COMMITS"/f"run_{rid:05d}.json";include.append(cp);c=load_json(cp)
        for k in ("row_request_relpath","row_result_relpath","rate_proof_relpath","stdout_relpath","stderr_relpath"):
            p=ROOT/c[k]
            if p.is_file():include.append(p)
        rr=load_json(ROOT/c["row_result_relpath"])
        meta=rr.get("cr_primary_refusal")
        if isinstance(meta,dict):
            for k in ("request_relpath","result_relpath","proof_relpath","stdout_relpath","stderr_relpath"):
                if meta.get(k) and (ROOT/meta[k]).is_file():include.append(ROOT/meta[k])
    for rel in ["WORK/COMMIT_FRONTIER.json","WORK/LIVE_STATUS.json"]:
        p=ROOT/rel
        if p.is_file():include.append(p)
    include=sorted(set(include),key=lambda p:p.relative_to(ROOT).as_posix())
    with zipfile.ZipFile(out,"w",zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in include:z.write(p,p.relative_to(ROOT))
    h=sha_file(out);out.with_suffix(out.suffix+".sha256.txt").write_text(f"{h}  {out.name}\n",encoding="utf-8")
    print("PRYMORDIAL_CANDIDATE_CR_RECOVERY_EXPORT PASS")
    print("FRONTIER",frontier,"/3030")
    print("ZIP",out);print("SHA256",h)
if __name__=="__main__":main()
