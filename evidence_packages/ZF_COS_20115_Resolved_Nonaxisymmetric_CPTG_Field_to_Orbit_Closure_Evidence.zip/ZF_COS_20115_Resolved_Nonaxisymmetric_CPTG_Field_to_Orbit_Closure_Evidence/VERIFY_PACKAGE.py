#!/usr/bin/env python3
from pathlib import Path
import json, math, py_compile, hashlib
import numpy as np
import pandas as pd

HERE=Path(__file__).resolve().parent
KPC_M=3.0856775814913673e19
issues=[]
checks={}

def ck(name, condition, detail=''):
    ok=bool(condition); checks[name]={'pass':ok,'detail':str(detail)}
    if not ok: issues.append(f'{name}: {detail}')

def sha256(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()

# Structural arithmetic and radius authority
loc=pd.read_csv(HERE/'LOCAL_STRUCTURAL_ACCELERATION_FIELD.csv').sort_values('bin_id')
fld=pd.read_csv(HERE/'NONAXISYMMETRIC_BARYONIC_AND_CPTG_FIELD.csv').sort_values('bin_id')
ck('resolved_bins',len(loc)==26 and len(fld)==26,(len(loc),len(fld)))
R=np.sqrt(fld.major_kpc.to_numpy()**2+(fld.minor_kpc.to_numpy()/0.70)**2)
rr=np.max(np.abs(R-loc.R_elliptical_kpc.to_numpy())/np.maximum(loc.R_elliptical_kpc.to_numpy(),1e-300))
ck('primary_radius_q0p70',rr<1e-12,rr)
a=(loc.observed_vrms_km_s.to_numpy()**2/R)*(1e6/KPC_M)
ar=np.max(np.abs(a-loc.a_star_local_m_s2.to_numpy())/loc.a_star_local_m_s2.to_numpy())
ck('local_a_star_identity',ar<1e-12,ar)
ck('bin21_present',21 in set(loc.bin_id.astype(int)),21)

# Source authority
params=json.loads((HERE/'SOURCE_MODEL_PARAMETERS.json').read_text())
comp=pd.read_csv(HERE/'AXISYMMETRIC_SOURCE_COMPONENTS.csv')
ms=float(comp.projected_component_mass_Msun.sum())
ck('source_mass_sum',abs(ms-float(params['total_stellar_mass_msun']))/ms<1e-12,ms)
# Source aperture-mass consistency
msa=json.loads((HERE/'SOURCE_MASS_APERTURE_SUMMARY.json').read_text())
q=float(params['projected_axis_ratio']); rap=3.0
map3=float(np.sum(np.pi*q*comp.surface_density_increment_Msun_kpc2.to_numpy(float)*np.minimum(rap,comp.outer_radius_kpc.to_numpy(float))**2))
ck('source_mass_inside_3kpc',abs(map3-float(msa['model_mass_inside_aperture_Msun']))/map3<1e-12,map3)
ck('source_mass_3kpc_literature_consistency',abs(float(msa['central_difference_sigma']))<1.0,msa['central_difference_sigma'])

# Field gate and direct source spot checks
fc=pd.read_csv(HERE/'FIELD_CONSISTENCY_26.csv').sort_values('bin_id')
ck('field_gate_rows',len(fc)==26,len(fc))
ck('field_gate_max_lt_1e3',float(fc.fractional_vector_mismatch.max())<1e-3,float(fc.fractional_vector_mismatch.max()))
spot=pd.read_csv(HERE/'DIRECT_QUADRATURE_SPOT_CHECKS.csv')
ck('direct_force_spotcheck',float(spot.base_force_fractional_mismatch.max())<1e-9,float(spot.base_force_fractional_mismatch.max()))
ck('direct_potential_spotcheck',float(spot.base_potential_fractional_mismatch.max())<1e-12,float(spot.base_potential_fractional_mismatch.max()))

# Orbit matrices and independent input consistency
m=np.load(HERE/'ORBIT_LIBRARY_MOMENT_MATRICES.npz',allow_pickle=False)
ck('matrix_shape_L',m['L'].shape==(4096,26),m['L'].shape)
ck('matrix_shape_M1',m['M1'].shape==(4096,26),m['M1'].shape)
ck('matrix_shape_M2',m['M2'].shape==(4096,26),m['M2'].shape)
ck('orbit_ids_complete',np.array_equal(m['orbit_ids'],np.arange(4096)),m['orbit_ids'].shape)
ck('energy_gate_4096',int(np.sum(m['energy_error']<=5e-4))==4096,float(np.max(m['energy_error'])))
ck('energy_max',float(np.max(m['energy_error']))<=5e-4,float(np.max(m['energy_error'])))
ck('retry_count',int(np.sum(m['retry']>0))==0,int(np.sum(m['retry']>0)))

ic=pd.read_csv(HERE/'ORBIT_LIBRARY_INITIAL_CONDITIONS_AND_WEIGHTS.csv').sort_values('global_orbit_id')
ck('ic_rows',len(ic)==4096,len(ic))
pos=ic[['x0_kpc','y0_kpc','z0_kpc']].to_numpy(float)
vel=ic[['vx0_km_s','vy0_km_s','vz0_km_s']].to_numpy(float)
ck('initial_positions_match',np.max(np.abs(pos-m['initial_position']))<1e-13,np.max(np.abs(pos-m['initial_position'])))
ck('initial_velocities_match',np.max(np.abs(vel-m['initial_velocity']))<1e-12,np.max(np.abs(vel-m['initial_velocity'])))
ck('periods_match',np.max(np.abs(ic.local_period_kpc_per_km_s.to_numpy()-m['period']))<1e-15,np.max(np.abs(ic.local_period_kpc_per_km_s.to_numpy()-m['period'])))

sp=pd.read_csv(HERE/'EXACT_RESOLVED_SPAXEL_SUPPORT.csv')
ck('spaxel_count',len(sp)==141,len(sp))
ck('spaxel_xy_match',np.max(np.abs(sp[['major_kpc','minor_kpc']].to_numpy()-m['spaxel_xy']))<1e-13,np.max(np.abs(sp[['major_kpc','minor_kpc']].to_numpy()-m['spaxel_xy'])))
ck('spaxel_bin_match',np.array_equal(sp.bin_id.to_numpy(int),m['spaxel_bin']),len(sp))
geom=json.loads((HERE/'OBSERVATION_GEOMETRY.json').read_text())
ck('psf_sigma_match',abs(float(geom['psf_sigma_kpc'])-float(m['sigma_psf']))<1e-15,float(m['sigma_psf']))

obs=pd.read_csv(HERE/'OBSERVATION_TARGETS.csv').sort_values('bin_id')
for col,key in [('target_tracer_fraction','light'),('observed_velocity_km_s','Vobs'),('velocity_1sigma_km_s','eV'),('observed_vrms_km_s','Vrms'),('vrms_1sigma_km_s','eVrms')]:
    delta=float(np.max(np.abs(obs[col].to_numpy(float)-m[key])))
    ck('observation_'+key,delta<1e-12,delta)

# Closure reconstruction
sol=np.load(HERE/'CLOSURE_SOLUTION.npz',allow_pickle=False)
w=sol['weights']
ck('weights_nonnegative',float(np.min(w))>=-1e-12,float(np.min(w)))
lp=w@m['L']; vp=(w@m['M1'])/lp; rp=np.sqrt(np.maximum((w@m['M2'])/lp,0))
pv=(vp-m['Vobs'])/m['eV']; pr=(rp-m['Vrms'])/m['eVrms']; lr=lp/m['light']-1
cl=pd.read_csv(HERE/'RESOLVED_BIN_OBSERVATIONS_AND_MODEL_CLOSURE.csv').sort_values('bin_id')
ck('closure_model_V',float(np.max(np.abs(vp-cl.model_velocity_km_s.to_numpy())))<1e-10,float(np.max(np.abs(vp-cl.model_velocity_km_s.to_numpy()))))
ck('closure_model_Vrms',float(np.max(np.abs(rp-cl.model_vrms_km_s.to_numpy())))<1e-10,float(np.max(np.abs(rp-cl.model_vrms_km_s.to_numpy()))))
ck('closure_velocity_pulls',float(np.max(np.abs(pv)))<3,float(np.max(np.abs(pv))))
ck('closure_vrms_pulls',float(np.max(np.abs(pr)))<3,float(np.max(np.abs(pr))))
ck('closure_tracer_1pct',float(np.max(np.abs(lr)))<=0.010000000001,float(np.max(np.abs(lr))))
ck('closure_tau',abs(float(sol['hard_tracer_tolerance'][0])-0.01)<1e-15,float(sol['hard_tracer_tolerance'][0]))
ck('active_orbits_23',int(np.sum(w>1e-10))==23,int(np.sum(w>1e-10)))

lad=pd.read_csv(HERE/'TRACER_TOLERANCE_CLOSURE_LADDER.csv')
ck('ladder_first_tau',abs(float(lad.iloc[0].hard_tracer_tolerance_fraction)-0.01)<1e-15,float(lad.iloc[0].hard_tracer_tolerance_fraction))
ck('ladder_first_tau_closes',bool(lad.iloc[0].all_velocity_and_vrms_pulls_below_3),lad.iloc[0].all_velocity_and_vrms_pulls_below_3)

cross=json.loads((HERE/'SOLVER_CROSSCHECK.json').read_text())
ck('solver_crosscheck_methods',cross['all_methods_optimal'] and len(cross['methods'])==3,cross['methods'])
ck('solver_crosscheck_constraint',float(cross['maximum_linear_constraint_violation'])<1e-12,cross['maximum_linear_constraint_violation'])

# Local input uncertainty propagation
uis=json.loads((HERE/'LOCAL_INPUT_UNCERTAINTY_SUMMARY.json').read_text())
uic=pd.read_csv(HERE/'LOCAL_INPUT_UNCERTAINTY_PROPAGATION.csv')
ck('uncertainty_rows',len(uic)==26,len(uic))
ck('a_star_uncertainty_range',abs(float(uic.a_star_linear_fractional_1sigma.min())-float(uis['a_star_fractional_1sigma_min']))<1e-12 and abs(float(uic.a_star_linear_fractional_1sigma.max())-float(uis['a_star_fractional_1sigma_max']))<1e-12,(uic.a_star_linear_fractional_1sigma.min(),uic.a_star_linear_fractional_1sigma.max()))
ck('local_g_uncertainty_finite',bool(np.isfinite(uic.g_CPTG_mc_fractional_halfwidth_68.to_numpy(float)).all()),uic.g_CPTG_mc_fractional_halfwidth_68.max())
ck('local_g_central_recompute',float(uis['central_field_recompute_max_fractional_error'])<1e-9,uis['central_field_recompute_max_fractional_error'])

# Sub-percent tracer-tolerance boundary diagnostic
sub=pd.read_csv(HERE/'SUBPERCENT_TRACER_TOLERANCE_DIAGNOSTIC.csv')
csub=sub[sub.model=='CPTG'].sort_values('tracer_tolerance_fraction')
bsub=sub[sub.model=='baryonic_only'].sort_values('tracer_tolerance_fraction')
ck('subpercent_rows',len(sub)==12,len(sub))
ck('subpercent_cptg_0p25_not_closed',not bool(csub[np.isclose(csub.tracer_tolerance_fraction,0.0025)].iloc[0].all_velocity_and_vrms_pulls_below_3),csub[np.isclose(csub.tracer_tolerance_fraction,0.0025)].iloc[0].max_abs_vrms_pull)
ck('subpercent_cptg_0p5_closed',bool(csub[np.isclose(csub.tracer_tolerance_fraction,0.005)].iloc[0].all_velocity_and_vrms_pulls_below_3),csub[np.isclose(csub.tracer_tolerance_fraction,0.005)].iloc[0].max_abs_vrms_pull)
ck('subpercent_baryonic_never_closed',not bool(bsub.all_velocity_and_vrms_pulls_below_3.any()),bsub.max_abs_vrms_pull.min())

# Structural Mode N: exact registered SPARC-workbench estimator on packaged full-R95 profile
sm=pd.read_csv(HERE/'STRUCTURAL_MODE_N_PROFILE.csv')
sms=json.loads((HERE/'STRUCTURAL_MODE_N_SUMMARY.json').read_text())
ck('structural_mode_profile_rows',len(sm)==16385,len(sm))
rr=sm.radius_kpc.to_numpy(float); gg=sm.gCPTG_m_s2.to_numpy(float)
ck('structural_mode_radius_monotonic',bool(np.all(np.diff(rr)>0)),float(np.min(np.diff(rr))))
r_m=rr*KPC_M
order=np.argsort(r_m); r_sorted=r_m[order]; g_sorted=np.maximum(gg[order],np.finfo(float).tiny)
dg=np.gradient(g_sorted,r_sorted)
Cg=g_sorted**2+(KPC_M*dg)**2
dCg=np.gradient(Cg,r_sorted)
finite=np.isfinite(r_sorted)&np.isfinite(dCg)&(r_sorted>0)
R_m=float(np.max(r_sorted)); mask=(r_sorted>R_m/5.0)&finite
r_outer=r_sorted[mask]; sw=np.abs(dCg[mask])
if len(sw)>5: sw=np.convolve(sw,np.ones(5)/5.0,mode='same')
lambda_m=float(np.sum(r_outer*sw)/np.sum(sw)); N_mode=float(R_m/lambda_m)
ck('structural_mode_R95',abs(R_m/KPC_M-float(sms['R95_kpc']))<1e-12,R_m/KPC_M)
ck('structural_mode_lambda',abs(lambda_m/KPC_M-float(sms['primary']['lambda_kpc']))<1e-10,lambda_m/KPC_M)
ck('structural_mode_N',abs(N_mode-float(sms['primary']['N']))<1e-10,N_mode)
ck('structural_mode_CSMI',3.30<N_mode<=3.55 and sms['primary']['CSMI_label']=='Bulged Spiral',sms['primary']['CSMI_label'])
mid=0.5*(rr[:-1]+rr[1:]); tv=np.abs(np.diff(sm.C_g.to_numpy(float)))
lambda_tv=float(np.sum(mid*tv)/np.sum(tv)); N_tv=float((R_m/KPC_M)/lambda_tv)
ck('structural_mode_continuum_N',abs(N_tv-float(sms['continuum_crosscheck']['N']))<1e-10,N_tv)
ck('structural_mode_primary_continuum_delta',abs(N_tv-N_mode)<1e-3,abs(N_tv-N_mode))
smc=pd.read_csv(HERE/'STRUCTURAL_MODE_N_SAMPLING_CONVERGENCE.csv')
ck('structural_mode_sampling_final',int(smc.iloc[-1].radial_samples)==16385 and abs(float(smc.iloc[-1].N)-N_mode)<1e-10,smc.iloc[-1].to_dict())
ck('structural_mode_sampling_convergence',abs(float(smc.iloc[-1].N)-float(smc.iloc[-2].N))<1e-3,abs(float(smc.iloc[-1].N)-float(smc.iloc[-2].N)))

# Sampling convergence record exists and is finite
sc=pd.read_csv(HERE/'MOMENT_SAMPLING_CONVERGENCE.csv')
ck('sampling_rows',len(sc)==32,len(sc))
ck('sampling_finite',np.isfinite(sc.select_dtypes(include=[float,int]).to_numpy()).all(),'finite')

# Python source compilation
for p in sorted(HERE.glob('*.py')):
    try: py_compile.compile(str(p),doraise=True)
    except Exception as e: issues.append(f'python_compile:{p.name}:{e}')
ck('python_sources_compile',not any(x.startswith('python_compile:') for x in issues),'all .py files')

# Manifest, when present
man=HERE/'EVIDENCE_MANIFEST_SHA256.csv'
if man.exists():
    mm=pd.read_csv(man)
    bad=[]
    for _,r in mm.iterrows():
        p=HERE/str(r.filename)
        if not p.exists() or sha256(p)!=str(r.sha256): bad.append(str(r.filename))
    ck('manifest_hashes',len(bad)==0,bad)

# Matched baryonic-only control
bm=np.load(HERE/'BARYONIC_CONTROL_ORBIT_MOMENT_MATRICES.npz',allow_pickle=False)
bfc=pd.read_csv(HERE/'BARYONIC_CONTROL_FIELD_CONSISTENCY_26.csv')
bcl=pd.read_csv(HERE/'BARYONIC_CONTROL_CLOSURE_LADDER.csv')
bsol=np.load(HERE/'BARYONIC_CONTROL_CLOSURE_SOLUTION.npz',allow_pickle=False)
bw=bsol['weights']; blp=bw@bm['L']; bvp=(bw@bm['M1'])/blp; brp=np.sqrt(np.maximum((bw@bm['M2'])/blp,0)); bpv=(bvp-bm['Vobs'])/bm['eV']; bpr=(brp-bm['Vrms'])/bm['eVrms']; blr=blp/bm['light']-1
ck('baryonic_control_field_rows',len(bfc)==26,len(bfc))
ck('baryonic_control_field_match',float(bfc.fractional_vector_mismatch.max())<1e-12,float(bfc.fractional_vector_mismatch.max()))
ck('baryonic_control_matrix_shape',bm['L'].shape==(4096,26),bm['L'].shape)
ck('baryonic_control_orbit_ids',np.array_equal(bm['orbit_ids'],np.arange(4096)),bm['orbit_ids'].shape)
ck('baryonic_control_energy_gate',int(np.sum(bm['energy_error']<=5e-4))==4096,float(np.max(bm['energy_error'])))
ck('baryonic_control_retries',int(np.sum(bm['retry']>0))==0,int(np.sum(bm['retry']>0)))
ck('baryonic_control_tau_1pct',abs(float(bsol['hard_tracer_tolerance'][0])-0.01)<1e-15,float(bsol['hard_tracer_tolerance'][0]))
ck('baryonic_control_tracer_1pct',float(np.max(np.abs(blr)))<=0.010000000001,float(np.max(np.abs(blr))))
ck('baryonic_control_vrms_pull',abs(float(np.max(np.abs(bpr)))-3.6466626571798413)<1e-10,float(np.max(np.abs(bpr))))
ck('baryonic_control_no_closing_tau',not bool(bcl.all_velocity_and_vrms_pulls_below_3.any()),float(bcl.max_abs_vrms_pull.min()))

report={'status':'PASS' if not issues else 'FAIL','checks':checks,'issues':issues}
print(report['status'])
for k,v in checks.items(): print(('PASS' if v['pass'] else 'FAIL'),k,v['detail'])
if issues: raise SystemExit(1)
