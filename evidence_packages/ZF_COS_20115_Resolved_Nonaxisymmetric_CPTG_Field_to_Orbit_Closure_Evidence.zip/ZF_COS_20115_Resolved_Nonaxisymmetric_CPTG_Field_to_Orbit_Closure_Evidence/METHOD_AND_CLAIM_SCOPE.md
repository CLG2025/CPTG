# ZF-COS-20115 Resolved Nonaxisymmetric CPTG Field-to-Orbit Closure

## Structural quantity

For each resolved bin i,

`a_star,i = (V_i^2 + sigma_i^2) / R_i = Vrms_i^2 / R_i`.

The adopted radius is

`R_i = sqrt(x_i^2 + (z_i/0.70)^2)`.

The 26 local values are retained individually. Bin 21 is retained normally.

## Local CPTG response

For each bin,

`g_pol,i = sqrt(a_star,i * g_bar,i)`

`R_c,i = 48*pi*c^2 / a_star,i`

`g_geom,i = 0.5*a_star,i*(R_i/R_c,i)^(7/5) / [1 + (R_i/R_c,i)^(12/5)]`

`Sigma_g,i = [1 + (g_i/a_star,i)^(123/50)]^(-11/50)`

`g_i = g_bar,i + (g_pol,i + g_geom,i)*Sigma_g,i`.

The vector target is

`g_target,i = (g_i / g_bar,i) * g_bar_vector,i`.

The numerical target vectors are stored in `NONAXISYMMETRIC_BARYONIC_AND_CPTG_FIELD.csv`.

## Source-mass aperture check

`CALCULATE_SOURCE_MASS_APERTURE.py` integrates the nested projected source components inside a 3 kpc semimajor-axis aperture. It gives `1.154957033043828e11 Msun`, while the full 30-component source extends to 15.574 kpc and totals `1.5703630157811557e11 Msun`. The finite-aperture value is the appropriate quantity for comparison with the published 3 kpc stellar-mass measurement cited in the manuscript.

## Conservative field realization

The base scalar potential and force are evaluated directly from the nested oblate stellar source using fixed 96-node Gauss quadrature. The nonaxisymmetric CPTG correction is a curl-free Hermite Gaussian scalar-potential expansion.

The actual potential supplied to orbit integration is the sum of those two scalar potentials. `FIELD_CONSISTENCY_26.csv` evaluates this exact orbit field at all 26 structural centers. The maximum fractional vector mismatch is below the 1e-3 gate by more than eight orders of magnitude.

`DIRECT_QUADRATURE_SPOT_CHECKS.csv` independently checks the compiled base evaluator against the vectorized source quadrature at random three-dimensional points and near nested-component edges.

The continuous field used for the orbit calculation is the supplied Hermite-kernel construction. `FIELD_INTERPOLATION_LEAVE_ONE_OUT.csv` is retained as a continuous-field sensitivity diagnostic. This archive does not assert robustness to alternate kernel scales.


## Local structural-input uncertainty

`LOCAL_STRUCTURAL_ACCELERATION_FIELD.csv` contains the linear propagated 1-sigma uncertainty of each local structural acceleration. Holding the adopted radius fixed, the fractional 1-sigma range is 0.20705 to 0.68621 with median 0.31362.

`PROPAGATE_LOCAL_INPUT_UNCERTAINTY.py` performs 200000 deterministic Monte Carlo draws per bin from the quoted Gaussian `Vrms` uncertainty, maps each draw through `a_star = Vrms^2/R`, and solves the same local implicit CPTG response with `R_i` and `g_bar,i` fixed. The resulting central 68-percent fractional half-width of `g_CPTG,i` ranges from 0.02349 to 0.19393 with median 0.07879.

This diagnostic propagates only the local measured-support uncertainty. It does not resample the source field, Hermite continuation, orbit library, or orbit weights, and it does not supply a joint covariance model for the 26 resolved bins.

## Full-galaxy Structural Mode N

Structural Mode is evaluated only after the CPTG radial field has been solved. It does not generate any local `a_star,i` and does not enter the orbit fit.

The full-galaxy radial continuation is sampled uniformly over the adopted interval from `R95/5` to `R95`, with

`R95 = 8.191131985921501 kpc`.

The reported value is calculated with the same sampled estimator used by the SPARC workbench:

`dg/dr = numpy.gradient(g, r)`

`C_g = g^2 + (kappa_struct * dg/dr)^2`, with `kappa_struct = 1 kpc`

`dC_g/dr = numpy.gradient(C_g, r)`

`w = abs(dC_g/dr)` on `r > R95/5`, followed by the five-sample moving average. The characteristic radius and mode are

`lambda = sum(r*w) / sum(w)`

`N = R95 / lambda`.

Applied to `STRUCTURAL_MODE_N_PROFILE.csv`, this gives

`lambda = 2.385686862661345 kpc`

`N = 3.433448083284456`.

The downstream CSMI mapping is `Bulged Spiral`, corresponding to `3.30 < N <= 3.55`. The CSMI name is descriptive and is not supplied to the field calculation.

A continuum total-variation calculation on the same radial solution gives `N = 3.434244640608126` and `lambda = 2.385133513514354 kpc`, differing from the sampled SPARC-equivalent value by only `7.965573236706e-04` in N. `STRUCTURAL_MODE_N_SAMPLING_CONVERGENCE.csv` records radial-sampling convergence.

The full-R95 Structural Mode is a model-continued galaxy-level structural readout; a direct resolved kinematic measurement at R95 is not claimed. The observed redshift fixes the physical coordinate/epoch but no `H(z)` or `E(z)` factor rescales `a_star`.

## Orbit integration

The orbit library contains 4096 supplied initial phase-space states. Every trajectory is integrated for 12 local periods with DOP853 using `rtol=1e-9` and `atol=1e-11`. The fractional energy qualification gate is

`max |E(t)-E(0)| / |E(0)| <= 5e-4`.

A failed trajectory may be retried at tolerances tighter by factors of ten, with a maximum of two retries. The completed library required zero retries.

Uniform observation sampling uses 4096 equally spaced times over `[0,T)`. The line of sight is the y-axis, so `v_los = v_y`, while the sky plane is `(x,z)`.

## PSF and spaxel observation operator

For each sampled phase-space point and resolved spaxel j,

`w_j = exp(-d_sky,j^2 / (2*sigma_PSF^2))`.

The Gaussian is intentionally unnormalized. Weights are summed over the exact spaxels belonging to each resolved bin and time-averaged to form per-orbit matrices:

`L`, `M1 = <w v_los>`, and `M2 = <w v_los^2>`.

The exact 141 spaxels and PSF scale are stored in `EXACT_RESOLVED_SPAXEL_SUPPORT.csv` and `OBSERVATION_GEOMETRY.json`. `MOMENT_SAMPLING_CONVERGENCE.csv` records the 2048-versus-4096 sampling comparison for 32 trajectories.

## Nonnegative orbit-weight closure

Orbit weights are constrained to be nonnegative. For each tested hard tracer tolerance, a linear minimax problem constrains tracer density and the first and second raw velocity moments. The solved model quantities are then reconstructed as

`V_model = (w @ M1) / (w @ L)`

`Vrms_model = sqrt((w @ M2) / (w @ L))`.

The tested tracer tolerances are 1%, 1.5%, 2%, 2.5%, 3%, 5%, 7.5%, and 10%. The 1% row is the first tested level and already places every marginal velocity and Vrms pull below 3 sigma. The tracer tolerance is a numerical closure tolerance, not an observational uncertainty.

`SOLVER_CROSSCHECK.json` records agreement of HiGHS, HiGHS dual-simplex, and HiGHS interior-point for the 1% solution.

A finer numerical diagnostic at tracer tolerances 0, 0.1%, 0.25%, 0.5%, 0.75%, and 1% is stored in `SUBPERCENT_TRACER_TOLERANCE_DIAGNOSTIC.csv`. CPTG first falls below the all-bin marginal 3-sigma closure criterion at the tested 0.5% row; the 0.25% row remains above it. The baryonic-only control remains above 3 sigma throughout this same diagnostic interval. These rows locate the numerical closure transition and do not redefine tracer tolerance as an observational uncertainty.

## Matched baryonic-only dynamical control

The baryonic-only control preserves the measured nonaxisymmetric stellar source field but removes the CPTG field augmentation. A separate curl-free Hermite scalar-potential correction makes the conservative baryonic-only orbit field reproduce the 26 nonaxisymmetric baryonic vectors. The maximum 26-center fractional mismatch is `5.254673552095104e-16`.

The control uses the same 4096 phase-space initial conditions, 12 local periods, 4096 uniform samples over `[0,T)`, DOP853 tolerances, energy gate, PSF, exact-spaxel observation operator, nonnegative orbit-weight solver, and tracer-tolerance ladder as the CPTG calculation. All 4096 control trajectories pass the energy gate, with maximum fractional energy error `3.412890140669127e-05` and zero retries.

At the 1% tracer tolerance, the baryonic-only maximum marginal velocity pull is `2.5336996139022028`, while the maximum marginal Vrms pull is `3.6466626571798413` at bin 11. The baryonic-only Vrms RMSE is `105.35480154193718 km/s`, its MAE is `76.55398361761478 km/s`, and 24/26 Vrms bins lie below 3 sigma. The corresponding CPTG values are maximum Vrms pull `2.8787326824138293`, RMSE `75.29988495135821 km/s`, MAE `54.964867586151186 km/s`, and 26/26 Vrms bins below 3 sigma.

The baryonic-only control does not reach all-bin 3-sigma closure anywhere on the tested 1%-10% tracer-tolerance ladder. Its smallest listed maximum Vrms pull is `3.072135674588437` at 10%. This is a matched conditional-compatibility control; it is not an out-of-sample prediction.

## Statistical and evidentiary scope

The reported kinematic closure is based on marginal per-bin pulls. It is not a joint covariance goodness-of-fit statistic.

The structural accelerations and orbit weights both use the resolved kinematic measurements. The result is therefore a conditional compatibility / stationary-existence closure in the constructed CPTG field, not an out-of-sample prediction of those same measurements.

The package starts from processed resolved kinematics and exact resolved spaxel support. Raw spectral-extraction data are outside the package scope.
