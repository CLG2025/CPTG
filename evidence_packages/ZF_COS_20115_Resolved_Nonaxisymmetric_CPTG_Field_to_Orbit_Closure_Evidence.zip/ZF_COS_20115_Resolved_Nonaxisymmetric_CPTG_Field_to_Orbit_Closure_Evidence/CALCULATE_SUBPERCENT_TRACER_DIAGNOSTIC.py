#!/usr/bin/env python3
from pathlib import Path
import json
import numpy as np
import pandas as pd
from scipy.optimize import linprog

HERE=Path(__file__).resolve().parent
TAUS=[0.0,0.001,0.0025,0.005,0.0075,0.01]

def solve_tau(d,tau):
    L=d['L']; M1=d['M1']; M2=d['M2']; light=d['light']; V=d['Vobs']; Vr=d['Vrms']; eV=d['eV']; eVr=d['eVrms']
    n=L.shape[0]
    c=np.r_[np.zeros(n),1.0]
    A=[]; b=[]
    for i in range(26):
        A.append(np.r_[ L[:,i],0.0]); b.append((1+tau)*light[i])
        A.append(np.r_[-L[:,i],0.0]); b.append(-(1-tau)*light[i])
        s1=light[i]*eV[i]; y1=light[i]*V[i]
        row1=M1[:,i]/s1
        A.append(np.r_[ row1,-1.0]); b.append(y1/s1)
        A.append(np.r_[-row1,-1.0]); b.append(-y1/s1)
        s2=light[i]*2*Vr[i]*eVr[i]; y2=light[i]*Vr[i]**2
        row2=M2[:,i]/s2
        A.append(np.r_[ row2,-1.0]); b.append(y2/s2)
        A.append(np.r_[-row2,-1.0]); b.append(-y2/s2)
    res=linprog(c,A_ub=np.asarray(A),b_ub=np.asarray(b),bounds=[(0,None)]*n+[(0,None)],method='highs')
    if not res.success:
        return {'solver_status':res.message}
    w=res.x[:-1]
    lp=w@L
    vp=(w@M1)/lp
    rp=np.sqrt(np.maximum((w@M2)/lp,0))
    pv=(vp-V)/eV
    pr=(rp-Vr)/eVr
    lr=lp/light-1
    return {
        'solver_status':'PASS',
        'minimax_raw_moment_t':float(res.x[-1]),
        'max_abs_tracer_fractional_residual':float(np.max(np.abs(lr))),
        'max_abs_velocity_pull':float(np.max(np.abs(pv))),
        'max_abs_velocity_pull_bin':int(np.argmax(np.abs(pv))),
        'max_abs_vrms_pull':float(np.max(np.abs(pr))),
        'max_abs_vrms_pull_bin':int(np.argmax(np.abs(pr))),
        'all_velocity_and_vrms_pulls_below_3':bool(np.max(np.abs(pv))<3 and np.max(np.abs(pr))<3),
        'active_orbits_gt_1e-10':int(np.sum(w>1e-10)),
    }

def main():
    cptg=np.load(HERE/'ORBIT_LIBRARY_MOMENT_MATRICES.npz',allow_pickle=False)
    bar=np.load(HERE/'BARYONIC_CONTROL_ORBIT_MOMENT_MATRICES.npz',allow_pickle=False)
    rows=[]
    for tau in TAUS:
        for label,d in [('CPTG',cptg),('baryonic_only',bar)]:
            x=solve_tau(d,tau)
            x={'model':label,'tracer_tolerance_fraction':tau,**x}
            rows.append(x)
    out=pd.DataFrame(rows)
    out.to_csv(HERE/'SUBPERCENT_TRACER_TOLERANCE_DIAGNOSTIC.csv',index=False)
    cs=out[(out.model=='CPTG') & (out.solver_status=='PASS')]
    crossing=cs[cs.all_velocity_and_vrms_pulls_below_3]
    first=float(crossing.tracer_tolerance_fraction.min()) if len(crossing) else None
    prev=None
    if first is not None:
        smaller=cs[cs.tracer_tolerance_fraction<first]
        prev=float(smaller.tracer_tolerance_fraction.max()) if len(smaller) else None
    summary={
        'tested_tolerances_fraction':TAUS,
        'first_tested_CPTG_tolerance_with_all_marginal_pulls_below_3':first,
        'largest_tested_lower_tolerance_without_all_marginal_pulls_below_3':prev,
        'interpretation':'diagnostic refinement below the publication ladder; tracer tolerance is numerical closure tolerance, not observational uncertainty'
    }
    (HERE/'SUBPERCENT_TRACER_TOLERANCE_SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(out.to_string(index=False))
    print(json.dumps(summary,indent=2))
if __name__=='__main__': main()
