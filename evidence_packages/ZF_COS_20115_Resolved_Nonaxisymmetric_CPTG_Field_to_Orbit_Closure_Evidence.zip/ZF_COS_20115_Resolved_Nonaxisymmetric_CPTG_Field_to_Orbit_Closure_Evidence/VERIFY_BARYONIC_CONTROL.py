#!/usr/bin/env python3
from pathlib import Path
import json, numpy as np, pandas as pd
HERE=Path(__file__).resolve().parent
issues=[]
def ck(name,cond,detail):
    print(('PASS' if cond else 'FAIL'),name,detail)
    if not cond: issues.append(name)
fc=pd.read_csv(HERE/'BARYONIC_CONTROL_FIELD_CONSISTENCY_26.csv')
ck('field_rows',len(fc)==26,len(fc))
ck('field_match',float(fc.fractional_vector_mismatch.max())<1e-12,float(fc.fractional_vector_mismatch.max()))
m=np.load(HERE/'BARYONIC_CONTROL_ORBIT_MOMENT_MATRICES.npz',allow_pickle=False)
ck('orbit_ids',np.array_equal(m['orbit_ids'].astype(int),np.arange(4096)),len(m['orbit_ids']))
ck('integration_periods',float(m['integration_periods'][0])==12.0,float(m['integration_periods'][0]))
ck('uniform_samples',int(m['uniform_samples'][0])==4096,int(m['uniform_samples'][0]))
ck('energy_gate',float(np.max(m['energy_error']))<=5e-4,float(np.max(m['energy_error'])))
ck('retries',int(np.sum(m['retry']>0))==0,int(np.sum(m['retry']>0)))
sol=np.load(HERE/'BARYONIC_CONTROL_CLOSURE_SOLUTION.npz',allow_pickle=False)
w=sol['weights']; lp=w@m['L']; v=(w@m['M1'])/lp; vr=np.sqrt(np.maximum((w@m['M2'])/lp,0)); pv=(v-m['Vobs'])/m['eV']; pr=(vr-m['Vrms'])/m['eVrms']; lr=lp/m['light']-1
ck('primary_tau',abs(float(sol['hard_tracer_tolerance'][0])-0.01)<1e-15,float(sol['hard_tracer_tolerance'][0]))
ck('tracer_1pct',float(np.max(np.abs(lr)))<=0.010000000001,float(np.max(np.abs(lr))))
ck('velocity_pull',abs(float(np.max(np.abs(pv)))-2.5336996139022028)<1e-10,float(np.max(np.abs(pv))))
ck('vrms_pull',abs(float(np.max(np.abs(pr)))-3.6466626571798413)<1e-10,float(np.max(np.abs(pr))))
lad=pd.read_csv(HERE/'BARYONIC_CONTROL_CLOSURE_LADDER.csv')
ck('ladder_rows',len(lad)==8,len(lad))
ck('no_all_bin_3sigma_closure',not bool(lad.all_velocity_and_vrms_pulls_below_3.any()),lad.max_abs_vrms_pull.min())
print('PASS' if not issues else 'FAIL')
if issues: raise SystemExit(1)
