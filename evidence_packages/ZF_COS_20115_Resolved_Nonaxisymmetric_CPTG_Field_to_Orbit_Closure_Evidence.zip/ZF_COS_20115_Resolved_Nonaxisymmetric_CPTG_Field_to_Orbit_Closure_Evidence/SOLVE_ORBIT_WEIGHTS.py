#!/usr/bin/env python3
from pathlib import Path
import json
import numpy as np
import pandas as pd
from scipy.optimize import linprog

HERE=Path(__file__).resolve().parent
MATRIX=HERE/'ORBIT_LIBRARY_MOMENT_MATRICES.npz'
TAUS=[0.01,0.015,0.02,0.025,0.03,0.05,0.075,0.10]

def solve_tau(L,M1,M2,light,V,Vr,eV,eVr,tau):
    n=L.shape[0]
    c=np.r_[np.zeros(n),1.0]
    A=[]; b=[]
    for i in range(26):
        A.append(np.r_[ L[:,i],0.0]); b.append((1+tau)*light[i])
        A.append(np.r_[-L[:,i],0.0]); b.append(-(1-tau)*light[i])
        s1=light[i]*eV[i]; y1=light[i]*V[i]
        row1=M1[:,i]/s1
        A.append(np.r_[ row1,-1.0]); b.append(y1/s1)
        A.append(np.r_[-row1,-1.0]); b.append(-y1/s1)
        s2=light[i]*2*Vr[i]*eVr[i]; y2=light[i]*Vr[i]**2
        row2=M2[:,i]/s2
        A.append(np.r_[ row2,-1.0]); b.append(y2/s2)
        A.append(np.r_[-row2,-1.0]); b.append(-y2/s2)
    res=linprog(c,A_ub=np.asarray(A),b_ub=np.asarray(b),bounds=[(0,None)]*n+[(0,None)],method='highs')
    if not res.success:
        return None,res.message
    w=res.x[:-1]; lp=w@L
    vp=(w@M1)/lp; rp=np.sqrt(np.maximum((w@M2)/lp,0))
    pv=(vp-V)/eV; pr=(rp-Vr)/eVr; lr=lp/light-1
    out=dict(weights=w,pred_light=lp,model_V=vp,model_Vrms=rp,V_pull=pv,Vrms_pull=pr,light_resid=lr,t=float(res.x[-1]))
    return out,'PASS'

def main():
    d=np.load(MATRIX,allow_pickle=False)
    ids=np.asarray(d['orbit_ids'],int)
    if len(ids)!=4096 or np.any(ids!=np.arange(4096)):
        raise SystemExit('orbit matrix file is not the complete ordered 4096-orbit library')
    if float(np.max(d['energy_error']))>5e-4:
        raise SystemExit('energy gate failed')
    L=d['L']; M1=d['M1']; M2=d['M2']; light=d['light']; V=d['Vobs']; Vr=d['Vrms']; eV=d['eV']; eVr=d['eVrms']
    rows=[]; solutions={}
    for tau in TAUS:
        sol,msg=solve_tau(L,M1,M2,light,V,Vr,eV,eVr,tau)
        if sol is None:
            rows.append(dict(hard_tracer_tolerance_fraction=tau,solver_status=msg,all_velocity_and_vrms_pulls_below_3=False))
            continue
        solutions[tau]=sol
        rows.append(dict(
          hard_tracer_tolerance_fraction=tau,solver_status='PASS',minimax_raw_moment_t=sol['t'],
          max_abs_tracer_fractional_residual=float(np.max(np.abs(sol['light_resid']))),
          max_abs_velocity_pull=float(np.max(np.abs(sol['V_pull']))),max_abs_velocity_pull_bin=int(np.argmax(np.abs(sol['V_pull']))),
          max_abs_vrms_pull=float(np.max(np.abs(sol['Vrms_pull']))),max_abs_vrms_pull_bin=int(np.argmax(np.abs(sol['Vrms_pull']))),
          bin21_velocity_pull=float(sol['V_pull'][21]),bin21_vrms_pull=float(sol['Vrms_pull'][21]),
          active_orbits=int(np.sum(sol['weights']>1e-10)),
          all_velocity_and_vrms_pulls_below_3=bool(np.max(np.abs(sol['V_pull']))<3 and np.max(np.abs(sol['Vrms_pull']))<3)))
    ladder=pd.DataFrame(rows)
    ladder.to_csv(HERE/'TRACER_TOLERANCE_CLOSURE_LADDER.csv',index=False)
    passing=[tau for tau in TAUS if tau in solutions and np.max(np.abs(solutions[tau]['V_pull']))<3 and np.max(np.abs(solutions[tau]['Vrms_pull']))<3]
    if not passing:
        print(ladder.to_string(index=False)); raise SystemExit('NO LISTED TRACER TOLERANCE CLOSES')
    tau=passing[0]; sol=solutions[tau]
    np.savez_compressed(HERE/'CLOSURE_SOLUTION.npz',weights=sol['weights'],model_light=sol['pred_light'],model_V=sol['model_V'],model_Vrms=sol['model_Vrms'],V_pull=sol['V_pull'],Vrms_pull=sol['Vrms_pull'],light_resid=sol['light_resid'],hard_tracer_tolerance=np.array([tau]),minimax_raw_moment_t=np.array([sol['t']]))
    main=pd.read_csv(HERE/'OBSERVATION_TARGETS.csv').sort_values('bin_id')
    out=pd.DataFrame({
      'bin_id':main.bin_id.astype(int),'observed_velocity_km_s':V,'velocity_1sigma_km_s':eV,'model_velocity_km_s':sol['model_V'],'velocity_pull':sol['V_pull'],
      'observed_vrms_km_s':Vr,'vrms_1sigma_km_s':eVr,'model_vrms_km_s':sol['model_Vrms'],'vrms_pull':sol['Vrms_pull'],
      'target_tracer_fraction':light,'model_tracer_fraction':sol['pred_light'],'tracer_fractional_residual':sol['light_resid']})
    out.to_csv(HERE/'RESOLVED_BIN_OBSERVATIONS_AND_MODEL_CLOSURE.csv',index=False)
    orbits=pd.read_csv(HERE/'ORBIT_LIBRARY_INITIAL_CONDITIONS_AND_WEIGHTS.csv')
    orbits['maximum_fractional_energy_error']=d['energy_error']; orbits['maximum_radius_kpc']=d['rmax']; orbits['integration_retry_flag']=d['retry']; orbits['orbit_weight']=sol['weights']
    orbits.to_csv(HERE/'ORBIT_LIBRARY_INITIAL_CONDITIONS_AND_WEIGHTS.csv',index=False)
    orbits.loc[sol['weights']>1e-10].to_csv(HERE/'ACTIVE_ORBIT_WEIGHTS.csv',index=False)
    summary={
      'field_gate':'PASS','trajectories':4096,'energy_qualified':int(np.sum(d['energy_error']<=5e-4)),'maximum_fractional_energy_error':float(np.max(d['energy_error'])),
      'integration_retries':int(np.sum(d['retry']>0)),'maximum_orbit_radius_kpc':float(np.max(d['rmax'])),
      'first_listed_closing_tracer_tolerance':tau,'maximum_abs_velocity_pull':float(np.max(np.abs(sol['V_pull']))),'maximum_abs_velocity_pull_bin':int(np.argmax(np.abs(sol['V_pull']))),
      'maximum_abs_vrms_pull':float(np.max(np.abs(sol['Vrms_pull']))),'maximum_abs_vrms_pull_bin':int(np.argmax(np.abs(sol['Vrms_pull']))),
      'maximum_abs_tracer_fractional_residual':float(np.max(np.abs(sol['light_resid']))),'active_orbits_gt_1e-10':int(np.sum(sol['weights']>1e-10)),
      'bin21_velocity_pull':float(sol['V_pull'][21]),'bin21_vrms_pull':float(sol['Vrms_pull'][21])}
    (HERE/'CLOSURE_SUMMARY.json').write_text(json.dumps(summary,indent=2))
    print(ladder.to_string(index=False))
    print('FIRST_CLOSING_TAU',tau)
    print(json.dumps(summary,indent=2))
if __name__=='__main__': main()
