#!/usr/bin/env python3
"""Recalculate the publication Structural Mode N from the packaged full-R95 CPTG profile.

The primary path reproduces the registered SPARC workbench estimator exactly:
  1. sort the radial CPTG field by radius;
  2. dg/dr = numpy.gradient(g, r);
  3. C_g = g^2 + (kappa_struct dg/dr)^2, kappa_struct = 1 kpc;
  4. dC_g/dr = numpy.gradient(C_g, r);
  5. retain r > R/5;
  6. smooth |dC_g/dr| with the five-sample moving average used by the workbench;
  7. lambda = sum(r w)/sum(w), N = R/lambda.

A continuum total-variation centroid is also reported as a numerical cross-check.
"""
from pathlib import Path
import json
import numpy as np
import pandas as pd

HERE=Path(__file__).resolve().parent
KPC_M=3.0856775814913673e19
KAPPA_STRUCT=KPC_M
EPS=np.finfo(float).tiny


def estimate_structure_scale_and_mode(r_m,g_field,kappa=KAPPA_STRUCT):
    r_m=np.asarray(r_m,dtype=float)
    g_field=np.asarray(g_field,dtype=float)
    order=np.argsort(r_m)
    r_sorted=r_m[order]
    g_sorted=np.maximum(g_field[order],EPS)
    dg=np.gradient(g_sorted,r_sorted)
    C=g_sorted**2+(kappa*dg)**2
    dC=np.gradient(C,r_sorted)
    finite=np.isfinite(r_sorted)&np.isfinite(dC)&(r_sorted>0)
    R_m=float(np.max(r_sorted))
    mask_outer=(r_sorted>R_m/5.0)&finite
    r_outer=r_sorted[mask_outer]
    w=np.abs(dC[mask_outer])
    if len(w)>5:
        w=np.convolve(w,np.ones(5)/5.0,mode='same')
    if not np.isfinite(w).all() or float(np.sum(w))<=0:
        raise RuntimeError('invalid structural weights')
    lambda_m=float(np.sum(r_outer*w)/np.sum(w))
    return R_m/KPC_M,lambda_m/KPC_M,float(R_m/lambda_m)


def classify(N):
    thresholds=[
        (1.45,'Dwarf Irregular'),(1.75,'Magellanic Irregular'),
        (1.95,'LSB Dwarf Disk'),(2.15,'Transition Dwarf'),
        (2.35,'LSB Spiral'),(2.55,'Very Late Spiral'),
        (2.80,'Late Spiral'),(3.05,'Intermediate Spiral'),
        (3.30,'Early Spiral'),(3.55,'Bulged Spiral'),
        (3.72,'Lenticular/Early Disk'),(float('inf'),'High-Mode Outlier')]
    for upper,label in thresholds:
        if N<=upper: return label
    raise RuntimeError('unclassifiable N')


def main():
    d=pd.read_csv(HERE/'STRUCTURAL_MODE_N_PROFILE.csv')
    R,lam,N=estimate_structure_scale_and_mode(
        d.radius_kpc.to_numpy()*KPC_M,d.gCPTG_m_s2.to_numpy())
    r=d.radius_kpc.to_numpy(float); C=d.C_g.to_numpy(float)
    mid=0.5*(r[:-1]+r[1:]); w=np.abs(np.diff(C))
    lam_tv=float(np.sum(mid*w)/np.sum(w)); N_tv=float(R/lam_tv)
    result={
        'R95_kpc':R,'lambda_kpc':lam,'N':N,'CSMI_label':classify(N),
        'continuum_lambda_kpc':lam_tv,'continuum_N':N_tv,
        'absolute_delta_N':abs(N_tv-N)}
    print(json.dumps(result,indent=2))

if __name__=='__main__':
    main()
