#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import argparse, json, os, platform, sys, time
from concurrent.futures import ProcessPoolExecutor, as_completed
import numpy as np
import pandas as pd
from scipy.integrate import solve_ivp

HERE=Path(__file__).resolve().parent
PERIODS=12.0
SAMPLES=4096
RTOL=1e-9
ATOL=1e-11
ENERGY_GATE=5e-4

_ORBITS=None; _SPXY=None; _SPBIN=None; _SIGMA=None; _PE=None

def _worker_init():
    global _ORBITS,_SPXY,_SPBIN,_SIGMA,_PE
    import POTENTIAL_EVALUATOR_BARYONIC_CONTROL as pe
    _PE=pe
    _PE.potential_and_acceleration(0.5,0.0,0.2)
    _ORBITS=pd.read_csv(HERE/'ORBIT_LIBRARY_INITIAL_CONDITIONS_AND_WEIGHTS.csv')
    sp=pd.read_csv(HERE/'EXACT_RESOLVED_SPAXEL_SUPPORT.csv')
    _SPXY=sp[['major_kpc','minor_kpc']].to_numpy(float)
    _SPBIN=sp['bin_id'].to_numpy(int)
    geom=json.loads((HERE/'OBSERVATION_GEOMETRY.json').read_text())
    _SIGMA=float(geom['psf_sigma_kpc'])

def _integrate_one(oid:int):
    r=_ORBITS.iloc[int(oid)]
    s0=np.array([r.x0_kpc,r.y0_kpc,r.z0_kpc,r.vx0_km_s,r.vy0_km_s,r.vz0_km_s],float)
    period=float(r.local_period_kpc_per_km_s)
    T=PERIODS*period
    def rhs(t,s):
        _,g=_PE.potential_and_acceleration(s[0],s[1],s[2])
        return np.array([s[3],s[4],s[5],g[0],g[1],g[2]],float)
    def energy_state(s):
        p,_=_PE.potential_and_acceleration(s[0],s[1],s[2])
        return 0.5*(s[3]*s[3]+s[4]*s[4]+s[5]*s[5])+p
    retry=0; rtol=RTOL; atol=ATOL
    while True:
        sol=solve_ivp(rhs,(0.0,T),s0,method='DOP853',rtol=rtol,atol=atol,dense_output=True)
        if not sol.success:
            emax=np.inf
        else:
            E0=energy_state(s0)
            ev=np.array([energy_state(sol.y[:,j]) for j in range(sol.y.shape[1])])
            emax=float(np.max(np.abs(ev-E0))/max(abs(E0),1e-300))
        if sol.success and emax<=ENERGY_GATE:
            break
        retry+=1
        if retry>2:
            raise RuntimeError(f'orbit {oid} failed energy gate: success={sol.success} emax={emax}')
        rtol*=0.1; atol*=0.1
    tt=np.arange(SAMPLES,dtype=float)*(T/SAMPLES)
    y=sol.sol(tt)
    x=y[0]; z=y[2]; vlos=y[4]
    dx=x[:,None]-_SPXY[None,:,0]
    dz=z[:,None]-_SPXY[None,:,1]
    w=np.exp(-(dx*dx+dz*dz)/(2.0*_SIGMA*_SIGMA))
    L=np.empty(26,float); M1=np.empty(26,float); M2=np.empty(26,float)
    for b in range(26):
        wb=w[:,_SPBIN==b].sum(axis=1)
        L[b]=float(np.mean(wb))
        M1[b]=float(np.mean(wb*vlos))
        M2[b]=float(np.mean(wb*vlos*vlos))
    rr0=np.sqrt(np.sum(sol.y[:3]*sol.y[:3],axis=0))
    rrs=np.sqrt(np.sum(y[:3]*y[:3],axis=0))
    rmax=float(max(np.max(rr0),np.max(rrs)))
    return int(oid),L,M1,M2,emax,rmax,retry,int(sol.nfev),int(sol.y.shape[1])

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--start',type=int,default=0)
    ap.add_argument('--count',type=int,default=4096)
    ap.add_argument('--workers',type=int,default=max(1,(os.cpu_count() or 2)-1))
    ap.add_argument('--output',default='BARYONIC_CONTROL_ORBIT_MOMENT_MATRICES_REGENERATED.npz')
    ap.add_argument('--progress-every',type=int,default=64)
    args=ap.parse_args()
    obs=pd.read_csv(HERE/'OBSERVATION_TARGETS.csv').sort_values('bin_id')
    sp=pd.read_csv(HERE/'EXACT_RESOLVED_SPAXEL_SUPPORT.csv')
    geom=json.loads((HERE/'OBSERVATION_GEOMETRY.json').read_text())
    corr=np.load(HERE/'BARYONIC_CONTROL_CORRECTION_DATA.npz',allow_pickle=False)
    ic=pd.read_csv(HERE/'ORBIT_LIBRARY_INITIAL_CONDITIONS_AND_WEIGHTS.csv')
    n_total=len(ic); start=max(0,args.start); stop=min(n_total,start+args.count); ids=list(range(start,stop)); n=len(ids)
    L=np.full((n,26),np.nan); M1=np.full((n,26),np.nan); M2=np.full((n,26),np.nan)
    ee=np.full(n,np.nan); rmax=np.full(n,np.nan); retry=np.full(n,-1,int); nfev=np.full(n,-1,int); nsteps=np.full(n,-1,int)
    t0=time.time(); done=0
    with ProcessPoolExecutor(max_workers=args.workers,initializer=_worker_init) as ex:
        futs={ex.submit(_integrate_one,oid):oid for oid in ids}
        for fut in as_completed(futs):
            oid,l,a,b,e,rm,re,nf,ns=fut.result(); j=oid-start
            L[j]=l; M1[j]=a; M2[j]=b; ee[j]=e; rmax[j]=rm; retry[j]=re; nfev[j]=nf; nsteps[j]=ns
            done+=1
            if done%args.progress_every==0 or done==n:
                print(f'PROGRESS {done}/{n} elapsed_s={time.time()-t0:.3f} max_energy={np.nanmax(ee):.6e}',flush=True)
    out=HERE/args.output
    np.savez_compressed(out,
        orbit_ids=np.asarray(ids,int),L=L,M1=M1,M2=M2,
        light=obs.target_tracer_fraction.to_numpy(float),Vobs=obs.observed_velocity_km_s.to_numpy(float),Vrms=obs.observed_vrms_km_s.to_numpy(float),
        eV=obs.velocity_1sigma_km_s.to_numpy(float),eVrms=obs.vrms_1sigma_km_s.to_numpy(float),
        energy_error=ee,rmax=rmax,retry=retry,nfev=nfev,nsteps=nsteps,
        initial_position=ic[['x0_kpc','y0_kpc','z0_kpc']].to_numpy(float)[start:stop],
        initial_velocity=ic[['vx0_km_s','vy0_km_s','vz0_km_s']].to_numpy(float)[start:stop],period=ic.local_period_kpc_per_km_s.to_numpy(float)[start:stop],
        spaxel_xy=sp[['major_kpc','minor_kpc']].to_numpy(float),spaxel_bin=sp.bin_id.to_numpy(int),sigma_psf=np.array(float(geom['psf_sigma_kpc'])),
        local_kernel_widths_kpc=corr['local_kernel_widths_kpc'],hermite_coefficients=corr['coefficients_major_minor'],
        integration_periods=np.array([PERIODS]),uniform_samples=np.array([SAMPLES]),rtol=np.array([RTOL]),atol=np.array([ATOL]),energy_gate=np.array([ENERGY_GATE]),
        line_of_sight_velocity_component=np.array(['vy']),sample_endpoint_included=np.array([False]))
    meta={
      'potential':'direct 96-node nested-oblate source quadrature plus curl-free Hermite correction matched to the nonaxisymmetric baryonic source field',
      'integration_method':'DOP853','integration_periods':PERIODS,'uniform_time_samples':SAMPLES,'endpoint_included':False,
      'rtol':RTOL,'atol':ATOL,'energy_gate':ENERGY_GATE,
      'projection':'sky=(x,z), line_of_sight=y, v_los=vy',
      'spaxel_operator':'exp(-d_sky^2/(2 sigma_psf^2)), unnormalized; summed over exact spaxels by bin and time-averaged',
      'python':sys.version,'platform':platform.platform(),'numpy':np.__version__,'pandas':pd.__version__}
    import scipy; meta['scipy']=scipy.__version__
    try:
        import numba; meta['numba']=numba.__version__
    except Exception: pass
    out.with_suffix('.json').write_text(json.dumps(meta,indent=2)+'\n')
    print('WROTE',out); print('WROTE',out.with_suffix('.json'))
    print('MAX_ENERGY',float(np.max(ee))); print('RETRIES',int(np.sum(retry>0))); print('MAX_R',float(np.max(rmax)))
if __name__=='__main__': main()
