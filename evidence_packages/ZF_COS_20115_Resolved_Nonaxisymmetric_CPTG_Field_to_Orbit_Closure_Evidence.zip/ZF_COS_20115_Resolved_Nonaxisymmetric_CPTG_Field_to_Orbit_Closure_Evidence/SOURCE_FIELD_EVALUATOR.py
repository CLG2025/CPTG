#!/usr/bin/env python3
from pathlib import Path
import json, math
import numpy as np
import pandas as pd
from numpy.polynomial.legendre import leggauss

HERE=Path(__file__).resolve().parent
G=4.300917270036279e-6

components=pd.read_csv(HERE/"AXISYMMETRIC_SOURCE_COMPONENTS.csv")
params=json.loads((HERE/"SOURCE_MODEL_PARAMETERS.json").read_text())
qproj=float(params["projected_axis_ratio"])
qintr=float(params["intrinsic_axis_ratio"])
A=float(params["primary_amplitude"])
Rnode=float(params["primary_radial_node_kpc"])
phi=math.radians(float(params["primary_phase_elliptical_deg"]))
eps=float(params["field_regularization_kpc"])

class NestedOblateSource:
    def __init__(self):
        self.r=components.outer_radius_kpc.to_numpy(float)
        self.c=components.surface_density_increment_Msun_kpc2.to_numpy(float)
        self.qp=qproj
        self.q=qintr
        self.fac=(self.qp/self.q)/math.pi

    def _u_edge(self,R,z,rb):
        R=np.asarray(R,float); z=np.asarray(z,float)
        m0=np.sqrt(R*R+z*z/(self.q*self.q))
        inside=m0<=rb
        aa=rb*rb
        bb=rb*rb*(1+self.q*self.q)-(R*R+z*z)
        cc=rb*rb*self.q*self.q-(R*R*self.q*self.q+z*z)
        disc=np.maximum(bb*bb-4*aa*cc,0.0)
        root=(-bb+np.sqrt(disc))/(2*aa)
        return np.where(inside,0.0,root)

    def axisymmetric_field(self,points,nodes=96):
        points=np.asarray(points,float)
        R=points[:,0]; z=points[:,1]
        gr=np.zeros(len(points)); gz=np.zeros(len(points)); pot=np.zeros(len(points))
        x,w=leggauss(int(nodes))
        s=(x+1)/2; wg=w/2
        t=s/(1-s); t2=t*t; jac=2*s/(1-s)**3
        for rb,cc in zip(self.r,self.c):
            if cc<=0: continue
            amp=self.fac*cc
            u0=self._u_edge(R,z,rb)
            u=u0[:,None]+t2[None,:]
            m=np.sqrt(R[:,None]**2/(1+u)+z[:,None]**2/(self.q*self.q+u))
            d=np.maximum(rb*rb-m*m,0)
            rho=amp/np.sqrt(np.maximum(d,1e-300))
            h=2*amp*np.sqrt(d)
            root=np.sqrt(self.q*self.q+u)
            base=wg[None,:]*jac[None,:]
            gr += 2*math.pi*G*self.q*R*np.sum(rho*base/((1+u)**2*root),axis=1)
            gz += 2*math.pi*G*self.q*z*np.sum(rho*base/((1+u)*(self.q*self.q+u)**1.5),axis=1)
            pot += -math.pi*G*self.q*np.sum(h*base/((1+u)*root),axis=1)
        return np.column_stack([gr,gz,pot])

def build_nonaxisymmetric_nodes(nt=38,nmu=48,nphi=128):
    xt,wt=leggauss(nt)
    t=(xt+1)*math.pi/4
    wt=wt*math.pi/4
    mu,wmu=leggauss(nmu)
    ph=np.arange(nphi)*2*math.pi/nphi
    wph=2*math.pi/nphi
    xs=[]; ys=[]; zs=[]; dms=[]
    fac=(qproj/qintr)/math.pi
    for _,row in components.iterrows():
        rb=float(row.outer_radius_kpc)
        cc=float(row.surface_density_increment_Msun_kpc2)
        if cc<=0: continue
        amp=fac*cc
        T,MU,PH=np.meshgrid(t,mu,ph,indexing="ij")
        m=rb*np.sin(T)
        st=np.sqrt(1-MU*MU)
        x=m*st*np.cos(PH)
        y=m*st*np.sin(PH)
        z=qintr*m*MU
        base=qintr*amp*m*m*wt[:,None,None]*wmu[None,:,None]*wph
        sproj=np.sqrt(x*x+(z/qintr)**2)
        theta=np.arctan2(z/qintr,x)
        delta=A*(1-sproj/Rnode)*np.cos(theta-phi)
        xs.append(x.ravel()); ys.append(y.ravel()); zs.append(z.ravel())
        dms.append((base*delta).ravel())
    return np.concatenate(xs),np.concatenate(ys),np.concatenate(zs),np.concatenate(dms)

def perturbation_field(nodes,point):
    x,y,z,dm=nodes
    p=np.asarray(point,float)
    dx=x-p[0]; dy=y-p[1]; dz=z-p[2]
    r2=dx*dx+dy*dy+dz*dz+eps*eps
    inv=1/np.sqrt(r2)
    fac=G*dm*inv/r2
    g=np.array([np.sum(fac*dx),np.sum(fac*dy),np.sum(fac*dz)])
    pot=-G*np.sum(dm*inv)
    return g,pot

if __name__=="__main__":
    print("source_components",len(components))
    print("component_mass_sum_msun",components.projected_component_mass_Msun.sum())
