#!/usr/bin/env python3
from pathlib import Path
import json, math
import numpy as np
import pandas as pd
from numpy.polynomial.legendre import leggauss
from numba import njit

HERE=Path(__file__).resolve().parent
G=4.300917270036279e-6
NODES=96
components=pd.read_csv(HERE/'AXISYMMETRIC_SOURCE_COMPONENTS.csv')
params=json.loads((HERE/'SOURCE_MODEL_PARAMETERS.json').read_text())
qproj=float(params['projected_axis_ratio'])
qintr=float(params['intrinsic_axis_ratio'])

_r=components.outer_radius_kpc.to_numpy(np.float64)
_c=components.surface_density_increment_Msun_kpc2.to_numpy(np.float64)
_fac=(qproj/qintr)/math.pi
_amp=_fac*_c
x,w=leggauss(NODES)
s=(x+1.0)/2.0
wg=w/2.0
t=s/(1.0-s)
_t2=(t*t).astype(np.float64)
_base=(wg*(2.0*s/(1.0-s)**3)).astype(np.float64)

corr=np.load(HERE/'CURL_FREE_CORRECTION_DATA.npz')
_centers=np.ascontiguousarray(corr['centers_major_minor_kpc'],dtype=np.float64)
_widths=np.ascontiguousarray(corr['local_kernel_widths_kpc'],dtype=np.float64)
_coeff=np.ascontiguousarray(corr['coefficients_major_minor'],dtype=np.float64)

@njit(cache=True)
def _axisymmetric_direct(x,y,z,radii,amps,t2,base,q):
    R=math.sqrt(x*x+y*y)
    q2=q*q
    gr=0.0
    gzder=0.0
    pot=0.0
    m0=math.sqrt(R*R+z*z/q2)
    for k in range(radii.shape[0]):
        amp=amps[k]
        if amp<=0.0:
            continue
        rb=radii[k]
        if m0<=rb:
            u0=0.0
        else:
            aa=rb*rb
            bb=rb*rb*(1.0+q2)-(R*R+z*z)
            cc=rb*rb*q2-(R*R*q2+z*z)
            disc=bb*bb-4.0*aa*cc
            if disc<0.0:
                disc=0.0
            u0=(-bb+math.sqrt(disc))/(2.0*aa)
        rb2=rb*rb
        for j in range(t2.shape[0]):
            u=u0+t2[j]
            one=1.0+u
            qu=q2+u
            m2=R*R/one+z*z/qu
            d=rb2-m2
            if d<0.0:
                d=0.0
            sd=math.sqrt(d)
            if sd==0.0:
                continue
            rho=amp/sd
            h=2.0*amp*sd
            rt=math.sqrt(qu)
            b=base[j]
            gr += 2.0*math.pi*G*q*R*rho*b/(one*one*rt)
            gzder += 2.0*math.pi*G*q*z*rho*b/(one*qu*rt)
            pot += -math.pi*G*q*h*b/(one*rt)
    if R>0.0:
        gx=-gr*x/R
        gy=-gr*y/R
    else:
        gx=0.0
        gy=0.0
    gz=-gzder
    return pot,gx,gy,gz

@njit(cache=True)
def _correction(x,y,z,centers,widths,coeff):
    phi=0.0; gx=0.0; gy=0.0; gz=0.0
    for i in range(centers.shape[0]):
        dx=x-centers[i,0]
        dy=y
        dz=z-centers[i,1]
        h=widths[i]
        cx=coeff[i,0]
        cz=coeff[i,1]
        h2=h*h
        r2=dx*dx+dy*dy+dz*dz
        e=math.exp(-r2/(2.0*h2))
        dc=dx*cx+dz*cz
        phi += -(dc/h2)*e
        h4=h2*h2
        gx += e*(cx/h2-dx*dc/h4)
        gy += e*(      -dy*dc/h4)
        gz += e*(cz/h2-dz*dc/h4)
    return phi,gx,gy,gz

@njit(cache=True)
def _combined(x,y,z,radii,amps,t2,base,q,centers,widths,coeff):
    p0,gx0,gy0,gz0=_axisymmetric_direct(x,y,z,radii,amps,t2,base,q)
    pc,gxc,gyc,gzc=_correction(x,y,z,centers,widths,coeff)
    return p0+pc,gx0+gxc,gy0+gyc,gz0+gzc

def potential_and_acceleration(x,y,z):
    p,gx,gy,gz=_combined(float(x),float(y),float(z),_r,_amp,_t2,_base,qintr,_centers,_widths,_coeff)
    return float(p),np.array([gx,gy,gz],dtype=float)

# trigger compilation on import only when called, not at module load.
if __name__=='__main__':
    p,g=potential_and_acceleration(0.5,0.0,0.2)
    print('potential_km2_s2',p)
    print('acceleration_km2_s2_per_kpc',*g)
