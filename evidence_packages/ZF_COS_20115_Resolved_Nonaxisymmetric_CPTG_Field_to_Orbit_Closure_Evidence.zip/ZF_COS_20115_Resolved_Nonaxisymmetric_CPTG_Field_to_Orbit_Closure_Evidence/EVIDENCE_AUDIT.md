# Evidence Audit — ZF-COS-20115 Resolved Nonaxisymmetric CPTG Field-to-Orbit Closure

## Classification

**PASS WITH DECLARED SCOPE.**

The numerical chain from processed resolved kinematics and source geometry through the constructed CPTG field, scalar potential, orbit integration, exact spaxel observation operator, nonnegative orbit weighting, and resolved kinematic closure is internally reproducible and passes the stated gates.

## Structural checks

- Resolved bins: 26.
- Exact resolved spaxels: 141.
- Adopted structural radius reconstructs as `R_i = sqrt(x_i^2 + (z_i/0.70)^2)` with maximum relative residual `8.23e-15`.
- Local structural acceleration identity reconstructs with maximum relative residual `8.22e-15`.
- No common `a_star` is imposed.
- Bin 21 is retained normally.
- Local `a_star` range: `5.427457965547974e-10` to `2.2548018653878797e-08 m s^-2`; median `4.537648642155431e-09 m s^-2`.

Radius-definition sensitivity is retained in `STRUCTURAL_RADIUS_SENSITIVITY.csv`. Relative to the adopted `q=0.70` convention, use of the source projected axis ratio changes `a_star` by a median absolute fraction `0.09544` and maximum `0.17669`; a circular radius changes it by a median absolute fraction `0.19874` and maximum `0.42341`.


## Local structural-input uncertainty

- Linear propagated fractional 1-sigma uncertainty in `a_star`: minimum `0.20704602908500622`, median `0.3136180168570243`, maximum `0.6862128472903307`.
- 200000-draw per-bin Monte Carlo through the local CPTG law gives 68-percent fractional half-widths in `g_CPTG`: minimum `0.023491924558008654`, median `0.0787906826378425`, maximum `0.19393017048892922`.
- Maximum central-field recomputation difference in the uncertainty script: `1.1449303644266675e-12` fraction.
- Scope: the diagnostic holds `R_i` and `g_bar,i` fixed and does not resample the source field, Hermite continuation, orbit library, orbit weights, or cross-bin covariance.

## Source and field checks

- Nested source component mass sum: `157036301578.11557 Msun`.
- The same source integrated inside a 3 kpc semimajor-axis aperture gives `115495703304.3828 Msun`, only `-0.0336` of the cited observational 1-sigma mass uncertainty from the published `1.16 +/- 0.15 x 10^11 Msun` comparison value.
- Orbit potential: direct 96-node nested-oblate source quadrature plus curl-free Hermite scalar-potential correction.
- 26-center field gate threshold: fractional vector mismatch `< 1e-3`.
- Median 26-center mismatch: `3.81372432763996e-13`.
- Maximum 26-center mismatch: `3.661132650972944e-12`.
- Direct three-dimensional base-field spot checks reach maximum force mismatch `5.730567815442671e-12` and maximum potential mismatch `3.612445732018029e-15` relative to the vectorized source quadrature.
- Axisymmetric base vertical force is exactly zero on the sampled midplane by construction.

The exact-center field agreement is an interpolation constraint. The leave-one-center-out sensitivity is retained: median fractional mismatch `0.29014158234545573`, maximum `1.05228957238026` at held-out bin 24. The numerical conclusion in this archive is therefore restricted to the supplied Hermite-kernel construction; it does not assert robustness to alternate kernel rules.

## Structural Mode checks

- Structural Mode is evaluated downstream and is absent from the local `a_star`, field, and orbit-weight solves.
- Full radial structural radius: `R95 = 8.191131985921501 kpc`.
- SPARC-workbench sampled estimator: `lambda = 2.385686862661345 kpc`, `N = 3.433448083284456`.
- Downstream CSMI mapping: `Bulged Spiral` (`3.30 < N <= 3.55`).
- Continuum total-variation cross-check: `lambda = 2.385133513514354 kpc`, `N = 3.434244640608126`.
- Absolute sampled-versus-continuum difference: `7.965573236706e-04` in N.
- 8193-to-16385-sample change in the exact SPARC estimator: `7.951625792098e-04` in N.
- No common `a_star` is introduced and none of the 26 measured local values are altered by the Structural Mode calculation.
- The R95 continuation is model-continued beyond the directly resolved kinematic footprint; no direct resolved kinematic measurement at R95 is claimed.
- Redshift supplies the physical coordinate/epoch and does not rescale the structural accelerations.

The Structural Mode inputs and exact recomputation path are stored in `STRUCTURAL_MODE_N_PROFILE.csv`, `STRUCTURAL_MODE_N_SUMMARY.json`, `STRUCTURAL_MODE_N_SAMPLING_CONVERGENCE.csv`, and `CALCULATE_STRUCTURAL_MODE_N.py`.

## Orbit-library checks

- Trajectories: 4096.
- Integration method: DOP853.
- Duration: 12 local periods per trajectory.
- Uniform observation samples: 4096 over `[0,T)`.
- Relative tolerance: `1e-9`.
- Absolute tolerance: `1e-11`.
- Energy gate: `max |Delta E|/|E0| <= 5e-4`.
- Qualified trajectories: 4096/4096.
- Maximum fractional energy error: `4.5943865089544735e-05`.
- Integration retries: 0.
- Maximum orbit radius: `3.3733479059588154 kpc`.
- Initial positions, initial velocities, periods, spaxel coordinates, bin assignments, PSF scale, and observation targets match the stored matrix metadata to floating-point precision.

The observation operator uses sky plane `(x,z)`, line of sight `y`, `v_los=v_y`, and the unnormalized Gaussian PSF weight `exp(-d_sky^2/(2 sigma_PSF^2))`, summed over the exact spaxels of each bin and time-averaged.

## Orbit-weight closure

The nonnegative minimax solver was applied to tracer tolerances 1%, 1.5%, 2%, 2.5%, 3%, 5%, 7.5%, and 10%.

The first tested level, 1%, closes every marginal resolved velocity and `Vrms` pull below 3 sigma:

- maximum `|velocity pull| = 2.4307712899341243` at bin 9;
- maximum `|Vrms pull| = 2.8787326824138293` at bin 11;
- maximum tracer fractional residual = `0.010000000000000453`;
- materially active orbit weights (`>1e-10`): 23.

Bin 21 remains included:

- observed velocity `90.377554115 km/s`;
- model velocity `45.74323902722158 km/s`;
- velocity pull `-2.398439594810073`;
- observed `Vrms = 116.840819298 km/s`;
- model `Vrms = 163.2900229344173 km/s`;
- `Vrms` pull `+2.063538435552405`.

HiGHS, HiGHS dual-simplex, and HiGHS interior-point return the same 1% optimum and closure values. The maximum recorded linear-constraint violation is `1.3877787807814457e-17`.

A finer closure-boundary diagnostic is stored in `SUBPERCENT_TRACER_TOLERANCE_DIAGNOSTIC.csv`. The CPTG maximum `|Vrms pull|` is `3.105072` at exact tracer equality, `3.025370` at `0.25%`, and `2.948594` at `0.50%`; the first tested sub-percent row satisfying the all-bin marginal 3-sigma criterion is therefore `0.50%`. The baryonic-only control remains above 3 sigma throughout the same `0`--`1%` diagnostic interval.

## Matched baryonic-only control

- Conservative baryonic-only field maximum 26-center fractional mismatch: `5.254673552095104e-16`.
- Baryonic-only trajectories: 4096.
- Integration duration: 12 local periods.
- Uniform observation samples: 4096 over `[0,T)`.
- Energy-qualified trajectories: 4096/4096.
- Maximum fractional energy error: `3.412890140669127e-05`.
- Integration retries: 0.
- At 1% tracer tolerance, maximum `|velocity pull| = 2.5336996139022028`; maximum `|Vrms pull| = 3.6466626571798413` at bin 11.
- Baryonic-only 1% `Vrms` RMSE: `105.35480154193718 km/s`; MAE: `76.55398361761478 km/s`; bins below 3 sigma: 24/26.
- Corresponding CPTG 1% `Vrms` RMSE: `75.29988495135821 km/s`; MAE: `54.964867586151186 km/s`; bins below 3 sigma: 26/26.
- The baryonic-only control does not achieve all-bin 3-sigma closure at any tested tracer tolerance from 1% through 10%; the smallest listed maximum `|Vrms pull|` is `3.072135674588437` at 10%.

The control holds the orbit initial conditions, integration schedule, observation operator, and solver formulation fixed while changing the gravitational field. It therefore tests whether the baryonic source field alone admits the same conditional stationary closure.

## Claim boundary

This is a conditional compatibility and stationary-existence result. The local structural accelerations and final orbit weights both use the resolved kinematic measurements, so the same 26 measurements are not an out-of-sample prediction.

The reported kinematic checks are marginal per-bin pulls rather than a joint covariance goodness-of-fit statistic. The central-value orbit closure is not a full uncertainty-marginalized inference; local input uncertainty is quantified separately and cross-bin covariance is not supplied.

The archive begins from processed resolved-bin kinematics and exact resolved spaxel support. Raw spectral-extraction inputs are outside its evidentiary scope.

## Final package checks

- All Python sources compile.
- Regeneration entry point executes from the packaged independent inputs.
- Field verifier passes.
- Orbit-weight solver reproduces the stored 1% closure.
- Package verifier passes all structural, field, Structural Mode, orbit, observation-operator, and closure checks.
- SHA-256 manifest covers every archive file except the manifest itself.
