#!/usr/bin/env python3
from pathlib import Path
import numpy as np, pandas as pd
from POTENTIAL_EVALUATOR import potential_and_acceleration
HERE=Path(__file__).resolve().parent
KPC_M=3.0856775814913673e19
CONV=1e6/KPC_M
D=pd.read_csv(HERE/'NONAXISYMMETRIC_BARYONIC_AND_CPTG_FIELD.csv')
rows=[]
for _,r in D.iterrows():
    _,g=potential_and_acceleration(r.major_kpc,0.0,r.minor_kpc)
    got=np.array([g[0],g[2]])*CONV
    tar=np.array([r.g_CPTG_target_major_m_s2,r.g_CPTG_target_minor_m_s2])
    f=float(np.linalg.norm(got-tar)/np.linalg.norm(tar))
    dot=float(np.dot(got,tar)/(np.linalg.norm(got)*np.linalg.norm(tar)))
    ang=float(np.degrees(np.arccos(np.clip(dot,-1,1))))
    rows.append([int(r.bin_id),tar[0],tar[1],got[0],got[1],f,ang])
out=pd.DataFrame(rows,columns=['bin_id','target_major_m_s2','target_minor_m_s2','model_major_m_s2','model_minor_m_s2','fractional_vector_mismatch','direction_mismatch_deg'])
out.to_csv(HERE/'FIELD_CONSISTENCY_26.csv',index=False)
mx=float(out.fractional_vector_mismatch.max()); med=float(out.fractional_vector_mismatch.median())
print('FIELD_GATE_PASS' if mx<1e-3 else 'FIELD_GATE_FAIL')
print('median_fractional_vector_mismatch',med)
print('maximum_fractional_vector_mismatch',mx)
print('worst_bin',int(out.loc[out.fractional_vector_mismatch.idxmax(),'bin_id']))
print('bins_ge_1e-3',int((out.fractional_vector_mismatch>=1e-3).sum()))
