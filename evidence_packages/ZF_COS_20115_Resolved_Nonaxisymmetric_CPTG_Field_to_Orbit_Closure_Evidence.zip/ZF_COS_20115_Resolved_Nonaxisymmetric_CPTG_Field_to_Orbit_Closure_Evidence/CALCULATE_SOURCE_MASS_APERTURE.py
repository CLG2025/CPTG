#!/usr/bin/env python3
from pathlib import Path
import json
import numpy as np
import pandas as pd
HERE=Path(__file__).resolve().parent
R_AP=3.0

def main():
    c=pd.read_csv(HERE/'AXISYMMETRIC_SOURCE_COMPONENTS.csv')
    p=json.loads((HERE/'SOURCE_MODEL_PARAMETERS.json').read_text())
    q=float(p['projected_axis_ratio'])
    r=c.outer_radius_kpc.to_numpy(float)
    sig=c.surface_density_increment_Msun_kpc2.to_numpy(float)
    contrib=np.pi*q*sig*np.minimum(R_AP,r)**2
    out=c[['component','outer_radius_kpc','surface_density_increment_Msun_kpc2']].copy()
    out['mass_inside_3kpc_Msun']=contrib
    out.to_csv(HERE/'SOURCE_MASS_APERTURE_COMPONENTS.csv',index=False)
    model=float(contrib.sum())
    total=float(c.projected_component_mass_Msun.sum())
    summary={
      'aperture_semimajor_axis_kpc':R_AP,
      'projected_axis_ratio':q,
      'model_mass_inside_aperture_Msun':model,
      'model_total_mass_Msun':total,
      'aperture_fraction_of_model_total':model/total,
      'literature_comparison_mass_inside_3kpc_Msun':1.16e11,
      'literature_comparison_1sigma_Msun':0.15e11,
      'central_difference_Msun':model-1.16e11,
      'central_difference_sigma':(model-1.16e11)/(0.15e11),
      'scope':'model aperture integral; literature comparison value is cited in the manuscript'
    }
    (HERE/'SOURCE_MASS_APERTURE_SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(summary,indent=2))
if __name__=='__main__': main()
