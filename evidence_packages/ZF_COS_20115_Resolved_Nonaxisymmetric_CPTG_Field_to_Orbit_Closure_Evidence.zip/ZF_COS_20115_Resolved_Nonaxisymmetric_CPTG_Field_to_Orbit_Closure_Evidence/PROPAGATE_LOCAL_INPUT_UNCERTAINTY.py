#!/usr/bin/env python3
from pathlib import Path
import json
import numpy as np
import pandas as pd

HERE=Path(__file__).resolve().parent
KPC_M=3.0856775814913673e19
C=299792458.0
P=123.0/50.0
Q=11.0/50.0
NMC=200000
SEED=20115


def solve_g(a, b, r_m):
    a=np.asarray(a, dtype=float)
    b=np.asarray(b, dtype=float)
    rc=48.0*np.pi*C*C/a
    x=r_m/rc
    ggeom=0.5*a*np.power(x,7.0/5.0)/(1.0+np.power(x,12.0/5.0))
    A=np.sqrt(a*b)+ggeom
    g=b+A
    for _ in range(80):
        gn=b+A*np.power(1.0+np.power(g/a,P),-Q)
        if np.max(np.abs(gn-g)/np.maximum(np.abs(gn),1e-300)) < 2e-14:
            g=gn
            break
        g=gn
    return g


def main():
    local=pd.read_csv(HERE/'LOCAL_STRUCTURAL_ACCELERATION_FIELD.csv').sort_values('bin_id')
    field=pd.read_csv(HERE/'NONAXISYMMETRIC_BARYONIC_AND_CPTG_FIELD.csv').sort_values('bin_id')
    df=local.merge(field[['bin_id','gbar_nonaxisymmetric_m_s2','g_CPTG_local_m_s2']],on='bin_id',validate='one_to_one')
    rng=np.random.default_rng(SEED)
    rows=[]
    central_err=[]
    for row in df.itertuples(index=False):
        r_m=float(row.R_elliptical_kpc)*KPC_M
        a0=float(row.a_star_local_m_s2)
        sa=float(row.a_star_local_1sigma_m_s2)
        b=float(row.gbar_nonaxisymmetric_m_s2)
        stored=float(row.g_CPTG_local_m_s2)
        recomputed=float(solve_g(np.array([a0]), b, r_m)[0])
        central_err.append(abs(recomputed-stored)/stored)

        # Draw the measured support coordinate through Vrms, which preserves positivity
        # and the exact relation a_star = Vrms^2/R used in this reduction.
        vr=float(row.observed_vrms_km_s)
        svr=float(row.vrms_1sigma_km_s)
        vdraw=rng.normal(vr,svr,NMC)
        # The probability of a negative Vrms draw is tiny for these bins; fold any such
        # draw because the second-moment magnitude entering a_star is nonnegative.
        vdraw=np.abs(vdraw)
        adraw=a0*np.square(vdraw/vr)
        gdraw=solve_g(adraw,b,r_m)
        enh=gdraw/b
        aq=np.quantile(adraw,[0.16,0.5,0.84])
        gq=np.quantile(gdraw,[0.16,0.5,0.84])
        eq=np.quantile(enh,[0.16,0.5,0.84])
        rows.append({
            'bin_id':int(row.bin_id),
            'R_elliptical_kpc':float(row.R_elliptical_kpc),
            'Vrms_km_s':vr,
            'Vrms_1sigma_km_s':svr,
            'a_star_central_m_s2':a0,
            'a_star_linear_1sigma_m_s2':sa,
            'a_star_linear_fractional_1sigma':sa/a0,
            'a_star_mc_p16_m_s2':aq[0],
            'a_star_mc_median_m_s2':aq[1],
            'a_star_mc_p84_m_s2':aq[2],
            'gbar_m_s2':b,
            'g_CPTG_central_m_s2':stored,
            'g_CPTG_mc_p16_m_s2':gq[0],
            'g_CPTG_mc_median_m_s2':gq[1],
            'g_CPTG_mc_p84_m_s2':gq[2],
            'g_CPTG_mc_fractional_halfwidth_68':0.5*(gq[2]-gq[0])/gq[1],
            'enhancement_central':stored/b,
            'enhancement_mc_p16':eq[0],
            'enhancement_mc_median':eq[1],
            'enhancement_mc_p84':eq[2],
        })
    out=pd.DataFrame(rows)
    out.to_csv(HERE/'LOCAL_INPUT_UNCERTAINTY_PROPAGATION.csv',index=False)
    rel=out.a_star_linear_fractional_1sigma.to_numpy(float)
    fg=out.g_CPTG_mc_fractional_halfwidth_68.to_numpy(float)
    summary={
        'sampling':'independent Gaussian Vrms errors transformed through a_star=Vrms^2/R; fixed R and gbar; negative Vrms draws folded to nonnegative magnitude',
        'monte_carlo_draws_per_bin':NMC,
        'random_seed':SEED,
        'a_star_fractional_1sigma_min':float(np.min(rel)),
        'a_star_fractional_1sigma_median':float(np.median(rel)),
        'a_star_fractional_1sigma_max':float(np.max(rel)),
        'local_g_CPTG_fractional_68_halfwidth_min':float(np.min(fg)),
        'local_g_CPTG_fractional_68_halfwidth_median':float(np.median(fg)),
        'local_g_CPTG_fractional_68_halfwidth_max':float(np.max(fg)),
        'central_field_recompute_max_fractional_error':float(np.max(central_err)),
        'scope':'local-input propagation only; source-field, conservative-interpolation, orbit-library, and weight-solve uncertainties are not resampled'
    }
    (HERE/'LOCAL_INPUT_UNCERTAINTY_SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(summary,indent=2))

if __name__=='__main__':
    main()
