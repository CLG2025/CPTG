#!/usr/bin/env python3
from pathlib import Path
import json
import numpy as np
import pandas as pd
from scipy.optimize import linprog
HERE=Path(__file__).resolve().parent
MATRIX=HERE/'BARYONIC_CONTROL_ORBIT_MOMENT_MATRICES.npz'
TAUS=[0.01,0.015,0.02,0.025,0.03,0.05,0.075,0.10]

def solve_tau(L,M1,M2,light,V,Vr,eV,eVr,tau):
    n=L.shape[0]; c=np.r_[np.zeros(n),1.0]; A=[]; b=[]
    for i in range(26):
        A.append(np.r_[ L[:,i],0.0]); b.append((1+tau)*light[i])
        A.append(np.r_[-L[:,i],0.0]); b.append(-(1-tau)*light[i])
        s1=light[i]*eV[i]; y1=light[i]*V[i]; row1=M1[:,i]/s1
        A.append(np.r_[ row1,-1.0]); b.append(y1/s1)
        A.append(np.r_[-row1,-1.0]); b.append(-y1/s1)
        s2=light[i]*2*Vr[i]*eVr[i]; y2=light[i]*Vr[i]**2; row2=M2[:,i]/s2
        A.append(np.r_[ row2,-1.0]); b.append(y2/s2)
        A.append(np.r_[-row2,-1.0]); b.append(-y2/s2)
    res=linprog(c,A_ub=np.asarray(A),b_ub=np.asarray(b),bounds=[(0,None)]*n+[(0,None)],method='highs')
    if not res.success: return None,res.message
    w=res.x[:-1]; lp=w@L; vp=(w@M1)/lp; rp=np.sqrt(np.maximum((w@M2)/lp,0))
    return dict(weights=w,pred_light=lp,model_V=vp,model_Vrms=rp,V_pull=(vp-V)/eV,Vrms_pull=(rp-Vr)/eVr,light_resid=lp/light-1,t=float(res.x[-1])),'PASS'

def main():
    d=np.load(MATRIX,allow_pickle=False); ids=d['orbit_ids'].astype(int)
    if len(ids)!=4096 or not np.array_equal(ids,np.arange(4096)): raise SystemExit('bad orbit ids')
    if float(np.max(d['energy_error']))>5e-4: raise SystemExit('energy gate failed')
    L,M1,M2=d['L'],d['M1'],d['M2']; light,V,Vr,eV,eVr=[d[k] for k in ['light','Vobs','Vrms','eV','eVrms']]
    rows=[]; sols={}
    for tau in TAUS:
        sol,msg=solve_tau(L,M1,M2,light,V,Vr,eV,eVr,tau)
        if sol is None:
            rows.append(dict(hard_tracer_tolerance_fraction=tau,solver_status=msg,all_velocity_and_vrms_pulls_below_3=False)); continue
        sols[tau]=sol
        rows.append(dict(hard_tracer_tolerance_fraction=tau,solver_status='PASS',minimax_raw_moment_t=sol['t'],max_abs_tracer_fractional_residual=float(np.max(np.abs(sol['light_resid']))),max_abs_velocity_pull=float(np.max(np.abs(sol['V_pull']))),max_abs_velocity_pull_bin=int(np.argmax(np.abs(sol['V_pull']))),max_abs_vrms_pull=float(np.max(np.abs(sol['Vrms_pull']))),max_abs_vrms_pull_bin=int(np.argmax(np.abs(sol['Vrms_pull']))),bin21_velocity_pull=float(sol['V_pull'][21]),bin21_vrms_pull=float(sol['Vrms_pull'][21]),active_orbits=int(np.sum(sol['weights']>1e-10)),all_velocity_and_vrms_pulls_below_3=bool(np.max(np.abs(sol['V_pull']))<3 and np.max(np.abs(sol['Vrms_pull']))<3)))
    ladder=pd.DataFrame(rows); ladder.to_csv(HERE/'BARYONIC_CONTROL_CLOSURE_LADDER.csv',index=False)
    # primary comparison uses same 1% tracer tolerance as CPTG; also report best listed t
    primary_tau=0.01; primary=sols[primary_tau]
    best_tau=min(sols,key=lambda t:sols[t]['t']); best=sols[best_tau]
    outobs=pd.read_csv(HERE/'OBSERVATION_TARGETS.csv').sort_values('bin_id')
    out=pd.DataFrame({'bin_id':outobs.bin_id.astype(int),'observed_velocity_km_s':V,'velocity_1sigma_km_s':eV,'model_velocity_km_s':primary['model_V'],'velocity_pull':primary['V_pull'],'observed_vrms_km_s':Vr,'vrms_1sigma_km_s':eVr,'model_vrms_km_s':primary['model_Vrms'],'vrms_pull':primary['Vrms_pull'],'target_tracer_fraction':light,'model_tracer_fraction':primary['pred_light'],'tracer_fractional_residual':primary['light_resid']})
    out.to_csv(HERE/'BARYONIC_CONTROL_RESOLVED_CLOSURE.csv',index=False)
    np.savez_compressed(HERE/'BARYONIC_CONTROL_CLOSURE_SOLUTION.npz',weights=primary['weights'],model_light=primary['pred_light'],model_V=primary['model_V'],model_Vrms=primary['model_Vrms'],V_pull=primary['V_pull'],Vrms_pull=primary['Vrms_pull'],light_resid=primary['light_resid'],hard_tracer_tolerance=np.array([primary_tau]),minimax_raw_moment_t=np.array([primary['t']]))
    summary={'potential':'matched nonaxisymmetric baryonic-only conservative Hermite field','trajectories':4096,'integration_periods':float(d['integration_periods'][0]),'uniform_samples':int(d['uniform_samples'][0]),'energy_qualified':int(np.sum(d['energy_error']<=5e-4)),'maximum_fractional_energy_error':float(np.max(d['energy_error'])),'integration_retries':int(np.sum(d['retry']>0)),'primary_tracer_tolerance':primary_tau,'primary_max_abs_velocity_pull':float(np.max(np.abs(primary['V_pull']))),'primary_max_abs_velocity_pull_bin':int(np.argmax(np.abs(primary['V_pull']))),'primary_max_abs_vrms_pull':float(np.max(np.abs(primary['Vrms_pull']))),'primary_max_abs_vrms_pull_bin':int(np.argmax(np.abs(primary['Vrms_pull']))),'primary_all_pulls_below_3':bool(np.max(np.abs(primary['V_pull']))<3 and np.max(np.abs(primary['Vrms_pull']))<3),'best_listed_tau_by_minimax_t':best_tau,'best_listed_max_abs_velocity_pull':float(np.max(np.abs(best['V_pull']))),'best_listed_max_abs_vrms_pull':float(np.max(np.abs(best['Vrms_pull']))),'best_listed_all_pulls_below_3':bool(np.max(np.abs(best['V_pull']))<3 and np.max(np.abs(best['Vrms_pull']))<3),'active_orbits_primary':int(np.sum(primary['weights']>1e-10))}
    (HERE/'BARYONIC_CONTROL_SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(ladder.to_string(index=False)); print(json.dumps(summary,indent=2))
if __name__=='__main__': main()
