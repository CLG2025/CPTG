ZF-COS-20115 RESOLVED NONAXISYMMETRIC CPTG FIELD-TO-ORBIT CLOSURE EVIDENCE

STATUS: PASS WITH DECLARED SCOPE

This archive is the standalone numerical evidence authority for the resolved 26-bin field-to-orbit closure of ZF-COS-20115 under the constructed CPTG field construction.

Numerical result
- 26 resolved kinematic bins and 141 exact resolved spaxels.
- Each bin retains its own local a_star; no common a_star is imposed.
- Adopted structural radius: R_i = sqrt(x_i^2 + (z_i/0.70)^2).
- Bin 21 is retained without clipping, down-weighting, or special treatment.
- The orbit potential uses direct 96-node nested-oblate source quadrature plus the curl-free Hermite scalar-potential correction.
- The 30-component source model has total mass 1.57036301578e11 Msun and mass 1.15495703304e11 Msun inside the 3 kpc semimajor-axis aperture.
- 26-center field gate: maximum fractional vector mismatch = 3.661132650972944e-12, threshold = 1e-3.
- 4096/4096 trajectories pass the fractional energy gate <= 5e-4.
- Maximum fractional energy error = 4.5943865089544735e-05.
- Integration retries = 0.
- The publication ladder begins at 1%; that row closes all 26 velocity and Vrms marginal pulls below 3 sigma.
- A matched nonaxisymmetric baryonic-only control uses the same 4096 initial conditions, 12 local periods, 4096 time samples, PSF, exact-spaxel operator, and closure solver.
- At 1% tracer tolerance the baryonic-only maximum |Vrms pull| is 3.6466626571798413; 24/26 Vrms bins are below 3 sigma.
- The baryonic-only control remains above 3 sigma throughout the tested 1%-10% tracer-tolerance ladder; its smallest listed maximum |Vrms pull| is 3.072135674588437 at 10%.
- Maximum |velocity pull| = 2.4307712899341243 at bin 9.
- Maximum |Vrms pull| = 2.8787326824138293 at bin 11.
- A sub-percent diagnostic gives maximum |Vrms pull| 3.025370 at 0.25% tracer tolerance and 2.948594 at 0.50%; exact tracer equality gives 3.105072.
- Linear local a_star fractional 1-sigma uncertainty ranges from 0.20705 to 0.68621 with median 0.31362.
- Local-only Monte Carlo propagation gives g_CPTG 68-percent fractional half-widths from 0.02349 to 0.19393 with median 0.07879.
- Bin 21 pulls are -2.398439594810073 (velocity) and +2.063538435552405 (Vrms).
- 23 orbit weights exceed 1e-10.
- Full-galaxy Structural Mode uses the SPARC workbench estimator on the dense uniform full-R95 CPTG radial profile.
- R95 = 8.191131985921501 kpc; lambda = 2.385686862661345 kpc; N = 3.433448083284456.
- The downstream CSMI mapping is Bulged Spiral (3.30 < N <= 3.55).
- Independent continuum total-variation cross-check: N = 3.434244640608126, |Delta N| = 7.965573236706e-04.

Claim boundary
The local structural accelerations and orbit weights use the resolved kinematic measurements. This archive therefore establishes conditional compatibility and existence of a stationary nonnegative orbit population in the constructed CPTG field. It is not an out-of-sample prediction of those same 26 measurements.

Structural Mode boundary
The reported N is a downstream full-R95 structural readout. It is not used to determine any local a_star, field coefficient, orbit trajectory, or orbit weight. The R95 continuation is model-continued beyond the directly resolved kinematic footprint, so no direct resolved measurement at R95 is claimed. Redshift sets the physical coordinate/epoch and does not rescale a_star.

Continuous-field boundary
The result is qualified for the supplied Hermite-kernel construction. Leave-one-center-out interpolation diagnostics are retained. No robustness claim across alternate kernel scales is made by this archive.

Observation boundary
The archive begins from processed resolved-bin kinematics and exact resolved spaxel support. Raw spectral-extraction inputs are not included.

Start with:
1. SUMMARY.json
2. METHOD_AND_CLAIM_SCOPE.md
3. EVIDENCE_AUDIT.md
4. RESOLVED_BIN_OBSERVATIONS_AND_MODEL_CLOSURE.csv
5. FIELD_CONSISTENCY_26.csv
6. TRACER_TOLERANCE_CLOSURE_LADDER.csv
7. STRUCTURAL_MODE_N_SUMMARY.json
8. STRUCTURAL_MODE_N_PROFILE.csv
9. STRUCTURAL_MODE_N_SAMPLING_CONVERGENCE.csv
10. CALCULATE_STRUCTURAL_MODE_N.py
11. LOCAL_INPUT_UNCERTAINTY_PROPAGATION.csv
12. SUBPERCENT_TRACER_TOLERANCE_DIAGNOSTIC.csv
13. SOURCE_MASS_APERTURE_SUMMARY.json
14. VERIFY_PACKAGE.py

Matched baryonic-only control
- BARYONIC_CONTROL_FIELD_CONSISTENCY_26.csv
- BARYONIC_CONTROL_POTENTIAL_COEFFICIENTS.csv
- BARYONIC_CONTROL_CORRECTION_DATA.npz
- BARYONIC_CONTROL_ORBIT_MOMENT_MATRICES.npz
- BARYONIC_CONTROL_CLOSURE_LADDER.csv
- BARYONIC_CONTROL_RESOLVED_CLOSURE.csv
- BARYONIC_CONTROL_CLOSURE_SOLUTION.npz
- BARYONIC_CONTROL_SUMMARY.json
- BARYONIC_CONTROL_AUDIT.json
- BARYONIC_CONTROL_AUDIT_CHECKS.csv
- POTENTIAL_EVALUATOR_BARYONIC_CONTROL.py
- REGENERATE_BARYONIC_CONTROL_ORBIT_MATRICES.py
- SOLVE_BARYONIC_CONTROL.py
- RADIALIZED_VRMS_COMPARISON.csv
- RADIALIZED_OBSERVED_DISPLAY_POINTS.csv
