from __future__ import annotations
import datetime,zipfile,hashlib
from common import *

def main():
    p=EVIDENCE/"FINAL_VALIDATION_SUMMARY.json"
    if not p.is_file() or load_json(p).get("decision")!="PASS":
        raise RuntimeError("FINAL_VALIDATION_SUMMARY PASS required")
    stamp=datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    out=ROOT.parent/f"CPTG_PRIMAT_A1A119_FINAL_EVIDENCE_{stamp}.zip"
    files=[]
    for rel in ("CONFIG","SOURCE","EVIDENCE","OUTPUT","RESULTS","PAPER_DATA","REFERENCE"):
        files.extend(x for x in (ROOT/rel).rglob("*") if x.is_file() and "__pycache__" not in x.parts and x.suffix not in (".pyc",".nbc",".nbi"))
    files += [ROOT/"README_FIRST.txt",ROOT/"SCIENTIFIC_PROTOCOL.md",ROOT/"MANIFEST.sha256"]
    files=sorted(set(x for x in files if x.is_file()),key=lambda x:x.relative_to(ROOT).as_posix())
    entries={}
    with zipfile.ZipFile(out,"w",zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for f in files:
            rel=f.relative_to(ROOT).as_posix();data=f.read_bytes()
            z.writestr(rel,data);entries[rel]=hashlib.sha256(data).hexdigest()
        man="".join(f"{h}  {rel}\n" for rel,h in sorted(entries.items()))
        z.writestr("FINAL_EVIDENCE_MANIFEST.sha256",man.encode())
    with zipfile.ZipFile(out) as z:
        if z.testzip() is not None:raise RuntimeError("ZIP CRC fail")
        for line in z.read("FINAL_EVIDENCE_MANIFEST.sha256").decode().splitlines():
            h,rel=line.split("  ",1)
            if hashlib.sha256(z.read(rel)).hexdigest()!=h:raise RuntimeError("manifest mismatch "+rel)
    h=sha_file(out);side=out.with_suffix(out.suffix+".sha256.txt")
    side.write_text(f"{h}  {out.name}\n",encoding="utf-8")
    print("R06_FINAL_EVIDENCE_EXPORT PASS")
    print("ZIP",out)
    print("SHA256",h)

if __name__=="__main__":main()
