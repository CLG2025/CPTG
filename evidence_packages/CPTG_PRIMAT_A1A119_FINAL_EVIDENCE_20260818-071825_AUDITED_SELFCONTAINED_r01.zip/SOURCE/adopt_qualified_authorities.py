from __future__ import annotations
import hashlib,json,shutil,math
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
R02=Path(r"D:\Downloads\CPTG_PRIMAT_NativeBoundaryFlux_A1A119_FinalValidation_20260817_r02")
R05=Path(r"D:\Downloads\CPTG_PRIMAT_NativeBoundaryFlux_AsymptoticContinuumQualification_20260818_r05")
EXPECT="97fd7b4f4f4e7466be9e45be264e62faade5b55e80d415201ed4390405080f9a"

def sha(p):
    h=hashlib.sha256()
    with p.open("rb") as f:
        for b in iter(lambda:f.read(1048576),b""):h.update(b)
    return h.hexdigest()

def main():
    for d in ("EVIDENCE","OUTPUT","REFERENCE"):
        (ROOT/d).mkdir(parents=True,exist_ok=True)

    # Frozen native trajectories.
    fp=R02/"OUTPUT/NATIVE_TRAJECTORY_FREEZE.json"
    if not fp.is_file() or sha(fp)!=EXPECT:
        raise RuntimeError("r02 native trajectory freeze identity mismatch")
    fr=json.loads(fp.read_text(encoding="utf-8"))
    if fr.get("eta_count")!=6:raise RuntimeError("native eta_count != 6")
    copied=0
    for rec in fr["files"]:
        src=R02/rec["path"]
        if not src.is_file() or sha(src)!=rec["sha256"]:
            raise RuntimeError("native member invalid "+rec["path"])
        dst=ROOT/rec["path"];dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
        if sha(dst)!=rec["sha256"]:raise RuntimeError("native copied member mismatch "+rec["path"])
        copied+=1
    shutil.copy2(fp,ROOT/"OUTPUT/NATIVE_TRAJECTORY_FREEZE.json")

    # Actual r05 qualification authority, no endpoint arrays.
    rp=R05/"EVIDENCE/ASYMPTOTIC_CONTINUUM_QUALIFICATION_RESULT.json"
    if not rp.is_file():raise RuntimeError("r05 qualification result missing")
    r=json.loads(rp.read_text(encoding="utf-8"))
    req=json.loads((ROOT/"CONFIG/R05_QUALIFICATION_REQUIREMENTS.json").read_text(encoding="utf-8"))
    if r.get("decision")!="PASS" or r.get("production_refinement")!=256:
        raise RuntimeError("r05 not PASS/256")
    mx=req["maximum_allowed"];orng=req["order_ranges"]
    checks={
      "global_positive_128_256_max":float(r["global_positive_128_256_max"])<=mx["global_positive_128_256_max"],
      "global_positive256_to_Richardson_max":float(r["global_positive256_to_Richardson_max"])<=mx["global_positive256_to_Richardson_max"],
      "global_continuum_cross_scheme_max":float(r["global_continuum_cross_scheme_max"])<=mx["global_continuum_cross_scheme_max"],
      "global_BE_128_256_max":float(r["global_BE_128_256_max"])<=mx["global_BE_128_256_max"],
      "positive_order":orng["global_positive_effective_order"][0]<=float(r["global_positive_effective_order"])<=orng["global_positive_effective_order"][1],
      "BE_order":orng["global_BE_effective_order"][0]<=float(r["global_BE_effective_order"])<=orng["global_BE_effective_order"][1],
      "controls_pass":r.get("controls_pass") is True,
      "prior_transport_outputs_imported":r.get("prior_transport_outputs_imported") is False
    }
    if not all(checks.values()):raise RuntimeError("r05 qualification gate mismatch "+repr(checks))
    dst=ROOT/"REFERENCE/R05_ASYMPTOTIC_CONTINUUM_QUALIFICATION_RESULT.json";shutil.copy2(rp,dst)
    evidence={
      "schema":"cptg-r06-authority-adoption-v1","pass":True,
      "native_freeze_sha256":EXPECT,"native_files_copied":copied,
      "r05_result_sha256":sha(rp),"r05_checks":checks,
      "native_trajectory_regenerated":False,
      "r05_endpoint_arrays_imported":False,
      "r02_r03_r04_transport_outputs_imported":False,
      "historical_postsilicon_numerical_inputs":0
    }
    (ROOT/"EVIDENCE/AUTHORITY_ADOPTION.json").write_text(json.dumps(evidence,indent=2,sort_keys=True)+"\n",encoding="utf-8")
    print("R06_FINAL_AUTHORITY_ADOPTION PASS")
    print("NATIVE_FREEZE_SHA256",EXPECT)
    print("R05_RESULT_SHA256",sha(rp))
    print("PRODUCTION_REFINEMENT 256")
    print("NATIVE_TRAJECTORY_REGENERATED False")
    print("R05_ENDPOINT_ARRAYS_IMPORTED False")
    print("HISTORICAL_POSTSILICON_NUMERICAL_INPUTS 0")

if __name__=="__main__":main()
