from __future__ import annotations
import json,hashlib,py_compile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def sha(p):
    h=hashlib.sha256();h.update(p.read_bytes());return h.hexdigest()
def ck(n,c):
    if not c:raise RuntimeError(n+" FAIL")
    print(n,"PASS")
def main():
    p=json.loads((ROOT/"CONFIG/FROZEN_FINAL_PREREGISTRATION.json").read_text())
    ck("R06_FINAL_SCHEMA",p["schema"]=="cptg-primat-native-boundary-flux-a1a119-final-evidence-validation-v1")
    ck("PRIMAT_PRIMARY",p["authority"]["primary_network"]=="PRIMAT v0.3.2")
    ck("PRODUCTION_REFINEMENT_256",p["authority"]["production_refinement"]==256)
    ck("FROZEN_NATIVE_IDENTITY",p["authority"]["native_trajectory_freeze_sha256"]=="97fd7b4f4f4e7466be9e45be264e62faade5b55e80d415201ed4390405080f9a")
    ck("NO_PRIOR_ENDPOINT_IMPORT",p["qualification_import_policy"]["r05_endpoint_arrays_imported"] is False and p["qualification_import_policy"]["r02_r03_r04_transport_outputs_imported"] is False)
    ck("NO_HISTORICAL_INPUT",p["qualification_import_policy"]["historical_postsilicon_numerical_inputs"]==0)
    ck("NO_ARTIFICIAL_SEED",p["scientific_graph"]["artificial_seed_or_floor"] is False)
    g=p["final_hard_gates"]
    ck("FROZEN_GRAPH_COUNTS",g["boundary_source_edge_count_exact"]==14 and g["external_species_A160_exact"]==2927)
    ck("OUTER_BOUNDARY_GATE",g["outer_A128_A140_A160_max_relative_through_A119"]==1e-10)
    s=(ROOT/"SOURCE/run_final_validation.py").read_text()
    ck("FRESH_GRAPH_BUILD","pyna.ReacLibLibrary()" in s and "build_graph(native,maxA,caps,betas)" in s)
    ck("PRODUCTION_256","PROD=256" in s)
    ck("OUTER_128_140_160","for mx in (128,140,160)" in s)
    ck("ZERO_HALF_DOUBLE_CONTROLS","source*0.0" in s and "source*0.5" in s and "source*2.0" in s)
    f=(ROOT/"SOURCE/finalize.py").read_text()
    ck("FULL_A1_A119_REGISTER","for A in range(1,120)" in f and "A1_A119_SIXANCHOR_REGISTER.csv" in f)
    ck("PAPER_DATA_OUTPUT","PRIMAT_A1A119_FINAL_RESULTS.tex" in f)
    a=(ROOT/"SOURCE/adopt_qualified_authorities.py").read_text()
    ck("ADOPT_ACTUAL_R05_RESULT","ASYMPTOTIC_CONTINUUM_QUALIFICATION_RESULT.json" in a and "r05_endpoint_arrays_imported" in a)
    pys=sorted((ROOT/"SOURCE").glob("*.py"))
    for x in pys:py_compile.compile(str(x),doraise=True)
    print("PYTHON_COMPILE",f"{len(pys)}/{len(pys)}","PASS")
    bad=[];n=0
    for line in (ROOT/"MANIFEST.sha256").read_text().splitlines():
        if not line.strip():continue
        h,rel=line.split("  ",1);n+=1;q=ROOT/rel
        if not q.is_file() or sha(q)!=h:bad.append(rel)
    ck(f"PACKAGE_MANIFEST {n-len(bad)}/{n}",not bad)
    print("R06_FINAL_STATIC_VERIFY PASS")
if __name__=="__main__":main()
