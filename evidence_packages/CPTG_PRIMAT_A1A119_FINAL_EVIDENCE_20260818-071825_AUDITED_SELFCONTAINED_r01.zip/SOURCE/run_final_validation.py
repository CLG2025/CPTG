from __future__ import annotations
import csv,json,math,importlib.metadata,hashlib
from collections import defaultdict,deque
from pathlib import Path
import numpy as np
import pynucastro as pyna
from common import *
from positive_transport_core import solve_backward_euler,solve_positive_exponential_inflow

PROD=256
SELECTED=[24,28,32,40,56,80,100,119]
LIGHT_TUPLES=set(LIGHT)

def nuc_tuple(n):return int(n.A),int(n.Z)

def select_rates():
    rl=pyna.ReacLibLibrary();caps=[];betas=[]
    for r in rl.get_rates():
        rea=[nuc_tuple(x) for x in r.reactants];pro=[nuc_tuple(x) for x in r.products]
        if not r.weak and len(rea)==2 and len(pro)==1:
            ls=[x for x in rea if x in LIGHT_TUPLES]
            if len(ls)==1:
                l=ls[0];h=rea[1] if rea[0]==l else rea[0];d=pro[0]
                if h[0]>=6 and d==(h[0]+l[0],h[1]+l[1]):
                    caps.append((h,l,d,r))
        if r.weak and getattr(r,"weak_type",None)=="beta_neg" and len(rea)==1 and len(pro)==1:
            if rea[0][0]>=6 and pro[0][0]==rea[0][0] and pro[0][1]==rea[0][1]+1:
                betas.append((rea[0],pro[0],r))
    caps.sort(key=lambda x:(x[0],x[1],x[2],str(x[3])))
    betas.sort(key=lambda x:(x[0],x[1],str(x[2])))
    return caps,betas

def build_graph(native,maxA,caps,betas):
    source=[(h,l,d,r) for h,l,d,r in caps if h in native and d not in native and 24<=d[0]<=maxA]
    seeds={d for h,l,d,r in source}
    if not seeds:raise RuntimeError("no native-to-external boundary source")
    cb=defaultdict(list);bb=defaultdict(list)
    for h,l,d,r in caps:
        if h[0]>=24:cb[h].append((d,l,r))
    for s,d,r in betas:
        if s[0]>=24:bb[s].append((d,r))
    seen=set(seeds);q=deque(sorted(seeds))
    while q:
        s=q.popleft()
        for d,l,r in cb.get(s,[]):
            if d[0]<=maxA and d not in seen:seen.add(d);q.append(d)
        for d,r in bb.get(s,[]):
            if d[0]<=maxA and d not in seen:seen.add(d);q.append(d)
    species=sorted(seen,key=lambda x:(x[0],x[1]));idx={s:i for i,s in enumerate(species)}
    incoming=[];outgoing=defaultdict(list)
    for s in species:
        for d,l,r in cb.get(s,[]):
            outgoing[s].append(("capture",d,l,r))
            if d in idx:
                if idx[d]<=idx[s]:raise RuntimeError("non-forward capture edge")
                incoming.append((idx[s],idx[d],"capture",l,r))
        for d,r in bb.get(s,[]):
            outgoing[s].append(("beta",d,None,r))
            if d in idx:
                if idx[d]<=idx[s]:raise RuntimeError("non-forward beta edge")
                incoming.append((idx[s],idx[d],"beta",None,r))
    incoming.sort(key=lambda e:(e[1],e[0],str(e[4])))
    return source,species,idx,incoming,outgoing

def load_traj(eta):
    z=np.load(OUTPUT/f"NATIVE_TRAJECTORIES/PRIMAT_NATIVE_TRAJECTORY_ETA{eta_tag(eta)}.npz")
    names=[str(x) for x in z["species"]];az=[parse_primat_name(n) for n in names]
    return np.asarray(z["t_s"],float),np.asarray(z["T_K"],float),np.asarray(z["rho_b_g_cm3"],float),az,np.asarray(z["Y"],float)

def precompute(eta,maxA,caps,betas):
    t,T,rho,naz,Y=load_traj(eta);native=set(naz);ixn={a:i for i,a in enumerate(naz)}
    source_edges,species,idx,incoming,outgoing=build_graph(native,maxA,caps,betas)
    ns=len(species);nt=len(t);ne=len(incoming)
    source=np.zeros((ns,nt));loss=np.zeros((ns,nt));inc=np.zeros((ne,nt))
    for h,l,d,r in source_edges:
        rv=np.array([float(r.eval(float(Tv))) for Tv in T])
        c=np.maximum(rv,0.0)*rho*Y[ixn[l],:]
        source[idx[d],:]+=c*Y[ixn[h],:]
    for e,(si,di,kind,l,r) in enumerate(incoming):
        rv=np.array([float(r.eval(float(Tv))) for Tv in T])
        inc[e,:]=np.maximum(rv,0.0)*rho*Y[ixn[l],:] if kind=="capture" else np.maximum(rv,0.0)
    for s in species:
        si=idx[s]
        for kind,d,l,r in outgoing.get(s,[]):
            rv=np.array([float(r.eval(float(Tv))) for Tv in T])
            loss[si,:]+=np.maximum(rv,0.0)*rho*Y[ixn[l],:] if kind=="capture" else np.maximum(rv,0.0)
    if not (np.all(np.isfinite(source)) and np.all(np.isfinite(loss)) and np.all(np.isfinite(inc))):
        raise RuntimeError("nonfinite coefficient table")
    if np.min(source)<0 or np.min(loss)<0 or (inc.size and np.min(inc)<0):
        raise RuntimeError("negative coefficient table")
    counts=np.zeros(ns,dtype=np.int64)
    for si,di,kind,l,r in incoming:counts[di]+=1
    starts=np.zeros(ns+1,dtype=np.int64);starts[1:]=np.cumsum(counts)
    inc_src=np.array([x[0] for x in incoming],dtype=np.int64)
    return t,source,loss,inc_src,starts,inc,species,source_edges,incoming,outgoing

def mass_sums(species,y):
    out={A:0.0 for A in range(24,120)}
    for s,v in zip(species,y):
        if 24<=s[0]<=119:out[s[0]]+=float(v)
    return out

def rel_dict(a,b,masses=SELECTED):
    by={A:symmetric_rel(a[A],b[A]) for A in masses}
    return max(by.values()) if by else 0.0,by

def graph_rows(source_edges,species,outgoing):
    present=set(species);rows=[]
    for h,l,d,r in source_edges:
        rows.append({"role":"BOUNDARY_SOURCE","src":az_name(*h),"light":az_name(*l),"dst":az_name(*d),
                     "src_A":h[0],"src_Z":h[1],"dst_A":d[0],"dst_Z":d[1],"kind":"capture","rate":str(r)})
    for s in species:
        for kind,d,l,r in outgoing.get(s,[]):
            rows.append({"role":"INTERNAL" if d in present else "OUTER_SINK","src":az_name(*s),
                         "light":az_name(*l) if l else "","dst":az_name(*d),
                         "src_A":s[0],"src_Z":s[1],"dst_A":d[0],"dst_Z":d[1],"kind":kind,"rate":str(r)})
    return rows

def main():
    if importlib.metadata.version("pynucastro")!="2.11.0":raise RuntimeError("pynucastro 2.11.0 required")
    if sha_file(OUTPUT/"NATIVE_TRAJECTORY_FREEZE.json")!="97fd7b4f4f4e7466be9e45be264e62faade5b55e80d415201ed4390405080f9a":
        raise RuntimeError("native freeze mismatch")
    adoption=load_json(EVIDENCE/"AUTHORITY_ADOPTION.json")
    if adoption.get("pass") is not True:raise RuntimeError("authority adoption PASS required")
    pre=load_json(CONFIG/"FROZEN_FINAL_PREREGISTRATION.json");g=pre["final_hard_gates"]
    caps,betas=select_rates()
    print("R06_FRESH_REACLIB_SELECTED",len(caps),"RADIATIVE_LIGHT_CAPTURES",len(betas),"BETA_MINUS",flush=True)
    anchors=[];graph_written=False

    for eta in ETA:
        print("R06_FINAL_START",eta,flush=True)
        t,source,loss,ii,st,ic,species,se,incoming,outgoing=precompute(eta,160,caps,betas)
        if len(se)!=int(g["boundary_source_edge_count_exact"]):raise RuntimeError(f"source edge count {len(se)}")
        if len(species)!=int(g["external_species_A160_exact"]):raise RuntimeError(f"external species count {len(species)}")
        integ=float(np.trapezoid(np.sum(source,axis=0),t))
        if not math.isfinite(integ) or integ<=0:raise RuntimeError("invalid boundary source integral")
        sn=source/integ

        yp,minp=solve_positive_exponential_inflow(t,sn,loss,ii,st,ic,PROD)
        yb,minb=solve_backward_euler(t,sn,loss,ii,st,ic,PROD)
        ya,mina=solve_positive_exponential_inflow(t,source,loss,ii,st,ic,PROD)
        if min(minp,minb,mina)<0 or np.min(yp)<0 or np.min(yb)<0 or np.min(ya)<0:
            raise RuntimeError("negative final production state")
        if not (np.all(np.isfinite(yp)) and np.all(np.isfinite(yb)) and np.all(np.isfinite(ya))):
            raise RuntimeError("nonfinite final production state")

        mp=mass_sums(species,yp);mb=mass_sums(species,yb);ma=mass_sums(species,ya)
        cross,cross_by=rel_dict(mp,mb)
        reconstruct,reconstruct_by=rel_dict(ma,{A:mp[A]*integ for A in mp})

        # source controls
        z,_=solve_positive_exponential_inflow(t,source*0.0,loss,ii,st,ic,PROD)
        h,_=solve_positive_exponential_inflow(t,source*0.5,loss,ii,st,ic,PROD)
        d,_=solve_positive_exponential_inflow(t,source*2.0,loss,ii,st,ic,PROD)
        base,_=solve_positive_exponential_inflow(t,source,loss,ii,st,ic,PROD)
        zero=bool(np.array_equal(z,np.zeros_like(z)))
        lin=max(vector_max_rel(h*2.0,base),vector_max_rel(d/2.0,base))

        # outer-boundary invariance, fresh production at each maxA
        outer={}
        for mx in (128,140,160):
            tt,ss,ll,iii,sts,ics,sps,ses,ins,outs=precompute(eta,mx,caps,betas)
            it=float(np.trapezoid(np.sum(ss,axis=0),tt))
            yy,_=solve_positive_exponential_inflow(tt,ss/it,ll,iii,sts,ics,PROD)
            outer[mx]=mass_sums(sps,yy)
        outer_rel=max(rel_dict(outer[128],outer[160],range(24,120))[0],
                      rel_dict(outer[140],outer[160],range(24,120))[0])

        structural={A for A,Z in species if 24<=A<=119}
        missing=[A for A in range(24,120) if A not in structural]
        nonpos=[A for A in range(24,120) if not (mp[A]>0 and math.isfinite(mp[A]))]

        passed=(not missing and not nonpos and zero and
                lin<=float(g["half_double_source_linearity_max_relative"]) and
                reconstruct<=float(g["absolute_normalized_reconstruction_max_relative"]) and
                outer_rel<=float(g["outer_A128_A140_A160_max_relative_through_A119"]))

        ddir=RESULTS/f"ETA{eta_tag(eta)}";ddir.mkdir(parents=True,exist_ok=True)
        with (ddir/"MASS_SECTORS.csv").open("w",newline="",encoding="utf-8") as f:
            w=csv.DictWriter(f,fieldnames=["A","normalized_primary256","absolute_primary256","normalized_BE256"])
            w.writeheader()
            for A in range(24,120):
                w.writerow({"A":A,"normalized_primary256":mp[A],"absolute_primary256":ma[A],"normalized_BE256":mb[A]})
        with (ddir/"NUCLIDE_ENDPOINT.csv").open("w",newline="",encoding="utf-8") as f:
            w=csv.DictWriter(f,fieldnames=["nuclide","A","Z","normalized_primary256","absolute_primary256","normalized_BE256"])
            w.writeheader()
            for s,pv,av,bv in zip(species,yp,ya,yb):
                if s[0]<=119:
                    w.writerow({"nuclide":az_name(*s),"A":s[0],"Z":s[1],
                                "normalized_primary256":float(pv),"absolute_primary256":float(av),"normalized_BE256":float(bv)})

        diag={"schema":"cptg-r06-final-anchor-v1","eta10":eta,"pass":passed,
              "boundary_source_edges":len(se),"external_species_A160":len(species),
              "boundary_source_integral":integ,
              "structural_missing_A24_A119":missing,"positive_support_missing_A24_A119":nonpos,
              "zero_source_exact_zero":zero,"source_linearity_max_relative":lin,
              "absolute_normalized_reconstruction_max_relative":reconstruct,
              "outer_boundary_max_relative_A24_A119":outer_rel,
              "primary256_vs_BE256_selected_mass_max_relative":cross,
              "primary256_vs_BE256_by_mass":cross_by}
        atomic_json(ddir/"FINAL_ANCHOR_DIAGNOSTICS.json",diag)
        anchors.append(diag)

        if not graph_written:
            rows=graph_rows(se,species,outgoing)
            with (EVIDENCE/"FINAL_FRESH_EXTERNAL_GRAPH_REGISTER.csv").open("w",newline="",encoding="utf-8") as f:
                w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
            atomic_json(EVIDENCE/"FINAL_RATE_LIBRARY_IDENTITY.json",{
                "schema":"cptg-r06-final-rate-library-identity-v1",
                "pynucastro_version":"2.11.0","selected_capture_rates":len(caps),
                "selected_beta_minus_rates":len(betas),
                "graph_register_sha256":sha_file(EVIDENCE/"FINAL_FRESH_EXTERNAL_GRAPH_REGISTER.csv"),
                "historical_rate_register_used":False})
            graph_written=True

        print("R06_FINAL_ANCHOR",eta,"PASS" if passed else "FAIL",
              "SOURCE_EDGES",len(se),"SPECIES",len(species),
              "OUTER_REL",outer_rel,"LINEARITY",lin,
              "ABS_RECON",reconstruct,"P256_BE256",cross,flush=True)

    overall=all(x["pass"] for x in anchors)
    out={"schema":"cptg-r06-final-sixanchor-transport-validation-v1",
         "decision":"PASS" if overall else "FAIL","production_refinement":256,
         "production_method":"positive_exponential_inflow",
         "verification_method":"backward_euler_triangular",
         "anchors":anchors,"all_six_anchors_pass":overall,
         "historical_postsilicon_numerical_inputs":0,
         "artificial_seed_or_floor_used":False}
    atomic_json(EVIDENCE/"FINAL_SIXANCHOR_TRANSPORT_VALIDATION.json",out)
    print("R06_FINAL_SIXANCHOR_TRANSPORT_VALIDATION","PASS" if overall else "FAIL")
    if not overall:raise SystemExit(5)

if __name__=="__main__":main()
