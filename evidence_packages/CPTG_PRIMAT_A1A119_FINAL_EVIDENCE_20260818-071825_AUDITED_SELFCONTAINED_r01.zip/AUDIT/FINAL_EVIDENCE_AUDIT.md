# CPTG PRIMAT A=1–119 Final Evidence Audit

## Decision

**PASS WITH ARCHIVAL REPAIR AND CLAIM-BOUNDARY NOTE**

The uploaded final evidence archive is scientifically internally consistent. Its own
`FINAL_EVIDENCE_MANIFEST.sha256` verified **54/54** entries with no hash failures.

The only archival defect was that the evidence exporter omitted six root Windows `.cmd`
launchers while retaining the original 18-entry `MANIFEST.sha256`. Those six launchers were
restored byte-for-byte from the released r06 package and each exactly matched the hash already
recorded in the retained distribution manifest. No scientific source, configuration, result,
trajectory, graph, register, or paper-data file was changed.

## Numerical authority

- r05 asymptotic continuum qualification: **PASS**
- Production refinement: **256**
- Positive-method observed order: `1.989305217002751`
- Backward-Euler observed order: `0.9756787775007231`
- Independent Richardson continuum cross-method max relative difference:
  `0.002068089097851021` (**0.206809%**)
- Positive-256 residual to Richardson continuum:
  `0.0006410375374877353` (**0.064104%**)

## Final six-anchor validation

- r06 final decision: **PASS**
- Six anchors complete: **6/6**
- Boundary-source edges: **14 at every anchor**
- External graph species through A≤160: **2927 at every anchor**
- Worst source-linearity residual: `2.072261514614524e-17`
- Worst absolute/normalized reconstruction residual: `3.48621117606944e-13`
- Amax=128/140/160 difference through A=119: `0`
- Raw production-256 vs BE-256 selected-mass discrepancy (report only):
  `0.03185068883946565` (**3.185069%**)

## A=1–119 register

- Register rows: **119**, exactly A=1…119
- Native PRIMAT frontier: **A=23**
- The only empty native mass coordinate in A=1…23 is **A=5**
- Every external mass sector A=24…119 has strictly positive modeled support at all six eta anchors
- Central η10=6.094 weakest external sector: **A=113**, `Y=1.6564420258952037e-56`
- Central A=119: `Y=2.8835564429723586e-56`
- Central A=119 boundary-source-normalized support: `1.7121290257504072e-20`
- Sum of central normalized support over A=24…119: `0.999999888722385`
- A=119 six-anchor full range / central value: `0.347795` (**34.779%**)

## Scientific claim boundary

The evidence supports **gap-free structural reachability and strictly positive modeled
transport support through A=119** under the preregistered reduced graph driven by the frozen
PRIMAT light-element bath.

It does **not** establish that PRIMAT natively evolves a heavy network beyond A=23, nor that
the ultra-small A≈100–119 abundances are observationally or astrophysically significant.
The A=24–119 result remains a prescribed-PRIMAT-bath reduced-graph validation.

The exact zero outer-boundary difference is expected from the strictly forward acyclic graph:
states above the truncation cannot feed back to A≤119. It is therefore an implementation
consistency check, not a separate demonstration of full heavy-network physical closure.
