@echo off
setlocal
cd /d "%~dp0"
"D:\Downloads\ChatGPT\cptg-cmb-like\Scripts\python.exe" -u SOURCE\adopt_qualified_authorities.py
exit /b %ERRORLEVEL%
