# CPTG PRIMAT Native Boundary-Flux A=1–119 Final Evidence Validation — r06

This is the **final production/evidence package** for the new PRIMAT-anchored A=1–119 test.

Numerical authority has already been qualified by r05:

```text
positive method observed order: 1.9893052170027505
backward Euler observed order:   0.9756787775007231
continuum cross-method max rel:  0.002068089097851021
positive 256 residual to limit:  0.0006410375374877353
qualified production refinement: 256
```

The actual r05 JSON file on your machine is re-read and independently checked before r06
is allowed to run. No r05 endpoint arrays are imported.

Frozen PRIMAT trajectory authority:

```text
97fd7b4f4f4e7466be9e45be264e62faade5b55e80d415201ed4390405080f9a
```

## Windows workflow

After extracting the package:

```cmd
cd /d D:\Downloads\CPTG_PRIMAT_NativeBoundaryFlux_A1A119_FinalEvidenceValidation_20260818_r06
RUN_STATIC_VERIFY_WINDOWS.cmd
RUN_ADOPT_QUALIFIED_AUTHORITIES_WINDOWS.cmd
RUN_TRANSPORT_SELFTEST_WINDOWS.cmd
RUN_FINAL_VALIDATION_WINDOWS.cmd
RUN_FINALIZE_WINDOWS.cmd
EXPORT_FINAL_EVIDENCE_WINDOWS.cmd
```

### Static verification

Required:

```text
PACKAGE_MANIFEST 18/18 PASS
R06_FINAL_STATIC_VERIFY PASS
```

### Authority adoption

Required:

```text
R06_FINAL_AUTHORITY_ADOPTION PASS
NATIVE_FREEZE_SHA256 97fd7b4f4f4e7466be9e45be264e62faade5b55e80d415201ed4390405080f9a
R05_RESULT_SHA256 <sha256>
PRODUCTION_REFINEMENT 256
NATIVE_TRAJECTORY_REGENERATED False
R05_ENDPOINT_ARRAYS_IMPORTED False
HISTORICAL_POSTSILICON_NUMERICAL_INPUTS 0
```

### Transport selftest

Required:

```text
R04_POSITIVE_TRANSPORT_CORE_SELFTEST PASS
```

### Final six-anchor run

```cmd
RUN_FINAL_VALIDATION_WINDOWS.cmd
```

Every anchor must report `PASS`, followed by:

```text
R06_FINAL_SIXANCHOR_TRANSPORT_VALIDATION PASS
```

### Finalization

```cmd
RUN_FINALIZE_WINDOWS.cmd
```

Required ending:

```text
R06_PRIMAT_A1A119_FINAL_VALIDATION PASS
NATIVE_MAX_A 23
BOUNDARY_SOURCE_EDGES 14
EXTERNAL_SPECIES_A160 2927
PRODUCTION_REFINEMENT 256
GAP_FREE_STRUCTURAL_A24_A119 True
POSITIVE_EXTERNAL_SUPPORT_A24_A119_ALL_ETAS True
HISTORICAL_POSTSILICON_NUMERICAL_INPUTS 0
```

This produces:

```text
RESULTS\A1_A119_SIXANCHOR_REGISTER.csv
RESULTS\A1_A119_CENTRAL_AND_ENVELOPE.csv
PAPER_DATA\PRIMAT_A1A119_FINAL_RESULTS.tex
PAPER_DATA\PRIMAT_A1A119_FINAL_RESULTS.md
```

### Final evidence archive

```cmd
EXPORT_FINAL_EVIDENCE_WINDOWS.cmd
```

Required:

```text
R06_FINAL_EVIDENCE_EXPORT PASS
ZIP D:\Downloads\CPTG_PRIMAT_A1A119_FINAL_EVIDENCE_<timestamp>.zip
SHA256 <sha256>
```

Upload that final evidence ZIP. The paper should then be revised only from the new r06
results and its paper-data files.
