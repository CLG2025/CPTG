# r06 Final PRIMAT A=1–119 Evidence Validation Protocol

## Authority chain

This final run is allowed only after:

1. fresh six-anchor PRIMAT v0.3.2 native trajectories passed and were frozen;
2. r02 failed its original coarse-resolution convergence gate;
3. r03 rejected Crank-Nicolson for loss of abundance positivity;
4. r04 demonstrated systematic convergence of two positive stiff schemes but did not reach
   its frozen resolution ceiling;
5. r05 established asymptotic convergence and mutually consistent independent continuum
   estimates, qualifying 256 substeps for production.

No earlier failed/not-qualified decision is altered.

## Final scientific object

A<=23 is supplied by the frozen native PRIMAT trajectory authority.

The external A>=24 graph is reconstructed fresh from pynucastro ReacLib 2.11.0 using the
same preregistered radiative light-particle capture and beta-minus rules. The prescribed
PRIMAT light bath is n, p, D, T, He-3, and He-4.

There is no Si-30 seed, abundance floor, historical post-silicon trajectory, imported
A=31-119 result vector, or inherited rate register.

## Final numerical authority

Production:
- positive exponential-inflow triangular method
- 256 substeps

Verification:
- triangular backward Euler at 256, reported as a raw cross-method diagnostic
- r05 independent generalized-Richardson continuum agreement remains the numerical
  qualification authority.

## Final gates

All six eta10 anchors must:

- expose exactly 14 native-to-external boundary source edges;
- reconstruct the A<=160 external graph with 2927 species;
- remain finite and non-negative;
- have structural reachability in every mass sector A=24..119;
- have strictly positive source-normalized support in every mass sector A=24..119;
- preserve exact zero-source behavior;
- preserve half/double source linearity to 1e-10;
- reconstruct absolute from normalized transport to 1e-10;
- remain invariant through A=119 when the outer graph is independently truncated at
  Amax=128, 140, and 160, to 1e-10.

The final package then constructs the combined six-anchor A=1..119 register and paper-facing
data files.

## Claim boundary

The A=24..119 result is a prescribed-PRIMAT-bath reduced-graph reachability/transport
validation. It is not a claim that PRIMAT natively evolves a heavy reaction network through
A=119.
