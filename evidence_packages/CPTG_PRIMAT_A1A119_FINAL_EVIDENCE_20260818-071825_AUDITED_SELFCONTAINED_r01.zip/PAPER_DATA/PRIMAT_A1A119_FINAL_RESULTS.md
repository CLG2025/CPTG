# PRIMAT A=1–119 Final Paper Data

- Final validation: **PASS**
- Native PRIMAT frontier: **A=23**
- External boundary-source edges: **14**
- A≤160 external graph species: **2927**
- Qualified production resolution: **256 substeps**
- Positive-method observed order: `1.9893052170027505`
- Backward-Euler observed order: `0.9756787775007231`
- Independent continuum cross-method maximum relative difference: `0.002068089097851021`
- 256-step positive-method residual to its Richardson continuum estimate: `0.0006410375374877353`
- Final outer-boundary maximum relative difference through A=119: `0.0`
- Gap-free structural A=24–119 reachability: **PASS**
- Positive normalized external support A=24–119 at all six anchors: **PASS**
- Historical post-silicon numerical inputs: **0**
- Artificial seed/floor: **none**

Claim boundary: A≤23 is native PRIMAT authority. A=24–119 is a prescribed-PRIMAT-bath reduced-graph transport validation, not native PRIMAT heavy-network coverage.
