from pathlib import Path
import zipfile, hashlib, json

ROOT = Path(__file__).resolve().parents[1]
lock = json.loads((ROOT/'AUTHORITY_LOCK.json').read_text(encoding='utf-8'))
evidence = ROOT/'EVIDENCE'/lock['authoritative_evidence_filename']

def sha256_file(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''):
            h.update(chunk)
    return h.hexdigest()

def fail(label):
    print(label, 'FAIL')
    raise SystemExit(1)

if sha256_file(evidence) != lock['authoritative_evidence_sha256']:
    fail('AUTHORITY_EVIDENCE_ARCHIVE_SHA256')
print('AUTHORITY_EVIDENCE_ARCHIVE_SHA256 PASS')

with zipfile.ZipFile(evidence,'r') as z:
    names=z.namelist()
    if not names: fail('AUTHORITY_EVIDENCE_ARCHIVE_CONTENT')
    top=names[0].split('/')[0]
    def b(rel): return z.read(f'{top}/{rel}')
    def t(rel): return b(rel).decode('utf-8')

    manifest=t('MANIFEST.sha256')
    if '\\n' in manifest:
        fail('AUTHORITY_NESTED_MANIFEST_LITERAL_ESCAPE')
    lines=[ln for ln in manifest.splitlines() if ln.strip()]
    good=0
    for ln in lines:
        expected, rel = ln.split(None,1)
        rel=rel.strip()
        try:
            data=b(rel)
        except KeyError:
            fail('AUTHORITY_NESTED_MANIFEST')
        if hashlib.sha256(data).hexdigest()!=expected:
            fail('AUTHORITY_NESTED_MANIFEST')
        good += 1
    if good != lock['authoritative_evidence_manifest_entries']:
        fail('AUTHORITY_NESTED_MANIFEST_COUNT')
    print(f'AUTHORITY_NESTED_MANIFEST {good}/{good} PASS')

    prereg=b('CONFIG/FROZEN_RADIATION_PREREGISTRATION.json')
    mapping=b('CONFIG/FROZEN_RADIATION_MAPPING.json')
    result_b=b('RESULTS/A7_FULL_RADIATION_VALIDATION.json')
    audit_b=b('EVIDENCE/FINAL_AUDIT.json')
    result=json.loads(result_b)
    audit=json.loads(audit_b)
    decision=t('DECISION.txt').strip()

    if hashlib.sha256(prereg).hexdigest()!=lock['preregistration_sha256']:
        fail('AUTHORITY_PREREGISTRATION_SHA256')
    print('AUTHORITY_PREREGISTRATION_SHA256 PASS')

    if hashlib.sha256(mapping).hexdigest()!=lock['frozen_radiation_mapping_sha256']:
        fail('AUTHORITY_MAPPING_SHA256')
    print('AUTHORITY_MAPPING_SHA256 PASS')

    if hashlib.sha256(result_b).hexdigest()!=lock['final_result_sha256']:
        fail('AUTHORITY_FINAL_RESULT_SHA256')
    print('AUTHORITY_FINAL_RESULT_SHA256 PASS')

    if hashlib.sha256(audit_b).hexdigest()!=lock['final_audit_sha256']:
        fail('AUTHORITY_FINAL_AUDIT_SHA256')
    print('AUTHORITY_FINAL_AUDIT_SHA256 PASS')

    if result.get('decision')!='PASS' or audit.get('decision')!='PASS' or decision != lock['decision']:
        fail('AUTHORITY_SCIENTIFIC_DECISION')
    print('AUTHORITY_SCIENTIFIC_DECISION PASS')

    gates=result.get('gates',{})
    if len(gates)!=lock['required_gate_count'] or not all(gates.values()):
        fail('AUTHORITY_REQUIRED_GATES')
    print(f"AUTHORITY_REQUIRED_GATES {len(gates)}/{len(gates)} PASS")

    if result.get('mapping_sha256') != lock['frozen_radiation_mapping_sha256']:
        fail('AUTHORITY_RESULT_MAPPING_BINDING')
    print('AUTHORITY_RESULT_MAPPING_BINDING PASS')

    if result.get('prereg_sha256') != lock['preregistration_sha256'] or audit.get('prereg_sha256') != lock['preregistration_sha256']:
        fail('AUTHORITY_RESULT_PREREG_BINDING')
    print('AUTHORITY_RESULT_PREREG_BINDING PASS')

print('A7_PRIMAT_FULL_RADIATION_AUTHORITY_LOCK PASS')
