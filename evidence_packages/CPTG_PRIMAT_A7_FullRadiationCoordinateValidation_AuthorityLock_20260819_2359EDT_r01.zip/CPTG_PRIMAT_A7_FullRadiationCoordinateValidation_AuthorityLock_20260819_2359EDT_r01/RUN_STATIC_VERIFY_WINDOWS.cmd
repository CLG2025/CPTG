@echo off
setlocal
cd /d "%~dp0"
set "PYTHONUTF8=1"
set "PYTHONIOENCODING=utf-8"
where python >nul 2>nul
if errorlevel 1 (
  echo PYTHON_NOT_FOUND FAIL
  exit /b 1
)
python SOURCE\static_verify.py
if errorlevel 1 exit /b 1
exit /b 0
