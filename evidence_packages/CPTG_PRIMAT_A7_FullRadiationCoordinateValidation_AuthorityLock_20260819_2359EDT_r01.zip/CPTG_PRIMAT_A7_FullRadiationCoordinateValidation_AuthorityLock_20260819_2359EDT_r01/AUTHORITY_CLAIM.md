# PRIMAT A=7 Full Radiation-Coordinate Authority Lock

**Status:** AUTHORITATIVE  
**Network:** PRIMAT v0.3.2  
**Decision:** `A7_PRIMAT_FULL_RADIATION_COORDINATE_VALIDATION PASS`

## Authoritative evidence

`CPTG_PRIMAT_A7_FullRadiationCoordinateValidation_20260819_2344EDT_r05_FINAL_EVIDENCE.zip`

SHA-256: `9c44543cd2497e72170c0a64173423c9b3bf2f1f3924c9d4e77c16a318fb8b4c`

The embedded FINAL_EVIDENCE archive is the sole scientific evidence recognized by this authority lock.

## Frozen authority bindings

- Preregistration SHA-256: `ab38b8c5bdb435b6c311e9b5e0fe31bca1c06ec67d2dc3e4a92098f255425162`
- Frozen radiation mapping SHA-256: `f4e1b0b4e4df47914da9f904d544565ac61a5687879c536560ec8c004b7cbe16`
- Final result SHA-256: `34c0dfdf44d5917ba44d2253c59195dfe258ae4d4de1adf3db6870eafc993626`
- Final audit SHA-256: `847f73fe9aa392cfe13ca61135b9570c20b09015caae2ef261de94e8519b7e14`
- Evidence manifest entries: `40`
- Required scientific gates: `23/23 PASS`

## Scientific claim boundary

PRIMAT v0.3.2 natively validates the joint CPTG transported baryon and radiation coordinate under the frozen prospective protocol. At that full coordinate, the locked live A=7 Li7/Be7 transport reproduces the `1/pi` survival law within preregistered tolerance while preserving D/H, YPBBN, He3/H, and Neff within all preregistered gates.

This lock does not enlarge the claim beyond the tested PRIMAT configuration and preregistered A=7 transport experiment.
