@echo off
setlocal
cd /d "%~dp0"
python -m pip install -r 02_CODE\requirements.txt || exit /b 1
python 02_CODE\reconstruct_accept_400.py || exit /b 1
python 02_CODE\replay_accept_final.py || exit /b 1
python 02_CODE\verify_accept_reproduction.py || exit /b 1
endlocal
