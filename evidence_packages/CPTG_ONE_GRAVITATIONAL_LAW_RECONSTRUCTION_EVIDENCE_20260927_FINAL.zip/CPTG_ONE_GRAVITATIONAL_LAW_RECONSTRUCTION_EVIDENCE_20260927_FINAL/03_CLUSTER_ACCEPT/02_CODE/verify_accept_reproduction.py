#!/usr/bin/env python3
from pathlib import Path
import json, sys
import numpy as np
import pandas as pd

BASE = Path(__file__).resolve().parents[1]
REF = BASE / '03_REFERENCE_FINAL'
REP = BASE / 'REPRODUCED' / 'FINAL_400'
if not REP.exists():
    raise SystemExit('REPRODUCED/FINAL_400 missing')

a = pd.read_csv(REF/'CPTG_ACCEPT_PRECISION_FINAL_SUMMARY.csv').sort_values('cluster').reset_index(drop=True)
b = pd.read_csv(REP/'CPTG_ACCEPT_PRECISION_FINAL_SUMMARY.csv').sort_values('cluster').reset_index(drop=True)
cols = ['N_fit','kappa_kpc','A_C','c_C','chi2_cov','reduced_chi2_cov',
        'median_abs_diag_sigma','max_abs_diag_sigma']
mr = {}
for c in cols:
    aa = a[c].to_numpy(float)
    bb = b[c].to_numpy(float)
    mr[c] = float(np.max(np.abs(aa-bb)/np.maximum(np.abs(aa),1e-300)))

field_ref = float(np.max(np.abs(a['max_abs_field_residual'].to_numpy(float))))
field_rep = float(np.max(np.abs(b['max_abs_field_residual'].to_numpy(float))))
status = (
    mr['N_fit'] == 0.0 and
    mr['kappa_kpc'] < 1e-7 and
    mr['A_C'] < 1e-7 and
    mr['c_C'] < 1e-7 and
    mr['chi2_cov'] < 1e-10 and
    mr['reduced_chi2_cov'] < 1e-10 and
    mr['median_abs_diag_sigma'] < 1e-7 and
    mr['max_abs_diag_sigma'] < 1e-7 and
    field_ref < 1e-18 and field_rep < 1e-18
)

ra = json.loads((REF/'AGGREGATE.json').read_text())
rb = json.loads((REP/'AGGREGATE.json').read_text())
for k in ['total_points','dof']:
    status = status and ra[k] == rb[k]
for k in ['chi2','reduced_chi2','pooled_median_frac_sigma',
          'pooled_median_abs_diag_sigma','max_abs_diag_sigma']:
    status = status and np.isclose(float(ra[k]),float(rb[k]),rtol=1e-10,atol=1e-25)
status = status and abs(float(ra['max_abs_field_residual'])) < 1e-18
status = status and abs(float(rb['max_abs_field_residual'])) < 1e-18

r = BASE/'REPRODUCTION_CHECK.txt'
with r.open('w', encoding='utf-8') as f:
    f.write('CPTG ACCEPT 400-DRAW NUMERICAL RECONSTRUCTION\n')
    f.write('status = '+('PASS' if status else 'FAIL')+'\n')
    for k,v in mr.items():
        f.write(f'max_relative_difference_{k} = {v:.16e}\n')
    f.write(f'reference_max_abs_field_residual_m_s2 = {field_ref:.16e}\n')
    f.write(f'reproduced_max_abs_field_residual_m_s2 = {field_rep:.16e}\n')
    f.write('reference_aggregate = '+json.dumps(ra,sort_keys=True)+'\n')
    f.write('reproduced_aggregate = '+json.dumps(rb,sort_keys=True)+'\n')
print(r.read_text(encoding='utf-8'),end='')
if not status:
    sys.exit(2)
