from concurrent.futures import ProcessPoolExecutor, as_completed
import numpy as np, pandas as pd, sys
from pathlib import Path
BASE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(BASE/'02_CODE'))
import accept_cptg_precision_forward_support as m

def main():
    profiles=BASE/'01_INPUTS/ACCEPT_all_profiles.dat'
    source=BASE/'01_INPUTS/ACCEPT_FIXED_BARYONIC_SOURCE_GRID.csv'
    out=BASE/'REPRODUCED/RECON_400'; out.mkdir(parents=True,exist_ok=True)
    recs={}
    with ProcessPoolExecutor(max_workers=7) as ex:
        futs={ex.submit(m.reconstruct_one,str(profiles),str(source),cl,400,20260930+1009*j):cl for j,cl in enumerate(m.CLUSTERS)}
        for f in as_completed(futs):
            r=f.result(); recs[r['cluster']]=r; print('DONE',r['cluster'],r['mc_valid'])
    for cl,r in recs.items():
        np.savez_compressed(out/f'{cl}.npz',r_kpc=r['r_kpc'],g=r['g'],g_domain=r['g_domain'],cov_total=r['cov_total'],cov_stat=r['cov_stat'],sig_stat=r['sig_stat'],sig_total=r['sig_total'],model_delta=r['model_delta'])
        r['source_rows'].to_csv(out/f'{cl}_source.csv',index=False)
    rows=[]
    for cl in m.CLUSTERS:
        r=recs[cl]
        rows.append(dict(cluster=cl,N=len(r['r_kpc']),pressure_redchi_full=r['pressure_redchi_full'],pressure_redchi_domain=r['pressure_redchi_domain'],mc_valid=r['mc_valid'],shrinkage=r['lw_shrinkage'],median_frac_stat=float(np.median(r['sig_stat']/r['g'])),median_frac_total=float(np.median(r['sig_total']/r['g'])),max_frac_total=float(np.max(r['sig_total']/r['g'])),max_pf=r['max_pf_science'],rho_clip=r['rho_clip_count']))
    pd.DataFrame(rows).to_csv(out/'RECON_SUMMARY.csv',index=False)
    print(pd.DataFrame(rows).to_string(index=False))

if __name__=='__main__':
    main()
