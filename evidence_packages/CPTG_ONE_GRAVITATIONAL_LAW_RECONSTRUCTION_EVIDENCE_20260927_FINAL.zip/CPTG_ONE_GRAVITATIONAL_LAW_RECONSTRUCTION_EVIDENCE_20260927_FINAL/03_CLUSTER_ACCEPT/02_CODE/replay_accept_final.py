#!/usr/bin/env python3
"""Replay the authoritative ACCEPT final CPTG coordinates on reconstructed support/covariance."""
from pathlib import Path
import json, sys
import numpy as np
import pandas as pd
from scipy.linalg import cholesky, solve_triangular

BASE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BASE/'02_CODE'))
import accept_cptg_precision_forward_support as m

REF = BASE/'03_REFERENCE_FINAL'
RECON = BASE/'REPRODUCED'/'RECON_400'
OUT = BASE/'REPRODUCED'/'FINAL_400'
OUT.mkdir(parents=True, exist_ok=True)
(OUT/'covariance').mkdir(exist_ok=True)
reference = pd.read_csv(REF/'CPTG_ACCEPT_PRECISION_FINAL_SUMMARY.csv').set_index('cluster')

rows=[]
points=[]
for cl in m.CLUSTERS:
    z=np.load(RECON/f'{cl}.npz')
    ss=pd.read_csv(RECON/f'{cl}_source.csv')
    rr=reference.loc[cl]
    r=z['r_kpc']*m.KPC_M
    aa=z['g']
    cov=z['cov_total']
    sig=np.sqrt(np.diag(cov))
    gb=ss.g_baryon_m_s2.to_numpy(float)
    support=m.build_support_state(r,aa,sig)
    s2=support['Sigma2_raw']
    mask=np.isfinite(s2)&(s2>=0)&(s2<=1)
    idx=np.where(mask)[0]
    C=cov[np.ix_(idx,idx)]
    C=(C+C.T)/2
    mine=float(np.min(np.linalg.eigvalsh(C)))
    if mine<=0:
        C=C+np.eye(len(C))*(abs(mine)+1e-30)
    L=cholesky(C,lower=True,check_finite=False)
    kappa=float(rr.kappa_kpc); A=float(rr.A_C); c=float(rr.c_C)
    Bfull=m.bpol_from_support(r,support,kappa)
    gm,S=m.solve_implicit(gb[idx],aa[idx],s2[idx],Bfull[idx],A,c)
    if gm is None:
        raise SystemExit(f'implicit solve failed for {cl}')
    wr=solve_triangular(L,gm-aa[idx],lower=True,check_finite=False)
    diag=(gm-aa[idx])/np.sqrt(np.diag(C))
    a23=np.maximum(aa[idx],m.EPS)**(2/3)
    field=(1+c*s2[idx])*gm-gb[idx]-A*a23*Bfull[idx]*S
    N=len(idx); dof=N-3
    frac=z['sig_total']/z['g']
    rows.append(dict(
        cluster=cl,N_fit=N,rmin_kpc=float(z['r_kpc'][idx].min()),rmax_kpc=float(z['r_kpc'][idx].max()),
        median_frac_sigma_total=float(np.median(frac[idx])),kappa_kpc=kappa,A_C=A,c_C=c,
        A_kappa23=A*kappa**(2/3),chi2_cov=float(wr@wr),dof=dof,reduced_chi2_cov=float((wr@wr)/dof),
        median_abs_diag_sigma=float(np.median(np.abs(diag))),max_abs_diag_sigma=float(np.max(np.abs(diag))),
        max_abs_field_residual=float(np.max(np.abs(field))),Sigma2_min=float(np.min(s2[idx])),
        Sigma2_median=float(np.median(s2[idx])),Sigma2_max=float(np.max(s2[idx]))))
    for q,j in enumerate(idx):
        points.append(dict(cluster=cl,radius_kpc=z['r_kpc'][j],g_baryon_m_s2=gb[j],
            g_ACCEPT_support_m_s2=aa[j],sigma_total_m_s2=z['sig_total'][j],fractional_sigma_total=frac[j],
            g_CPTG_m_s2=gm[q],diag_residual_sigma=diag[q],whitened_residual_component=wr[q],
            field_residual=field[q],Sigma_C_squared=s2[j],B_pol=Bfull[j],Sigma_g=S[q],
            kappa_kpc=kappa,A_C=A,c_C=c))
    pd.DataFrame(C,index=z['r_kpc'][idx],columns=z['r_kpc'][idx]).to_csv(OUT/'covariance'/f'{cl}_support_covariance.csv')

sdf=pd.DataFrame(rows)
pdf=pd.DataFrame(points)
sdf.to_csv(OUT/'CPTG_ACCEPT_PRECISION_FINAL_SUMMARY.csv',index=False)
pdf.to_csv(OUT/'CPTG_ACCEPT_PRECISION_FINAL_POINTS.csv',index=False)
agg=dict(total_points=int(sdf.N_fit.sum()),chi2=float(sdf.chi2_cov.sum()),dof=int(sdf.dof.sum()))
agg['reduced_chi2']=agg['chi2']/agg['dof']
agg['pooled_median_frac_sigma']=float(np.median(pdf.fractional_sigma_total))
agg['pooled_median_abs_diag_sigma']=float(np.median(np.abs(pdf.diag_residual_sigma)))
agg['max_abs_diag_sigma']=float(np.max(np.abs(pdf.diag_residual_sigma)))
agg['max_abs_field_residual']=float(np.max(np.abs(pdf.field_residual)))
(OUT/'AGGREGATE.json').write_text(json.dumps(agg,indent=2)+'\n')
print(json.dumps(agg,indent=2))
