#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, math, os, shutil, json
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor, as_completed

import numpy as np
import pandas as pd
from scipy.interpolate import UnivariateSpline
from scipy.optimize import least_squares, brentq
from scipy.linalg import cholesky, solve_triangular
from scipy.stats import norm
from sklearn.covariance import LedoitWolf

KPC_M=3.085677581491367e19
MPC_M=KPC_M*1e3
MP_KG=1.67262192369e-27
MU=0.60
Z90=float(norm.ppf(0.95))
EPS=1e-300
P_INNER=123.0/50.0
P_OUTER=11.0/50.0
SUPP_AT_ONE=2.0**(-P_OUTER)
KAPPA_MIN,KAPPA_MAX=1e-4,1e7
A_MIN,A_MAX=1e-30,1e5
C_MIN,C_MAX=1e-10,1e5

CLUSTERS={
 'A85':'ABELL_0085','A644':'ABELL_0644','A1795':'ABELL_1795',
 'A2029':'ABELL_2029','A2142':'ABELL_2142','A2319':'ABELL_2319','ZW1215':'ZWCL_1215'
}
COLS=['Name','Rin','Rout','ne','neerr','Kitpl','Kflat','Kerr','Pitpl','Pflat','Perr','Mgrav','Merr','Tx','Txerr','Lambda','tcool52','t52err','tcool32','t32err']

def sha256(p:Path):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1<<20),b''):h.update(b)
    return h.hexdigest()

def gnfw_fit_log(x, lp, slp, th0=None):
    x=np.asarray(x,float); lp=np.asarray(lp,float); slp=np.asarray(slp,float)
    r=np.exp(x); rmed=float(np.exp(np.median(x)))
    def unpack(th):
        lnP0,lnrprel,lnalpha,qgamma,lndelta=th
        rp=rmed*np.exp(lnrprel); alpha=np.exp(lnalpha)
        gamma=2/(1+np.exp(-qgamma)); beta=gamma+np.exp(lndelta)
        return lnP0,rp,alpha,gamma,beta
    def model(th, rr=r):
        lnP0,rp,a,g,b=unpack(th)
        lnu=np.log(rr/rp); z=a*lnu
        return lnP0-g*lnu-((b-g)/a)*np.logaddexp(0,z)
    if th0 is None: th0=np.array([np.median(lp),0.0,0.0,-3.0,np.log(1.5)])
    lo=np.array([lp.min()-10,-5,np.log(.15),-12,np.log(.1)])
    hi=np.array([lp.max()+10, 5,np.log(10), 12,np.log(10)])
    res=least_squares(lambda th:(model(th)-lp)/slp,th0,bounds=(lo,hi),max_nfev=700,
                      xtol=1e-10,ftol=1e-10,gtol=1e-10)
    return res,res.x,unpack(res.x)

def gnfw_eval(theta,xobs,xt):
    rmed=float(np.exp(np.median(xobs))); rr=np.exp(xt)
    lnP0,lnrprel,lnalpha,qgamma,lndelta=theta
    rp=rmed*np.exp(lnrprel); a=np.exp(lnalpha); g=2/(1+np.exp(-qgamma)); b=g+np.exp(lndelta)
    lnu=np.log(rr/rp); z=a*lnu
    lp=lnP0-g*lnu-((b-g)/a)*np.logaddexp(0,z)
    frac=1/(1+np.exp(-z)); slope=-g-(b-g)*frac
    return lp,slope,(rp,a,g,b)

def load_master(path:Path):
    df=pd.read_csv(path,sep=r'\s+',comment='#',names=COLS)
    df['r_Mpc']=0.5*(df.Rin+df.Rout)
    return df

def reconstruct_one(master_path, source_path, cluster, draws, seed):
    master=load_master(Path(master_path))
    src=pd.read_csv(source_path)
    nm=CLUSTERS[cluster]
    d=master[master.Name==nm].sort_values('r_Mpc').reset_index(drop=True)
    ss=src[src.cluster==cluster].sort_values('radius_kpc').reset_index(drop=True)
    if len(d)<10 or len(ss)<6: raise RuntimeError(f'{cluster}: insufficient rows')
    rfull=d.r_Mpc.to_numpy(float)*MPC_M
    rsrc=ss.radius_kpc.to_numpy(float)*KPC_M
    # No extrapolation: one raw-bin guard on each side for derivative evaluation.
    target=(rsrc>=rfull[1])&(rsrc<=rfull[-2])
    sst=ss.loc[target].reset_index(drop=True)
    rt=sst.radius_kpc.to_numpy(float)*KPC_M
    if len(rt)<6: raise RuntimeError(f'{cluster}: too little ACCEPT/source overlap')

    # Directly constrained science region has Pitpl == Pflat for all seven systems.
    sci_raw=(rfull>=rt.min())&(rfull<=rt.max())
    max_pf=float(np.max(np.abs(d.loc[sci_raw,'Pitpl'].to_numpy()-d.loc[sci_raw,'Pflat'].to_numpy())/
                        np.maximum(d.loc[sci_raw,'Pitpl'].to_numpy(),EPS)))

    # Full-profile primary forward fit.
    P=d['Pitpl'].to_numpy(float)*0.1; ne=d['ne'].to_numpy(float)*1e6; T=d['Tx'].to_numpy(float)
    sP=d['Perr'].to_numpy(float)/Z90*0.1; sne=d['neerr'].to_numpy(float)/Z90*1e6; sT=d['Txerr'].to_numpy(float)/Z90
    slp=np.maximum(sP/np.maximum(P,EPS),1e-6); sln=np.maximum(sne/np.maximum(ne,EPS),1e-6); slt=np.maximum(sT/np.maximum(T,EPS),1e-6)
    x=np.log(rfull); lp=np.log(P); ln=np.log(ne); xt=np.log(rt)
    pres,th0,pars=gnfw_fit_log(x,lp,slp)
    p_redchi=float(np.sum(pres.fun**2)/max(1,len(x)-5))
    nspl=UnivariateSpline(x,ln,w=1/sln,s=float(len(x)),k=min(3,len(x)-1))
    lpf,slope,_=gnfw_eval(th0,x,xt); lnf=nspl(xt)
    gnom=-(np.exp(lpf)/(MU*MP_KG*np.exp(lnf)*rt))*slope
    if np.any(~np.isfinite(gnom)) or np.any(gnom<=0): raise RuntimeError(f'{cluster}: nonpositive primary support')

    # Overlap-domain fit used only as a model-dependence sensitivity vector.
    il=max(0,int(np.searchsorted(rfull,rt.min())-2)); ih=min(len(rfull),int(np.searchsorted(rfull,rt.max(),side='right')+2))
    xd=x[il:ih]; lpd0=lp[il:ih]; slpd=slp[il:ih]; lnd0=ln[il:ih]; slnd=sln[il:ih]
    dres,dth,dpars=gnfw_fit_log(xd,lpd0,slpd)
    d_redchi=float(np.sum(dres.fun**2)/max(1,len(xd)-5))
    dnspl=UnivariateSpline(xd,lnd0,w=1/slnd,s=float(len(xd)),k=min(3,len(xd)-1))
    dlpf,dslope,_=gnfw_eval(dth,xd,xt); dlnf=dnspl(xt)
    gdomain=-(np.exp(dlpf)/(MU*MP_KG*np.exp(dlnf)*rt))*dslope
    delta_model=gnom-gdomain

    # Within-bin P-ne covariance inferred from log P = log ne + log T and quoted errors.
    covPn=.5*(slp**2+sln**2-slt**2)
    rho_raw=covPn/np.maximum(slp*sln,EPS)
    rho=np.clip(rho_raw,-.98,.98)
    rho_clip_count=int(np.sum(np.abs(rho-rho_raw)>1e-12))

    rng=np.random.default_rng(seed)
    G=np.empty((draws,len(rt)),float)
    valid=0
    for z in range(draws):
        z1=rng.normal(size=len(x)); z2=rng.normal(size=len(x))
        lpd=lp+slp*z1
        lnd=ln+sln*(rho*z1+np.sqrt(np.maximum(1-rho*rho,0))*z2)
        try:
            rr,thd,_=gnfw_fit_log(x,lpd,slp,th0)
            nd=UnivariateSpline(x,lnd,w=1/sln,s=float(len(x)),k=min(3,len(x)-1))
            ll,sl,_=gnfw_eval(thd,x,xt)
            gd=-(np.exp(ll)/(MU*MP_KG*np.exp(nd(xt))*rt))*sl
            if np.all(np.isfinite(gd)) and np.all(gd>0):
                G[valid]=gd; valid+=1
        except Exception:
            pass
    if valid<max(100,draws//2): raise RuntimeError(f'{cluster}: only {valid}/{draws} MC profiles valid')
    G=G[:valid]
    lw=LedoitWolf().fit(G)
    cov_stat=lw.covariance_
    # If the smooth pressure family is more dispersed than quoted statistical errors,
    # retain that overdispersion conservatively rather than treating it as extra precision.
    cov_stat_scaled=cov_stat*max(1.0,p_redchi)
    # Rank-1 model-domain sensitivity covariance; no fitted coefficient.
    cov_total=cov_stat_scaled+np.outer(delta_model,delta_model)
    sig_stat=np.sqrt(np.diag(cov_stat)); sig_total=np.sqrt(np.diag(cov_total))

    return dict(cluster=cluster, r_kpc=rt/KPC_M, source_rows=sst, g=gnom, g_domain=gdomain,
                cov_total=cov_total,cov_stat=cov_stat,sig_stat=sig_stat,sig_total=sig_total,
                pressure_redchi_full=p_redchi,pressure_redchi_domain=d_redchi,
                pressure_params=pars,pressure_params_domain=dpars,mc_valid=valid,mc_requested=draws,
                lw_shrinkage=float(lw.shrinkage_),rho_clip_count=rho_clip_count,max_pf_science=max_pf,
                model_delta=delta_model)

def build_support_state(r_m,g_obs,sigma_g):
    x=np.log(r_m); y=np.log(np.maximum(g_obs,EPS)); w=np.maximum(g_obs/np.maximum(sigma_g,EPS),EPS)
    spl=UnivariateSpline(x,y,w=w,s=float(len(r_m)),k=min(3,len(r_m)-1))
    gs=np.exp(spl(x)); slope=spl.derivative(1)(x); gp=gs*slope/r_m
    return dict(x=x,g_smooth=gs,slope=slope,gp=gp,Sigma2_raw=(1-slope)/3)

def bpol_from_support(r_m,support,kappa_kpc):
    x=support['x']; g=support['g_smooth']; gp=support['gp']; km=float(kappa_kpc)*KPC_M
    C=g*g+km*km*(gp*gp+2*(g/r_m)**2); Cp=np.maximum(C,EPS)**(-2/3)
    inner=r_m*r_m*km*km*gp*Cp
    spl=UnivariateSpline(x,inner,s=0.0,k=min(3,len(r_m)-1))
    dinner=spl.derivative(1)(x)/r_m
    return ((r_m*r_m+2*km*km)*g*Cp-dinner)/(r_m*r_m)

def solve_implicit(gb,astar,sigma2,B,A,c):
    out=np.empty_like(gb)
    for i in range(len(gb)):
        D=1+c*sigma2[i]; P0=A*(max(astar[i],EPS)**(2/3))*B[i]
        def f(g):
            S=(1+(max(g,EPS)/max(astar[i],EPS))**P_INNER)**(-P_OUTER)
            return D*g-gb[i]-P0*S
        lo=EPS; flo=f(lo); hi=max(1e-15,gb[i],astar[i])*10; fhi=f(hi); n=0
        while flo*fhi>0 and n<40: hi*=10; fhi=f(hi); n+=1
        if flo*fhi>0:return None,None
        out[i]=brentq(f,lo,hi,xtol=1e-22,rtol=1e-12,maxiter=200)
    S=(1+(np.maximum(out,EPS)/np.maximum(astar,EPS))**P_INNER)**(-P_OUTER)
    return out,S
