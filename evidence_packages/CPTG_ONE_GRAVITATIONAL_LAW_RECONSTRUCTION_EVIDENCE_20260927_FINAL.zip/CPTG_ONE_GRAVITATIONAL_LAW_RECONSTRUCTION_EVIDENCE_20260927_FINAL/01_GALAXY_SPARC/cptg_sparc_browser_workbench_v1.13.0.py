#!/usr/bin/env python3

# ========================================================================
# REFERENCE
# ========================================================================
#
# Curvature Polarization Transport Gravity:
# A Unified Geometric Framework for Cosmic Structure and Expansion
#
#   CPTG SPARC Browser Workbench
#
# - Author: Carter L Glass Jr
# - E-mail: carterglass@bellsouth.net
# - ORCID: https://orcid.org/0009-0005-7538-543X
# - GitHub: https://github.com/CLG2025/CPTG
#
# ========================================================================

"""
CPTG SPARC Browser Workbench

Local browser interface for SPARC-style galaxy rotation-curve files.
Locked release v1.13.0 uses the resolved local-a_star CPTG support-conditioned
polarization/transport calculation validated on the SPARC primary sample.

Local-only: data are processed on the machine running this Python script.
"""

from __future__ import annotations

import argparse
import base64
import csv
import datetime as _dt
import html
import json
import math
import re
import sys
import threading
import tempfile
import traceback
import webbrowser
import zipfile
from dataclasses import dataclass
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import parse_qs, urlparse

try:
    import numpy as np
except Exception as exc:  # pragma: no cover
    raise SystemExit("Missing dependency: numpy. Install with: python -m pip install numpy") from exc

try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
except Exception as exc:  # pragma: no cover
    raise SystemExit("Missing dependency: matplotlib. Install with: python -m pip install matplotlib") from exc

try:
    from scipy.interpolate import UnivariateSpline
    from scipy.optimize import least_squares
except Exception as exc:  # pragma: no cover
    raise SystemExit("Missing dependency: scipy. Install with: python -m pip install scipy") from exc

# ----------------------------
# Application/package metadata
# ----------------------------
APP_TITLE = "CPTG SPARC Browser Workbench"
APP_SUBTITLE = "Local CPTG/MOND Rotation-Curve Comparison"
APP_VERSION = "1.13.0"
LOCKED_RELEASE_VERSION = "v1.13.0"
DEFAULT_HOST = "127.0.0.1"
DEFAULT_PORT = 8787
DEFAULT_OUT_DIR = "runs"
DEFAULT_SPARC_DIR_NAME = "sparc_database"
DEFAULT_METADATA_DIR_NAME = "metadata"
COPYRIGHT_YEAR = 2026
COPYRIGHT_AUTHOR = "Carter L Glass Jr"
COPYRIGHT_URL = "https://github.com/CLG2025/CPTG"
CPTG_PLOT_COLOR = "orange"
MOND_PLOT_COLOR = "green"
OUTPUT_DECIMALS = 6
SCIENCE_SAMPLE_MIN_INCLINATION_DEG = 30.0
SCIENCE_SAMPLE_EXCLUDED_Q_FLAGS = {3}

# ----------------------------
# Embedded structured help
# ----------------------------
HELP_HTML_BODY = '\n<section class="help-card">\n  <h2>Using the workbench</h2>\n  <ol>\n    <li>Use the search box to find a galaxy, or scroll through the compact five-column galaxy list.</li>\n    <li>Select one or more galaxy checkboxes. Selected entries are highlighted automatically; the displayed names omit the standard <code>_rotmod.dat</code> suffix.</li>\n    <li>Select an optional metadata file from <code>sparc_database/metadata</code>.</li>\n    <li>Choose <strong>Run selected galaxies</strong>. One selected galaxy produces a single-galaxy result; two or more produce a batch result. Select <strong>Save result files</strong> only when a persistent run folder and downloadable files are required.</li>\n  </ol>\n  <p>All selected data are processed locally. Results are displayed in the browser without being saved by default. A run folder is written only when <strong>Save result files</strong> is selected.</p>\n</section>\n\n<section class="help-card">\n  <h2>Unified galaxy selection</h2>\n  <table>\n    <tr><th>Selection</th><th>Processing behavior</th><th>Result</th></tr>\n    <tr><td>One galaxy</td><td>The selected file is loaded and solved as an individual galaxy.</td><td>Single-galaxy plots and metrics in the browser; optional saved point results, summary, images, and ZIP bundle.</td></tr>\n    <tr><td>Two or more galaxies</td><td>Every galaxy is solved independently before aggregate values and plots are calculated.</td><td>Batch metrics and averaged plots in the browser; optional saved reports, images, and ZIP bundle.</td></tr>\n  </table>\n  <p>The search filter begins with the first character and stays active while matching galaxies are selected. <strong>Select all visible</strong> applies only to rows currently shown by the search filter. <strong>Clear selection</strong> removes all checked galaxies. After a completed run, the search and galaxy-selection fields reset automatically; the selected metadata file remains active until <strong>Reset metadata</strong> is used. Metadata status filtering is compact and appears only when the selected file defines a primary sample.</p>\n</section>\n\n<section class="help-card">\n  <h2>Galaxy input files</h2>\n  <p>Galaxy rotation-curve files may use <code>.dat</code>, <code>.txt</code>, or <code>.csv</code>.</p>\n  <p>Each usable row must contain at least six numeric columns:</p>\n  <table>\n    <tr><th>Column</th><th>Meaning</th></tr>\n    <tr><td>1</td><td>Radius in kpc</td></tr>\n    <tr><td>2</td><td>Observed velocity in km/s</td></tr>\n    <tr><td>3</td><td>Velocity uncertainty in km/s</td></tr>\n    <tr><td>4</td><td>Gas velocity contribution in km/s</td></tr>\n    <tr><td>5</td><td>Disk velocity contribution in km/s</td></tr>\n    <tr><td>6</td><td>Bulge velocity contribution in km/s</td></tr>\n  </table>\n  <p>Blank lines and comment lines beginning with <code>#</code>, <code>;</code>, or <code>//</code> are ignored. Extra columns are allowed and ignored.</p>\n</section>\n\n<section class="help-card">\n  <h2>Metadata and the primary science sample</h2>\n  <p>Metadata is optional. It adds catalog information and can control the primary science sample; it never replaces a galaxy rotation-curve file.</p>\n  <p>Place metadata in <code>sparc_database/metadata</code>. Metadata selectors accept <code>.mrt</code>, <code>.dat</code>, <code>.txt</code>, <code>.csv</code>, <code>.tsv</code>, and <code>.json</code>.</p>\n  <p>When usable primary-sample metadata is selected, <strong>Show</strong> defaults to <strong>Primary</strong>. Only checked galaxies are processed, so choosing <strong>Excluded</strong> or <strong>Unmatched</strong> intentionally runs those visible selections.</p>\n  <p>Galaxy badges use <strong>P</strong> for primary, <strong>X</strong> for outside the primary sample, and <strong>?</strong> for unmatched metadata. Single-galaxy runs remain available for every status.</p>\n  <p>SPARC metadata is commonly distributed as a CDS/VizieR-style <code>.mrt</code> file. Useful fields include:</p>\n  <table>\n    <tr><th>Field</th><th>Use</th></tr>\n    <tr><td>Galaxy</td><td>Matches metadata to the galaxy file name.</td></tr>\n    <tr><td>T</td><td>Catalog morphology type.</td></tr>\n    <tr><td>D</td><td>Distance in Mpc.</td></tr>\n    <tr><td>Inc</td><td>Inclination in degrees.</td></tr>\n    <tr><td>Vflat</td><td>Flat rotation velocity.</td></tr>\n    <tr><td>Q</td><td>Quality flag.</td></tr>\n  </table>\n</section>\n\n<section class="help-card">\n  <h2>CPTG calculation rules — locked v1.13.0</h2>\n  <h3>Physical baryonic source</h3>\n  <pre>Q(V) = V |V|\nVbar² = Q(Vgas) + Q(Vdisk) + Q(Vbulge)\ng_b = Vbar² / r</pre>\n  <p>The v1.13.0 CPTG calculation uses the direct physical baryonic source shown above.</p>\n  <h3>Resolved local structural acceleration</h3>\n  <pre>a_star(r_i) = g_sup(r_i) = Vobs(r_i)² / r_i</pre>\n  <p><code>a_star</code> belongs to the resolved object-state being measured. Every resolved radius receives its own local <code>a_star</code> value from the measured support state at that radius.</p>\n  <h3>Support-state coordinate</h3>\n  <pre>Sigma_C²(r) = (1/3) [1 - d ln(g_sup) / d ln(r)]\n0 &lt;= Sigma_C² &lt;= 1  (numerical admissibility)</pre>\n  <p>The logarithmic support profile is reconstructed with the error-weighted resolved radial spline before the derivative is evaluated.</p>\n  <h3>Spherical polarization carrier</h3>\n  <pre>C_C = g_sup² + kappa_C²[(dg_sup/dr)² + 2(g_sup/r)²]\nB_pol = { (r² + 2 kappa_C²) g_sup C_C^(-2/3)\n          - d/dr[r² kappa_C² (dg_sup/dr) C_C^(-2/3)] } / r²</pre>\n    <h3>Registered high-acceleration suppression</h3>\n  <pre>Sigma_g(r) = [1 + (g_C(r) / a_star(r))^(123/50)]^(-11/50)</pre>\n  <p>The suppression is evaluated on the solved local field. It damps the geometric polarization response as the local solved acceleration rises relative to the local structural acceleration state.</p>\n  <h3>Locked v1.13.0 CPTG radial field</h3>\n  <pre>g_C(r) =\n  [ g_b(r) + A_C a_star(r)^(2/3) B_pol(r) Sigma_g(r) ]\n  / [ 1 + c_C Sigma_C²(r) ]</pre>\n  <p>The field equation is implicit because <code>Sigma_g</code> contains the solved <code>g_C</code>. <code>kappa_C</code>, <code>A_C</code>, and <code>c_C</code> remain the only three galaxy-level reduced fit quantities. The local <code>a_star(r_i)</code> values are calculated directly at each resolved radius and are not fit parameters.</p>\n</section>\n\n<section class="help-card">\n  <h2>MOND comparison rules</h2>\n  <h3>MOND source field</h3>\n  <pre>Q(V) = V |V|\nVbar² = Q(Vgas) + Q(Vdisk) + Q(Vbulge)\ng_b = Vbar² / r</pre>\n  <p>The benchmark MOND acceleration law is:</p>\n  <pre>g_MOND = g_b / (1 - exp(-sqrt(g_b / a0)))\na0 = 1.2e-10 m/s²</pre>\n</section>\n\n<section class="help-card">\n  <h2>Optional saved output files</h2>\n  <h3>Single galaxy</h3>\n  <table>\n    <tr><th>File</th><th>Description</th></tr>\n    <tr><td>point_results.csv</td><td>Per-radius observed, direct baryonic source, local a_star, Sigma_C², Sigma_g, B_pol, CPTG, MOND, acceleration, and residual values.</td></tr>\n    <tr><td>summary.json</td><td>Galaxy-level diagnostics.</td></tr>\n    <tr><td>rotation_curve.png</td><td>Observed, CPTG, MOND, and source rotation-curve plot.</td></tr>\n    <tr><td>rar_scatter_vs_radius.png</td><td>RAR scatter versus radius: <code>log10(g_model / g_obs)</code> by radius for CPTG and MOND.</td></tr>\n    <tr><td>results_bundle.zip</td><td>Complete downloadable bundle of the single-galaxy result files.</td></tr>\n  </table>\n  <h3>Batch</h3>\n  <table>\n    <tr><th>File</th><th>Description</th></tr>\n    <tr><td>batch_galaxy_results.csv</td><td>One row per included solved galaxy.</td></tr>\n    <tr><td>batch_failures.csv</td><td>Files that could not be parsed or solved.</td></tr>\n    <tr><td>batch_metadata_excluded.csv</td><td>Galaxies explicitly outside the primary sample.</td></tr>\n    <tr><td>batch_metadata_unmatched.csv</td><td>Galaxies without a usable metadata match or sample classification.</td></tr>\n    <tr><td>average_rotation_curve.csv</td><td>Average normalized rotation-curve data.</td></tr>\n    <tr><td>average_rotation_curve.png</td><td>Average normalized observed, CPTG, MOND, and source plot.</td></tr>\n    <tr><td>average_rar_scatter_vs_radius.csv</td><td>Average normalized RAR scatter data.</td></tr>\n    <tr><td>average_rar_scatter_vs_radius.png</td><td>Average normalized RAR scatter-versus-radius plot.</td></tr>\n    <tr><td>average_csmi_by_galaxy_type.csv</td><td>Mean, median, and standard deviation of CSMI grouped by solved CPTG mode type.</td></tr>\n    <tr><td>batch_summary.json</td><td>Overall batch diagnostics and output paths.</td></tr>\n    <tr><td>results_bundle.zip</td><td>Complete downloadable bundle of the batch result files.</td></tr>\n  </table>\n</section>\n\n<section class="help-card">\n  <h2>Plot interpretation</h2>\n  <table>\n    <tr><th>Plot item</th><th>Meaning</th></tr>\n    <tr><td>Observed</td><td>Measured SPARC velocity data.</td></tr>\n    <tr><td>CPTG</td><td>Final solved CPTG prediction.</td></tr>\n    <tr><td>MOND</td><td>Final MOND comparison prediction.</td></tr>\n    <tr><td>Baryonic source</td><td>Direct physical gas + disk + bulge source curve. The same physical source is supplied to the v1.13.0 CPTG calculation and the MOND comparator.</td></tr>\n    <tr><td>Observed shaded band</td><td>Cross-galaxy spread in normalized observed curves, not the SPARC measurement-error band.</td></tr>\n  </table>\n  <p>Plots are rendered at <code>1280 × 800</code> and are written to disk only when file saving is selected. CPTG is orange and MOND is green. The RAR plot uses lines without point markers.</p>\n</section>\n\n<section class="help-card">\n  <h2>CSMI and mode type</h2>\n  <p>CSMI is the Curvature Structure Mode Index. It is computed after the CPTG field is solved. It is not a velocity component, mass term, fit parameter, or MOND interpolation quantity.</p>\n  <p>The diagnostic is reported as a structural mode:</p>\n  <pre>N = R / lambda</pre>\n  <p>Batch output groups average CSMI by solved CPTG mode type.</p>\n</section>\n\n<section class="help-card">\n  <h2>Result formatting</h2>\n  <p>Displayed and exported result values use six-decimal formatting. Summary tables include total points, total χ², χ² per point, and mean observed, CPTG, and MOND velocities. Batch mean velocities are point-weighted across included galaxies. Internal calculations retain full precision.</p>\n</section>\n\n<section class="help-card">\n  <h2>Troubleshooting</h2>\n  <table>\n    <tr><th>Issue</th><th>Check</th></tr>\n    <tr><td>No galaxies appear in the list</td><td>Confirm the package-local <code>sparc_database</code> folder contains supported galaxy files, then reload the workbench page.</td></tr>\n    <tr><td>No usable numeric rows</td><td>Confirm that the galaxy file has at least three valid rows and six numeric columns per row.</td></tr>\n    <tr><td>A galaxy is difficult to find</td><td>Enter part of the galaxy name or relative path in the search box.</td></tr>\n    <tr><td>Metadata does not match a galaxy</td><td>Confirm the metadata galaxy identifier matches the rotation-curve file name or file stem.</td></tr>\n    <tr><td>Fewer galaxies appear in batch results</td><td>The <strong>Show</strong> filter controls visibility, while the checked galaxies control processing. Review the compact metadata status counts or the saved metadata reports when needed.</td></tr>\n    <tr><td>Saved plots or output files are missing</td><td>Confirm that <strong>Save result files</strong> was selected before the run, then review any browser error and corresponding batch failure report.</td></tr>\n  </table>\n</section>\n'


def format_result_value(value: Any, decimals: int = OUTPUT_DECIMALS) -> Any:
    """Format numeric report/output values to six decimals without changing internal calculations.

    Ordinary-sized numbers use fixed six-decimal notation. Very small or very
    large values use scientific notation with six digits after the decimal so
    SI accelerations such as local a_star values are not rounded to zero.
    """
    if isinstance(value, np.generic):
        value = value.item()
    if isinstance(value, bool) or value is None:
        return value
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        if math.isnan(value):
            return "nan"
        if math.isinf(value):
            return "inf" if value > 0 else "-inf"
        av = abs(value)
        if av != 0.0 and (av < 1.0e-4 or av >= 1.0e6):
            return f"{value:.{decimals}e}"
        return f"{value:.{decimals}f}"
    return value


def format_csv_row(row: List[Any]) -> List[Any]:
    return [format_result_value(v) for v in row]


def format_csv_dict(row: Dict[str, Any]) -> Dict[str, Any]:
    return {k: format_result_value(v) for k, v in row.items()}


def format_report_object(obj: Any) -> Any:
    """Recursively format numeric values for JSON report files."""
    if isinstance(obj, dict):
        return {k: format_report_object(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [format_report_object(v) for v in obj]
    return format_result_value(obj)


def fmt_html(value: Any) -> str:
    return html.escape(str(format_result_value(value)))


# ----------------------------
# Audited CPTG/MOND constants
# ----------------------------

KPC_TO_M = 3.085677581491367e19
A0_MOND = 1.2e-10


# Locked v1.13.0 reduced-fit search domain.
CPTG_KAPPA_MIN_KPC = 1.0e-4
CPTG_KAPPA_MAX_KPC = 1.0e7
CPTG_A_MIN = 1.0e-30
CPTG_A_MAX = 1.0e5
CPTG_C_MIN = 1.0e-10
CPTG_C_MAX = 1.0e3

# Registered galaxy high-acceleration suppression.
CPTG_SUPPRESSION_INNER_POWER = 123.0 / 50.0
CPTG_SUPPRESSION_OUTER_POWER = 11.0 / 50.0
CPTG_SUPPRESSION_AT_UNIT_RATIO = 2.0 ** (-CPTG_SUPPRESSION_OUTER_POWER)

KAPPA_STRUCT = KPC_TO_M
MIN_POINTS_FOR_STRUCTURE = 1


MODE_TYPE_THRESHOLDS = [
    (1.45, "Dwarf Irregular"),
    (1.75, "Magellanic Irregular"),
    (1.95, "LSB Dwarf Disk"),
    (2.15, "Transition Dwarf"),
    (2.35, "LSB Spiral"),
    (2.55, "Very Late Spiral"),
    (2.80, "Late Spiral"),
    (3.05, "Intermediate Spiral"),
    (3.30, "Early Spiral"),
    (3.55, "Bulged Spiral"),
    (3.72, "Lenticular/Early Disk"),
    (float("inf"), "High-Mode Outlier"),
]

EPS = 1e-30


@dataclass
class GalaxyData:
    name: str
    radius_kpc: np.ndarray
    vobs_km_s: np.ndarray
    errv_km_s: np.ndarray
    vgas_km_s: np.ndarray
    vdisk_km_s: np.ndarray
    vbulge_km_s: np.ndarray
    raw_rows: int
    source_name: str


# ----------------------------
# Input parsing
# ----------------------------


def _clean_name_from_filename(filename: str) -> str:
    stem = Path(filename).stem
    stem = re.sub(r"_rotmod$", "", stem, flags=re.IGNORECASE)
    return re.sub(r"[^A-Za-z0-9_.+-]+", "_", stem).strip("_") or "galaxy"


def _is_number(token: str) -> bool:
    try:
        float(token)
        return True
    except Exception:
        return False


def parse_sparc_dat_text(text: str, filename: str = "uploaded.dat") -> GalaxyData:
    """Parse a SPARC-style rotation-curve file.

    Required first six numeric columns:
      radius_kpc, vobs_km_s, errv_km_s, vgas_km_s, vdisk_km_s, vbulge_km_s
    """
    rows: List[List[float]] = []
    for line in text.splitlines():
        s = line.strip()
        if not s or s.startswith("#") or s.startswith(";") or s.startswith("//"):
            continue
        parts = re.split(r"[\s,]+", s)
        nums = [float(tok) for tok in parts if _is_number(tok)]
        if len(nums) >= 6:
            rows.append(nums[:6])

    if len(rows) < 3:
        raise ValueError(f"{filename}: found {len(rows)} usable numeric rows; expected at least 3 rows with 6 numeric columns.")

    arr = np.array(rows, dtype=float)
    radius = arr[:, 0]
    vobs = arr[:, 1]
    errv = arr[:, 2]
    vgas = arr[:, 3]
    vdisk = arr[:, 4]
    vbulge = arr[:, 5]

    mask = (
        np.isfinite(radius) & np.isfinite(vobs) & np.isfinite(errv)
        & np.isfinite(vgas) & np.isfinite(vdisk) & np.isfinite(vbulge)
        & (radius > 0) & (vobs > 0) & (errv > 0)
    )
    if int(mask.sum()) < 3:
        raise ValueError(f"{filename}: fewer than 3 valid rows after filtering.")

    order = np.argsort(radius[mask])
    return GalaxyData(
        name=_clean_name_from_filename(filename),
        radius_kpc=radius[mask][order],
        vobs_km_s=vobs[mask][order],
        errv_km_s=errv[mask][order],
        vgas_km_s=vgas[mask][order],
        vdisk_km_s=vdisk[mask][order],
        vbulge_km_s=vbulge[mask][order],
        raw_rows=len(rows),
        source_name=filename,
    )


# ----------------------------
# Audited physics functions
# ----------------------------


def signed_square(v: np.ndarray) -> np.ndarray:
    arr = np.asarray(v, dtype=float)
    return arr * np.abs(arr)


def build_physical_baryonic_field(
    r_m: np.ndarray,
    vgas_m_s: np.ndarray,
    vdisk_m_s: np.ndarray,
    vbulge_m_s: np.ndarray,
) -> np.ndarray:
    """Build the locked v1.13.0 direct physical baryonic acceleration field."""
    gas_term = signed_square(vgas_m_s)
    disk_term = signed_square(vdisk_m_s)
    bulge_term = signed_square(vbulge_m_s)
    vb2 = np.maximum(gas_term + disk_term + bulge_term, 0.0)
    return vb2 / np.maximum(r_m, EPS)

def mond_acceleration(gbar_physical: np.ndarray) -> np.ndarray:
    """MOND comparison law applied to the direct physical baryonic source."""
    gbar = np.maximum(np.asarray(gbar_physical, dtype=float), EPS)
    x = np.maximum(gbar / A0_MOND, EPS)
    return gbar / (1.0 - np.exp(-np.sqrt(x)))


def _resolved_spline_degree(n_points: int) -> int:
    """Spline degree valid for the available resolved radial points."""
    return max(1, min(3, int(n_points) - 1))


def resolved_support_state(
    r_m: np.ndarray,
    vobs_m_s: np.ndarray,
    errv_m_s: np.ndarray,
) -> Dict[str, np.ndarray]:
    """Construct the locked v1.13.0 resolved support state.

    For a SPARC rotation-supported ring,

        a_star(r_i) = g_sup(r_i) = V_obs(r_i)^2 / r_i.

    The logarithmic support slope is reconstructed with the same error-weighted
    radial spline used in the validated v1.13.0 scan.  Sigma_C^2 is then evaluated
    locally and restricted to the numerical admissibility interval [0, 1].
    """
    r_m = np.asarray(r_m, dtype=float)
    vobs_m_s = np.asarray(vobs_m_s, dtype=float)
    errv_m_s = np.asarray(errv_m_s, dtype=float)

    if r_m.size < 3:
        raise ValueError("v1.13.0 CPTG requires at least three resolved radial points.")
    if np.any(~np.isfinite(r_m)) or np.any(r_m <= 0.0):
        raise ValueError("Resolved radii must be finite and positive.")
    if np.any(np.diff(r_m) <= 0.0):
        raise ValueError("Resolved radii must be strictly increasing for the v1.13.0 support spline.")

    g_support_observed = (vobs_m_s**2) / np.maximum(r_m, EPS)
    sigma_g = 2.0 * np.abs(vobs_m_s) * np.maximum(errv_m_s, EPS) / np.maximum(r_m, EPS)
    x = np.log(r_m)
    log_g = np.log(np.maximum(g_support_observed, EPS))
    weights = np.maximum(g_support_observed / np.maximum(sigma_g, EPS), EPS)
    degree = _resolved_spline_degree(r_m.size)

    support_spline = UnivariateSpline(
        x,
        log_g,
        w=weights,
        s=float(r_m.size),
        k=degree,
    )
    g_support_smooth = np.exp(support_spline(x))
    log_slope = support_spline.derivative(1)(x)
    dg_dr = g_support_smooth * log_slope / r_m

    sigma_c_squared_raw = (1.0 - log_slope) / 3.0
    sigma_c_squared = np.clip(sigma_c_squared_raw, 0.0, 1.0)

    return {
        "x_log_r": x,
        "g_support_observed": g_support_observed,
        "g_support_smooth": g_support_smooth,
        "sigma_g": sigma_g,
        "log_slope": log_slope,
        "dg_dr": dg_dr,
        "Sigma_C_squared_raw": sigma_c_squared_raw,
        "Sigma_C_squared": sigma_c_squared,
        "a_star_local": g_support_observed.copy(),
    }


def cptg_bpol_from_support(
    r_m: np.ndarray,
    support_state: Dict[str, np.ndarray],
    kappa_kpc: float,
) -> np.ndarray:
    """Evaluate the locked v1.13.0 spherical polarization carrier B_pol."""
    r_m = np.asarray(r_m, dtype=float)
    x = np.asarray(support_state["x_log_r"], dtype=float)
    g = np.asarray(support_state["g_support_smooth"], dtype=float)
    gp = np.asarray(support_state["dg_dr"], dtype=float)
    kappa_m = max(float(kappa_kpc), CPTG_KAPPA_MIN_KPC) * KPC_TO_M

    C_c = g**2 + kappa_m**2 * (gp**2 + 2.0 * (g / r_m)**2)
    C_power = np.maximum(C_c, EPS) ** (-2.0 / 3.0)
    inner = r_m**2 * kappa_m**2 * gp * C_power
    degree = _resolved_spline_degree(r_m.size)
    inner_spline = UnivariateSpline(x, inner, s=0.0, k=degree)
    d_inner_dr = inner_spline.derivative(1)(x) / r_m

    return (
        (r_m**2 + 2.0 * kappa_m**2) * g * C_power
        - d_inner_dr
    ) / r_m**2


def _solve_cptg_implicit_high_accel(
    gbar: np.ndarray,
    a_star_local: np.ndarray,
    sigma_c_squared: np.ndarray,
    B_pol: np.ndarray,
    A_C: float,
    c_C: float,
) -> Tuple[Optional[np.ndarray], Optional[np.ndarray]]:
    """Solve the locked v1.13.0 implicit high-acceleration-suppressed field."""
    gbar = np.asarray(gbar, dtype=float)
    a_star_local = np.maximum(np.asarray(a_star_local, dtype=float), EPS)
    sigma_c_squared = np.asarray(sigma_c_squared, dtype=float)
    B_pol = np.asarray(B_pol, dtype=float)

    denominator = 1.0 + float(c_C) * sigma_c_squared
    polarization_raw = float(A_C) * a_star_local ** (2.0 / 3.0) * B_pol

    g = np.maximum(
        (gbar + polarization_raw * CPTG_SUPPRESSION_AT_UNIT_RATIO) / denominator,
        EPS,
    )

    for _ in range(28):
        ratio = np.maximum(g / a_star_local, 1.0e-16)
        ratio_p = ratio ** CPTG_SUPPRESSION_INNER_POWER
        suppression = (1.0 + ratio_p) ** (-CPTG_SUPPRESSION_OUTER_POWER)
        F = denominator * g - gbar - polarization_raw * suppression
        dS_dg = (
            -CPTG_SUPPRESSION_OUTER_POWER
            * CPTG_SUPPRESSION_INNER_POWER
            * ratio ** (CPTG_SUPPRESSION_INNER_POWER - 1.0)
            / a_star_local
            * (1.0 + ratio_p) ** (-CPTG_SUPPRESSION_OUTER_POWER - 1.0)
        )
        dF_dg = denominator - polarization_raw * dS_dg
        if np.any(~np.isfinite(dF_dg)) or np.any(np.abs(dF_dg) < 1.0e-25):
            break
        trial = g - F / dF_dg
        invalid = (~np.isfinite(trial)) | (trial <= 0.0)
        trial = np.where(invalid, 0.5 * g, trial)
        rel = float(np.max(np.abs(trial - g) / np.maximum(np.abs(trial), EPS)))
        g = trial
        if rel < 2.0e-11:
            break

    ratio = np.maximum(g / a_star_local, 1.0e-16)
    suppression = (1.0 + ratio ** CPTG_SUPPRESSION_INNER_POWER) ** (-CPTG_SUPPRESSION_OUTER_POWER)
    F = denominator * g - gbar - polarization_raw * suppression
    scale = np.maximum(
        np.abs(denominator * g) + np.abs(gbar) + np.abs(polarization_raw * suppression),
        EPS,
    )
    normalized_residual = float(np.max(np.abs(F) / scale))

    if (
        np.any(~np.isfinite(g))
        or np.any(g <= 0.0)
        or not np.isfinite(normalized_residual)
        or normalized_residual > 5.0e-8
    ):
        g = np.maximum(
            (gbar + polarization_raw * CPTG_SUPPRESSION_AT_UNIT_RATIO) / denominator,
            EPS,
        )
        for _ in range(180):
            ratio = np.maximum(g / a_star_local, 1.0e-16)
            suppression = (1.0 + ratio ** CPTG_SUPPRESSION_INNER_POWER) ** (-CPTG_SUPPRESSION_OUTER_POWER)
            trial = (gbar + polarization_raw * suppression) / denominator
            if np.any(~np.isfinite(trial)) or np.any(trial <= 0.0):
                return None, None
            updated = 0.55 * trial + 0.45 * g
            rel = float(np.max(np.abs(updated - g) / np.maximum(np.abs(updated), EPS)))
            g = updated
            if rel < 1.0e-11:
                break

        ratio = np.maximum(g / a_star_local, 1.0e-16)
        suppression = (1.0 + ratio ** CPTG_SUPPRESSION_INNER_POWER) ** (-CPTG_SUPPRESSION_OUTER_POWER)
        exact = (gbar + polarization_raw * suppression) / denominator
        if (
            np.any(~np.isfinite(exact))
            or np.any(exact <= 0.0)
            or float(np.max(np.abs(exact - g) / np.maximum(np.abs(exact), EPS))) > 2.0e-7
        ):
            return None, None
        g = exact

    ratio = np.maximum(g / a_star_local, 1.0e-16)
    suppression = (1.0 + ratio ** CPTG_SUPPRESSION_INNER_POWER) ** (-CPTG_SUPPRESSION_OUTER_POWER)
    return g, suppression


def fit_cptg_local_astar_profile(
    gbar_physical: np.ndarray,
    r_m: np.ndarray,
    vobs_m_s: np.ndarray,
    errv_m_s: np.ndarray,
) -> Dict[str, Any]:
    """Fit the locked v1.13.0 local-a_star CPTG radial reduction.

    The local structural acceleration is calculated independently at every
    resolved radius:

        a_star(r_i) = V_obs(r_i)^2 / r_i.

    The registered nonlinear galaxy suppression is applied only to the
    polarization response:

        Sigma_g = [1 + (g_C/a_star)^(123/50)]^(-11/50).

    kappa_C, A_C, and c_C remain the only three galaxy-level reduced fit
    quantities. The fit uses a deterministic global basin scan followed by
    bounded nonlinear least-squares refinement of the best independent seeds.
    """
    gbar = np.maximum(np.asarray(gbar_physical, dtype=float), 0.0)
    r_m = np.asarray(r_m, dtype=float)
    vobs = np.asarray(vobs_m_s, dtype=float)
    errv = np.maximum(np.asarray(errv_m_s, dtype=float), EPS)

    support = resolved_support_state(r_m, vobs, errv)
    a_star_local = np.asarray(support["a_star_local"], dtype=float)
    a_star_23 = np.maximum(a_star_local, EPS) ** (2.0 / 3.0)
    sigma_c_squared = np.asarray(support["Sigma_C_squared"], dtype=float)
    gobs = np.asarray(support["g_support_observed"], dtype=float)
    sigma_g = np.asarray(support["sigma_g"], dtype=float)

    lower = np.log(np.array([CPTG_KAPPA_MIN_KPC, CPTG_A_MIN, CPTG_C_MIN], dtype=float))
    upper = np.log(np.array([CPTG_KAPPA_MAX_KPC, CPTG_A_MAX, CPTG_C_MAX], dtype=float))

    bpol_cache: Dict[float, np.ndarray] = {}

    def bpol_for_logk(log_kappa: float) -> np.ndarray:
        kappa = float(np.exp(log_kappa))
        key = round(float(log_kappa), 11)
        cached = bpol_cache.get(key)
        if cached is None:
            cached = cptg_bpol_from_support(r_m, support, kappa)
            bpol_cache[key] = cached
        return cached

    def model_from_theta(theta: np.ndarray) -> Tuple[Optional[np.ndarray], Optional[np.ndarray], np.ndarray]:
        log_kappa, log_A, log_c = theta
        B_pol = bpol_for_logk(float(log_kappa))
        A_C = float(np.exp(log_A))
        c_C = float(np.exp(log_c))
        g_model, suppression = _solve_cptg_implicit_high_accel(
            gbar, a_star_local, sigma_c_squared, B_pol, A_C, c_C
        )
        return g_model, suppression, B_pol

    def velocity_residual(theta: np.ndarray) -> np.ndarray:
        g_model, _, _ = model_from_theta(theta)
        if g_model is None or np.any(~np.isfinite(g_model)) or np.any(g_model <= 0.0):
            return np.full_like(vobs, 1.0e6)
        v_model = np.sqrt(g_model * r_m)
        return (v_model - vobs) / errv

    kappa_grid = np.geomspace(1.0e-3, 1.0e6, 30)
    c_grid = np.geomspace(1.0e-8, CPTG_C_MAX, 18)
    candidate_seeds: List[Tuple[float, np.ndarray]] = []
    accel_weights = 1.0 / np.maximum(sigma_g, EPS) ** 2

    for kappa in kappa_grid:
        log_k = float(np.log(kappa))
        B_pol = bpol_for_logk(log_k)
        for c_C in c_grid:
            denominator = 1.0 + c_C * sigma_c_squared
            phi = (
                CPTG_SUPPRESSION_AT_UNIT_RATIO
                * a_star_23
                * B_pol
                / denominator
            )
            base = gbar / denominator
            target = gobs - base
            denom_A = float(np.sum(accel_weights * phi**2))
            if denom_A > 0.0 and np.isfinite(denom_A):
                A_C = float(np.sum(accel_weights * phi * target) / denom_A)
            else:
                A_C = CPTG_A_MIN
            if not np.isfinite(A_C) or A_C <= 0.0:
                A_C = CPTG_A_MIN
            A_C = float(np.clip(A_C, CPTG_A_MIN, CPTG_A_MAX))
            g_approx = base + A_C * phi
            if np.any(~np.isfinite(g_approx)) or np.any(g_approx <= 0.0):
                chi2_approx = float("inf")
            else:
                v_approx = np.sqrt(g_approx * r_m)
                chi2_approx = float(np.sum(((v_approx - vobs) / errv) ** 2))
            candidate_seeds.append(
                (chi2_approx, np.array([log_k, np.log(A_C), np.log(c_C)], dtype=float))
            )

    candidate_seeds.sort(key=lambda item: item[0])
    seeds: List[np.ndarray] = []
    for _, theta in candidate_seeds:
        if all(np.linalg.norm(theta - existing) > 0.25 for existing in seeds):
            seeds.append(theta)
        if len(seeds) >= 12:
            break

    best_chi2 = float("inf")
    best_theta: Optional[np.ndarray] = None
    best_residual: Optional[np.ndarray] = None
    best_model: Optional[np.ndarray] = None
    best_suppression: Optional[np.ndarray] = None
    best_bpol: Optional[np.ndarray] = None

    for seed in seeds:
        seed = np.minimum(np.maximum(seed, lower + 1.0e-12), upper - 1.0e-12)
        solution = least_squares(
            velocity_residual,
            seed,
            bounds=(lower, upper),
            max_nfev=300,
            xtol=1.0e-10,
            ftol=1.0e-10,
            gtol=1.0e-10,
        )
        residual = np.asarray(solution.fun, dtype=float)
        chi2 = float(np.sum(residual**2))
        if np.isfinite(chi2) and chi2 < best_chi2:
            g_model, suppression, B_pol = model_from_theta(np.asarray(solution.x, dtype=float))
            if g_model is not None and suppression is not None:
                best_chi2 = chi2
                best_theta = np.asarray(solution.x, dtype=float)
                best_residual = residual
                best_model = np.asarray(g_model, dtype=float)
                best_suppression = np.asarray(suppression, dtype=float)
                best_bpol = np.asarray(B_pol, dtype=float)

    if (
        best_theta is None
        or best_residual is None
        or best_model is None
        or best_suppression is None
        or best_bpol is None
    ):
        raise RuntimeError("v1.13.0 CPTG local-a_star suppressed profile optimization failed")

    kappa_C_kpc, A_C, c_C = np.exp(best_theta)
    polarization_raw = A_C * a_star_23 * best_bpol
    polarization_response = polarization_raw * best_suppression
    transport_denominator = 1.0 + c_C * sigma_c_squared

    return {
        "kappa_C_kpc": float(kappa_C_kpc),
        "A_C": float(A_C),
        "c_C": float(c_C),
        "fit_chi2": best_chi2,
        "g_cptg": best_model,
        "B_pol": best_bpol,
        "Sigma_g_high_accel": best_suppression,
        "polarization_raw_m_s2": polarization_raw,
        "polarization_response_m_s2": polarization_response,
        "transport_denominator": transport_denominator,
        "a_star_local_m_s2": a_star_local,
        "a_star_min_m_s2": float(np.min(a_star_local)),
        "a_star_median_m_s2": float(np.median(a_star_local)),
        "a_star_max_m_s2": float(np.max(a_star_local)),
        "Sigma_C_squared": sigma_c_squared,
        "Sigma_C_squared_raw": np.asarray(support["Sigma_C_squared_raw"], dtype=float),
        "g_support_smooth_m_s2": np.asarray(support["g_support_smooth"], dtype=float),
    }


def estimate_structure_scale_and_mode(r_m: np.ndarray, g_field: np.ndarray, kappa: float = KAPPA_STRUCT) -> float:
    """Post-solve CSMI structural mode N = R/lambda from the solved CPTG field."""
    r_m = np.asarray(r_m, dtype=float)
    g_field = np.asarray(g_field, dtype=float)
    if r_m.size < MIN_POINTS_FOR_STRUCTURE:
        return float("nan")

    order = np.argsort(r_m)
    r_sorted = r_m[order]
    g_sorted = np.maximum(g_field[order], EPS)

    dg = np.gradient(g_sorted, r_sorted)
    C = g_sorted**2 + (kappa * dg)**2
    dC = np.gradient(C, r_sorted)

    finite = np.isfinite(r_sorted) & np.isfinite(dC) & (r_sorted > 0)
    if np.count_nonzero(finite) < MIN_POINTS_FOR_STRUCTURE:
        return float("nan")

    R_m = float(np.max(r_sorted))
    mask_outer = (r_sorted > 1.0 / 5.0 * R_m) & finite
    if np.count_nonzero(mask_outer) < MIN_POINTS_FOR_STRUCTURE:
        return float("nan")

    r_outer = r_sorted[mask_outer]
    dC_outer = np.abs(dC[mask_outer])
    window = 5
    if len(dC_outer) > window:
        kernel = np.ones(window) / window
        dC_outer = np.convolve(dC_outer, kernel, mode="same")

    weight_sum = np.sum(dC_outer)
    if weight_sum <= 0 or not np.isfinite(weight_sum):
        return float("nan")

    lambda_m = float(np.sum(r_outer * dC_outer) / weight_sum)
    return float(R_m / lambda_m) if lambda_m > 0 else float("nan")


def detect_galaxy_type_from_mode(N: float) -> str:
    if not np.isfinite(N):
        return "Unknown"
    for upper_bound, label in MODE_TYPE_THRESHOLDS:
        if N <= upper_bound:
            return label
    return "Unknown"


# ----------------------------
# Diagnostics
# ----------------------------


def chi2_stats(vobs_km_s: np.ndarray, verr_km_s: np.ndarray, vmodel_km_s: np.ndarray, n_params: int) -> Dict[str, float]:
    resid = np.asarray(vobs_km_s, dtype=float) - np.asarray(vmodel_km_s, dtype=float)
    verr = np.maximum(np.asarray(verr_km_s, dtype=float), 1e-12)
    chi2 = float(np.nansum((resid / verr) ** 2))
    n = int(np.isfinite(resid).sum())
    dof = max(n - n_params, 1)
    return {
        "n_points": n,
        "chi2": chi2,
        "chi2_per_point": chi2 / max(n, 1),
        "chi2_per_dof": chi2 / dof,
        "rms_km_s": float(np.sqrt(np.nanmean(resid**2))),
        "mae_km_s": float(np.nanmean(np.abs(resid))),
    }


def rar_scatter(gobs: np.ndarray, gmodel: np.ndarray) -> float:
    valid = (gobs > EPS) & (gmodel > EPS) & np.isfinite(gobs) & np.isfinite(gmodel)
    if int(valid.sum()) < 3:
        return float("nan")
    return float(np.std(np.log10(gmodel[valid]) - np.log10(gobs[valid])))


def create_results_bundle(out_dir: Path, bundle_name: str = "results_bundle.zip") -> Path:
    """Create a downloadable ZIP containing the completed run outputs."""
    out_dir = Path(out_dir)
    bundle_path = out_dir / bundle_name
    with zipfile.ZipFile(bundle_path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(out_dir.rglob("*")):
            if not path.is_file():
                continue
            if path.resolve() == bundle_path.resolve() or path.suffix.lower() == ".zip":
                continue
            archive.write(path, path.relative_to(out_dir))
    return bundle_path


def run_galaxy_analysis(
    galaxy: GalaxyData,
    out_dir: Path,
    metadata: Optional[Dict[str, Any]] = None,
    create_bundle: bool = True,
    metadata_sample_status_value: str = "n/a",
    metadata_sample_reason_value: str = "",
) -> Dict[str, Any]:
    out_dir.mkdir(parents=True, exist_ok=True)
    metadata = metadata or {}

    r_kpc = galaxy.radius_kpc
    r_m = r_kpc * KPC_TO_M
    vobs_m_s = galaxy.vobs_km_s * 1000.0
    errv_m_s = galaxy.errv_km_s * 1000.0
    vgas_m_s = galaxy.vgas_km_s * 1000.0
    vdisk_m_s = galaxy.vdisk_km_s * 1000.0
    vbulge_m_s = galaxy.vbulge_km_s * 1000.0

    gobs = (vobs_m_s**2) / np.maximum(r_m, EPS)

    # Locked v1.13.0: both model calculations receive the same direct physical
    # baryonic source.
    gbar_physical = build_physical_baryonic_field(
        r_m,
        vgas_m_s,
        vdisk_m_s,
        vbulge_m_s,
    )

    fit = fit_cptg_local_astar_profile(gbar_physical, r_m, vobs_m_s, errv_m_s)
    g_cptg = np.asarray(fit["g_cptg"], dtype=float)
    g_mond = mond_acceleration(gbar_physical)

    a_star_local = np.asarray(fit["a_star_local_m_s2"], dtype=float)
    sigma_c_squared = np.asarray(fit["Sigma_C_squared"], dtype=float)
    b_pol = np.asarray(fit["B_pol"], dtype=float)
    sigma_g_high_accel = np.asarray(fit["Sigma_g_high_accel"], dtype=float)
    polarization_raw = np.asarray(fit["polarization_raw_m_s2"], dtype=float)
    polarization_response = np.asarray(fit["polarization_response_m_s2"], dtype=float)
    transport_denominator = np.asarray(fit["transport_denominator"], dtype=float)
    delta_g = g_cptg - gbar_physical

    v_cptg_km_s = np.sqrt(np.maximum(g_cptg, 0.0) * r_m) / 1000.0
    v_mond_km_s = np.sqrt(np.maximum(g_mond, 0.0) * r_m) / 1000.0
    vbar_physical_km_s = np.sqrt(np.maximum(gbar_physical, 0.0) * r_m) / 1000.0
    cptg_stats = chi2_stats(galaxy.vobs_km_s, galaxy.errv_km_s, v_cptg_km_s, n_params=3)
    mond_stats = chi2_stats(galaxy.vobs_km_s, galaxy.errv_km_s, v_mond_km_s, n_params=0)

    primary_flag = metadata_primary_sample_flag(metadata)
    primary_sample_known = primary_flag is not None
    primary_sample = bool(primary_flag) if primary_sample_known else True
    inc_deg = metadata.get("inc_deg")
    e_inc_deg = metadata.get("e_inc_deg")
    inclination_known = inc_deg is not None and e_inc_deg is not None
    cptg_stats_inclination = None
    mond_stats_inclination = None
    if inclination_known:
        inc_systematic_km_s = inclination_velocity_systematic(vobs_m_s, float(inc_deg), float(e_inc_deg)) / 1000.0
        errv_total_km_s = np.sqrt(galaxy.errv_km_s**2 + inc_systematic_km_s**2)
        cptg_stats_inclination = chi2_stats(galaxy.vobs_km_s, errv_total_km_s, v_cptg_km_s, n_params=3)
        mond_stats_inclination = chi2_stats(galaxy.vobs_km_s, errv_total_km_s, v_mond_km_s, n_params=0)

    cptg_rar = rar_scatter(gobs, g_cptg)
    mond_rar = rar_scatter(gobs, g_mond)
    mode_n = estimate_structure_scale_and_mode(r_m, g_cptg)
    mode_label = detect_galaxy_type_from_mode(mode_n)
    winner = "CPTG" if cptg_stats["chi2_per_point"] < mond_stats["chi2_per_point"] else "MOND"

    point_csv = out_dir / "point_results.csv"
    with point_csv.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow([
            "galaxy", "radius_kpc", "vobs_km_s", "errv_km_s", "vgas_km_s", "vdisk_km_s", "vbulge_km_s",
            "vbar_physical_km_s", "vcptg_km_s", "vmond_km_s",
            "gobs_m_s2", "gbar_physical_m_s2", "gcptg_m_s2", "gmond_m_s2",
            "a_star_local_m_s2", "g_support_smooth_m_s2", "Sigma_C_squared", "Sigma_C_squared_raw",
            "Sigma_g_high_accel", "B_pol", "polarization_raw_m_s2", "polarization_response_m_s2",
            "transport_denominator", "delta_g_m_s2",
            "resid_cptg_km_s", "resid_mond_km_s",
        ])
        for i in range(len(r_kpc)):
            w.writerow(format_csv_row([
                galaxy.name, r_kpc[i], galaxy.vobs_km_s[i], galaxy.errv_km_s[i], galaxy.vgas_km_s[i], galaxy.vdisk_km_s[i], galaxy.vbulge_km_s[i],
                vbar_physical_km_s[i], v_cptg_km_s[i], v_mond_km_s[i],
                gobs[i], gbar_physical[i], g_cptg[i], g_mond[i],
                a_star_local[i], fit["g_support_smooth_m_s2"][i], sigma_c_squared[i], fit["Sigma_C_squared_raw"][i],
                sigma_g_high_accel[i], b_pol[i], polarization_raw[i], polarization_response[i],
                transport_denominator[i], delta_g[i],
                galaxy.vobs_km_s[i] - v_cptg_km_s[i], galaxy.vobs_km_s[i] - v_mond_km_s[i],
            ]))

    fig, ax = plt.subplots(figsize=(8, 5))
    ax.errorbar(r_kpc, galaxy.vobs_km_s, yerr=galaxy.errv_km_s, fmt="o", label="Observed", markersize=4)
    ax.plot(r_kpc, v_cptg_km_s, label="CPTG", color=CPTG_PLOT_COLOR, linewidth=2.0)
    ax.plot(r_kpc, v_mond_km_s, label="MOND", color=MOND_PLOT_COLOR, linewidth=2.0)
    ax.plot(r_kpc, vbar_physical_km_s, "--", label="Baryonic source", alpha=0.75)
    ax.set_xlabel("Radius (kpc)")
    ax.set_ylabel("Velocity (km/s)")
    ax.set_title(f"{galaxy.name}: CPTG/MOND rotation-curve comparison")
    ax.grid(True, alpha=0.3)
    ax.legend(fontsize=8)
    fig.tight_layout()
    rotation_png = out_dir / "rotation_curve.png"
    fig.savefig(rotation_png, dpi=160)
    plt.close(fig)

    cptg_rar_resid = np.full_like(gobs, np.nan, dtype=float)
    mond_rar_resid = np.full_like(gobs, np.nan, dtype=float)
    valid_cptg_rar = (gobs > EPS) & (g_cptg > EPS) & np.isfinite(gobs) & np.isfinite(g_cptg) & np.isfinite(r_kpc)
    valid_mond_rar = (gobs > EPS) & (g_mond > EPS) & np.isfinite(gobs) & np.isfinite(g_mond) & np.isfinite(r_kpc)
    cptg_rar_resid[valid_cptg_rar] = np.log10(g_cptg[valid_cptg_rar] / gobs[valid_cptg_rar])
    mond_rar_resid[valid_mond_rar] = np.log10(g_mond[valid_mond_rar] / gobs[valid_mond_rar])

    fig, ax = plt.subplots(figsize=(8, 5))
    ax.axhline(0.0, color="black", linewidth=1.0, alpha=0.55, label="Observed match")
    ax.plot(r_kpc[valid_cptg_rar], cptg_rar_resid[valid_cptg_rar], label="CPTG", color=CPTG_PLOT_COLOR, linewidth=2.0)
    ax.plot(r_kpc[valid_mond_rar], mond_rar_resid[valid_mond_rar], label="MOND", color=MOND_PLOT_COLOR, linewidth=2.0)
    ax.set_xlabel("Radius (kpc)")
    ax.set_ylabel("RAR scatter log10(g_model / g_obs) [dex]")
    ax.set_title(f"{galaxy.name}: RAR scatter vs radius")
    ax.grid(True, alpha=0.30)
    ax.legend(fontsize=8)
    fig.tight_layout()
    rar_png = out_dir / "rar_scatter_vs_radius.png"
    fig.savefig(rar_png, dpi=160)
    plt.close(fig)

    summary = {
        "galaxy": galaxy.name,
        "source_name": galaxy.source_name,
        "locked_release_version": LOCKED_RELEASE_VERSION,
        "raw_rows": galaxy.raw_rows,
        "valid_points": int(len(r_kpc)),
        "mean_observed_velocity_km_s": float(np.mean(galaxy.vobs_km_s)),
        "mean_cptg_velocity_km_s": float(np.mean(v_cptg_km_s)),
        "mean_mond_velocity_km_s": float(np.mean(v_mond_km_s)),
        "a_star_rule": "local resolved a_star(r_i)=Vobs(r_i)^2/r_i",
        "high_acceleration_suppression_rule": "Sigma_g=[1+(g_C/a_star)^(123/50)]^(-11/50)",
        "a_star_min_m_s2": fit["a_star_min_m_s2"],
        "a_star_median_m_s2": fit["a_star_median_m_s2"],
        "a_star_max_m_s2": fit["a_star_max_m_s2"],
        "kappa_C_kpc": fit["kappa_C_kpc"],
        "A_C": fit["A_C"],
        "c_C": fit["c_C"],
        "fit_chi2": fit["fit_chi2"],
        "CSMI_N": mode_n,
        "mode_label": mode_label,
        "winner": winner,
        "metadata_primary_sample_known": primary_sample_known,
        "metadata_primary_sample": primary_sample,
        "metadata_primary_sample_label": primary_sample_label(metadata),
        "metadata_sample_status": metadata_sample_status_value,
        "metadata_sample_reason": metadata_sample_reason_value,
        "metadata_inclination_known": inclination_known,
        "CPTG": {**cptg_stats, "rar_scatter_dex": cptg_rar},
        "MOND": {**mond_stats, "rar_scatter_dex": mond_rar},
        "CPTG_inclination_systematic": cptg_stats_inclination,
        "MOND_inclination_systematic": mond_stats_inclination,
        "metadata": metadata,
        "outputs": {
            "point_results_csv": str(point_csv),
            "summary_json": str(out_dir / "summary.json"),
            "rotation_curve_png": str(rotation_png),
            "rar_scatter_vs_radius_png": str(rar_png),
            "results_bundle_zip": str(out_dir / "results_bundle.zip") if create_bundle else None,
        },
    }
    with (out_dir / "summary.json").open("w", encoding="utf-8") as f:
        json.dump(format_report_object(summary), f, indent=2)
    if create_bundle:
        create_results_bundle(out_dir)

    return {
        "summary": summary,
        "arrays": {
            "r": r_kpc, "vobs": galaxy.vobs_km_s, "verr": galaxy.errv_km_s,
            "vcptg": v_cptg_km_s, "vmond": v_mond_km_s,
            "vbar_physical": vbar_physical_km_s,
            "gobs": gobs, "gbar_physical": gbar_physical, "gcptg": g_cptg,
            "gmond": g_mond,
            "a_star_local": a_star_local, "Sigma_C_squared": sigma_c_squared,
            "Sigma_g_high_accel": sigma_g_high_accel,
        },
    }


# ----------------------------
# Metadata parsing
# ----------------------------

META_ALIASES = {
    "galaxy": ["galaxy", "name", "object", "id", "file", "filename"],
    "type": ["t", "type", "morph", "morphology"],
    "D_Mpc": ["d", "dist", "distance", "d_mpc"],
    "inc_deg": ["inc", "incl", "inclination", "inc_deg", "i"],
    "e_inc_deg": ["einc", "e_inc", "e_inc_deg", "incerr", "inc_error", "incerror", "inclinationerror", "einclination"],
    "q_flag": ["q", "quality", "qualityflag", "qflag", "q_flag"],
    "primary_sample": ["primary", "isprimary", "science_sample", "primarysample", "primary_sample", "in_primary_sample", "is_primary"],
    "Vflat_km_s": ["vflat", "v_flat", "vflat_km_s", "vf"],
    "L36": ["l36", "lum", "luminosity"],
    "Rdisk": ["rdisk", "r_disk"],
    "SBdisk": ["sbdisk", "sb_disk"],
    "MHI": ["mhi"],
}


def _normalize_key(s: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", str(s).lower())


def canonical_galaxy_key(name: str) -> str:
    """Normalize a galaxy identifier for matching data files to metadata."""
    return _normalize_key(_clean_name_from_filename(str(name))).upper()


def parse_float_or_none(value: Any) -> Optional[float]:
    if value is None:
        return None
    s = str(value).strip()
    if not s or s in {"---", "NaN", "nan", "None", "null"}:
        return None
    try:
        val = float(s)
    except Exception:
        return None
    return val if np.isfinite(val) else None


def parse_int_or_none(value: Any) -> Optional[int]:
    val = parse_float_or_none(value)
    return None if val is None else int(round(val))


def parse_bool_or_none(value: Any) -> Optional[bool]:
    if value is None:
        return None
    if isinstance(value, bool):
        return value
    s = str(value).strip().lower()
    if s in {"1", "true", "t", "yes", "y"}:
        return True
    if s in {"0", "false", "f", "no", "n"}:
        return False
    return None


def best_matching_column(fieldnames: List[str], aliases: List[str]) -> Optional[str]:
    norm = {name: _normalize_key(name) for name in fieldnames}
    alias_norms = {_normalize_key(a) for a in aliases}
    for original, key in norm.items():
        if key in alias_norms:
            return original
    return None


def normalize_metadata_record(raw: Dict[str, Any], galaxy_name: Optional[str] = None) -> Dict[str, Any]:
    """Return a canonical metadata record while preserving useful raw fields."""
    rec: Dict[str, Any] = dict(raw)
    galaxy = galaxy_name or raw.get("Galaxy") or raw.get("name") or raw.get("galaxy") or raw.get("Name") or raw.get("ID") or raw.get("id") or raw.get("file") or raw.get("filename") or ""
    rec["Galaxy"] = str(galaxy)

    type_val = raw.get("meta_type", raw.get("T", raw.get("type", raw.get("Type"))))
    if type_val not in (None, ""):
        try:
            t = float(type_val)
            rec["meta_type"] = int(t) if float(t).is_integer() else t
        except Exception:
            rec["meta_type"] = type_val

    inc_val = raw.get("inc_deg", raw.get("meta_Inc_deg", raw.get("Inc", raw.get("i", raw.get("inclination")))))
    e_inc_val = raw.get("e_inc_deg", raw.get("meta_e_Inc_deg", raw.get("e_Inc", raw.get("eInc", raw.get("inc_error")))))
    q_val = raw.get("q_flag", raw.get("meta_Q", raw.get("Q", raw.get("quality", raw.get("quality_flag")))))
    primary_val = raw.get("primary_sample", raw.get("is_primary", raw.get("primary", raw.get("science_sample"))))

    rec["inc_deg"] = parse_float_or_none(inc_val)
    rec["e_inc_deg"] = parse_float_or_none(e_inc_val)
    rec["q_flag"] = parse_int_or_none(q_val)
    rec["primary_sample"] = parse_bool_or_none(primary_val)

    if rec["inc_deg"] is not None:
        rec["meta_Inc_deg"] = rec["inc_deg"]
    if rec["e_inc_deg"] is not None:
        rec["meta_e_Inc_deg"] = rec["e_inc_deg"]
    if rec["q_flag"] is not None:
        rec["meta_Q"] = rec["q_flag"]

    for raw_key, out_key in [
        ("D", "meta_D_Mpc"), ("Dist", "meta_D_Mpc"), ("D_Mpc", "meta_D_Mpc"),
        ("Vflat", "meta_Vflat_km_s"), ("Vf", "meta_Vflat_km_s"), ("Vflat_km_s", "meta_Vflat_km_s"),
        ("L36", "meta_L36"), ("Rdisk", "meta_Rdisk"), ("SBdisk", "meta_SBdisk"), ("MHI", "meta_MHI"),
    ]:
        if raw_key in raw and raw[raw_key] not in (None, ""):
            rec[out_key] = raw[raw_key]
    return rec


def metadata_record_is_useful(rec: Dict[str, Any]) -> bool:
    return any(rec.get(k) is not None for k in ("inc_deg", "e_inc_deg", "q_flag", "primary_sample"))


def metadata_primary_sample_flag(metadata: Optional[Dict[str, Any]]) -> Optional[bool]:
    """Explicit primary_sample wins; otherwise derive from Q flag and inclination."""
    if not metadata:
        return None
    explicit = metadata.get("primary_sample")
    if explicit is not None:
        return bool(explicit)
    q_flag = metadata.get("q_flag")
    inc_deg = metadata.get("inc_deg")
    if q_flag is None and inc_deg is None:
        return None
    if q_flag in SCIENCE_SAMPLE_EXCLUDED_Q_FLAGS:
        return False
    if inc_deg is not None and inc_deg < SCIENCE_SAMPLE_MIN_INCLINATION_DEG:
        return False
    return True


def inclination_velocity_systematic(v_m_s: np.ndarray, inc_deg: float, e_inc_deg: float) -> np.ndarray:
    """Convert inclination uncertainty into a velocity-space systematic term."""
    v_m_s = np.asarray(v_m_s, dtype=float)
    inc_rad = np.deg2rad(float(inc_deg))
    e_inc_rad = np.deg2rad(max(float(e_inc_deg), 0.0))
    sin_i = np.sin(inc_rad)
    if abs(sin_i) < 1e-12:
        return np.full_like(v_m_s, np.inf, dtype=float)
    cot_i = np.cos(inc_rad) / sin_i
    return np.abs(v_m_s) * abs(cot_i) * e_inc_rad


def parse_mrt_metadata_text(text: str) -> Dict[str, Dict[str, Any]]:
    """Parse SPARC/CDS .mrt metadata into normalized per-galaxy records."""
    records: Dict[str, Dict[str, Any]] = {}
    useful_rows = 0

    # Official SPARC master metadata can be read reliably by position:
    # Galaxy, T, ..., Inc, e_Inc, ..., Q at the same columns used by the audited benchmark.
    for ln in text.splitlines():
        s = ln.strip()
        if not s or s.startswith(("#", "=", "-", "|")):
            continue
        parts = s.split()
        if len(parts) >= 18 and re.search(r"[A-Za-z]", parts[0]):
            raw = {
                "Galaxy": parts[0],
                "T": parts[1] if len(parts) > 1 else "",
                "Inc": parts[5] if len(parts) > 5 else "",
                "e_Inc": parts[6] if len(parts) > 6 else "",
                "Q": parts[17] if len(parts) > 17 else "",
            }
            rec = normalize_metadata_record(raw, parts[0])
            if metadata_record_is_useful(rec):
                useful_rows += 1
                records[canonical_galaxy_key(parts[0])] = rec
    if useful_rows >= 1:
        return records

    # Fallback for byte-described fixed-width MRT files.
    lines = text.splitlines()
    if "Byte-by-byte" not in text:
        return {}

    cols: List[Tuple[int, int, str]] = []
    in_block = False
    seen_col = False
    block_end_idx: Optional[int] = None
    for i, ln in enumerate(lines):
        if "Byte-by-byte" in ln:
            in_block = True
            continue
        if not in_block:
            continue
        if re.match(r"^\s*-{5,}\s*$", ln):
            if seen_col and cols:
                block_end_idx = i
                break
            continue
        m = re.match(r"^\s*(\d+)\s*-\s*(\d+)\s+\S+\s+\S+\s+([A-Za-z0-9_./+-]+)\s+", ln)
        if m:
            cols.append((int(m.group(1)) - 1, int(m.group(2)), m.group(3).strip()))
            seen_col = True
            continue
        m = re.match(r"^\s*(\d+)\s+\S+\s+\S+\s+([A-Za-z0-9_./+-]+)\s+", ln)
        if m:
            start = int(m.group(1)) - 1
            cols.append((start, start + 1, m.group(2).strip()))
            seen_col = True

    if not cols or block_end_idx is None:
        return {}

    for ln in lines[block_end_idx + 1:]:
        if not ln.strip() or re.match(r"^\s*-{5,}\s*$", ln):
            continue
        raw = {label: ln[start:end].strip() for start, end, label in cols}
        galaxy = raw.get("Galaxy") or raw.get("Name") or raw.get("ID") or ""
        if not galaxy or not re.search(r"[A-Za-z0-9]", str(galaxy)):
            continue
        rec = normalize_metadata_record(raw, str(galaxy))
        if metadata_record_is_useful(rec):
            records[canonical_galaxy_key(str(galaxy))] = rec
    return records


def parse_delimited_metadata_text(text: str, delimiter_hint: Optional[str] = None) -> Dict[str, Dict[str, Any]]:
    lines = [ln for ln in text.splitlines() if ln.strip() and not ln.strip().startswith("#")]
    if not lines:
        return {}

    import io
    sample = "\n".join(lines[:20])
    try:
        dialect = csv.Sniffer().sniff(sample, delimiters=",\t;|")
    except Exception:
        dialect = csv.excel
        dialect.delimiter = delimiter_hint or ("\t" if "\t" in sample else ",")

    reader = csv.DictReader(io.StringIO("\n".join(lines)), dialect=dialect)
    if not reader.fieldnames:
        return {}

    galaxy_col = best_matching_column(reader.fieldnames, META_ALIASES["galaxy"])
    if galaxy_col is None:
        return {}

    colmap = {field: best_matching_column(reader.fieldnames, aliases) for field, aliases in META_ALIASES.items()}
    useful_rows = 0
    records: Dict[str, Dict[str, Any]] = {}
    for row in reader:
        galaxy = (row.get(galaxy_col) or "").strip()
        if not galaxy:
            continue
        raw: Dict[str, Any] = {k: v for k, v in row.items() if k is not None}
        for field, col in colmap.items():
            if col and row.get(col) not in (None, ""):
                raw[field] = row.get(col)
        rec = normalize_metadata_record(raw, galaxy)
        if metadata_record_is_useful(rec):
            useful_rows += 1
        records[canonical_galaxy_key(galaxy)] = rec

    return records if useful_rows > 0 else {}

def parse_whitespace_metadata_text(text: str) -> Dict[str, Dict[str, Any]]:
    """Parse generic whitespace metadata tables with a header row."""
    lines = [ln.strip() for ln in text.splitlines() if ln.strip() and not ln.strip().startswith("#")]
    if not lines:
        return {}
    header_idx = None
    header: List[str] = []
    for i, ln in enumerate(lines[:20]):
        parts = ln.split()
        if len(parts) >= 2 and any(re.search(r"[A-Za-z]", part) for part in parts):
            norm_parts = {_normalize_key(part) for part in parts}
            if norm_parts & {_normalize_key(a) for aliases in META_ALIASES.values() for a in aliases}:
                header_idx = i
                header = parts
                break
    if header_idx is None:
        return {}

    galaxy_col_name = best_matching_column(header, META_ALIASES["galaxy"])
    if galaxy_col_name is None:
        return {}
    colmap = {field: best_matching_column(header, aliases) for field, aliases in META_ALIASES.items()}
    header_index = {name: idx for idx, name in enumerate(header)}
    galaxy_idx = header_index[galaxy_col_name]

    useful_rows = 0
    records: Dict[str, Dict[str, Any]] = {}
    for ln in lines[header_idx + 1:]:
        parts = ln.split()
        if galaxy_idx >= len(parts):
            continue
        galaxy = parts[galaxy_idx].strip()
        if not galaxy:
            continue
        raw: Dict[str, Any] = {h: parts[j] for j, h in enumerate(header) if j < len(parts)}
        for field, col in colmap.items():
            if col is not None:
                idx = header_index.get(col)
                if idx is not None and idx < len(parts):
                    raw[field] = parts[idx]
        rec = normalize_metadata_record(raw, galaxy)
        if metadata_record_is_useful(rec):
            useful_rows += 1
        records[canonical_galaxy_key(galaxy)] = rec
    return records if useful_rows > 0 else {}


def parse_json_metadata_text(text: str) -> Dict[str, Dict[str, Any]]:
    try:
        payload = json.loads(text)
    except Exception:
        return {}
    if isinstance(payload, list):
        rows = payload
    elif isinstance(payload, dict) and isinstance(payload.get("rows"), list):
        rows = payload.get("rows", [])
    elif isinstance(payload, dict):
        rows = []
        for galaxy_key, value in payload.items():
            if isinstance(value, dict):
                row = dict(value)
                row.setdefault("galaxy", galaxy_key)
                rows.append(row)
    else:
        rows = []

    records: Dict[str, Dict[str, Any]] = {}
    useful_rows = 0
    for row in rows:
        if not isinstance(row, dict):
            continue
        galaxy = row.get("galaxy") or row.get("name") or row.get("object") or row.get("id") or row.get("file") or row.get("filename")
        if not galaxy:
            continue
        rec = normalize_metadata_record(row, str(galaxy))
        if metadata_record_is_useful(rec):
            useful_rows += 1
        records[canonical_galaxy_key(str(galaxy))] = rec
    return records if useful_rows > 0 else {}


def parse_metadata_text(text: str, filename: str = "metadata") -> Dict[str, Dict[str, Any]]:
    """Parse optional SPARC-like metadata without replacing galaxy data."""
    lower = filename.lower()
    if lower.endswith(".json") or text.lstrip().startswith(("{", "[")):
        json_records = parse_json_metadata_text(text)
        if json_records:
            return json_records

    mrt_records = parse_mrt_metadata_text(text)
    if mrt_records:
        return mrt_records

    delimited_records = parse_delimited_metadata_text(text, delimiter_hint="\t" if lower.endswith(".tsv") else None)
    if delimited_records:
        return delimited_records

    whitespace_records = parse_whitespace_metadata_text(text)
    if whitespace_records:
        return whitespace_records

    # Last fallback: SPARC-style whitespace metadata table with at least 18 columns.
    sparc_records: Dict[str, Dict[str, Any]] = {}
    useful_simple = 0
    for ln in text.splitlines():
        parts = ln.split()
        if len(parts) >= 18 and re.search(r"[A-Za-z]", parts[0]):
            rec = normalize_metadata_record({"Galaxy": parts[0], "T": parts[1], "Inc": parts[5], "e_Inc": parts[6], "Q": parts[17]}, parts[0])
            if metadata_record_is_useful(rec):
                useful_simple += 1
                sparc_records[canonical_galaxy_key(parts[0])] = rec
    return sparc_records if useful_simple > 0 else {}


def metadata_for_galaxy(meta: Dict[str, Dict[str, Any]], galaxy_name: str) -> Dict[str, Any]:
    if not meta:
        return {}
    key = canonical_galaxy_key(galaxy_name)
    if key in meta:
        return meta[key]
    simple = _normalize_key(galaxy_name)
    for mk, rec in meta.items():
        if _normalize_key(mk) == simple or _normalize_key(rec.get("Galaxy", "")) == simple:
            return rec
    return {}


def metadata_type_label(metadata: Dict[str, Any]) -> str:
    if not metadata:
        return "metadata-missing"
    raw = None
    for k in ("meta_type", "T", "Type", "type"):
        if k in metadata and metadata[k] not in (None, ""):
            raw = metadata[k]
            break
    if raw is None or raw == "":
        return "type-missing"
    try:
        t = float(raw)
        if t <= -1: fam = "early/S0"
        elif t < 1: fam = "Sa/Sab"
        elif t < 3: fam = "Sb/Sbc"
        elif t < 5: fam = "Sc/Scd"
        elif t < 7: fam = "Sd/Sdm"
        else: fam = "Sm/Im"
        return f"T={int(t) if float(t).is_integer() else t:g} ({fam})"
    except Exception:
        return str(raw)


def primary_sample_label(metadata: Dict[str, Any]) -> str:
    flag = metadata_primary_sample_flag(metadata)
    if flag is None:
        return "unknown"
    return "primary" if flag else "excluded"

def primary_filter_is_active(metadata_records: Optional[Dict[str, Dict[str, Any]]]) -> bool:
    """Return True when metadata can define a primary science sample."""
    if not metadata_records:
        return False
    return any(metadata_primary_sample_flag(rec) is not None for rec in metadata_records.values())


def metadata_exclusion_reason(metadata: Dict[str, Any]) -> str:
    """Return a concise human-readable reason for an explicit exclusion."""
    reasons: List[str] = []
    if metadata.get("primary_sample") is False:
        reasons.append("primary_sample=false")
    q_flag = metadata.get("q_flag")
    if q_flag in SCIENCE_SAMPLE_EXCLUDED_Q_FLAGS:
        reasons.append(f"quality flag Q={q_flag}")
    inc_deg = metadata.get("inc_deg")
    if inc_deg is not None and float(inc_deg) < SCIENCE_SAMPLE_MIN_INCLINATION_DEG:
        reasons.append(f"inclination {float(inc_deg):g}° < {SCIENCE_SAMPLE_MIN_INCLINATION_DEG:g}°")
    return "; ".join(reasons) or "excluded by primary-sample metadata"


def classify_metadata_sample(
    metadata_records: Optional[Dict[str, Dict[str, Any]]],
    galaxy_name: str,
    primary_filter_active: Optional[bool] = None,
) -> Tuple[str, Dict[str, Any], str]:
    """Classify a galaxy as primary, excluded, unmatched, or n/a.

    The three-state primary-sample policy is activated only when the selected
    metadata file contains usable primary-sample information. A metadata file
    that contains catalog fields but no usable primary-sample fields leaves the
    sample status as n/a rather than treating every galaxy as unmatched.
    """
    records = metadata_records or {}
    if not records:
        return "n/a", {}, "No metadata file selected"
    active = primary_filter_is_active(records) if primary_filter_active is None else bool(primary_filter_active)
    metadata = metadata_for_galaxy(records, galaxy_name)
    if not active:
        return "n/a", metadata, "Primary-sample status is not defined by this metadata file"
    if not metadata:
        return "unmatched", {}, "No matching metadata record"
    flag = metadata_primary_sample_flag(metadata)
    if flag is True:
        return "primary", metadata, "Primary sample"
    if flag is False:
        return "excluded", metadata, metadata_exclusion_reason(metadata)
    return "unmatched", metadata, "Primary-sample status is unavailable for the matched record"


def metadata_sample_display(status: str) -> str:
    return {
        "primary": "primary",
        "excluded": "excluded",
        "unmatched": "n/a",
        "n/a": "n/a",
    }.get(str(status or "n/a"), "n/a")


def metadata_status_row(
    source_name: str,
    galaxy_name: str,
    metadata: Dict[str, Any],
    status: str,
    reason: str,
    source_path: Optional[str] = None,
    included_in_run: bool = False,
) -> Dict[str, Any]:
    """Build a report row for an excluded or unmatched metadata classification."""
    row = {
        "source_name": source_name,
        "source_path": source_path or "",
        "galaxy": galaxy_name,
        "metadata_status": status,
        "reason": reason,
        "included_in_run": bool(included_in_run),
        "primary_sample_label": primary_sample_label(metadata),
        "inc_deg": metadata.get("inc_deg"),
        "e_inc_deg": metadata.get("e_inc_deg"),
        "q_flag": metadata.get("q_flag"),
    }
    for k, v in metadata.items():
        if k.startswith("meta_") or k in ("Galaxy", "T", "Q", "inc_deg", "e_inc_deg", "q_flag"):
            row[k] = v
    return row


def metadata_exclusion_row(
    source_name: str,
    galaxy_name: str,
    metadata: Dict[str, Any],
    source_path: Optional[str] = None,
    included_in_run: bool = False,
) -> Dict[str, Any]:
    return metadata_status_row(
        source_name,
        galaxy_name,
        metadata,
        "excluded",
        metadata_exclusion_reason(metadata),
        source_path=source_path,
        included_in_run=included_in_run,
    )


def metadata_unmatched_row(
    source_name: str,
    galaxy_name: str,
    metadata: Dict[str, Any],
    reason: str,
    source_path: Optional[str] = None,
    included_in_run: bool = False,
) -> Dict[str, Any]:
    return metadata_status_row(
        source_name,
        galaxy_name,
        metadata,
        "unmatched",
        reason,
        source_path=source_path,
        included_in_run=included_in_run,
    )


# ----------------------------
# Batch processing
# ----------------------------


def stack_nan_stats(arr: np.ndarray) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    arr = np.asarray(arr, dtype=float)
    finite = np.isfinite(arr)
    count = np.sum(finite, axis=0)
    safe = np.where(finite, arr, 0.0)
    mean = np.divide(np.sum(safe, axis=0), count, out=np.full(arr.shape[1], np.nan, dtype=float), where=count > 0)
    diff = np.where(finite, arr - mean, 0.0)
    var = np.divide(np.sum(diff**2, axis=0), count, out=np.full(arr.shape[1], np.nan, dtype=float), where=count > 0)
    std = np.sqrt(var)
    return mean, std, count


def normalized_curve_record(galaxy_name: str, arrays: Dict[str, np.ndarray], grid: np.ndarray) -> Dict[str, np.ndarray]:
    r = arrays["r"]
    vmax = float(np.nanmax(arrays["vobs"])) if len(arrays["vobs"]) else 1.0
    rmax = float(np.nanmax(r)) if len(r) else 1.0
    vmax = vmax if vmax > 0 else 1.0
    rmax = rmax if rmax > 0 else 1.0
    x = np.clip(r / rmax, 0.0, 1.0)
    def interp(y):
        return np.interp(grid, x, y / vmax, left=np.nan, right=np.nan)
    return {"galaxy": galaxy_name, "obs": interp(arrays["vobs"]), "cptg": interp(arrays["vcptg"]), "mond": interp(arrays["vmond"]), "bar": interp(arrays["vbar_physical"])}


def normalized_rar_record(galaxy_name: str, arrays: Dict[str, np.ndarray], grid: np.ndarray) -> Dict[str, np.ndarray]:
    r = np.asarray(arrays["r"], dtype=float)
    gobs = np.asarray(arrays["gobs"], dtype=float)
    gcptg = np.asarray(arrays["gcptg"], dtype=float)
    gmond = np.asarray(arrays["gmond"], dtype=float)
    rmax = float(np.nanmax(r)) if len(r) else 1.0
    rmax = rmax if rmax > 0 else 1.0
    x = np.clip(r / rmax, 0.0, 1.0)

    def interp_rar(gmodel: np.ndarray) -> np.ndarray:
        valid = (gobs > EPS) & (gmodel > EPS) & np.isfinite(gobs) & np.isfinite(gmodel) & np.isfinite(x)
        if int(np.count_nonzero(valid)) < 2:
            return np.full_like(grid, np.nan, dtype=float)
        x_valid = x[valid]
        y_valid = np.log10(gmodel[valid] / gobs[valid])
        order = np.argsort(x_valid)
        x_valid = x_valid[order]
        y_valid = y_valid[order]
        x_unique, unique_idx = np.unique(x_valid, return_index=True)
        y_unique = y_valid[unique_idx]
        if len(x_unique) < 2:
            return np.full_like(grid, np.nan, dtype=float)
        return np.interp(grid, x_unique, y_unique, left=np.nan, right=np.nan)

    return {"galaxy": galaxy_name, "cptg": interp_rar(gcptg), "mond": interp_rar(gmond)}


def write_average_rotation_curve(curves: List[Dict[str, np.ndarray]], out_dir: Path) -> Tuple[Path, Path]:
    grid = np.linspace(0.02, 1.0, 80)
    if not curves:
        raise ValueError("No curves available for averaging.")
    keys = ["obs", "cptg", "mond", "bar"]
    means: Dict[str, np.ndarray] = {}
    stds: Dict[str, np.ndarray] = {}
    counts: Dict[str, np.ndarray] = {}
    for key in keys:
        arr = np.vstack([c[key] for c in curves])
        means[key], stds[key], counts[key] = stack_nan_stats(arr)

    csv_path = out_dir / "average_rotation_curve.csv"
    with csv_path.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["r_over_rmax", "vobs_mean_norm", "vcptg_mean_norm", "vmond_mean_norm", "vbar_physical_mean_norm", "vobs_std_norm", "vcptg_std_norm", "vmond_std_norm", "count"])
        for i, x in enumerate(grid):
            w.writerow(format_csv_row([x, means["obs"][i], means["cptg"][i], means["mond"][i], means["bar"][i], stds["obs"][i], stds["cptg"][i], stds["mond"][i], int(counts["obs"][i])]))

    fig, ax = plt.subplots(figsize=(8, 5))
    ax.plot(grid, means["obs"], label="Observed mean")
    ax.plot(grid, means["cptg"], label="CPTG mean", color=CPTG_PLOT_COLOR, linewidth=2.0)
    ax.plot(grid, means["mond"], label="MOND mean", color=MOND_PLOT_COLOR, linewidth=2.0)
    ax.plot(grid, means["bar"], "--", label="Baryonic source mean", alpha=0.75)
    ax.fill_between(grid, means["obs"] - stds["obs"], means["obs"] + stds["obs"], alpha=0.15, label="Observed cross-galaxy ±1σ")
    ax.set_xlabel("r / rmax")
    ax.set_ylabel("v / vmax(observed)")
    ax.set_title("Average normalized SPARC rotation curve")
    ax.grid(True, alpha=0.3)
    ax.legend(fontsize=8)
    fig.tight_layout()
    png_path = out_dir / "average_rotation_curve.png"
    fig.savefig(png_path, dpi=160)
    plt.close(fig)
    return csv_path, png_path


def write_average_rar_scatter_vs_radius(rar_records: List[Dict[str, np.ndarray]], out_dir: Path) -> Tuple[Path, Path]:
    grid = np.linspace(0.02, 1.0, 80)
    if not rar_records:
        raise ValueError("No RAR records available for averaging.")

    cptg_arr = np.vstack([c["cptg"] for c in rar_records])
    mond_arr = np.vstack([c["mond"] for c in rar_records])
    cptg_mean, cptg_std, cptg_count = stack_nan_stats(cptg_arr)
    mond_mean, mond_std, mond_count = stack_nan_stats(mond_arr)

    csv_path = out_dir / "average_rar_scatter_vs_radius.csv"
    with csv_path.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["r_over_rmax", "cptg_mean_rar_dex", "mond_mean_rar_dex", "cptg_std_rar_dex", "mond_std_rar_dex", "cptg_count", "mond_count"])
        for i, x in enumerate(grid):
            w.writerow(format_csv_row([x, cptg_mean[i], mond_mean[i], cptg_std[i], mond_std[i], int(cptg_count[i]), int(mond_count[i])]))

    fig, ax = plt.subplots(figsize=(8, 5))
    ax.axhline(0.0, color="black", linewidth=1.0, alpha=0.55, label="Observed match")
    ax.plot(grid, cptg_mean, label="CPTG mean", color=CPTG_PLOT_COLOR, linewidth=2.0)
    ax.plot(grid, mond_mean, label="MOND mean", color=MOND_PLOT_COLOR, linewidth=2.0)
    ax.set_xlabel("r / rmax")
    ax.set_ylabel("RAR scatter log10(g_model / g_obs) [dex]")
    ax.set_title("Average normalized RAR scatter vs radius")
    ax.grid(True, alpha=0.30)
    ax.legend(fontsize=8)
    fig.tight_layout()
    png_path = out_dir / "average_rar_scatter_vs_radius.png"
    fig.savefig(png_path, dpi=160)
    plt.close(fig)
    return csv_path, png_path


def write_average_csmi_by_mode_type(results: List[Dict[str, Any]], out_dir: Path) -> Path:
    groups: Dict[str, List[float]] = {}
    for row in results:
        t = row.get("mode_label") or "Unknown"
        try:
            n = float(row.get("CSMI_N"))
        except Exception:
            continue
        if np.isfinite(n):
            groups.setdefault(str(t), []).append(n)
    path = out_dir / "average_csmi_by_galaxy_type.csv"
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["cptg_mode_type", "count", "mean_CSMI_N", "median_CSMI_N", "std_CSMI_N"])
        order = [label for _, label in MODE_TYPE_THRESHOLDS]
        for t in order + sorted(set(groups) - set(order)):
            if t not in groups: continue
            vals = np.array(groups[t], dtype=float)
            w.writerow(format_csv_row([t, len(vals), float(np.mean(vals)), float(np.median(vals)), float(np.std(vals))]))
    return path


def scan_directory_for_sparc_files(directory: Path, recursive: bool = False) -> List[Path]:
    if not directory.exists():
        raise ValueError(f"Directory does not exist: {directory}")
    if not directory.is_dir():
        raise ValueError(f"Path is not a directory: {directory}")
    patterns = ["*.dat", "*.DAT", "*.txt", "*.TXT", "*.csv", "*.CSV"]
    files: List[Path] = []
    for pat in patterns:
        iterator = directory.rglob(pat) if recursive else directory.glob(pat)
        files.extend(iterator)
    filtered = []
    metadata_like_names = {"sparc_lelli2016c", "table1", "sample_metadata", "metadata"}
    for p in files:
        name = p.name.lower()
        stem = p.stem.lower()
        try:
            relative_parent_parts = [part.lower() for part in p.relative_to(directory).parts[:-1]]
        except ValueError:
            relative_parent_parts = [part.lower() for part in p.parent.parts]
        if DEFAULT_METADATA_DIR_NAME.lower() in relative_parent_parts:
            continue
        if any(token in name for token in ["metadata", "readme", "index", "notes"]):
            continue
        if stem in metadata_like_names or stem.startswith("table1"):
            continue
        filtered.append(p)
    result = sorted(set(filtered), key=lambda p: str(p).lower())
    # SPARC database archives are often unpacked with one nested folder under
    # sparc_database. If the selected/default folder contains no top-level
    # galaxy files, automatically search subdirectories instead of reporting
    # an empty scan.
    if not result and not recursive:
        return scan_directory_for_sparc_files(directory, recursive=True)
    return result



def resolve_selected_sparc_paths(raw_paths: List[Any], sparc_dir: Path) -> List[Path]:
    """Validate checkbox-selected galaxy paths against the package-local scan."""
    available = {path.resolve(): path.resolve() for path in scan_directory_for_sparc_files(sparc_dir, recursive=True)}
    selected: List[Path] = []
    seen = set()
    for raw_path in raw_paths:
        path = Path(str(raw_path)).expanduser().resolve()
        if path not in available:
            raise ValueError(f"Selected galaxy file is not available in the configured SPARC directory: {path}")
        if path not in seen:
            selected.append(path)
            seen.add(path)
    if not selected:
        raise ValueError("Select at least one galaxy before running the comparison.")
    return selected


def flatten_summary_for_batch(summary: Dict[str, Any], metadata: Dict[str, Any]) -> Dict[str, Any]:
    row = {
        "galaxy": summary.get("galaxy"), "source_name": summary.get("source_name"), "valid_points": summary.get("valid_points"),
        "locked_release_version": summary.get("locked_release_version", LOCKED_RELEASE_VERSION),
        "mean_observed_velocity_km_s": summary.get("mean_observed_velocity_km_s"),
        "mean_cptg_velocity_km_s": summary.get("mean_cptg_velocity_km_s"),
        "mean_mond_velocity_km_s": summary.get("mean_mond_velocity_km_s"),
        "a_star_min_m_s2": summary.get("a_star_min_m_s2"),
        "a_star_median_m_s2": summary.get("a_star_median_m_s2"),
        "a_star_max_m_s2": summary.get("a_star_max_m_s2"),
        "kappa_C_kpc": summary.get("kappa_C_kpc"), "A_C": summary.get("A_C"), "c_C": summary.get("c_C"),
        "CSMI_N": summary.get("CSMI_N"),
        "mode_label": summary.get("mode_label"), "metadata_type": metadata_type_label(metadata),
        "primary_sample_known": summary.get("metadata_primary_sample_known"), "primary_sample": summary.get("metadata_primary_sample"), "primary_sample_label": summary.get("metadata_primary_sample_label"),
        "metadata_sample_status": summary.get("metadata_sample_status", "n/a"), "metadata_sample_reason": summary.get("metadata_sample_reason", ""),
        "inc_deg": metadata.get("inc_deg"), "e_inc_deg": metadata.get("e_inc_deg"), "q_flag": metadata.get("q_flag"),
        "inclination_systematics_available": summary.get("metadata_inclination_known"),
        "winner": summary.get("winner"), "cptg_chi2": summary.get("CPTG", {}).get("chi2"), "mond_chi2": summary.get("MOND", {}).get("chi2"),
        "cptg_chi2_per_point": summary.get("CPTG", {}).get("chi2_per_point"), "mond_chi2_per_point": summary.get("MOND", {}).get("chi2_per_point"),
        "cptg_rms_km_s": summary.get("CPTG", {}).get("rms_km_s"), "mond_rms_km_s": summary.get("MOND", {}).get("rms_km_s"),
        "cptg_mae_km_s": summary.get("CPTG", {}).get("mae_km_s"), "mond_mae_km_s": summary.get("MOND", {}).get("mae_km_s"),
        "cptg_rar_scatter_dex": summary.get("CPTG", {}).get("rar_scatter_dex"), "mond_rar_scatter_dex": summary.get("MOND", {}).get("rar_scatter_dex"),
    }
    if summary.get("CPTG_inclination_systematic"):
        row["cptg_chi2_inclination_systematic"] = summary.get("CPTG_inclination_systematic", {}).get("chi2")
        row["mond_chi2_inclination_systematic"] = summary.get("MOND_inclination_systematic", {}).get("chi2")
        row["cptg_chi2_per_point_inclination_systematic"] = summary.get("CPTG_inclination_systematic", {}).get("chi2_per_point")
        row["mond_chi2_per_point_inclination_systematic"] = summary.get("MOND_inclination_systematic", {}).get("chi2_per_point")
    for k, v in metadata.items():
        if k.startswith("meta_") or k in ("Galaxy", "T", "Q", "inc_deg", "e_inc_deg", "q_flag"):
            row[k] = v
    return row


def run_batch_from_files(
    file_items: List[Tuple[str, str]],
    out_base: Path,
    metadata_records: Optional[Dict[str, Dict[str, Any]]] = None,
    batch_label: str = "BATCH",
    create_bundle: bool = True,
) -> Dict[str, Any]:
    stamp = _dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    out_dir = out_base / f"{stamp}_{batch_label}"
    out_dir.mkdir(parents=True, exist_ok=True)
    results_rows: List[Dict[str, Any]] = []
    failures: List[Dict[str, Any]] = []
    metadata_exclusions: List[Dict[str, Any]] = []
    metadata_unmatched: List[Dict[str, Any]] = []
    curves: List[Dict[str, np.ndarray]] = []
    rar_records: List[Dict[str, np.ndarray]] = []
    grid = np.linspace(0.02, 1.0, 80)
    metadata_records = metadata_records or {}
    primary_filter_active = primary_filter_is_active(metadata_records)

    for filename, content in file_items:
        try:
            galaxy = parse_sparc_dat_text(content, filename)
            status, meta, reason = classify_metadata_sample(metadata_records, galaxy.name, primary_filter_active)
            # Explicit browser selections are always processed; metadata status
            # is recorded for reporting and filtering.
            if status == "excluded":
                metadata_exclusions.append(
                    metadata_exclusion_row(filename, galaxy.name, meta, included_in_run=True)
                )
            elif status == "unmatched":
                metadata_unmatched.append(
                    metadata_unmatched_row(filename, galaxy.name, meta, reason, included_in_run=True)
                )

            res = run_galaxy_analysis(
                galaxy,
                out_dir / galaxy.name,
                meta,
                create_bundle=False,
                metadata_sample_status_value=status,
                metadata_sample_reason_value=reason,
            )
            results_rows.append(flatten_summary_for_batch(res["summary"], meta))
            curves.append(normalized_curve_record(galaxy.name, res["arrays"], grid))
            rar_records.append(normalized_rar_record(galaxy.name, res["arrays"], grid))
        except Exception as exc:
            failures.append({"source_name": filename, "source_path": "", "error": str(exc)})

    return finalize_batch_outputs(
        out_dir,
        results_rows,
        failures,
        curves,
        rar_records,
        metadata_records,
        metadata_exclusions=metadata_exclusions,
        metadata_unmatched=metadata_unmatched,
        create_bundle=create_bundle,
        selected_file_count=len(file_items),
        source_mode="server-local-file-picker",
    )


def finalize_batch_outputs(
    out_dir: Path,
    results_rows: List[Dict[str, Any]],
    failures: List[Dict[str, Any]],
    curves: List[Dict[str, np.ndarray]],
    rar_records: List[Dict[str, np.ndarray]],
    metadata_records: Dict[str, Dict[str, Any]],
    metadata_exclusions: Optional[List[Dict[str, Any]]] = None,
    metadata_unmatched: Optional[List[Dict[str, Any]]] = None,
    create_bundle: bool = True,
    **extra_summary: Any,
) -> Dict[str, Any]:
    metadata_exclusions = metadata_exclusions or []
    metadata_unmatched = metadata_unmatched or []

    results_csv = out_dir / "batch_galaxy_results.csv"
    all_keys: List[str] = []
    for row in results_rows:
        for key in row.keys():
            if key not in all_keys:
                all_keys.append(key)
    if not all_keys:
        all_keys = ["galaxy", "error"]
    with results_csv.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=all_keys, extrasaction="ignore")
        writer.writeheader()
        for row in results_rows:
            writer.writerow(format_csv_dict(row))

    failures_csv = out_dir / "batch_failures.csv"
    with failures_csv.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["source_name", "source_path", "error"], extrasaction="ignore")
        writer.writeheader()
        for row in failures:
            writer.writerow(format_csv_dict(row))

    def write_status_report(path: Path, rows: List[Dict[str, Any]]) -> None:
        keys: List[str] = []
        for row in rows:
            for key in row.keys():
                if key not in keys:
                    keys.append(key)
        if not keys:
            keys = ["source_name", "source_path", "galaxy", "metadata_status", "reason", "included_in_run"]
        with path.open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=keys, extrasaction="ignore")
            writer.writeheader()
            for row in rows:
                writer.writerow(format_csv_dict(row))

    metadata_excluded_csv = out_dir / "batch_metadata_excluded.csv"
    metadata_unmatched_csv = out_dir / "batch_metadata_unmatched.csv"
    write_status_report(metadata_excluded_csv, metadata_exclusions)
    write_status_report(metadata_unmatched_csv, metadata_unmatched)

    avg_curve_csv = avg_curve_png = None
    avg_rar_csv = avg_rar_png = None
    if curves:
        avg_curve_csv, avg_curve_png = write_average_rotation_curve(curves, out_dir)
    if rar_records:
        avg_rar_csv, avg_rar_png = write_average_rar_scatter_vs_radius(rar_records, out_dir)
    type_csmi_csv = write_average_csmi_by_mode_type(results_rows, out_dir)

    def vals(key: str) -> List[float]:
        values: List[float] = []
        for row in results_rows:
            try:
                value = float(row[key])
                if np.isfinite(value):
                    values.append(value)
            except Exception:
                pass
        return values

    def mean_of(key: str) -> float:
        values = vals(key)
        return float(np.mean(values)) if values else float("nan")

    def median_of(key: str) -> float:
        values = vals(key)
        return float(np.median(values)) if values else float("nan")

    def weighted_mean_of(value_key: str, weight_key: str = "valid_points") -> float:
        numerator = 0.0
        denominator = 0.0
        for row in results_rows:
            try:
                value = float(row[value_key])
                weight = float(row[weight_key])
            except Exception:
                continue
            if np.isfinite(value) and np.isfinite(weight) and weight > 0.0:
                numerator += value * weight
                denominator += weight
        return numerator / denominator if denominator > 0.0 else float("nan")

    groups: Dict[str, List[float]] = {}
    for row in results_rows:
        mode_type = row.get("mode_label") or "Unknown"
        try:
            mode_n = float(row.get("CSMI_N"))
            if np.isfinite(mode_n):
                groups.setdefault(str(mode_type), []).append(mode_n)
        except Exception:
            pass
    type_summary = []
    order = [label for _, label in MODE_TYPE_THRESHOLDS]
    for mode_type in order + sorted(set(groups) - set(order)):
        if mode_type not in groups:
            continue
        arr = np.array(groups[mode_type], dtype=float)
        type_summary.append({
            "cptg_mode_type": mode_type,
            "count": int(len(arr)),
            "mean_CSMI_N": float(np.mean(arr)),
            "median_CSMI_N": float(np.median(arr)),
            "std_CSMI_N": float(np.std(arr)),
        })

    cptg_wins = sum(1 for row in results_rows if row.get("winner") == "CPTG")
    mond_wins = sum(1 for row in results_rows if row.get("winner") == "MOND")
    total_points = sum(int(row.get("valid_points") or 0) for row in results_rows)
    total_cptg_chi2 = sum(float(row.get("cptg_chi2") or 0.0) for row in results_rows)
    total_mond_chi2 = sum(float(row.get("mond_chi2") or 0.0) for row in results_rows)
    primary_filter_active = primary_filter_is_active(metadata_records)
    primary_rows = [row for row in results_rows if row.get("metadata_sample_status") == "primary"]
    excluded_included = sum(1 for row in results_rows if row.get("metadata_sample_status") == "excluded")
    unmatched_included = sum(1 for row in results_rows if row.get("metadata_sample_status") == "unmatched")
    primary_points = sum(int(row.get("valid_points") or 0) for row in primary_rows)
    primary_cptg_chi2 = sum(float(row.get("cptg_chi2") or 0.0) for row in primary_rows)
    primary_mond_chi2 = sum(float(row.get("mond_chi2") or 0.0) for row in primary_rows)
    inclination_rows = [row for row in results_rows if bool(row.get("inclination_systematics_available"))]

    included_metadata_statuses = {
        str(row.get("metadata_sample_status") or "n/a")
        for row in results_rows
    }
    if not primary_filter_active:
        aggregate_scope = "All selected galaxies"
    elif included_metadata_statuses == {"primary"}:
        aggregate_scope = "Primary sample"
    elif included_metadata_statuses == {"excluded"}:
        aggregate_scope = "Excluded sample"
    elif included_metadata_statuses == {"unmatched"}:
        aggregate_scope = "Metadata-unmatched sample"
    else:
        aggregate_scope = "Selected galaxies (mixed metadata status)"
    primary_summary = {
        "metadata_primary_filter_active": primary_filter_active,
        "metadata_aggregate_scope": aggregate_scope,
        "metadata_primary_sample_galaxies": len(primary_rows),
        "metadata_excluded_sample_galaxies": len(metadata_exclusions),
        "metadata_unmatched_galaxies": len(metadata_unmatched),
        "metadata_excluded_included_galaxies": excluded_included,
        "metadata_unmatched_included_galaxies": unmatched_included,
        "metadata_primary_sample_points": primary_points,
        "metadata_primary_cptg_wins": sum(1 for row in primary_rows if row.get("winner") == "CPTG"),
        "metadata_primary_mond_wins": sum(1 for row in primary_rows if row.get("winner") == "MOND"),
        "metadata_primary_cptg_chi2": primary_cptg_chi2 if primary_rows else float("nan"),
        "metadata_primary_mond_chi2": primary_mond_chi2 if primary_rows else float("nan"),
        "metadata_primary_cptg_chi2_per_point": primary_cptg_chi2 / max(primary_points, 1) if primary_rows else float("nan"),
        "metadata_primary_mond_chi2_per_point": primary_mond_chi2 / max(primary_points, 1) if primary_rows else float("nan"),
        "metadata_inclination_systematic_galaxies": len(inclination_rows),
    }

    summary = {
        "locked_release_version": LOCKED_RELEASE_VERSION,
        "batch_output_dir": str(out_dir),
        "valid_galaxies": len(results_rows),
        "failed_files": len(failures),
        "cptg_wins": cptg_wins,
        "mond_wins": mond_wins,
        "metadata_records_loaded": len(metadata_records),
        **primary_summary,
        "total_points": total_points,
        "total_cptg_chi2": total_cptg_chi2 if results_rows else float("nan"),
        "total_mond_chi2": total_mond_chi2 if results_rows else float("nan"),
        "aggregate_cptg_chi2_per_point": total_cptg_chi2 / total_points if total_points > 0 else float("nan"),
        "aggregate_mond_chi2_per_point": total_mond_chi2 / total_points if total_points > 0 else float("nan"),
        "mean_observed_velocity_km_s": weighted_mean_of("mean_observed_velocity_km_s"),
        "mean_cptg_velocity_km_s": weighted_mean_of("mean_cptg_velocity_km_s"),
        "mean_mond_velocity_km_s": weighted_mean_of("mean_mond_velocity_km_s"),
        "mean_cptg_chi2_per_point": mean_of("cptg_chi2_per_point"),
        "mean_mond_chi2_per_point": mean_of("mond_chi2_per_point"),
        "median_cptg_chi2_per_point": median_of("cptg_chi2_per_point"),
        "median_mond_chi2_per_point": median_of("mond_chi2_per_point"),
        "mean_cptg_rms_km_s": mean_of("cptg_rms_km_s"),
        "mean_mond_rms_km_s": mean_of("mond_rms_km_s"),
        "mean_cptg_mae_km_s": mean_of("cptg_mae_km_s"),
        "mean_mond_mae_km_s": mean_of("mond_mae_km_s"),
        "mean_cptg_rar_scatter_dex": mean_of("cptg_rar_scatter_dex"),
        "mean_mond_rar_scatter_dex": mean_of("mond_rar_scatter_dex"),
        "mean_CSMI_N": mean_of("CSMI_N"),
        "median_CSMI_N": median_of("CSMI_N"),
        "average_CSMI_by_galaxy_type": type_summary,
        "outputs": {
            "batch_galaxy_results_csv": str(results_csv),
            "batch_failures_csv": str(failures_csv),
            "batch_metadata_excluded_csv": str(metadata_excluded_csv),
            "batch_metadata_unmatched_csv": str(metadata_unmatched_csv),
            "average_rotation_curve_csv": str(avg_curve_csv) if avg_curve_csv else None,
            "average_rotation_curve_png": str(avg_curve_png) if avg_curve_png else None,
            "average_rar_scatter_vs_radius_csv": str(avg_rar_csv) if avg_rar_csv else None,
            "average_rar_scatter_vs_radius_png": str(avg_rar_png) if avg_rar_png else None,
            "average_csmi_by_galaxy_type_csv": str(type_csmi_csv),
            "batch_summary_json": str(out_dir / "batch_summary.json"),
            "results_bundle_zip": str(out_dir / "results_bundle.zip") if create_bundle else None,
        },
        **extra_summary,
    }
    with (out_dir / "batch_summary.json").open("w", encoding="utf-8") as f:
        json.dump(format_report_object(summary), f, indent=2)
    if create_bundle:
        create_results_bundle(out_dir)
    return summary


# ----------------------------
# Local browser interface
# ----------------------------


def b64_file(path: Optional[Path]) -> Optional[str]:
    if not path or not path.exists():
        return None
    return base64.b64encode(path.read_bytes()).decode("ascii")


def read_post(handler: BaseHTTPRequestHandler) -> bytes:
    length = int(handler.headers.get("Content-Length", "0") or "0")
    return handler.rfile.read(length) if length else b""


def parse_multipart(body: bytes, content_type: str) -> Dict[str, Any]:
    m = re.search(r"boundary=(.+)", content_type)
    if not m:
        return {}
    boundary = m.group(1)
    if boundary.startswith('"') and boundary.endswith('"'):
        boundary = boundary[1:-1]
    marker = ("--" + boundary).encode("utf-8")
    parts = body.split(marker)
    out: Dict[str, Any] = {}
    for part in parts:
        if not part or part in (b"--\r\n", b"--"):
            continue
        part = part.strip(b"\r\n")
        if not part or b"\r\n\r\n" not in part:
            continue
        head, data = part.split(b"\r\n\r\n", 1)
        headers = head.decode("utf-8", errors="replace")
        name_m = re.search(r'name="([^"]+)"', headers)
        if not name_m or re.search(r'filename="', headers):
            continue
        out[name_m.group(1)] = data.rstrip(b"\r\n").decode("utf-8", errors="replace")
    return out


def app_base_dir() -> Path:
    """Return the folder that should anchor local package defaults."""
    if getattr(sys, "frozen", False):
        return Path.cwd().resolve()
    return Path(__file__).resolve().parent


def default_sparc_dir() -> Path:
    """Return the package-local SPARC data directory used as the UI default."""
    return (app_base_dir() / DEFAULT_SPARC_DIR_NAME).resolve()


def default_metadata_dir(sparc_dir: Optional[Path] = None) -> Path:
    """Return the package-local SPARC metadata directory used by metadata pickers."""
    return ((sparc_dir or default_sparc_dir()) / DEFAULT_METADATA_DIR_NAME).resolve()


def choose_metadata_file_dialog(sparc_dir: Optional[Path] = None) -> List[str]:
    """Open the native local metadata-file chooser."""
    try:
        import tkinter as tk
        from tkinter import filedialog

        root = tk.Tk()
        root.withdraw()
        root.attributes("-topmost", True)
        initial_path = default_metadata_dir(sparc_dir)
        initial_path.mkdir(parents=True, exist_ok=True)
        chosen = filedialog.askopenfilename(
            title="Select optional SPARC metadata file",
            initialdir=str(initial_path),
            filetypes=[
                ("Metadata files", ("*.mrt", "*.dat", "*.txt", "*.csv", "*.tsv", "*.json")),
                ("All files", "*.*"),
            ],
        )
        try:
            root.destroy()
        except Exception:
            pass
        return [str(Path(chosen).resolve())] if chosen else []
    except Exception:
        return []

def read_text_file(path: Path) -> str:
    """Read a local text file selected through the server-side picker."""
    if not path.exists() or not path.is_file():
        raise ValueError(f"Selected file does not exist: {path}")
    return path.read_text(encoding="utf-8", errors="replace")



def help_page() -> str:
    """Render a structured local browser help page."""
    return f"""<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>CPTG SPARC Workbench Help</title>
<style>
body {{ font-family: Segoe UI, Arial, sans-serif; margin:0; background:#f6f7f9; color:#1f2937; }}
header {{ background:#111827; color:white; padding:22px 30px; }}
main {{ max-width:1120px; margin:0 auto; padding:24px; }}
.help-card {{ background:white; padding:22px 24px; margin:16px 0; border-radius:12px; box-shadow:0 2px 12px rgba(0,0,0,0.08); }}
h1 {{ margin:0; }}
h2 {{ margin-top:0; border-bottom:1px solid #e5e7eb; padding-bottom:8px; }}
h3 {{ margin-bottom:8px; }}
a {{ color:#0f766e; font-weight:700; }}
.back {{ display:inline-block; color:white; background:#14532d; text-decoration:none; padding:8px 12px; border-radius:8px; margin-top:12px; }}
pre {{ white-space:pre-wrap; word-wrap:break-word; background:#f3f4f6; border:1px solid #e5e7eb; padding:12px; border-radius:8px; overflow:auto; }}
code {{ background:#f3f4f6; padding:2px 5px; border-radius:4px; }}
table {{ border-collapse:collapse; width:100%; margin-top:10px; }}
th, td {{ border:1px solid #d1d5db; padding:8px 10px; text-align:left; vertical-align:top; }}
th {{ background:#f3f4f6; }}
li {{ margin:5px 0; }}
footer {{ max-width:1120px; margin:0 auto; padding:4px 24px 28px; text-align:center; font-size:0.9rem; }}
.copyright-link {{ color:#374151; font-weight:600; text-decoration:none; }}
.copyright-link:hover {{ text-decoration:underline; }}
</style>
</head>
<body>
<header>
  <h1>CPTG SPARC Workbench Help</h1>
  <a class="back" href="/" target="_self">Back to workbench</a>
</header>
<main>
{HELP_HTML_BODY}
</main>
<footer><a class="copyright-link" href="{html.escape(COPYRIGHT_URL)}" target="_blank" rel="noopener noreferrer">&copy; {COPYRIGHT_YEAR} {html.escape(COPYRIGHT_AUTHOR)}</a></footer>
</body>
</html>"""


def html_page(
    result: Optional[Dict[str, Any]] = None,
    error: Optional[str] = None,
    output_dir: Optional[str] = None,
    sparc_dir: Optional[str] = None,
    selected_paths: Optional[List[str]] = None,
    metadata_path: Optional[str] = None,
    save_outputs: bool = False
) -> str:
    result = result or {}
    sparc_root = Path(sparc_dir).expanduser().resolve() if sparc_dir else default_sparc_dir()
    output_dir_value = html.escape(output_dir or DEFAULT_OUT_DIR)
    selected_set = {str(Path(path).expanduser().resolve()) for path in (selected_paths or [])}
    metadata_path_value = (metadata_path or "").strip()
    metadata_path_attr = html.escape(metadata_path_value, quote=True)
    metadata_display_name = re.split(r"[\\/]", metadata_path_value)[-1] if metadata_path_value else ""
    metadata_display_text = metadata_display_name or "No metadata file selected."
    metadata_display_title = html.escape(metadata_path_value, quote=True)
    save_outputs_checked = " checked" if save_outputs else ""
    single = result.get("single")
    batch = result.get("batch")
    err_html = f'<div class="error"><b>Run failed</b><br>{html.escape(error)}</div>' if error else ""

    try:
        galaxy_paths = scan_directory_for_sparc_files(sparc_root, recursive=True)
        scan_error = ""
    except Exception as exc:
        galaxy_paths = []
        scan_error = str(exc)

    galaxy_rows: List[str] = []
    for path in galaxy_paths:
        resolved = str(path.resolve())
        try:
            relative = str(path.resolve().relative_to(sparc_root))
        except ValueError:
            relative = path.name
        is_selected = resolved in selected_set
        selected_class = " selected" if is_selected else ""
        checked = " checked" if is_selected else ""
        display_name = path.stem
        if display_name.lower().endswith("_rotmod"):
            display_name = display_name[:-7]
        # Search only the displayed galaxy identifier. Excluding the common
        # _rotmod.dat suffix ensures a one-character search such as "d"
        # actually filters the list instead of matching every .dat file.
        search_text = display_name.lower()
        galaxy_rows.append(
            f'<label class="galaxy-row{selected_class}" data-search="{html.escape(search_text, quote=True)}" data-path="{html.escape(resolved, quote=True)}" data-metadata-status="n/a" title="{html.escape(relative, quote=True)}">'
            f'<input class="galaxy-checkbox" type="checkbox" value="{html.escape(resolved, quote=True)}"{checked}>'
            f'<span class="galaxy-name">{html.escape(display_name)}</span>'
            '<span class="metadata-status-marker" aria-hidden="true"></span>'
            '</label>'
        )
    if galaxy_rows:
        galaxy_list_html = "".join(galaxy_rows)
        galaxy_status_html = f'<span id="galaxy-total-count">{len(galaxy_rows)} galaxies available</span>'
    else:
        detail = f" ({html.escape(scan_error)})" if scan_error else ""
        galaxy_list_html = f'<div class="empty-galaxy-list">No supported galaxy files were found in <code>{html.escape(str(sparc_root))}</code>{detail}.</div>'
        galaxy_status_html = '<span id="galaxy-total-count">0 galaxies available</span>'

    def link_for(path: Optional[str], text_label: str) -> str:
        if not path:
            return ""
        return f'<a href="/file?path={html.escape(path, quote=True)}" target="_blank">{html.escape(text_label)}</a>'

    single_html = ""
    if single:
        s = single["summary"]
        saved_to_disk = bool(single.get("saved_to_disk"))
        rot_path = s.get("outputs", {}).get("rotation_curve_png")
        rar_path = s.get("outputs", {}).get("rar_scatter_vs_radius_png")
        rot = b64_file(Path(rot_path)) if rot_path else None
        rar = b64_file(Path(rar_path)) if rar_path else None
        metadata_status = str(s.get("metadata_sample_status") or "n/a")
        metadata_sample_display_value = metadata_sample_display(metadata_status)
        metadata_reason = str(s.get("metadata_sample_reason") or "")
        metadata_note_html = ""
        if metadata_status in {"excluded", "unmatched"} and metadata_reason:
            metadata_note_html = f'<div><b>Metadata note:</b> {html.escape(metadata_reason)}</div>'
        single_downloads = ""
        if saved_to_disk:
            single_downloads = f"<p>{link_for(s['outputs']['point_results_csv'], 'Download point_results.csv')} &nbsp; {link_for(s['outputs']['summary_json'], 'Download summary.json')} &nbsp; {link_for(s['outputs'].get('results_bundle_zip'), 'Download complete results ZIP')}</p>"
        single_save_note = (
            f"<p class=\"save-status saved\"><b>Saved:</b> {html.escape(str(Path(s['outputs']['summary_json']).parent))}</p>"
            if saved_to_disk else
            "<p class=\"save-status\"><b>Not saved:</b> This result is displayed in the browser only.</p>"
        )
        single_html = f"""
        <section class="card result-card" id="results"><h2>Single-galaxy result: {html.escape(s['galaxy'])}</h2>
        <div class="comparison-table-wrap"><table class="comparison-table">
          <thead><tr><th>Metric</th><th>Observed</th><th>CPTG</th><th>MOND</th></tr></thead>
          <tbody>
            <tr><td>Total points</td><td colspan="3" class="shared-points-cell" title="The same radial points are used for Observed, CPTG, and MOND">{s.get('valid_points', s['CPTG'].get('n_points'))}</td></tr>
            <tr><td>Total χ²</td><td>n/a</td><td>{fmt_html(s['CPTG']['chi2'])}</td><td>{fmt_html(s['MOND']['chi2'])}</td></tr>
            <tr><td>χ²/point</td><td>n/a</td><td>{fmt_html(s['CPTG']['chi2_per_point'])}</td><td>{fmt_html(s['MOND']['chi2_per_point'])}</td></tr>
            <tr><td>RMS residual (km/s)</td><td>n/a</td><td>{fmt_html(s['CPTG']['rms_km_s'])}</td><td>{fmt_html(s['MOND']['rms_km_s'])}</td></tr>
            <tr><td>Mean velocity (km/s)</td><td>{fmt_html(s.get('mean_observed_velocity_km_s'))}</td><td>{fmt_html(s.get('mean_cptg_velocity_km_s'))}</td><td>{fmt_html(s.get('mean_mond_velocity_km_s'))}</td></tr>
          </tbody>
        </table></div>
        <div class="grid">
          <div><b>a⋆ local median:</b> {fmt_html(s['a_star_median_m_s2'])} m/s²</div>
          <div><b>a⋆ local range:</b> {fmt_html(s['a_star_min_m_s2'])} to {fmt_html(s['a_star_max_m_s2'])} m/s²</div>
          <div><b>κ<sub>C</sub>:</b> {fmt_html(s['kappa_C_kpc'])} kpc</div>
          <div><b>A<sub>C</sub>:</b> {fmt_html(s['A_C'])}</div>
          <div><b>c<sub>C</sub>:</b> {fmt_html(s['c_C'])}</div>
          <div><b>CSMI N:</b> {fmt_html(s['CSMI_N'])}</div>
          <div><b>Mode type:</b> {html.escape(s['mode_label'])}</div>
          <div><b>Winner:</b> {html.escape(s['winner'])}</div>
          <div><b>Metadata sample:</b> {html.escape(metadata_sample_display_value)}</div>
          <div><b>Inclination systematics:</b> {html.escape('available' if s.get('metadata_inclination_known') else 'n/a')}</div>
          {metadata_note_html}
        </div>
        {single_save_note}
        {single_downloads}
        <div class="plots">{f'<img src="data:image/png;base64,{rot}" alt="rotation curve">' if rot else ''}{f'<img src="data:image/png;base64,{rar}" alt="RAR scatter vs radius">' if rar else ''}</div>
        </section>"""

    batch_html = ""
    if batch:
        saved_to_disk = bool(batch.get("saved_to_disk"))
        avg_png = batch.get("outputs", {}).get("average_rotation_curve_png")
        avg_b64 = b64_file(Path(avg_png)) if avg_png else None
        avg_rar_png = batch.get("outputs", {}).get("average_rar_scatter_vs_radius_png")
        avg_rar_b64 = b64_file(Path(avg_rar_png)) if avg_rar_png else None
        batch_downloads = ""
        if saved_to_disk:
            batch_downloads = f"<p>{link_for(batch['outputs']['batch_galaxy_results_csv'], 'Download batch_galaxy_results.csv')} &nbsp; {link_for(batch['outputs']['batch_failures_csv'], 'Download batch_failures.csv')} &nbsp; {link_for(batch['outputs'].get('batch_metadata_excluded_csv'), 'Download batch_metadata_excluded.csv')} &nbsp; {link_for(batch['outputs'].get('batch_metadata_unmatched_csv'), 'Download batch_metadata_unmatched.csv')} &nbsp; {link_for(batch['outputs']['average_rotation_curve_csv'], 'Download average_rotation_curve.csv')} &nbsp; {link_for(batch['outputs']['average_rar_scatter_vs_radius_csv'], 'Download average_rar_scatter_vs_radius.csv')} &nbsp; {link_for(batch['outputs']['average_csmi_by_galaxy_type_csv'], 'Download average_csmi_by_galaxy_type.csv')} &nbsp; {link_for(batch['outputs']['batch_summary_json'], 'Download batch_summary.json')} &nbsp; {link_for(batch['outputs'].get('results_bundle_zip'), 'Download complete results ZIP')}</p>"
        batch_save_note = (
            f"<p class=\"save-status saved\"><b>Saved:</b> {html.escape(str(batch.get('batch_output_dir', '')))}</p>"
            if saved_to_disk else
            "<p class=\"save-status\"><b>Not saved:</b> This result is displayed in the browser only.</p>"
        )
        type_rows = ""
        for row in batch.get("average_CSMI_by_galaxy_type", []):
            type_rows += f"<tr><td>{html.escape(str(row.get('cptg_mode_type','')))}</td><td>{row.get('count','')}</td><td>{fmt_html(row.get('mean_CSMI_N'))}</td><td>{fmt_html(row.get('median_CSMI_N'))}</td><td>{fmt_html(row.get('std_CSMI_N'))}</td></tr>"
        if batch.get("metadata_primary_filter_active"):
            metadata_batch_html = (
                f"<div><b>Aggregate:</b> {html.escape(str(batch.get('metadata_aggregate_scope', 'Primary sample')))}</div>"
                f"<div><b>Primary:</b> {batch.get('metadata_primary_sample_galaxies', 0)}</div>"
                f"<div><b>Outside primary:</b> {batch.get('metadata_excluded_sample_galaxies', 0)}</div>"
                f"<div><b>Unmatched:</b> {batch.get('metadata_unmatched_galaxies', 0)}</div>"
            )
        else:
            metadata_batch_html = "<div><b>Aggregate:</b> All selected galaxies</div>"
        batch_html = f"""
        <section class="card result-card" id="results"><h2>Batch result</h2>
        <div class="comparison-table-wrap"><table class="comparison-table">
          <thead><tr><th>Metric</th><th>Observed</th><th>CPTG</th><th>MOND</th></tr></thead>
          <tbody>
            <tr><td>Total points</td><td colspan="3" class="shared-points-cell" title="The same radial points are used for Observed, CPTG, and MOND">{batch.get('total_points', 0)}</td></tr>
            <tr><td>Total χ²</td><td>n/a</td><td>{fmt_html(batch.get('total_cptg_chi2'))}</td><td>{fmt_html(batch.get('total_mond_chi2'))}</td></tr>
            <tr><td>χ²/point (all points)</td><td>n/a</td><td>{fmt_html(batch.get('aggregate_cptg_chi2_per_point'))}</td><td>{fmt_html(batch.get('aggregate_mond_chi2_per_point'))}</td></tr>
            <tr><td>Mean galaxy χ²/point</td><td>n/a</td><td>{fmt_html(batch.get('mean_cptg_chi2_per_point'))}</td><td>{fmt_html(batch.get('mean_mond_chi2_per_point'))}</td></tr>
            <tr><td>Mean velocity (km/s)</td><td>{fmt_html(batch.get('mean_observed_velocity_km_s'))}</td><td>{fmt_html(batch.get('mean_cptg_velocity_km_s'))}</td><td>{fmt_html(batch.get('mean_mond_velocity_km_s'))}</td></tr>
          </tbody>
        </table></div>
        <div class="grid">
          <div><b>Valid galaxies:</b> {batch.get('valid_galaxies')}</div>
          <div><b>Failed files:</b> {batch.get('failed_files')}</div>
          <div><b>CPTG wins:</b> {batch.get('cptg_wins')}</div>
          <div><b>MOND wins:</b> {batch.get('mond_wins')}</div>
          {metadata_batch_html}
          <div><b>Mean CSMI N:</b> {fmt_html(batch.get('mean_CSMI_N'))}</div>
          <div><b>Median CSMI N:</b> {fmt_html(batch.get('median_CSMI_N'))}</div>
        </div>
        {batch_save_note}
        {batch_downloads}
        <div class="plots">{f'<img src="data:image/png;base64,{avg_b64}" alt="average rotation curve">' if avg_b64 else '<p>No average curve generated.</p>'}{f'<img src="data:image/png;base64,{avg_rar_b64}" alt="average RAR scatter vs radius">' if avg_rar_b64 else '<p>No average RAR plot generated.</p>'}</div>
        <h3>Average CSMI by CPTG mode type</h3><table><thead><tr><th>CPTG mode type</th><th>Count</th><th>Mean CSMI N</th><th>Median CSMI N</th><th>Std</th></tr></thead><tbody>{type_rows}</tbody></table>
        </section>"""

    browser_behavior_script = r"""<script>
(function () {
  var metadataPolicyActive = false;

  function allRows() {
    return Array.prototype.slice.call(document.querySelectorAll(".galaxy-row"));
  }

  function selectedCheckboxes() {
    return Array.prototype.slice.call(document.querySelectorAll(".galaxy-checkbox:checked"));
  }

  function visibleRows() {
    return allRows().filter(function (row) { return row.style.display !== "none"; });
  }

  function updateMetadataSelectionSummary() {
    var summary = document.getElementById("metadata-status-summary");
    if (!summary) { return; }
    if (!metadataPolicyActive) {
      summary.hidden = true;
      summary.textContent = "";
      return;
    }
    var selectedRows = selectedCheckboxes().map(function (checkbox) { return checkbox.closest(".galaxy-row"); });
    var rows = selectedRows.length ? selectedRows : allRows();
    var counts = {primary: 0, excluded: 0, unmatched: 0};
    rows.forEach(function (row) {
      var status = row ? (row.getAttribute("data-metadata-status") || "unmatched") : "unmatched";
      if (counts.hasOwnProperty(status)) { counts[status] += 1; }
    });
    summary.hidden = false;
    summary.textContent = (selectedRows.length ? "Selected" : "Metadata") + ": P " + counts.primary + " · X " + counts.excluded + " · ? " + counts.unmatched;
    summary.title = "P = primary, X = outside primary sample, ? = metadata unmatched";
  }

  function updateSelectionState() {
    var selected = selectedCheckboxes();
    allRows().forEach(function (row) {
      var checkbox = row.querySelector(".galaxy-checkbox");
      row.classList.toggle("selected", !!(checkbox && checkbox.checked));
    });
    var counter = document.getElementById("selected-galaxy-count");
    if (counter) {
      counter.textContent = "Selected: " + selected.length + (selected.length === 1 ? " galaxy" : " galaxies");
    }
    var runButton = document.getElementById("run-selected-button");
    if (runButton) {
      runButton.disabled = selected.length === 0;
      runButton.textContent = selected.length === 1 ? "Run selected galaxy" : "Run selected galaxies";
    }
    var selectAll = document.getElementById("select-all-visible");
    if (selectAll) {
      var visible = visibleRows();
      var checkedVisible = visible.filter(function (row) {
        var checkbox = row.querySelector(".galaxy-checkbox");
        return checkbox && checkbox.checked;
      });
      selectAll.checked = visible.length > 0 && checkedVisible.length === visible.length;
      selectAll.indeterminate = checkedVisible.length > 0 && checkedVisible.length < visible.length;
    }
    updateMetadataSelectionSummary();
  }

  function applySearchFilter() {
    var search = document.getElementById("galaxy-search");
    var statusFilter = document.getElementById("metadata-status-filter");
    var query = search ? search.value.trim().toLowerCase() : "";
    var wantedStatus = (metadataPolicyActive && statusFilter) ? statusFilter.value : "all";
    allRows().forEach(function (row) {
      var text = row.getAttribute("data-search") || "";
      var status = row.getAttribute("data-metadata-status") || "n/a";
      var searchMatch = !query || text.indexOf(query) !== -1;
      var statusMatch = wantedStatus === "all" || status === wantedStatus;
      row.style.display = (searchMatch && statusMatch) ? "" : "none";
    });
    var visibleCount = visibleRows().length;
    var visibleLabel = document.getElementById("visible-galaxy-count");
    if (visibleLabel) { visibleLabel.textContent = visibleCount + " visible"; }
    updateSelectionState();
  }

  function clearMetadataPolicy() {
    metadataPolicyActive = false;
    allRows().forEach(function (row) {
      row.setAttribute("data-metadata-status", "n/a");
      row.removeAttribute("data-metadata-reason");
      var marker = row.querySelector(".metadata-status-marker");
      if (marker) {
        marker.textContent = "";
        marker.className = "metadata-status-marker";
        marker.title = "";
      }
    });
    var policyRow = document.getElementById("metadata-policy-row");
    if (policyRow) { policyRow.hidden = true; }
    var statusFilter = document.getElementById("metadata-status-filter");
    if (statusFilter) { statusFilter.value = "all"; statusFilter.disabled = true; }
    applySearchFilter();
  }

  function applyMetadataStatusPayload(data) {
    metadataPolicyActive = !!(data && data.active);
    var statuses = data && data.statuses ? data.statuses : {};
    allRows().forEach(function (row) {
      var path = row.getAttribute("data-path") || "";
      var item = statuses[path] || {status: metadataPolicyActive ? "unmatched" : "n/a", reason: ""};
      var status = item.status || "n/a";
      row.setAttribute("data-metadata-status", status);
      row.setAttribute("data-metadata-reason", item.reason || "");
      var marker = row.querySelector(".metadata-status-marker");
      if (marker) {
        marker.className = "metadata-status-marker status-" + status.replace(/[^a-z]/g, "");
        marker.textContent = status === "primary" ? "P" : (status === "excluded" ? "X" : (status === "unmatched" ? "?" : ""));
        marker.title = item.reason || "";
      }
    });
    var policyRow = document.getElementById("metadata-policy-row");
    if (policyRow) { policyRow.hidden = !metadataPolicyActive; }
    var statusFilter = document.getElementById("metadata-status-filter");
    if (statusFilter) {
      statusFilter.disabled = !metadataPolicyActive;
      if (metadataPolicyActive) {
        var savedFilter = "";
        try { savedFilter = window.sessionStorage.getItem("cptgMetadataStatusFilter") || ""; } catch (exc) { savedFilter = ""; }
        if (["all", "primary", "excluded", "unmatched"].indexOf(savedFilter) === -1) { savedFilter = "primary"; }
        statusFilter.value = savedFilter;
      } else {
        statusFilter.value = "all";
      }
    }
    applySearchFilter();
  }

  function loadMetadataStatuses(path) {
    if (!path) { clearMetadataPolicy(); return; }
    fetch("/metadata-status-json?path=" + encodeURIComponent(path), {cache: "no-store"})
      .then(function (response) {
        if (!response.ok) { throw new Error("Metadata status request failed"); }
        return response.json();
      })
      .then(applyMetadataStatusPayload)
      .catch(function () {
        clearMetadataPolicy();
        window.alert("The metadata file was selected, but its primary-sample status could not be loaded.");
      });
  }

  function showProcessingOverlay(selectionCount) {
    var overlay = document.getElementById("selection-processing-overlay");
    var title = document.getElementById("selection-processing-title");
    var message = document.getElementById("selection-processing-message");
    if (title) { title.textContent = selectionCount === 1 ? "Processing selected galaxy" : "Processing selected galaxies"; }
    if (message) {
      message.textContent = selectionCount === 1
        ? "The selected galaxy is being processed locally."
        : selectionCount + " selected galaxies are being processed locally.";
    }
    document.body.classList.add("selection-processing");
    document.body.setAttribute("aria-busy", "true");
    if (overlay) { overlay.setAttribute("aria-hidden", "false"); }
  }

  function bindGalaxySelection() {
    var form = document.getElementById("galaxy-selection-form");
    var hidden = document.getElementById("selected_sparc_paths");
    var search = document.getElementById("galaxy-search");
    var selectAll = document.getElementById("select-all-visible");
    var clearButton = document.getElementById("clear-galaxy-selection");
    var statusFilter = document.getElementById("metadata-status-filter");

    document.querySelectorAll(".galaxy-checkbox").forEach(function (checkbox) {
      checkbox.addEventListener("change", updateSelectionState);
    });
    if (search) { search.addEventListener("input", applySearchFilter); }
    if (statusFilter) {
      statusFilter.addEventListener("change", function () {
        try { window.sessionStorage.setItem("cptgMetadataStatusFilter", statusFilter.value); } catch (exc) {}
        applySearchFilter();
      });
    }
    if (selectAll) {
      selectAll.addEventListener("change", function () {
        visibleRows().forEach(function (row) {
          var checkbox = row.querySelector(".galaxy-checkbox");
          if (checkbox) { checkbox.checked = selectAll.checked; }
        });
        updateSelectionState();
      });
    }
    if (clearButton) {
      clearButton.addEventListener("click", function () {
        document.querySelectorAll(".galaxy-checkbox").forEach(function (checkbox) { checkbox.checked = false; });
        updateSelectionState();
      });
    }
    if (form) {
      form.addEventListener("submit", function (event) {
        var selected = selectedCheckboxes();
        if (!selected.length) {
          event.preventDefault();
          window.alert("Select at least one galaxy before running the comparison.");
          return false;
        }
        if (form.dataset.submitting === "1") {
          event.preventDefault();
          return false;
        }
        if (hidden) {
          hidden.value = JSON.stringify(selected.map(function (checkbox) { return checkbox.value; }));
        }
        form.dataset.submitting = "1";
        showProcessingOverlay(selected.length);
      });
    }
    applySearchFilter();
  }

  function setSelectionDisplay(display, paths) {
    if (!display) { return; }
    var fullPath = paths && paths.length ? paths[0] : "";
    var fileName = fullPath ? fullPath.split(/[\\/]/).pop() : "";
    display.textContent = fileName || "No metadata file selected.";
    display.title = fullPath;
  }

  function bindMetadataPicker() {
    var button = document.querySelector("[data-choose-metadata]");
    var resetButton = document.getElementById("reset-metadata-file");
    var target = document.getElementById("metadata_path");
    var display = document.getElementById("metadata_display");

    if (resetButton) {
      resetButton.addEventListener("click", function () {
        if (target) { target.value = ""; }
        setSelectionDisplay(display, []);
        clearMetadataPolicy();
      });
    }

    if (button) {
      button.addEventListener("click", function (event) {
        event.preventDefault();
        var savedX = window.scrollX || window.pageXOffset || 0;
        var savedY = window.scrollY || window.pageYOffset || 0;
        target = document.querySelector(button.getAttribute("data-target-input") || "");
        display = document.querySelector(button.getAttribute("data-target-display") || "");
        var originalText = button.textContent;
        button.textContent = "Browse...";
        button.setAttribute("aria-busy", "true");
        fetch("/choose-file-json?kind=metadata&multiple=0", {cache: "no-store"})
          .then(function (response) {
            if (!response.ok) { throw new Error("Metadata picker request failed"); }
            return response.json();
          })
          .then(function (data) {
            var paths = data && data.paths ? data.paths : [];
            if (target && paths.length) {
              target.value = paths[0];
              setSelectionDisplay(display, paths);
              loadMetadataStatuses(paths[0]);
            }
          })
          .catch(function () { window.alert("Metadata picker was cancelled or unavailable."); })
          .finally(function () {
            button.textContent = originalText;
            button.removeAttribute("aria-busy");
            window.scrollTo(savedX, savedY);
            window.setTimeout(function () { window.scrollTo(savedX, savedY); }, 50);
          });
      });
    }

    if (target && target.value) { loadMetadataStatuses(target.value); }
    else { clearMetadataPolicy(); }
  }

  function bindWorkbenchBehavior() {
    bindGalaxySelection();
    bindMetadataPicker();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", bindWorkbenchBehavior);
  } else {
    bindWorkbenchBehavior();
  }
})();
</script>"""

    result_scroll_script = ""
    if single or batch:
        result_scroll_script = r"""<script>
(function () {
  function scrollToResults() {
    var el = document.getElementById("results") || document.querySelector(".result-card");
    if (!el) { return; }
    el.scrollIntoView({behavior: "auto", block: "start"});
  }
  if ("scrollRestoration" in history) { history.scrollRestoration = "manual"; }
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", scrollToResults);
  } else {
    scrollToResults();
  }
  window.addEventListener("load", function () {
    scrollToResults();
    window.setTimeout(scrollToResults, 100);
    window.setTimeout(scrollToResults, 350);
  });
})();
</script>"""

    return f"""<!doctype html>
<html><head><meta charset="utf-8"><title>{html.escape(APP_TITLE)}</title>
<style>
body {{ font-family: Segoe UI, Arial, sans-serif; margin:0; background:#f6f7f9; color:#1f2937; }}
.app-header {{ background:#111827; color:white; padding:12px 30px; display:flex; align-items:center; justify-content:space-between; gap:24px; }} .header-left {{ min-width:0; }} .header-left h1 {{ margin:0; font-size:1.65rem; line-height:1.12; }} .app-subtitle {{ margin-top:3px; color:#e5e7eb; font-size:0.95rem; }} .header-right {{ display:flex; align-items:center; justify-content:flex-end; gap:12px; flex:0 0 auto; }} main {{ max-width:1180px; margin:0 auto; padding:24px; }}
.card {{ background:white; padding:20px; margin:18px 0; border-radius:12px; box-shadow:0 2px 12px rgba(0,0,0,0.08); }}
label {{ font-weight:600; }} input[type=text] {{ width:100%; padding:10px; border:1px solid #cfd4dc; border-radius:8px; box-sizing:border-box; }}
button {{ background:#14532d; color:white; border:0; padding:10px 18px; border-radius:8px; font-weight:700; cursor:pointer; }} button:hover:not(:disabled) {{ background:#166534; }} button:disabled {{ background:#9ca3af; cursor:not-allowed; }}
.browsebtn {{ display:inline-block; text-decoration:none; background:#1f2937; color:white; padding:10px 14px; border-radius:8px; font-weight:700; text-align:center; }} .browsebtn:hover {{ background:#374151; }}
.selected-file-display {{ margin-top:8px; padding:10px; background:#f9fafb; border:1px solid #e5e7eb; border-radius:8px; color:#374151; word-break:break-all; }}
.help {{ color:#4b5563; font-size:0.95rem; }} .versionbar {{ margin:0; color:#d1d5db; font-size:0.95rem; white-space:nowrap; }} .error {{ background:#fee2e2; color:#7f1d1d; border:1px solid #fecaca; padding:14px; border-radius:8px; margin:14px 0; white-space:pre-wrap; }}
.grid {{ display:grid; grid-template-columns:repeat(auto-fit,minmax(240px,1fr)); gap:10px; }} .plots {{ display:grid; grid-template-columns:repeat(auto-fit,minmax(360px,1fr)); gap:16px; }}
img {{ width:100%; max-width:100%; height:auto; border:1px solid #e5e7eb; border-radius:8px; background:white; }} code {{ background:#f3f4f6; padding:2px 5px; border-radius:4px; }} table {{ border-collapse:collapse; width:100%; font-size:0.92rem; }} th,td {{ border:1px solid #d1d5db; padding:6px 8px; text-align:left; }} th {{ background:#f3f4f6; }} .comparison-table-wrap {{ overflow-x:auto; margin:10px 0 14px; }} .comparison-table {{ min-width:560px; margin:0; }} .comparison-table th:not(:first-child),.comparison-table td:not(:first-child) {{ text-align:right; white-space:nowrap; }} .comparison-table th:first-child {{ width:34%; }} .comparison-table .shared-points-cell {{ text-align:center !important; font-weight:400; }}
.toplinks {{ margin:0; display:flex; gap:10px; flex-wrap:wrap; }} .toplinks a {{ color:white; background:#14532d; text-decoration:none; padding:7px 11px; border-radius:8px; font-weight:700; }} .toplinks a:hover {{ background:#166534; }}
.selection-tools {{ display:flex; gap:10px; align-items:end; margin-bottom:12px; flex-wrap:wrap; }}
.galaxy-search-block {{ flex:0 1 50%; min-width:280px; }}
.selection-tools label {{ display:block; margin-bottom:5px; }} .selection-actions {{ display:flex; gap:8px; align-items:center; flex-wrap:wrap; }}
.select-all-control {{ display:flex !important; align-items:center; gap:7px; min-height:40px; padding:0 10px; border:1px solid #d1d5db; border-radius:8px; background:#f9fafb; margin-bottom:0 !important; }}
.secondary-button {{ background:#4b5563; margin:0; }} .secondary-button:hover:not(:disabled) {{ background:#374151; }}
.selection-summary {{ display:flex; justify-content:space-between; gap:12px; flex-wrap:wrap; padding:9px 12px; margin-bottom:10px; background:#f3f4f6; border-radius:8px; color:#374151; }} #metadata-status-summary {{ font-weight:700; color:#374151; }}
.galaxy-list {{ display:grid; grid-template-columns:repeat(5,minmax(0,1fr)); grid-auto-rows:40px; max-height:205px; overflow:auto; border:1px solid #d1d5db; border-radius:10px; background:#f9fafb; }}
.galaxy-row {{ display:flex; gap:8px; align-items:center; min-width:0; padding:8px 10px; border-right:1px solid #e5e7eb; border-bottom:1px solid #e5e7eb; cursor:pointer; font-weight:400; transition:background 0.12s ease, box-shadow 0.12s ease; }}
.galaxy-row:hover {{ background:#eef2f7; }} .galaxy-row.selected {{ background:#dcfce7; box-shadow:inset 4px 0 0 #15803d; }}
.galaxy-checkbox {{ width:17px; height:17px; flex:0 0 auto; accent-color:#15803d; }} .galaxy-name {{ min-width:0; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; font-weight:700; color:#111827; }} .metadata-status-marker {{ display:none; margin-left:auto; width:20px; height:20px; flex:0 0 20px; align-items:center; justify-content:center; border-radius:999px; font-size:0.72rem; font-weight:800; }} .metadata-status-marker.status-primary,.metadata-status-marker.status-excluded,.metadata-status-marker.status-unmatched {{ display:inline-flex; }} .metadata-status-marker.status-primary {{ background:#dcfce7; color:#166534; }} .metadata-status-marker.status-excluded {{ background:#fee2e2; color:#991b1b; }} .metadata-status-marker.status-unmatched {{ background:#e5e7eb; color:#4b5563; }}
.empty-galaxy-list {{ grid-column:1 / -1; padding:18px; color:#7f1d1d; }}
.metadata-run-row {{ display:grid; grid-template-columns:minmax(0,560px) auto; gap:16px; align-items:end; justify-content:space-between; margin-top:14px; }}
.metadata-block {{ min-width:0; }} .metadata-block > label {{ display:block; margin-bottom:7px; }} .metadata-controls {{ display:grid; grid-template-columns:auto auto minmax(180px,280px); gap:8px; align-items:center; max-width:680px; }} .metadata-reset-button {{ padding:10px 14px; }}
.metadata-controls .selected-file-display {{ margin-top:0; min-width:0; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }} .metadata-policy-row {{ display:flex; gap:10px; align-items:center; margin-top:8px; flex-wrap:wrap; }} .metadata-policy-row[hidden] {{ display:none; }} .compact-control {{ display:flex; align-items:center; gap:6px; min-height:34px; padding:0 9px; border:1px solid #d1d5db; border-radius:8px; background:#f9fafb; font-size:0.9rem; font-weight:600; }} .compact-control input {{ accent-color:#15803d; }} .compact-control select {{ border:0; background:transparent; font:inherit; color:#1f2937; padding:2px 0; }}
.run-selection-row {{ display:flex; align-items:center; gap:12px; flex-wrap:nowrap; white-space:nowrap; }}
.save-output-control {{ display:flex; align-items:center; gap:7px; min-height:40px; padding:0 10px; border:1px solid #d1d5db; border-radius:8px; background:#f9fafb; font-weight:600; }} .save-output-control input {{ accent-color:#15803d; }}
.save-status {{ padding:9px 12px; border-radius:8px; background:#f3f4f6; color:#374151; }} .save-status.saved {{ background:#dcfce7; color:#14532d; }}
#selection-processing-overlay {{ position:fixed; inset:0; display:none; align-items:center; justify-content:center; background:rgba(17,24,39,0.58); z-index:9999; pointer-events:all; }}
body.selection-processing #selection-processing-overlay {{ display:flex; }} body.selection-processing {{ cursor:wait; }} body.selection-processing main, body.selection-processing header {{ user-select:none; }}
.processing-box {{ background:white; color:#111827; width:min(440px, calc(100vw - 48px)); padding:28px 32px; border-radius:16px; box-shadow:0 20px 60px rgba(0,0,0,0.35); text-align:center; border:1px solid #e5e7eb; }}
.processing-box h2 {{ margin:12px 0 8px; font-size:1.35rem; }} .processing-box p {{ margin:0; color:#4b5563; line-height:1.45; }}
.processing-spinner {{ width:44px; height:44px; border-radius:50%; border:5px solid #e5e7eb; border-top-color:#14532d; margin:0 auto; animation:selection-spin 0.9s linear infinite; }} @keyframes selection-spin {{ to {{ transform:rotate(360deg); }} }}
@media (max-width:1050px) {{ .galaxy-list {{ grid-template-columns:repeat(3,minmax(0,1fr)); }} }}
@media (max-width:760px) {{ .app-header {{ padding:12px 20px; align-items:flex-start; }} .header-left h1 {{ font-size:1.4rem; }} .header-right {{ gap:8px; }} .galaxy-search-block {{ flex-basis:100%; min-width:0; }} .galaxy-list {{ grid-template-columns:repeat(2,minmax(0,1fr)); }} .metadata-run-row {{ grid-template-columns:1fr; }} .run-selection-row {{ justify-content:space-between; }} }}
@media (max-width:480px) {{ .app-header {{ flex-direction:column; gap:8px; }} .header-right {{ width:100%; justify-content:space-between; }} .galaxy-list {{ grid-template-columns:1fr; }} .metadata-controls {{ grid-template-columns:1fr 1fr; }} .metadata-controls .selected-file-display {{ grid-column:1 / -1; }} .run-selection-row {{ align-items:stretch; flex-direction:column; white-space:normal; }} }}
footer {{ max-width:1180px; margin:0 auto; padding:4px 24px 28px; text-align:center; font-size:0.9rem; }}
.copyright-link {{ color:#374151; font-weight:600; text-decoration:none; }}
.copyright-link:hover {{ text-decoration:underline; }}
</style></head><body>
<div id="selection-processing-overlay" role="status" aria-live="assertive" aria-modal="true" aria-hidden="true"><div class="processing-box"><div class="processing-spinner" aria-hidden="true"></div><h2 id="selection-processing-title">Processing selected galaxies</h2><p id="selection-processing-message">Selected galaxies are being processed locally.</p></div></div>
<header class="app-header"><div class="header-left"><h1>{html.escape(APP_TITLE)}</h1><div class="app-subtitle">{html.escape(APP_SUBTITLE)}</div></div><div class="header-right"><div class="versionbar">Version: {html.escape(APP_VERSION)}</div><div class="toplinks"><a href="/help" target="_self">Help</a></div></div></header><main>
{err_html}
<section class="card" id="galaxy-selection"><h2>Galaxy selection</h2>
<form id="galaxy-selection-form" method="post" action="/run-selected" enctype="multipart/form-data">
<input type="hidden" id="selected_sparc_paths" name="selected_sparc_paths" value="[]">
<div class="selection-tools">
  <div class="galaxy-search-block"><label for="galaxy-search">Search galaxies</label><input type="text" id="galaxy-search" placeholder="Enter a galaxy name"></div>
  <label class="select-all-control"><input type="checkbox" id="select-all-visible"> Select all visible</label>
  <button class="secondary-button" type="button" id="clear-galaxy-selection">Clear selection</button>
</div>
<div class="selection-summary"><span>{galaxy_status_html}</span><span id="visible-galaxy-count">{len(galaxy_rows)} visible</span><span id="metadata-status-summary" hidden></span></div>
<div class="galaxy-list" id="galaxy-list">{galaxy_list_html}</div>
<div class="metadata-run-row">
  <div class="metadata-block"><label>Metadata</label><input type="hidden" id="metadata_path" name="metadata_path" value="{metadata_path_attr}"><div class="metadata-controls"><a class="browsebtn" href="#" data-choose-metadata="1" data-target-input="#metadata_path" data-target-display="#metadata_display">Metadata</a><button class="secondary-button metadata-reset-button" type="button" id="reset-metadata-file">Reset metadata</button><div class="selected-file-display" id="metadata_display" title="{metadata_display_title}">{html.escape(metadata_display_text)}</div></div><div class="metadata-policy-row" id="metadata-policy-row" hidden><label class="compact-control">Show <select id="metadata-status-filter" disabled><option value="primary" selected>Primary</option><option value="all">All</option><option value="excluded">Excluded</option><option value="unmatched">Unmatched</option></select></label></div></div>
  <div class="run-selection-row"><strong id="selected-galaxy-count">Selected: {len(selected_set)} galaxies</strong><label class="save-output-control"><input type="checkbox" id="save_outputs" name="save_outputs" value="1"{save_outputs_checked}> Save result files</label><button id="run-selected-button" type="submit"{' disabled' if not selected_set else ''}>Run selected galaxies</button></div>
</div>
</form></section>
{single_html}{batch_html}
<section class="card"><h2>Outputs</h2><p>Results are displayed without saving by default. Select <strong>Save result files</strong> before a run to write a folder under <code>{output_dir_value}</code> and create downloadable output files.</p></section>
{browser_behavior_script}
{result_scroll_script}
</main><footer><a class="copyright-link" href="{html.escape(COPYRIGHT_URL)}" target="_blank" rel="noopener noreferrer">&copy; {COPYRIGHT_YEAR} {html.escape(COPYRIGHT_AUTHOR)}</a></footer></body></html>"""


class WorkbenchHandler(BaseHTTPRequestHandler):
    server_version = f"CPTGSPARCWorkbench/{APP_VERSION}"

    @property
    def out_base(self) -> Path:
        return Path(getattr(self.server, "out_base", Path.cwd() / DEFAULT_OUT_DIR))

    @property
    def sparc_dir(self) -> Path:
        return Path(getattr(self.server, "sparc_dir", default_sparc_dir()))

    def _send_html(
        self,
        result: Optional[Dict[str, Any]] = None,
        error: Optional[str] = None,
        selected_paths: Optional[List[str]] = None,
        metadata_path: Optional[str] = None,
        save_outputs: bool = False
    ) -> None:
        body = html_page(
            result=result,
            error=error,
            output_dir=str(self.out_base),
            sparc_dir=str(self.sparc_dir),
            selected_paths=selected_paths,
            metadata_path=metadata_path,
            save_outputs=save_outputs,
        ).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self) -> None:
        try:
            parsed = urlparse(self.path)
            if parsed.path == "/":
                self._send_html()
                return
            if parsed.path == "/help":
                body = help_page().encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Cache-Control", "no-store")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
                return
            if parsed.path == "/metadata-status-json":
                qs = parse_qs(parsed.query)
                metadata_path_value = (qs.get("path", [""])[0] or "").strip()
                if not metadata_path_value:
                    self.send_error(400, "Metadata path is required.")
                    return
                metadata_path = Path(metadata_path_value).expanduser().resolve()
                metadata_records = parse_metadata_text(read_text_file(metadata_path), metadata_path.name)
                active = primary_filter_is_active(metadata_records)
                statuses: Dict[str, Dict[str, str]] = {}
                counts = {"primary": 0, "excluded": 0, "unmatched": 0}
                for galaxy_path in scan_directory_for_sparc_files(self.sparc_dir, recursive=True):
                    galaxy_name = _clean_name_from_filename(galaxy_path.name)
                    status, _, reason = classify_metadata_sample(metadata_records, galaxy_name, active)
                    statuses[str(galaxy_path.resolve())] = {"status": status, "reason": reason}
                    if status in counts:
                        counts[status] += 1
                payload = json.dumps({
                    "ok": True,
                    "active": active,
                    "metadata_file": metadata_path.name,
                    "records_loaded": len(metadata_records),
                    "counts": counts,
                    "statuses": statuses,
                }).encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "application/json; charset=utf-8")
                self.send_header("Cache-Control", "no-store")
                self.send_header("Content-Length", str(len(payload)))
                self.end_headers()
                self.wfile.write(payload)
                return
            if parsed.path == "/choose-file-json":
                paths = choose_metadata_file_dialog(self.sparc_dir)
                payload = json.dumps({"paths": paths, "ok": bool(paths), "count": len(paths)}).encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "application/json; charset=utf-8")
                self.send_header("Cache-Control", "no-store")
                self.send_header("Content-Length", str(len(payload)))
                self.end_headers()
                self.wfile.write(payload)
                return
            if parsed.path == "/file":
                qs = parse_qs(parsed.query)
                path = Path(qs.get("path", [""])[0])
                if not path.exists() or not path.is_file():
                    self.send_error(404, "File not found")
                    return
                data = path.read_bytes()
                self.send_response(200)
                self.send_header("Content-Type", "application/octet-stream")
                self.send_header("Content-Disposition", f'attachment; filename="{path.name}"')
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)
                return
            self.send_error(404)
        except Exception as exc:
            self._send_html(error=f"{exc}\n\n{traceback.format_exc()}")

    def do_POST(self) -> None:
        selected_path_strings: List[str] = []
        metadata_path_value = ""
        save_outputs_requested = False
        try:
            if self.path != "/run-selected":
                self.send_error(404)
                return

            form = parse_multipart(read_post(self), self.headers.get("Content-Type", ""))
            selected_paths_raw = (form.get("selected_sparc_paths") or "").strip()
            try:
                decoded_paths = json.loads(selected_paths_raw)
            except Exception as exc:
                raise ValueError("Selected galaxy list could not be parsed.") from exc
            if not isinstance(decoded_paths, list):
                raise ValueError("Selected galaxy list is invalid.")
            selected_paths = resolve_selected_sparc_paths(decoded_paths, self.sparc_dir)
            selected_path_strings = [str(path) for path in selected_paths]

            save_outputs_requested = (form.get("save_outputs") or "").strip().lower() in {"1", "true", "on", "yes"}

            metadata_records: Dict[str, Dict[str, Any]] = {}
            metadata_path_value = (form.get("metadata_path") or "").strip()
            if metadata_path_value:
                metadata_path = Path(metadata_path_value).expanduser().resolve()
                metadata_records = parse_metadata_text(read_text_file(metadata_path), metadata_path.name)
            primary_filter_active = primary_filter_is_active(metadata_records)

            def run_and_send(run_base: Path, persistent: bool) -> None:
                if len(selected_paths) == 1:
                    path = selected_paths[0]
                    galaxy = parse_sparc_dat_text(read_text_file(path), path.name)
                    status, meta, reason = classify_metadata_sample(metadata_records, galaxy.name, primary_filter_active)
                    out_dir = run_base / f"{_dt.datetime.now().strftime('%Y%m%d_%H%M%S')}_{galaxy.name}"
                    single = run_galaxy_analysis(
                        galaxy,
                        out_dir,
                        meta,
                        create_bundle=persistent,
                        metadata_sample_status_value=status,
                        metadata_sample_reason_value=reason,
                    )
                    single["saved_to_disk"] = persistent
                    # Successful runs reset selection controls while retaining
                    # the metadata file itself for the next comparison.
                    self._send_html(result={"single": single}, metadata_path=metadata_path_value)
                    return

                file_items = [(path.name, read_text_file(path)) for path in selected_paths]
                batch = run_batch_from_files(
                    file_items,
                    run_base,
                    metadata_records,
                    batch_label="SELECTED_BATCH",
                    create_bundle=persistent,
                )
                batch["saved_to_disk"] = persistent
                self._send_html(result={"batch": batch}, metadata_path=metadata_path_value)

            if save_outputs_requested:
                run_and_send(self.out_base, True)
                return

            # Unsaved results use an operating-system temporary directory. The
            # result page embeds the plots before this context exits, then every
            # generated CSV, JSON, image, and run folder is deleted automatically.
            with tempfile.TemporaryDirectory(prefix="cptg_sparc_unsaved_", ignore_cleanup_errors=True) as temp_root:
                run_and_send(Path(temp_root), False)
        except Exception as exc:
            self._send_html(
                error=f"{exc}\n\n{traceback.format_exc()}",
                selected_paths=selected_path_strings,
                metadata_path=metadata_path_value,
                save_outputs=save_outputs_requested,
            )

    def log_message(self, fmt: str, *args: Any) -> None:
        sys.stderr.write("%s - - [%s] %s\n" % (self.client_address[0], self.log_date_time_string(), fmt % args))


def _browser_url_for(host: str, port: int) -> str:
    browser_host = "127.0.0.1" if host in ("0.0.0.0", "::", "") else host
    return f"http://{browser_host}:{port}/"


def open_browser_after_start(url: str, delay_seconds: float = 0.8) -> None:
    """Open the default browser without blocking server startup."""
    def _open() -> None:
        try:
            webbrowser.open(url, new=2)
        except Exception:
            pass
    timer = threading.Timer(delay_seconds, _open)
    timer.daemon = True
    timer.start()



def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(description=f"{APP_TITLE} - {APP_SUBTITLE}")
    parser.add_argument("--host", default=DEFAULT_HOST, help="Server host. Default: 127.0.0.1")
    parser.add_argument("--port", type=int, default=DEFAULT_PORT, help="Server port. Default: 8787")
    parser.add_argument("--out", default=DEFAULT_OUT_DIR, help="Output run folder. Default: runs")
    parser.add_argument("--sparc-dir", default=str(default_sparc_dir()), help="Default SPARC data directory shown in the browser. Default: package-local sparc_database")
    parser.add_argument("--no-browser", action="store_true", help="Start the local server without opening the default browser.")
    args = parser.parse_args(argv)

    out_base = Path(args.out).expanduser()
    sparc_dir = Path(args.sparc_dir).expanduser().resolve()
    if args.sparc_dir == str(default_sparc_dir()):
        sparc_dir.mkdir(parents=True, exist_ok=True)
    server = ThreadingHTTPServer((args.host, args.port), WorkbenchHandler)
    server.out_base = out_base
    server.sparc_dir = sparc_dir

    url = _browser_url_for(args.host, args.port)
    print(APP_TITLE)
    print(APP_SUBTITLE)
    print(f"Version: {APP_VERSION} (locked {LOCKED_RELEASE_VERSION})")
    print(f"Serving {url}")
    print(f"Saved run outputs (opt-in): {out_base}")
    print(f"Default SPARC directory: {sparc_dir}")
    if args.no_browser:
        print("Browser auto-open disabled by --no-browser.")
    else:
        print("Opening default browser...")
        open_browser_after_start(url)
    print("Press Ctrl+C to stop.")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nWorkbench stopped.")
        return 0
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
