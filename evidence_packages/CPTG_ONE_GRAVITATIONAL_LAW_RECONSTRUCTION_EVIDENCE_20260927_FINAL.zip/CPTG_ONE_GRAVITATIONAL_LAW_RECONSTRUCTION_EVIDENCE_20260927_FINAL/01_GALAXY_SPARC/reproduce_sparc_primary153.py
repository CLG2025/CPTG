#!/usr/bin/env python3
"""Reconstruct the locked SPARC primary-153 CPTG solved field from source inputs and final coordinates."""
from pathlib import Path
import importlib.util
import sys
import numpy as np
import pandas as pd

BASE = Path(__file__).resolve().parent
SOLVER = BASE / 'cptg_sparc_browser_workbench_v1.13.0.py'
INPUT = BASE / 'SPARC_PRIMARY153_DIRECT_SOURCE_INPUT.csv'
REFERENCE = BASE / 'SPARC_PRIMARY153_REFERENCE_GALAXY_RESULTS.csv'
OUT = BASE / 'REPRODUCED_PRIMARY153_SOLVED_CHECK.csv'
REPORT = BASE / 'REPRODUCTION_CHECK.txt'


def load_solver():
    spec = importlib.util.spec_from_file_location('cptg_wb_v113_replay', SOLVER)
    wb = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = wb
    spec.loader.exec_module(wb)
    return wb


def main():
    wb = load_solver()
    inp = pd.read_csv(INPUT)
    ref = pd.read_csv(REFERENCE).set_index('galaxy')
    if inp.galaxy.nunique() != 153 or len(inp) != 3168:
        raise SystemExit('input sample is not the locked 153-galaxy / 3168-point sample')
    if set(inp.galaxy) != set(ref.index):
        raise SystemExit('input and reference galaxy sets differ')

    rows = []
    for galaxy, g in inp.groupby('galaxy', sort=False):
        g = g.sort_values('radius_kpc')
        r = g.radius_kpc.to_numpy(float) * wb.KPC_TO_M
        v = g.Vobs_km_s.to_numpy(float) * 1000.0
        e = g.sigmaV_km_s.to_numpy(float) * 1000.0
        gb = wb.build_physical_baryonic_field(
            r,
            g.Vgas_km_s.to_numpy(float) * 1000.0,
            g.Vdisk_km_s.to_numpy(float) * 1000.0,
            g.Vbulge_km_s.to_numpy(float) * 1000.0,
        )
        rr = ref.loc[galaxy]
        support = wb.resolved_support_state(r, v, e)
        bpol = wb.cptg_bpol_from_support(r, support, float(rr.kappa_C_kpc))
        g_cptg, suppression = wb._solve_cptg_implicit_high_accel(
            gb,
            support['a_star_local'],
            support['Sigma_C_squared'],
            bpol,
            float(rr.A_C),
            float(rr.c_C),
        )
        if g_cptg is None:
            raise SystemExit(f'implicit field solve failed for {galaxy}')

        v_cptg = np.sqrt(g_cptg * r)
        residual = (v_cptg - v) / e
        polarization = (
            float(rr.A_C)
            * np.maximum(support['a_star_local'], wb.EPS) ** (2.0 / 3.0)
            * bpol
            * suppression
        )
        denominator = 1.0 + float(rr.c_C) * support['Sigma_C_squared']
        rhs = (gb + polarization) / denominator
        closure_abs = float(np.max(np.abs(rhs - g_cptg)))
        closure_rel = float(np.max(np.abs(rhs - g_cptg) / np.maximum(np.abs(g_cptg), wb.EPS)))
        clip_count = int(np.count_nonzero(
            (support['Sigma_C_squared_raw'] < 0.0) |
            (support['Sigma_C_squared_raw'] > 1.0)
        ))
        rows.append({
            'galaxy': galaxy,
            'Npts': len(g),
            'chi2_cptg': float(np.sum(residual**2)),
            'median_abs_sigma': float(np.median(np.abs(residual))),
            'max_abs_sigma': float(np.max(np.abs(residual))),
            'formula_closure_abs_m_s2': closure_abs,
            'formula_closure_relmax': closure_rel,
            'sigma_clipped_points': clip_count,
        })

    out = pd.DataFrame(rows).set_index('galaxy').loc[ref.index]
    out.to_csv(OUT)

    compare = ['Npts','chi2_cptg','median_abs_sigma','max_abs_sigma','sigma_clipped_points']
    max_rel = {}
    max_abs = {}
    for c in compare:
        a = out[c].to_numpy(float)
        b = ref[c].to_numpy(float)
        max_abs[c] = float(np.max(np.abs(a-b)))
        max_rel[c] = float(np.max(np.abs(a-b) / np.maximum(np.abs(b), 1e-300)))

    total_c = float(out.chi2_cptg.sum())
    medmed = float(np.median(out.median_abs_sigma))
    below1 = int((out.median_abs_sigma < 1.0).sum())
    below2 = int((out.median_abs_sigma < 2.0).sum())
    below3 = int((out.median_abs_sigma < 3.0).sum())
    clipped = int(out.sigma_clipped_points.sum())
    max_closure_abs = float(out.formula_closure_abs_m_s2.max())
    max_closure_rel = float(out.formula_closure_relmax.max())

    status = (
        max_rel['chi2_cptg'] < 1e-10 and
        max_rel['median_abs_sigma'] < 1e-10 and
        max_rel['max_abs_sigma'] < 1e-10 and
        max_abs['sigma_clipped_points'] == 0.0 and
        clipped == 94 and
        max_closure_rel < 1e-11
    )

    with REPORT.open('w', encoding='utf-8') as f:
        f.write('CPTG SPARC PRIMARY-153 SOLVED-FIELD RECONSTRUCTION\n')
        f.write('status = ' + ('PASS' if status else 'FAIL') + '\n')
        f.write(f'galaxies = {len(out)}\npoints = {len(inp)}\n')
        f.write(f'aggregate_chi2_cptg = {total_c:.16g}\n')
        f.write(f'median_of_galaxy_median_abs_sigma = {medmed:.16g}\n')
        f.write(f'galaxies_below_1sigma_median = {below1}\n')
        f.write(f'galaxies_below_2sigma_median = {below2}\n')
        f.write(f'galaxies_below_3sigma_median = {below3}\n')
        f.write(f'sigma_clipped_points = {clipped}\n')
        f.write(f'max_implicit_closure_abs_m_s2 = {max_closure_abs:.16e}\n')
        f.write(f'max_implicit_closure_relative = {max_closure_rel:.16e}\n')
        for c in compare:
            f.write(f'max_relative_difference_{c} = {max_rel[c]:.16e}\n')
    print(REPORT.read_text(encoding='utf-8'), end='')
    if not status:
        raise SystemExit(2)


if __name__ == '__main__':
    main()
