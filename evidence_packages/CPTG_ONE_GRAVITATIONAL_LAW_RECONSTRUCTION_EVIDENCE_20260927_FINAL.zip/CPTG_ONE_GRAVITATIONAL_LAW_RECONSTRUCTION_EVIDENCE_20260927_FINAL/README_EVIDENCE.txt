A NEW CPTG GRAVITATIONAL LAW — FROM GALAXIES AND GALAXY CLUSTERS TO BLACK HOLES
Minimal Numerical Reconstruction Evidence
Date: 2026-09-27

PURPOSE
This archive contains only the numerical source inputs, executable equations/reconstruction
code, authoritative solved records, and integrity checks needed to reconstruct the numerical
results used by the cross-regime paper. Manuscript source, discussion material, run logs,
discarded trial outputs, duplicated subarchives, and unrelated diagnostics are excluded.

01_GALAXY_SPARC
SPARC_PRIMARY153_DIRECT_SOURCE_INPUT.csv contains the 3168 retained rows for the locked
153-galaxy sample with radius, observed velocity, observational uncertainty, and the original
Vgas, Vdisk, and Vbulge source components. These are the quantities required by the locked
v1.13.0 direct baryonic-source construction. The component rows are consolidated from the
SPARC Rotmod data (Lelli, McGaugh & Schombert; SPARC v1; DOI 10.5281/zenodo.16284118).

SPARC_PRIMARY153_REFERENCE_GALAXY_RESULTS.csv contains the authoritative final per-galaxy
solved coordinates and statistics. cptg_sparc_browser_workbench_v1.13.0.py is the locked
solver. reproduce_sparc_primary153.py rebuilds the direct baryonic field from Vgas/Vdisk/
Vbulge, reconstructs the support state, solves the implicit CPTG field at the authoritative
final coordinates, and independently recomputes only the CPTG statistics reported in this paper. The locked v1.13.0 workbench is preserved unchanged as the authoritative implementation; capabilities present in that software but not used by this paper are outside the publication replay.

The retained REPRODUCTION_CHECK.txt records the successful 153-galaxy / 3168-point replay.
The implicit CPTG equation closes at approximately 9.6e-16 relative in this reconstruction.

02_CLUSTER_XCOP
XCOP_SEVEN_CLUSTER_SOURCE_SUPPORT_INPUT.csv contains the seven-cluster baryonic mass source
(Mgas, Mstar, Mbaryon), baryonic acceleration, reconstructed support acceleration, and
support uncertainty on the 294 retained radii.

XCOP_SEVEN_CLUSTER_FINAL_SOLVED_POINTS.csv and XCOP_SEVEN_CLUSTER_REFERENCE_SUMMARY.csv are
the authoritative final solved records. verify_xcop_final_closure.py reconstructs Mbaryon,
g_baryon, the local structural acceleration identity, and the final implicit CPTG field.
REPRODUCTION_CHECK.txt records the successful equation closure. The registered support
residual is reconstructed directly as (g_C - g_support) / sigma_g at every retained radius.
The resulting aggregate chi-square = 266.11357298765 for 273 dof (reduced chi-square =
0.97477499263). The point table and cluster summary are generated from this same residual
definition, so the solved field and reported statistic are internally identical.

03_CLUSTER_ACCEPT
01_INPUTS/ACCEPT_all_profiles.dat is the independent ACCEPT profile input.
01_INPUTS/ACCEPT_FIXED_BARYONIC_SOURCE_GRID.csv contains only the fixed cluster, radius, and
baryonic-acceleration source grid needed by the solve.

02_CODE/accept_cptg_precision_forward_support.py contains the pressure/density support and
CPTG field functions needed by the reconstruction. reconstruct_accept_400.py rebuilds the
400-draw ACCEPT support state and covariance on the fixed source grid. replay_accept_final.py
then solves the CPTG field at the authoritative final coordinates. This separates independent
support reconstruction from optimizer-coordinate degeneracy and directly tests the solved
field used by the paper. verify_accept_reproduction.py compares the reconstructed solution
with 03_REFERENCE_FINAL.

03_REFERENCE_FINAL contains only the authoritative final point table, compact final summary,
aggregate statistics, and the seven covariance matrices required for verification.
RUN_REPRODUCTION.cmd performs the complete Windows reconstruction and verification chain.
The retained REPRODUCTION_CHECK.txt records 238 points, chi-square = 102.02949735052,
217 dof, and reduced covariance chi-square = 0.47018201544.

04_COMPACT_M33_X7
M33_X7_CONDITIONAL_MASS_SPIN_CLOSURE.csv contains only the retained central benchmark
(M_infinity = 15.65 Msun, a_infinity = 0.84). M33_X7_FINITE_INTERIOR_PROFILE.csv contains
the associated 1001-point finite interior profile. M33_X7_ROTATING_STRUCTURAL_MODE_REFERENCE.csv
records the spherical benchmark and the retained a_infinity = 0.79, 0.84, and 0.89 rotating
Structural Mode readouts, including the determinant-based equal-measure shell radius and
organization length. verify_m33_x7.py reconstructs the mass-spin mapping and finite profile
in a temporary location, leaves the reference evidence untouched, compares every retained
quantity, verifies the compact cubic and matching radius, reconstructs the geometric mass share,
exterior enhancement relative to physical source mass, and retained Kerr outer-horizon coordinate,
checks F(1)=1, F'(1)=0, F''(1)=0 and the mass-channel identity, and independently reconstructs the rotating Structural Mode
using the exact compact structural polynomial plus Gauss-Legendre integration before issuing
PASS. The rotating mode is a registered post-solution readout of the retained Kerr-compatible
mass-function geometry; it is not used to obtain the mass-spin closure.

05_CLUSTER_STRUCTURAL_MODE_N
CLUSTER_STRUCTURAL_MODE_N_REFERENCE.csv records the post-solution Structural Mode N readout
for all seven cluster fields. The X-COP value is the primary cluster structural readout used
in the paper. The ACCEPT value is retained separately as an independent support-reconstruction
sensitivity readout. The cluster mode is rederived from the solved spherical organization scale:
C_C(r)=3 g(r)^2+[r dg/dr]^2, w_C=|dC_C/dr|, and
lambda_C = integral r^3 w_C dr / integral r^2 w_C dr over the sampled R/5<r<=R domain,
with N=R/lambda_C. verify_cluster_structural_mode_n.py reproduces both X-COP and ACCEPT
values using second-order gradients and trapezoidal shell integration. It does not reuse the
galaxy 1-kpc/five-point estimator. Structural Mode N values are never averaged, pooled, or
replaced by a composite mode.

06_COMPACT_LMC_X3
LMC_X3_CONDITIONAL_MASS_SPIN_REFERENCE.csv records the central dynamical mass and low-spin
branch together with the published one-dimensional mass and spin sensitivity endpoints used
in the paper. The observational inputs are M_infinity = 6.98 +/- 0.56 Msun from Orosz et al.
(2014; DOI 10.1088/0004-637X/794/2/154) and a_infinity = 0.21 +0.18/-0.22 at 90% confidence
from Steiner et al. (2014; DOI 10.1088/2041-8205/793/2/L29). The later IXPE analysis
(Svoboda et al. 2024; DOI 10.3847/1538-4357/ad0842) independently supports the retained
low-spin interpretation but is not used to alter the central numerical input.

LMC_X3_ROTATING_STRUCTURAL_MODE_REFERENCE.csv records the spherical benchmark and the
absolute spin endpoints 0.01, 0.21, and 0.39 used by the scalar rotating Structural Mode
registry. verify_lmc_x3.py reconstructs the conditional compact cubic, physical/geometric
mass split, source spin, finite matching radius, retained Kerr outer-horizon coordinate,
source-only Kerr handoff, determinant-based rotating shell measure, and Structural Mode. It also verifies that the same compact equations
used for M33 X-7 are used unchanged for LMC X-3 and that the rotating mode decreases
monotonically with spin magnitude. REPRODUCTION_CHECK.txt is the fail-closed PASS record.

RECONSTRUCTION SCOPE
This archive reconstructs the solved numerical mathematics and the statistics quoted from
those solutions. It is intentionally not a general project archive, manuscript archive,
software release bundle, or record of exploratory calculations.

INTEGRITY
PACKAGE_QA.txt summarizes the retained reconstruction checks and content policy.
MANIFEST_SHA256.txt hashes every ordinary file in this tree except MANIFEST_SHA256.txt itself.
