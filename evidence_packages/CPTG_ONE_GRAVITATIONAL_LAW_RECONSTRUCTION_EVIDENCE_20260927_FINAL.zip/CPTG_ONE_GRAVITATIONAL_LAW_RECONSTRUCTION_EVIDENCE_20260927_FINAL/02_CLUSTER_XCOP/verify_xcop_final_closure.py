#!/usr/bin/env python3
from pathlib import Path
import numpy as np, pandas as pd
BASE=Path(__file__).resolve().parent
SRC=pd.read_csv(BASE/'XCOP_SEVEN_CLUSTER_SOURCE_SUPPORT_INPUT.csv')
PTS=pd.read_csv(BASE/'XCOP_SEVEN_CLUSTER_FINAL_SOLVED_POINTS.csv')
SUM=pd.read_csv(BASE/'XCOP_SEVEN_CLUSTER_REFERENCE_SUMMARY.csv')
G=6.67430e-11; MSUN=1.98847e30; KPC=3.085677581491367e19; INNER=123/50; OUTER=11/50
m=SRC.merge(PTS,on=['cluster','domain','radius_kpc'],suffixes=('_src','_sol'))
if len(m)!=len(PTS): raise SystemExit('FAIL: row mismatch')
checks={}
checks['max_rel_Mbaryon_sum']=float(np.max(np.abs((m.Mgas_Msun+m.Mstar_Msun)-m.Mbaryon_Msun)/np.maximum(np.abs(m.Mbaryon_Msun),1e-300)))
gb=G*(m.Mbaryon_Msun.to_numpy()*MSUN)/(m.radius_kpc.to_numpy()*KPC)**2
checks['max_rel_gb_from_mass']=float(np.max(np.abs(gb-m.g_baryon_m_s2_src.to_numpy())/np.maximum(np.abs(m.g_baryon_m_s2_src.to_numpy()),1e-300)))
checks['max_rel_gb_source_vs_solution']=float(np.max(np.abs(m.g_baryon_m_s2_src-m.g_baryon_m_s2_sol)/np.maximum(np.abs(m.g_baryon_m_s2_sol),1e-300)))
checks['max_rel_support_source_vs_solution']=float(np.max(np.abs(m.g_support_m_s2-m.g_FORW_m_s2)/np.maximum(np.abs(m.g_FORW_m_s2),1e-300)))
checks['max_rel_sigma_source_vs_solution']=float(np.max(np.abs(m.sigma_g_m_s2-m.sigma_g_m_s2_used)/np.maximum(np.abs(m.sigma_g_m_s2_used),1e-300)))
checks['max_rel_astar_identity']=float(np.max(np.abs(m.a_star_local_full-m.g_FORW_m_s2)/np.maximum(np.abs(m.g_FORW_m_s2),1e-300)))
def solve(r):
    g=max(float(r.g_C_closure_m_s2),1e-300)
    for _ in range(100):
        S=(1+(g/max(r.a_star_local_full,1e-300))**INNER)**(-OUTER)
        new=(r.g_baryon_m_s2_sol+r.A_C_closure*max(r.a_star_local_full,1e-300)**(2/3)*r.B_pol_full*S)/(1+r.c_C_closure*r.Sigma_C_squared_full)
        if abs(new-g)/max(abs(new),1e-300)<1e-14: g=new; break
        g=.6*new+.4*g
    return g
re=np.array([solve(r) for r in m.itertuples(index=False)])
checks['max_rel_recomputed_gC']=float(np.max(np.abs(re-m.g_C_closure_m_s2.to_numpy())/np.maximum(np.abs(m.g_C_closure_m_s2.to_numpy()),1e-300)))
# Registered support residual: (g_C - g_support) / sigma_g.
res_stored=m.support_residual_sigma.to_numpy(float)
res_from_stored_field=(m.g_C_closure_m_s2.to_numpy()-m.g_FORW_m_s2.to_numpy())/m.sigma_g_m_s2_used.to_numpy()
res_from_recomputed_field=(re-m.g_FORW_m_s2.to_numpy())/m.sigma_g_m_s2_used.to_numpy()
checks['max_abs_stored_residual_mismatch']=float(np.max(np.abs(res_stored-res_from_stored_field)))
checks['max_abs_recomputed_residual_mismatch']=float(np.max(np.abs(res_stored-res_from_recomputed_field)))
checks['aggregate_chi2']=float(res_from_recomputed_field@res_from_recomputed_field)
checks['aggregate_dof']=int(len(m)-3*m.cluster.nunique())
checks['aggregate_redchi2']=checks['aggregate_chi2']/checks['aggregate_dof']
# Independently rebuild each summary row from the solved point table.
summary_mismatch=0.0
for row in SUM.itertuples(index=False):
    q=m[(m.cluster==row.cluster)&(m.domain==row.domain)]
    rr=(q.g_C_closure_m_s2.to_numpy()-q.g_FORW_m_s2.to_numpy())/q.sigma_g_m_s2_used.to_numpy()
    vals=[
        abs(float(rr@rr)-row.chi2_support_closure),
        abs(float((rr@rr)/(len(q)-3))-row.reduced_chi2_support_closure),
        abs(float(np.median(np.abs(rr)))-row.median_abs_support_sigma),
        abs(float(np.max(np.abs(rr)))-row.max_abs_support_sigma),
    ]
    summary_mismatch=max(summary_mismatch,*vals)
    if row.dof != len(q)-3 or row.N != len(q): summary_mismatch=float('inf')
checks['max_abs_summary_mismatch']=float(summary_mismatch)
EXPECTED_CHI2=266.1135729876476
EXPECTED_DOF=273
status=(checks['max_rel_Mbaryon_sum']<1e-12 and checks['max_rel_gb_from_mass']<5e-7 and checks['max_rel_gb_source_vs_solution']<1e-12 and checks['max_rel_support_source_vs_solution']<1e-12 and checks['max_rel_sigma_source_vs_solution']<1e-12 and checks['max_rel_astar_identity']<1e-12 and checks['max_rel_recomputed_gC']<5e-10 and checks['max_abs_stored_residual_mismatch']<1e-12 and checks['max_abs_recomputed_residual_mismatch']<1e-10 and checks['max_abs_summary_mismatch']<1e-10 and abs(checks['aggregate_chi2']-EXPECTED_CHI2)<1e-9 and checks['aggregate_dof']==EXPECTED_DOF)
report=BASE/'REPRODUCTION_CHECK.txt'
with report.open('w') as f:
    f.write('CPTG X-COP SEVEN-CLUSTER FINAL CLOSURE REPRODUCTION\nstatus = '+('PASS' if status else 'FAIL')+f'\npoints = {len(m)}\nclusters = {m.cluster.nunique()}\n')
    f.write('support_residual_definition = (g_C - g_support) / sigma_g\n')
    for k,v in checks.items(): f.write(f'{k} = {v}\n')
print(report.read_text(),end='')
if not status: raise SystemExit(2)
