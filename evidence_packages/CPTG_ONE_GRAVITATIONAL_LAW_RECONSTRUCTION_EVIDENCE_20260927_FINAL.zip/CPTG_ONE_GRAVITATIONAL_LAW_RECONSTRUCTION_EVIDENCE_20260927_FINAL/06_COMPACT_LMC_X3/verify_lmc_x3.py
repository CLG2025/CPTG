#!/usr/bin/env python3
from pathlib import Path
import math
import numpy as np
import pandas as pd

G=6.67430e-11
C=299792458.0
MSUN=1.98847e30
BASE=Path(__file__).resolve().parent
REF_MASS=BASE/'LMC_X3_CONDITIONAL_MASS_SPIN_REFERENCE.csv'
REF_STRUCT=BASE/'LMC_X3_ROTATING_STRUCTURAL_MODE_REFERENCE.csv'
REPORT=BASE/'REPRODUCTION_CHECK.txt'


def solve_Apol(a):
    a=abs(float(a))
    lo,hi=1.0,2.0
    for _ in range(220):
        m=(lo+hi)/2
        if a*a*m**3+m-2>0:
            hi=m
        else:
            lo=m
    return (lo+hi)/2


def reconstruct_mass(M,a):
    A=solve_Apol(a)
    alpha=1/A
    fg=1-alpha
    Mc=M/A
    ac=A*A*a
    rm=G*(M*MSUN)/C**2/1000
    rplus=rm*(1+math.sqrt(max(0.0,1-float(a)*float(a))))
    return dict(M_infinity_Msun=M,a_infinity=a,A_pol=A,alpha_c=alpha,f_geom=fg,
                M_core_Msun=Mc,M_geom_equiv_Msun=M-Mc,a_c_source=ac,r_m_km=rm,
                r_plus_kerr_km=rplus)


def compact_structural_mode(a, r_g_km, n_quad=256):
    a=abs(float(a))
    cpoly=np.poly1d([
        1225/64,0,56175/64,0,-220590/64,0,308790/64,0,
        -188811/64,0,43659/64,0,0,0,0
    ])
    dcpoly=np.polyder(cpoly)
    roots=np.roots(dcpoly)
    split=sorted(r.real for r in roots if abs(r.imag)<1e-10 and 1e-12<r.real<1-1e-12)
    bounds=[0.0]+split+[1.0]
    nodes,weights=np.polynomial.legendre.leggauss(n_quad)
    iw=0.0; ixi=0.0
    for lo,hi in zip(bounds[:-1],bounds[1:]):
        x=0.5*(hi-lo)*nodes+0.5*(hi+lo)
        jac=0.5*(hi-lo)
        w=np.abs(np.polyval(dcpoly,x))
        xi=np.cbrt(x*(x*x+a*a)/(1+a*a))
        iw += jac*np.dot(weights,w)
        ixi += jac*np.dot(weights,xi*w)
    N=iw/ixi
    rho=r_g_km*(1+a*a)**(1/3)
    return dict(N_BH=N,rho_g_km=rho,lambda_N_km=rho/N,weighted_integral=ixi,weight_integral=iw)


refm=pd.read_csv(REF_MASS)
refs=pd.read_csv(REF_STRUCT)
checks={}
checks['mass_reference_rows']=len(refm)
checks['structural_reference_rows']=len(refs)

mass_rows=[]
for _,r in refm.iterrows():
    mass_rows.append({'role':r.role,**reconstruct_mass(float(r.M_infinity_Msun),float(r.a_infinity))})
genm=pd.DataFrame(mass_rows)
num=[c for c in refm.columns if c!='role']
checks['max_abs_mass_reference_mismatch']=float(np.max(np.abs(refm[num].to_numpy(float)-genm[num].to_numpy(float))))
checks['max_mass_split_residual_Msun']=float(np.max(np.abs(genm.M_core_Msun+genm.M_geom_equiv_Msun-genm.M_infinity_Msun)))
checks['max_cubic_residual']=float(np.max(np.abs(genm.a_infinity**2*genm.A_pol**3+genm.A_pol-2)))
checks['max_source_spin_bound_excess']=float(np.max(np.maximum(0.0,np.abs(genm.a_c_source)-1.0)))

central=genm.loc[genm.role=='central'].iloc[0]
struct_rows=[]
for _,r in refs.iterrows():
    q=compact_structural_mode(float(r.a_infinity),float(central.r_m_km))
    struct_rows.append({'role':r.role,'a_infinity':float(r.a_infinity),**q})
gens=pd.DataFrame(struct_rows)
cols=['a_infinity','N_BH','rho_g_km','lambda_N_km','weighted_integral']
checks['max_abs_structural_reference_mismatch']=float(np.max(np.abs(refs[cols].to_numpy(float)-gens[cols].to_numpy(float))))
checks['weight_integral_residual']=abs(float(gens.weight_integral.iloc[0])-22.3113987445115021565)
checks['central_mass_residual']=abs(float(central.M_infinity_Msun)-6.98)
checks['central_spin_residual']=abs(float(central.a_infinity)-0.21)
checks['central_Apol_residual']=abs(float(central.A_pol)-1.7596997170895596)
checks['central_Mcore_residual']=abs(float(central.M_core_Msun)-3.9665858511044783)
checks['central_Mgeom_residual']=abs(float(central.M_geom_equiv_Msun)-3.013414148895522)
checks['central_fgeom_residual']=abs(float(central.f_geom)-0.4317212247701321)
checks['central_ac_residual']=abs(float(central.a_c_source)-0.650274049808266)
checks['central_rm_residual_km']=abs(float(central.r_m_km)-10.307154443413406)
checks['central_kerr_outer_horizon_residual_km']=abs(float(central.r_plus_kerr_km)-20.384473627202035)

sc=gens.loc[gens.role=='central'].iloc[0]
slow=gens.loc[gens.role=='spin_low_abs'].iloc[0]
shigh=gens.loc[gens.role=='spin_high'].iloc[0]
s0=gens.loc[gens.role=='spherical_benchmark'].iloc[0]
checks['N0_residual']=abs(float(s0.N_BH)-1.912233171442049)
checks['N_low_residual']=abs(float(slow.N_BH)-1.9120062966442606)
checks['N_central_residual']=abs(float(sc.N_BH)-1.8319670296410255)
checks['N_high_residual']=abs(float(shigh.N_BH)-1.7121445499706334)
checks['rho_central_residual_km']=abs(float(sc.rho_g_km)-10.456495354776653)
checks['lambda_central_residual_km']=abs(float(sc.lambda_N_km)-5.707796693713209)
checks['monotonicity_margin']=min(float(s0.N_BH-slow.N_BH),float(slow.N_BH-sc.N_BH),float(sc.N_BH-shigh.N_BH))

# Source-only Kerr handoff radius for central branch.
rb=G*(float(central.M_core_Msun)*MSUN)/C**2*(1+math.sqrt(max(0.0,1-float(central.a_c_source)**2)))/1000
checks['central_boundary_radius_residual_km']=abs(rb-float(central.r_m_km))

status=(
    checks['mass_reference_rows']==5 and checks['structural_reference_rows']==4 and
    checks['max_abs_mass_reference_mismatch']<1e-12 and
    checks['max_mass_split_residual_Msun']<1e-12 and
    checks['max_cubic_residual']<1e-13 and
    checks['max_source_spin_bound_excess']==0.0 and
    checks['max_abs_structural_reference_mismatch']<1e-11 and
    checks['weight_integral_residual']<1e-11 and
    checks['central_mass_residual']<1e-14 and checks['central_spin_residual']<1e-14 and
    checks['central_Apol_residual']<1e-12 and checks['central_Mcore_residual']<1e-12 and
    checks['central_Mgeom_residual']<1e-12 and checks['central_fgeom_residual']<1e-12 and
    checks['central_ac_residual']<1e-12 and checks['central_rm_residual_km']<1e-11 and
    checks['central_kerr_outer_horizon_residual_km']<1e-9 and
    checks['N0_residual']<1e-12 and checks['N_low_residual']<1e-12 and
    checks['N_central_residual']<1e-12 and checks['N_high_residual']<1e-12 and
    checks['rho_central_residual_km']<1e-10 and checks['lambda_central_residual_km']<1e-10 and
    checks['monotonicity_margin']>0 and checks['central_boundary_radius_residual_km']<1e-10
)

with REPORT.open('w') as f:
    f.write('CPTG LMC X-3 CONDITIONAL COMPACT CLOSURE AND ROTATING STRUCTURAL MODE\n')
    f.write('status = '+('PASS' if status else 'FAIL')+'\n')
    f.write('observational_reference_mass = 6.98 +/- 0.56 Msun (Orosz et al. 2014; DOI 10.1088/0004-637X/794/2/154)\n')
    f.write('observational_reference_spin = 0.21 +0.18/-0.22, 90% confidence (Steiner et al. 2014; DOI 10.1088/2041-8205/793/2/L29)\n')
    for k,v in checks.items(): f.write(f'{k} = {v}\n')
    for k in ['M_infinity_Msun','a_infinity','A_pol','M_core_Msun','M_geom_equiv_Msun','f_geom','a_c_source','r_m_km','r_plus_kerr_km']:
        f.write(f'{k} = {central[k]:.16g}\n')
    f.write(f'N_BH_spin_low_abs_0p01 = {slow.N_BH:.16g}\n')
    f.write(f'N_BH_central_0p21 = {sc.N_BH:.16g}\n')
    f.write(f'N_BH_spin_high_0p39 = {shigh.N_BH:.16g}\n')
    f.write(f'rho_g_central_km = {sc.rho_g_km:.16g}\n')
    f.write(f'lambda_N_central_km = {sc.lambda_N_km:.16g}\n')

print(REPORT.read_text(),end='')
if not status: raise SystemExit(2)
