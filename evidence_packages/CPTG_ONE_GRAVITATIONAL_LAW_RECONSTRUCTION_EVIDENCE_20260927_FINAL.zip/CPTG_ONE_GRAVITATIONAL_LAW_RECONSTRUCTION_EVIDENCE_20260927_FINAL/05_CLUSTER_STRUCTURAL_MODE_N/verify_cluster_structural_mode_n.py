#!/usr/bin/env python3
"""Fail-closed replay of spherical cluster Structural Mode N.

This verifier uses the cluster-specific rederivation of the common post-solution
Structural Mode N = R/lambda. It does not reuse the galaxy 1-kpc sampled estimator.

For a solved spherical cluster field g(r):
  C_C(r) = 3 g(r)^2 + [r dg/dr]^2
  w_C(r) = |dC_C/dr|
  lambda_C = integral_(R/5)^R r^3 w_C dr / integral_(R/5)^R r^2 w_C dr
  N = R/lambda_C

The exact retained numerical realization uses second-order gradients on the full
nonuniform radial grid, sampled points satisfying r > R/5, and trapezoidal shell
integration. No five-point smoothing and no interpolation at R/5 are used.

X-COP is the primary cluster Structural Mode readout. ACCEPT is a separate
support-reconstruction sensitivity readout. Structural Mode values are never
averaged, pooled, or replaced by a composite mode.
"""
from pathlib import Path
import sys
import numpy as np
import pandas as pd

TOL_N = 5e-12
TOL_KPC = 5e-10
HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
REF = HERE / "CLUSTER_STRUCTURAL_MODE_N_REFERENCE.csv"
XCOP = ROOT / "02_CLUSTER_XCOP" / "XCOP_SEVEN_CLUSTER_FINAL_SOLVED_POINTS.csv"
ACCEPT = ROOT / "03_CLUSTER_ACCEPT" / "03_REFERENCE_FINAL" / "CPTG_ACCEPT_PRECISION_FINAL_POINTS.csv"
ORDER = ["A2029", "A1795", "A2142", "A2319", "A644", "A85", "ZW1215"]


def spherical_structural_mode(df, g_col):
    result = {}
    for cluster, group in df.groupby("cluster", sort=True):
        group = group.sort_values("radius_kpc")
        r = group["radius_kpc"].to_numpy(float)
        g = group[g_col].to_numpy(float)

        if len(r) < 3 or not np.all(np.isfinite(r)) or not np.all(np.isfinite(g)):
            raise RuntimeError(f"invalid solved field for {cluster}")
        if np.any(r <= 0.0) or np.any(np.diff(r) <= 0.0):
            raise RuntimeError(f"invalid radial grid for {cluster}")

        dg = np.gradient(g, r, edge_order=2)
        C = 3.0 * g**2 + (r * dg)**2
        dC = np.gradient(C, r, edge_order=2)
        w = np.abs(dC)

        R = float(r[-1])
        mask = np.isfinite(w) & (r > R / 5.0)
        r_outer = r[mask]
        w_outer = w[mask]
        if len(r_outer) < 2:
            raise RuntimeError(f"insufficient outer points for {cluster}")

        numerator = float(np.trapezoid(r_outer**3 * w_outer, r_outer))
        denominator = float(np.trapezoid(r_outer**2 * w_outer, r_outer))
        if not np.isfinite(numerator) or not np.isfinite(denominator) or denominator <= 0.0:
            raise RuntimeError(f"invalid spherical organization integral for {cluster}")

        lam = numerator / denominator
        N = R / lam
        if not np.isfinite(N) or not (1.0 <= N <= 5.0):
            raise RuntimeError(f"invalid Structural Mode N for {cluster}: {N}")

        result[cluster] = {
            "N": float(N),
            "R_kpc": R,
            "lambda_kpc": float(lam),
            "n_points": int(len(group)),
            "n_outer_points": int(np.count_nonzero(mask)),
        }
    return result


def close(a, b, tol):
    return np.isfinite(a) and np.isfinite(b) and abs(a - b) <= tol


def main():
    for p in (REF, XCOP, ACCEPT):
        if not p.exists():
            raise SystemExit(f"FAIL: missing required file: {p}")

    ref = pd.read_csv(REF).set_index("cluster")
    x = spherical_structural_mode(pd.read_csv(XCOP), "g_C_closure_m_s2")
    a = spherical_structural_mode(pd.read_csv(ACCEPT), "g_CPTG_m_s2")

    if list(ref.index) != ORDER:
        raise SystemExit("FAIL: reference cluster order/content changed")

    failures = []
    for cl in ORDER:
        rr = ref.loc[cl]
        checks = [
            ("N_XCOP_primary", x[cl]["N"], rr["N_XCOP_primary"], TOL_N),
            ("R_XCOP_kpc", x[cl]["R_kpc"], rr["R_XCOP_kpc"], TOL_KPC),
            ("lambda_XCOP_kpc", x[cl]["lambda_kpc"], rr["lambda_XCOP_kpc"], TOL_KPC),
            ("N_ACCEPT_sensitivity", a[cl]["N"], rr["N_ACCEPT_sensitivity"], TOL_N),
            ("R_ACCEPT_kpc", a[cl]["R_kpc"], rr["R_ACCEPT_kpc"], TOL_KPC),
            ("lambda_ACCEPT_kpc", a[cl]["lambda_kpc"], rr["lambda_ACCEPT_kpc"], TOL_KPC),
        ]
        for name, got, expected, tol in checks:
            if not close(float(got), float(expected), tol):
                failures.append(f"{cl} {name}: got={got:.17g} expected={expected:.17g}")

        for name, got, expected in [
            ("n_XCOP_points", x[cl]["n_points"], int(rr["n_XCOP_points"])),
            ("n_XCOP_outer_points", x[cl]["n_outer_points"], int(rr["n_XCOP_outer_points"])),
            ("n_ACCEPT_points", a[cl]["n_points"], int(rr["n_ACCEPT_points"])),
            ("n_ACCEPT_outer_points", a[cl]["n_outer_points"], int(rr["n_ACCEPT_outer_points"])),
        ]:
            if int(got) != int(expected):
                failures.append(f"{cl} {name}: got={got} expected={expected}")

    if failures:
        print("STATUS = FAIL")
        for f in failures:
            print(f)
        return 1

    print("CPTG SPHERICAL CLUSTER STRUCTURAL MODE N REPLAY")
    print("definition = cluster-specific shell-weighted solved-field organization scale")
    print("X-COP = primary cluster Structural Mode readout")
    print("ACCEPT = independent support-reconstruction sensitivity readout")
    print("Structural Mode N values are never averaged or pooled.")
    for cl in ORDER:
        print(
            f"{cl}: N_XCOP={x[cl]['N']:.9f}  lambda_XCOP={x[cl]['lambda_kpc']:.9f} kpc  "
            f"N_ACCEPT={a[cl]['N']:.9f}  lambda_ACCEPT={a[cl]['lambda_kpc']:.9f} kpc"
        )
    print("STATUS = PASS")
    return 0


if __name__ == "__main__":
    sys.exit(main())
