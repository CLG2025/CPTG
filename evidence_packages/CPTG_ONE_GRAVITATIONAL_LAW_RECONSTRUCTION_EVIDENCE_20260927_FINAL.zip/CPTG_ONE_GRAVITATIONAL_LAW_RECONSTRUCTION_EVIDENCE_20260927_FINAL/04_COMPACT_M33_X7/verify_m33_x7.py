#!/usr/bin/env python3
from pathlib import Path
import math, tempfile
import numpy as np, pandas as pd

G=6.67430e-11
C=299792458.0
MSUN=1.98847e30
BASE=Path(__file__).resolve().parent
REF_CLOSURE=BASE/'M33_X7_CONDITIONAL_MASS_SPIN_CLOSURE.csv'
REF_PROFILE=BASE/'M33_X7_FINITE_INTERIOR_PROFILE.csv'
REF_STRUCT=BASE/'M33_X7_ROTATING_STRUCTURAL_MODE_REFERENCE.csv'
REPORT=BASE/'REPRODUCTION_CHECK.txt'


def solve_Apol(a):
    lo,hi=1.0,2.0
    for _ in range(200):
        m=(lo+hi)/2
        if a*a*m**3+m-2>0:
            hi=m
        else:
            lo=m
    return (lo+hi)/2


def reconstruct(M,a):
    A=solve_Apol(a)
    alpha=1/A
    fg=1-alpha
    Mc=M/A
    ac=A*A*a
    rm=G*(M*MSUN)/C**2/1000
    rb=G*(Mc*MSUN)/C**2*(1+math.sqrt(max(0.0,1-ac*ac)))/1000
    rplus=rm*(1+math.sqrt(max(0.0,1-a*a)))
    row=dict(branch='central',M_infinity_Msun=M,a_infinity=a,A_pol=A,alpha_c=alpha,f_geom=fg,
             M_core_Msun=Mc,M_geom_equiv_Msun=M-Mc,a_c_source=ac,r_m_km=rm,
             r_boundary_from_source_km=rb,boundary_residual_km=rb-rm,
             geom_share_exterior=(M-Mc)/M,exterior_enhancement_vs_source=M/Mc-1.0,
             r_plus_kerr_km=rplus)
    x=np.linspace(0,1,1001)
    F=(63*x**5-90*x**7+35*x**9)/8
    Hc=alpha*F
    Ht=fg*F*(1-F)
    Hp=fg*F**2
    profile=pd.DataFrame({'x_r_over_rm':x,'F':F,'H_core':Hc,'H_transport':Ht,
                          'H_polarization':Hp,'H_sum':Hc+Ht+Hp,'identity_residual':Hc+Ht+Hp-F})
    return pd.DataFrame([row]),profile


def compact_structural_mode(a, r_g_km, n_quad=256):
    # Exact polynomial for C(x)=U^2+U'^2+2(U/x)^2 from the retained finite profile.
    cpoly=np.poly1d([
        1225/64,0,56175/64,0,-220590/64,0,308790/64,0,
        -188811/64,0,43659/64,0,0,0,0
    ])
    dcpoly=np.polyder(cpoly)
    roots=np.roots(dcpoly)
    split=sorted(r.real for r in roots if abs(r.imag)<1e-10 and 1e-12<r.real<1-1e-12)
    bounds=[0.0]+split+[1.0]
    nodes,weights=np.polynomial.legendre.leggauss(n_quad)
    iw=0.0
    ixi=0.0
    for lo,hi in zip(bounds[:-1],bounds[1:]):
        x=0.5*(hi-lo)*nodes+0.5*(hi+lo)
        jac=0.5*(hi-lo)
        w=np.abs(np.polyval(dcpoly,x))
        xi=np.cbrt(x*(x*x+a*a)/(1+a*a))
        iw += jac*np.dot(weights,w)
        ixi += jac*np.dot(weights,xi*w)
    N=iw/ixi
    rho=r_g_km*(1+a*a)**(1/3)
    lam=rho/N
    return dict(N_BH=N,rho_g_km=rho,lambda_N_km=lam,weighted_integral=ixi,weight_integral=iw)


refc=pd.read_csv(REF_CLOSURE)
refp=pd.read_csv(REF_PROFILE)
refs=pd.read_csv(REF_STRUCT)
checks={}
checks['reference_closure_rows']=int(len(refc))
checks['reference_profile_rows']=int(len(refp))
checks['reference_structural_rows']=int(len(refs))
valid_shape=(len(refc)==1 and len(refp)==1001 and list(refc['branch'])==['central'] and len(refs)==4)
M=float(refc.M_infinity_Msun.iloc[0]) if len(refc) else float('nan')
a=float(refc.a_infinity.iloc[0]) if len(refc) else float('nan')
checks['input_mass_residual']=abs(M-15.65)
checks['input_spin_residual']=abs(a-0.84)
genc,genp=reconstruct(M,a)

# Reconstructed outputs are written only to a temporary directory; references are never overwritten.
with tempfile.TemporaryDirectory(prefix='m33_x7_reconstruction_') as td:
    genc.to_csv(Path(td)/'M33_X7_CONDITIONAL_MASS_SPIN_CLOSURE.csv',index=False)
    genp.to_csv(Path(td)/'M33_X7_FINITE_INTERIOR_PROFILE.csv',index=False)

numcols=[c for c in refc.columns if c!='branch']
checks['max_abs_closure_reference_mismatch']=float(np.max(np.abs(refc[numcols].to_numpy(float)-genc[numcols].to_numpy(float)))) if valid_shape else float('inf')
checks['max_abs_profile_reference_mismatch']=float(np.max(np.abs(refp.to_numpy(float)-genp.to_numpy(float)))) if valid_shape else float('inf')
q=genc.iloc[0]
checks['mass_split_residual_Msun']=abs((q.M_core_Msun+q.M_geom_equiv_Msun)-q.M_infinity_Msun)
checks['compact_cubic_residual']=abs(q.a_infinity**2*q.A_pol**3+q.A_pol-2)
checks['source_spin_bound_excess']=max(0.0,q.a_c_source-1.0)
checks['boundary_radius_residual_km']=abs(q.r_boundary_from_source_km-q.r_m_km)
checks['geom_share_residual']=abs(q.geom_share_exterior-0.08166394061969029)
checks['exterior_enhancement_residual']=abs(q.exterior_enhancement_vs_source-0.088925987154198)
checks['kerr_outer_horizon_residual_km']=abs(q.r_plus_kerr_km-35.64898758717672)
checks['max_mass_decomposition_residual']=float(np.max(np.abs(genp.H_sum-genp.F)))
checks['F_at_0_residual']=abs(float(genp.F.iloc[0]))
checks['F_at_1_residual']=abs(float(genp.F.iloc[-1])-1.0)
checks['Fprime_at_1_residual']=abs((315-630+315)/8)
checks['Fsecond_at_1_residual']=abs((1260-3780+2520)/8)

# Rotating post-solution Structural Mode reconstruction.
struct_rows=[]
for _,r in refs.iterrows():
    s=compact_structural_mode(float(r.a_infinity), float(q.r_m_km))
    struct_rows.append({
        'role':r.role,
        'a_infinity':float(r.a_infinity),
        **s,
    })
gens=pd.DataFrame(struct_rows)
refnum=['a_infinity','N_BH','rho_g_km','lambda_N_km','weighted_integral']
gennum=['a_infinity','N_BH','rho_g_km','lambda_N_km','weighted_integral']
checks['max_abs_structural_reference_mismatch']=float(np.max(np.abs(refs[refnum].to_numpy(float)-gens[gennum].to_numpy(float)))) if valid_shape else float('inf')
checks['structural_weight_integral_residual']=abs(float(gens.weight_integral.iloc[0])-22.3113987445115021565)
central=gens.loc[gens.role=='central'].iloc[0]
low=gens.loc[gens.role=='spin_low'].iloc[0]
high=gens.loc[gens.role=='spin_high'].iloc[0]
spherical=gens.loc[gens.role=='spherical_benchmark'].iloc[0]
checks['N_spherical_residual']=abs(float(spherical.N_BH)-1.9122331714420491305)
checks['N_central_residual']=abs(float(central.N_BH)-1.4938716334439189411)
checks['N_spin_low_residual']=abs(float(low.N_BH)-1.5108865707484272226)
checks['N_spin_high_residual']=abs(float(high.N_BH)-1.4783171255220149504)
checks['rho_g_central_residual_km']=abs(float(central.rho_g_km)-27.6115062456773924)
checks['lambda_N_central_residual_km']=abs(float(central.lambda_N_km)-18.4831853202960956)
checks['rotating_monotonicity_margin']=min(float(spherical.N_BH-low.N_BH),float(low.N_BH-central.N_BH),float(central.N_BH-high.N_BH))

status=(
    valid_shape and
    checks['input_mass_residual']<1e-14 and
    checks['input_spin_residual']<1e-14 and
    checks['max_abs_closure_reference_mismatch']<1e-12 and
    checks['max_abs_profile_reference_mismatch']<1e-12 and
    checks['mass_split_residual_Msun']<1e-12 and
    checks['compact_cubic_residual']<1e-13 and
    checks['source_spin_bound_excess']==0.0 and
    checks['boundary_radius_residual_km']<1e-10 and
    checks['geom_share_residual']<1e-12 and
    checks['exterior_enhancement_residual']<1e-12 and
    checks['kerr_outer_horizon_residual_km']<1e-9 and
    checks['max_mass_decomposition_residual']<5e-15 and
    checks['F_at_0_residual']<1e-15 and
    checks['F_at_1_residual']<1e-15 and
    checks['Fprime_at_1_residual']<1e-15 and
    checks['Fsecond_at_1_residual']<1e-15 and
    checks['max_abs_structural_reference_mismatch']<1e-11 and
    checks['structural_weight_integral_residual']<1e-11 and
    checks['N_spherical_residual']<1e-12 and
    checks['N_central_residual']<1e-12 and
    checks['N_spin_low_residual']<1e-12 and
    checks['N_spin_high_residual']<1e-12 and
    checks['rho_g_central_residual_km']<1e-10 and
    checks['lambda_N_central_residual_km']<1e-10 and
    checks['rotating_monotonicity_margin']>0.0
)

with REPORT.open('w') as f:
    f.write('CPTG M33 X-7 CONDITIONAL COMPACT CLOSURE AND ROTATING STRUCTURAL MODE\n')
    f.write('status = '+('PASS' if status else 'FAIL')+'\n')
    f.write('reference_branch = central\n')
    for k,v in checks.items():
        f.write(f'{k} = {v}\n')
    for k in ['M_infinity_Msun','a_infinity','A_pol','M_core_Msun','M_geom_equiv_Msun','f_geom','a_c_source','r_m_km','geom_share_exterior','exterior_enhancement_vs_source','r_plus_kerr_km']:
        f.write(f'{k} = {q[k]:.16g}\n')
    f.write(f'N_BH_spherical = {spherical.N_BH:.16g}\n')
    f.write(f'N_BH_spin_low_0p79 = {low.N_BH:.16g}\n')
    f.write(f'N_BH_central_0p84 = {central.N_BH:.16g}\n')
    f.write(f'N_BH_spin_high_0p89 = {high.N_BH:.16g}\n')
    f.write(f'rho_g_central_km = {central.rho_g_km:.16g}\n')
    f.write(f'lambda_N_central_km = {central.lambda_N_km:.16g}\n')

print(REPORT.read_text(),end='')
if not status:
    raise SystemExit(2)
