# Audited evidence chain

## Embedded input audits

```json
{
  "v10_669": {
    "path": "D:\\Downloads\\CPTG_DPGammaHe3_C7cqCompleteFreshTwoCodeClosureEvidenceReportAndAIHandoff_v10_670_r01\\INPUTS\\CPTG_v10_669_outputs_r01.zip",
    "exists": true,
    "size_bytes": 10088,
    "sha256": "85f225080cbe6293229708f399c9d7e675e403634cbd2ffe812754e124d0a093",
    "zip_crc_pass": true,
    "zip_bad_member": null,
    "zip_member_count": 12,
    "members": [
      "OUTPUTS/c7cp_alterbbn_diagnostic_noncanonical_rows.csv",
      "OUTPUTS/c7cp_decision.json",
      "OUTPUTS/c7cp_evidence_chain_index.csv",
      "OUTPUTS/c7cp_fresh_two_code_closure_table.csv",
      "OUTPUTS/C7CP_FRESH_TWO_CODE_LOCKED_GATE_CLOSURE_RECONCILIATION.md",
      "OUTPUTS/c7cp_input_zip_audit.json",
      "OUTPUTS/c7cp_output_sha256_ledger.csv",
      "OUTPUTS/c7cp_progress_accounting.json",
      "OUTPUTS/c7cp_v10_660_decision_extract.json",
      "OUTPUTS/c7cp_v10_668_canonical_alterbbn_row.json",
      "OUTPUTS/c7cp_v10_668_decision_extract.json",
      "OUTPUTS/c7cp_v10_668_diagnostic_noncanonical_rows.json"
    ]
  },
  "v10_660": {
    "path": "D:\\Downloads\\CPTG_DPGammaHe3_C7cqCompleteFreshTwoCodeClosureEvidenceReportAndAIHandoff_v10_670_r01\\INPUTS\\CPTG_v10_660_outputs_r01.zip",
    "exists": true,
    "size_bytes": 15520,
    "sha256": "3cd335c2b941226565a60720fa620e4a4dee9f39454587ebd668c14750b32170",
    "zip_crc_pass": true,
    "zip_bad_member": null,
    "zip_member_count": 14,
    "members": [
      "OUTPUTS/c7cg_authorized_pi_gate_application_table.csv",
      "OUTPUTS/c7cg_decision.json",
      "OUTPUTS/C7CG_DECISION.md",
      "OUTPUTS/c7cg_embedded_input_audit.json",
      "OUTPUTS/c7cg_evidence_chain_index.csv",
      "OUTPUTS/c7cg_literal_pdf_authority_ledger.csv",
      "OUTPUTS/c7cg_literal_pdf_authority_ledger.json",
      "OUTPUTS/c7cg_output_sha256_ledger.csv",
      "OUTPUTS/c7cg_progress_accounting.json",
      "OUTPUTS/c7cg_start_environment.json",
      "OUTPUTS/PRIOR_V10_658_EXTRACTS/OUTPUTS__c7ce_decision.json",
      "OUTPUTS/PRIOR_V10_658_EXTRACTS/OUTPUTS__C7CE_DECISION.md",
      "OUTPUTS/PRIOR_V10_658_EXTRACTS/OUTPUTS__c7ce_mass7_diagnostic_reapplied_table.csv",
      "OUTPUTS/PRIOR_V10_658_EXTRACTS/OUTPUTS__c7ce_progress_accounting.json"
    ]
  },
  "v10_668": {
    "path": "D:\\Downloads\\CPTG_DPGammaHe3_C7cqCompleteFreshTwoCodeClosureEvidenceReportAndAIHandoff_v10_670_r01\\INPUTS\\CPTG_v10_668_outputs_r01.zip",
    "exists": true,
    "size_bytes": 9254,
    "sha256": "c2497dd09a2d7a1ec731be1681f304af2ec4720a1153b91e71e74c57aea10bce",
    "zip_crc_pass": true,
    "zip_bad_member": null,
    "zip_member_count": 10,
    "members": [
      "OUTPUTS/c7co_alter_eta_source_inspection.json",
      "OUTPUTS/c7co_build_records.json",
      "OUTPUTS/c7co_decision.json",
      "OUTPUTS/c7co_default_root_snapshot.json",
      "OUTPUTS/C7CO_FRESH_ALTERBBN_CORRECT_ETA_ARGUMENT_AND_PHYSICAL_ETA_REPLAY.md",
      "OUTPUTS/c7co_output_sha256_ledger.csv",
      "OUTPUTS/c7co_parsed_comparisons.json",
      "OUTPUTS/c7co_replay_records.json",
      "OUTPUTS/c7co_tool_resolution.json",
      "OUTPUTS/c7co_v10_667_verification.json"
    ]
  }
}
```

## Embedded non-ZIP authority/input file audits

```json
{
  "public_status_v10_641": {
    "path": "D:\\Downloads\\CPTG_DPGammaHe3_C7cqCompleteFreshTwoCodeClosureEvidenceReportAndAIHandoff_v10_670_r01\\INPUTS\\Pasted_public_status_v10_641_C7BP.txt",
    "exists": true,
    "size_bytes": 10231,
    "sha256": "47a1d0870278efdbb548b9efa0da43c29a660d4a89f9c68054bff118f5c7f7fc"
  },
  "lithium_pdf": {
    "path": "D:\\Downloads\\CPTG_DPGammaHe3_C7cqCompleteFreshTwoCodeClosureEvidenceReportAndAIHandoff_v10_670_r01\\AUTHORITY\\CPTG_Cosmological_Lithium_Problem.pdf",
    "exists": true,
    "size_bytes": 273005,
    "sha256": "d1781a2ad9c4112e2f2272b6efc8d77282be51c49c92ea9bedc77bfc0d252430"
  },
  "pi_branch_pdf": {
    "path": "D:\\Downloads\\CPTG_DPGammaHe3_C7cqCompleteFreshTwoCodeClosureEvidenceReportAndAIHandoff_v10_670_r01\\AUTHORITY\\CPTG_Geometric_Pi_Branch_Comparison_Coordinates.pdf",
    "exists": true,
    "size_bytes": 488514,
    "sha256": "809a9a848ced3fd275bbb891f6b1bbd738c43d745ac2f700b794b4e652520458"
  },
  "unified_framework_pdf": {
    "path": "D:\\Downloads\\CPTG_DPGammaHe3_C7cqCompleteFreshTwoCodeClosureEvidenceReportAndAIHandoff_v10_670_r01\\AUTHORITY\\CPTG_Unified_Geometric_Framework_Cosmic_Structure_Expansion.pdf",
    "exists": true,
    "size_bytes": 490050,
    "sha256": "832c64c0f85a681411691dceacdfddb6ea7ea03ee363c5afb73218e43d86ff3c"
  }
}
```

## v10.669 decision

```json
{
  "state": "C7CP_FRESH_PRYMORDIAL_AND_ALTERBBN_LOCKED_GATE_TWO_CODE_CLOSURE_RECONCILED",
  "package_version": "v10_669_r01",
  "started_at": "2026-07-06T02:31:58-04:00",
  "ended_at": "2026-07-06T02:31:58-04:00",
  "runtime_design": "embedded input ZIP verification only; no D:\\Downloads scan, no archive crawl, no compiler invocation, no network",
  "input_sha256": {
    "v10_660": "3cd335c2b941226565a60720fa620e4a4dee9f39454587ebd668c14750b32170",
    "v10_668": "c2497dd09a2d7a1ec731be1681f304af2ec4720a1153b91e71e74c57aea10bce"
  },
  "v10_660_state": "C7CG_LITERAL_PDF_AUTHORITY_AUTHORIZES_LOCKED_MASS7_GATE_FASTPATH_PASS",
  "v10_668_state": "C7CO_FRESH_ALTERBBN_CORRECT_PHYSICAL_ETA_REPLAY_LOCKED_GATE_PASS",
  "canonical_alterbbn_row": "correct_physical_eta_cptg_bbn_failsafe1",
  "canonical_alterbbn_eta_argument": "5.9980718347440000E-10",
  "canonical_alterbbn_background_admitted_DH_YP": true,
  "canonical_alterbbn_locked_gate_pass": true,
  "canonical_alterbbn_raw_Li7_H": 5.291e-10,
  "canonical_alterbbn_gated_Li7_H": 1.6841776077984365e-10,
  "canonical_alterbbn_gated_Li7_pull_sigma": 0.9367104311937463,
  "fresh_prymordial_locked_gate_pass": true,
  "fresh_prymordial_gated_Li7_pull_sigma": 0.9059237908124455,
  "claim_boundary": "This reconciles fresh PRyMordial and fresh local AlterBBN locked A=7 gate evidence. It does not overwrite v10.641/C7BP as the retained integrated PRIMAT-compatible current-chain frontier."
}
```

## v10.668 canonical AlterBBN row

```json
{
  "source_label": "correct_physical_eta_cptg_bbn_failsafe1",
  "command_semantics": {
    "argv1": "eta_BBN = eta10_BBN*1e-10",
    "eta10_BBN": "5.998071834744",
    "eta": "5.9980718347440000E-10",
    "argv2": "failsafe=1"
  },
  "raw_abundances": {
    "Yp": 0.2471,
    "D_H": 2.5e-05,
    "He3_H": 1.041e-05,
    "Li7_H": 5.291e-10,
    "Li6_H": 1.1e-14,
    "Be7_H": 4.998e-10
  },
  "rows": [
    {
      "observable": "D/H",
      "value": 2.5e-05,
      "observed": 2.508e-05,
      "sigma": 2.9e-07,
      "pull_sigma": -0.27586206896551463,
      "result": "PASS"
    },
    {
      "observable": "Yp",
      "value": 0.2471,
      "observed": 0.245,
      "sigma": 0.003,
      "pull_sigma": 0.699999999999997,
      "result": "PASS"
    },
    {
      "observable": "He3/H",
      "value": 1.041e-05,
      "upper": 1.1e-05,
      "result": "PASS"
    },
    {
      "observable": "Li7/H raw AlterBBN report",
      "value": 5.291e-10,
      "observed": 1.45e-10,
      "sigma": 2.5e-11,
      "pull_sigma": 15.363999999999997,
      "result": "FAIL"
    },
    {
      "observable": "Li7/H after authorized locked 1/pi gate",
      "value": 1.6841776077984365e-10,
      "observed": 1.45e-10,
      "sigma": 2.5e-11,
      "pull_sigma": 0.9367104311937463,
      "coefficient": 0.3183098861837907,
      "tau": 1.1447298858494002,
      "result": "PASS"
    }
  ],
  "background_admitted_DH_YP": true,
  "locked_gate_pass": true,
  "locked_gate": {
    "authorized_tau": "ln(pi)",
    "authorized_survival_factor": 0.3183098861837907,
    "raw_key_used": "Li7_H",
    "raw_value": 5.291e-10,
    "gated_value": 1.6841776077984365e-10
  }
}
```

## v10.660 decision extract

```json
{
  "state": "C7CG_LITERAL_PDF_AUTHORITY_AUTHORIZES_LOCKED_MASS7_GATE_FASTPATH_PASS",
  "claim_boundary": "Fast-path package. It does not scan D:\\Downloads, does not perform coefficient fitting, and does not use numerical near-matches. It applies only the uploaded lithium PDF literal authority: tau7,trans=ln(pi), survival factor=1/pi on mass-seven.",
  "runtime_design": "O(embedded inputs only); expected seconds, not minutes",
  "prior_v10_658_state": "C7CE_NATIVE_MASS7_NEAR_CANDIDATES_FOUND_NOT_AUTHORIZED",
  "prior_v10_658_authorized_closure_candidate_count": 0,
  "literal_authority_found": true,
  "authorized_formula": "Y7,CPTG = Y7,raw/pi; tau7,trans = ln(pi)",
  "selected_row_label": "transport_sqrtGT_large_PRIMAT",
  "selected_Li7_over_H_before_gate": 5.266820229187348e-10,
  "authorized_gate_coefficient": 0.3183098861837907,
  "selected_Li7_over_H_after_gate": 1.6764809477031113e-10,
  "observed_Li7_over_H": 1.45e-10,
  "observed_sigma": 2.5e-11,
  "Li7_pull_sigma_after_authorized_gate": 0.9059237908124455,
  "Li7_abs_pull_lt_2sigma": true,
  "gate_closure": "PASS",
  "authority_files": [
    "AUTHORITY/CPTG_Cosmological_Lithium_Problem.pdf",
    "AUTHORITY/CPTG_Geometric_Pi_Branch_Comparison_Coordinates.pdf",
    "AUTHORITY/CPTG_Unified_Geometric_Framework_Cosmic_Structure_Expansion.pdf"
  ],
  "embedded_inputs": [
    {
      "relative_path": "AUTHORITY/CPTG_Cosmological_Lithium_Problem.pdf",
      "size_bytes": 273005,
      "sha256": "d1781a2ad9c4112e2f2272b6efc8d77282be51c49c92ea9bedc77bfc0d252430",
      "exists_now": true,
      "actual_sha256": "d1781a2ad9c4112e2f2272b6efc8d77282be51c49c92ea9bedc77bfc0d252430",
      "sha256_match": true
    },
    {
      "relative_path": "AUTHORITY/CPTG_Geometric_Pi_Branch_Comparison_Coordinates.pdf",
      "size_bytes": 488514,
      "sha256": "809a9a848ced3fd275bbb891f6b1bbd738c43d745ac2f700b794b4e652520458",
      "exists_now": true,
      "actual_sha256": "809a9a848ced3fd275bbb891f6b1bbd738c43d745ac2f700b794b4e652520458",
      "sha256_match": true
    },
    {
      "relative_path": "AUTHORITY/CPTG_Unified_Geometric_Framework_Cosmic_Structure_Expansion.pdf",
      "size_bytes": 490050,
      "sha256": "832c64c0f85a681411691dceacdfddb6ea7ea03ee363c5afb73218e43d86ff3c",
      "exists_now": true,
      "actual_sha256": "832c64c0f85a681411691dceacdfddb6ea7ea03ee363c5afb73218e43d86ff3c",
      "sha256_match": true
    },
    {
      "relative_path": "INPUT/CPTG_v10_658_outputs_r01.zip",
      "size_bytes": 22006,
      "sha256": "eb04092b854e970ea373b5dd4d09c578658b3b87fd361efeadc55da483f8d68c",
      "exists_now": true,
      "actual_sha256": "eb04092b854e970ea373b5dd4d09c578658b3b87fd361efeadc55da483f8d68c",
      "sha256_match": true,
      "zip_crc_pass": true,
      "zip_member_count": 20,
      "zip_bad_member": null
    }
  ]
}
```
