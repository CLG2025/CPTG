# Updated public status block

The retained integrated current-chain frontier remains `v10.641 / C7BP`. The fresh two-code locked A=7 gate lane is now reconciled through `v10.669 / C7CP` and packaged for handoff as `v10.670 / C7CQ`.

Current package frontier for handoff/reporting: `v10.670 / C7CQ`.

Current fresh two-code gate closure:
- PRyMordial: pass after PDF-authorized locked `1/pi` gate; Li7 pull after gate = `0.9059237908124455` sigma.
- AlterBBN: pass after correct physical-eta `alter_eta.x` replay; canonical row = `correct_physical_eta_cptg_bbn_failsafe1`; Li7 pull after gate = `1.6841776077984365e-10` as abundance, `0.9367104311937463` sigma.

Non-regression note: `v10.659` was aborted/superseded and must not be rerun. `v10.662` was superseded by the exact default-root AlterBBN path check.
