# CPTG D(p,gamma)He3 / BBN Locked A=7 Gate: Complete Fresh Two-Code Closure Evidence Report and AI Handoff

Package: `v10_670_r01`
Decision: `C7CQ_COMPLETE_FRESH_TWO_CODE_CLOSURE_EVIDENCE_REPORT_AND_HANDOFF_READY`

## Executive state

The fresh two-code locked A=7 gate lane is closed.

- Fresh PRyMordial/PDF-authorized lane: **PASS**, retained from v10.660 / C7CG.
- Fresh local AlterBBN lane: **PASS**, retained from v10.668 / C7CO using `alter_eta.x 5.9980718347440000E-10 1`.
- Fresh two-code reconciliation: **PASS**, verified from v10.669 / C7CP.
- Retained integrated current-chain frontier: **v10.641 / C7BP**, retained and not overwritten.
- This package, v10.670 / C7CQ, is a **report, evidence-chain, non-regression, and AI handoff package**.

## Verified input

v10.669 upload SHA-256:

```text
85f225080cbe6293229708f399c9d7e675e403634cbd2ffe812754e124d0a093
```

v10.669 decision:

```text
C7CP_FRESH_PRYMORDIAL_AND_ALTERBBN_LOCKED_GATE_TWO_CODE_CLOSURE_RECONCILED
```

ZIP CRC: `PASS`.
Members: `12`.

## Canonical two-code closure table

```csv
code_or_lane,source_version,row_label,eta10_BBN,D_H,D_H_pull_sigma,Yp,Yp_pull_sigma,He3_H,raw_Li7_H_or_mass7,authorized_survival_factor,gated_Li7_H,gated_Li7_pull_sigma,background_admitted_DH_YP,locked_gate_pass,status,eta_argument
PRyMordial fresh replay / PDF-authorized fastpath,v10.660 / C7CG,transport_sqrtGT_large_PRIMAT,5.998071834744,25.074383114428e-6 from retained PRyMordial canonical CSV row,-0.019 retained from v10.656/v10.660 chain,0.245694338195 retained from v10.656/v10.660 chain,+0.231 retained from v10.656/v10.660 chain,1.0489348718552855e-05 retained from v10.656/v10.660 chain,5.266820229187348e-10,0.3183098861837907,1.6764809477031113e-10,0.9059237908124455,True,True,PASS,
AlterBBN fresh local replay / alter_eta precise,v10.668 / C7CO,correct_physical_eta_cptg_bbn_failsafe1,5.998071834744,2.5e-05,-0.27586206896551463,0.2471,0.699999999999997,1.041e-05,5.291e-10,0.3183098861837907,1.6841776077984365e-10,0.9367104311937463,True,True,PASS,5.9980718347440000E-10
```

## Fresh AlterBBN canonical row

The selected AlterBBN row is the precise physical-eta replay:

```text
row: correct_physical_eta_cptg_bbn_failsafe1
eta10_BBN: 5.998071834744
eta argument: 5.9980718347440000E-10
D/H pull: -0.27586206896551463
Yp pull: 0.699999999999997
raw Li7/H: 5.291e-10
gated Li7/H: 1.6841776077984365e-10
locked gate pass: True
```

## Fresh PRyMordial canonical state

The v10.660 lane applied only the literal PDF-authorized locked gate:

```text
authorized formula: Y7,CPTG = Y7,raw/pi; tau7,trans = ln(pi)
selected raw Li7/H: 5.266820229187348e-10
authorized coefficient: 0.3183098861837907
selected gated Li7/H: 1.6764809477031113e-10
Li7 pull after gate: 0.9059237908124455
gate closure: PASS
```

## Retained integrated frontier

The retained public integrated frontier remains v10.641 / C7BP. It is not overwritten by the fresh two-code lane. The retained frontier covers source-to-amplitude closure, anchored S-factor comparison, native CPTG p+D rate branch, PRIMAT-compatible BBN integration, live A=7 RHS gate, randomized support/width MC, and reference two-code crosswalk.

## Progress accounting

```json
{
  "Strict physical contracts": {
    "closed": 6,
    "total": 6,
    "percent": 100.0
  },
  "Evidentiary subgates": {
    "closed": 27,
    "total": 27,
    "percent": 100.0
  },
  "C2.4 action elements": {
    "closed": 10,
    "total": 10,
    "percent": 100.0
  },
  "Native/all-anchor angular row pairs": {
    "closed": 9504,
    "total": 9504,
    "percent": 100.0
  },
  "Support-explicit six-map records": {
    "closed": 114048,
    "total": 114048,
    "percent": 100.0
  },
  "Exact exchange reconstruction links": {
    "closed": 57024,
    "total": 57024,
    "percent": 100.0
  },
  "Support-slot physical values": {
    "closed": 272,
    "total": 272,
    "percent": 100.0
  },
  "Physical current/source coefficients": {
    "closed": 5,
    "total": 5,
    "percent": 100.0
  },
  "Fresh PRyMordial replay": {
    "status": "CLOSED",
    "source": "v10.660 / C7CG; PDF-authorized locked 1/pi gate retained",
    "Li7_pull_sigma_after_gate": 0.9059237908124455
  },
  "Fresh AlterBBN replay": {
    "status": "CLOSED",
    "source": "v10.668 / C7CO; alter_eta.x physical eta argument eta10_BBN*1e-10; canonical precise failsafe=1 row",
    "selected_row": "correct_physical_eta_cptg_bbn_failsafe1",
    "D_H_pull_sigma": -0.27586206896551463,
    "Yp_pull_sigma": 0.699999999999997,
    "Li7_pull_sigma_after_gate": 0.9367104311937463
  },
  "Fresh two-code locked A=7 gate": {
    "status": "CLOSED",
    "PRyMordial": "PASS from v10.660",
    "AlterBBN": "PASS from v10.668 canonical precise/failsafe=1 row"
  },
  "Retained integrated PRIMAT-compatible current-chain frontier": {
    "status": "RETAINED_NOT_OVERWRITTEN",
    "frontier": "v10.641 / C7BP"
  },
  "Aborted/superseded packages": [
    "v10.659 broad locator; do not rerun",
    "v10.662 explicit-root probe superseded by v10.663 exact default-root path"
  ]
}
```

## Formula list

- **CPTG native ordering**: `CPTG-native geometric quantity -> comparison-coordinate quantity -> reported observational quantity` — retained
- **CPTG action schematic**: `S_CPTG = ∫ d^4x sqrt(-g)[c^4 R/(16πG) + L_pol + L_trans + L_m]` — theory-side schematic
- **CPTG field equation schematic**: `G_mu_nu + Pi_pol_mu_nu + Theta_trans_mu_nu = (8πG/c^4) T_mu_nu` — theory-side schematic
- **Pi branch**: `p_C = π` — locked
- **Acoustic exponent**: `p_ac = 3 - π/100 = 2.968584073464` — locked
- **Acoustic transport**: `G_T = p_ac/p_C = 0.9449296585513721` — locked
- **BBN eta transport**: `eta10_BBN = eta10_ac sqrt(G_T) = 5.998071834744` — locked
- **Mass-seven definition**: `Y7 = Y7Li + Y7Be` — retained
- **Locked mass-seven gate**: `tau7 = ∫ Gamma7,trans dt = ln(pi)` — authorized
- **Locked mass-seven survival**: `Y7_CPTG = Y7_raw exp(-ln(pi)) = Y7_raw/pi` — authorized
- **Live Li7 RHS gate**: `dY_Li7/dt -> (dY_Li7/dt)_BBN - Gamma7(T) Y_Li7` — authorized live source-network form
- **Live Be7 RHS gate**: `dY_Be7/dt -> (dY_Be7/dt)_BBN - Gamma7(T) Y_Be7` — authorized live source-network form
- **C6 coherent amplitude**: `A_C6 = 17.5595746398194` — retained from v10.641 public status
- **C7 source intensity**: `I_C7 = |A_C6|^2 = 308.3386615313886` — retained from v10.641 public status
- **S-factor normalization**: `K_S0 = S12_best(0)/I_C7 = 0.0006956636541608783 eV b per dimensionless intensity` — retained from v10.641 public status
- **Anchored S-factor**: `S_CPTG(0) = 0.2145 eV b` — closed anchor row

## Non-regression instructions for the next AI agent

1. Do not rerun v10.659. It was a broad locator and was superseded.
2. Do not rerun v10.662 for AlterBBN. It was superseded by the exact default-root path in v10.663.
3. Do not reopen PRyMordial binding or parsing unless a new contradiction appears.
4. Do not reopen AlterBBN compiler/root/argument semantics unless a new contradiction appears.
5. Preserve the lane split: v10.641 / C7BP is the retained integrated current-chain frontier; v10.669 / C7CP is the fresh two-code locked-gate closure.
6. Treat v10.670 as handoff/report packaging, not new physics.

## Evidence chain index from v10.669

```csv
{evidence_index_text.strip()}
```
