# Next-agent handoff: v10.670 / C7CQ

Start here.

## Current frontier split

- `v10.641 / C7BP`: retained integrated PRIMAT-compatible current-chain frontier.
- `v10.660 / C7CG`: fresh PRyMordial/PDF-authorized locked gate closed.
- `v10.668 / C7CO`: fresh local AlterBBN physical-eta locked gate closed.
- `v10.669 / C7CP`: fresh two-code locked gate reconciliation closed.
- `v10.670 / C7CQ`: this complete report/evidence-chain/handoff package.

## What is closed

- Strict physical contracts: 6/6.
- Evidentiary subgates: 27/27.
- C2.4 action elements: 10/10.
- Support-slot physical values: 272/272.
- Physical current/source coefficients: 5/5.
- Fresh PRyMordial locked mass-seven gate: closed.
- Fresh AlterBBN locked mass-seven gate: closed.
- Fresh two-code locked A=7 gate: closed.

## What must not be lost

- The authorized A=7 gate is `tau7 = ln(pi)` and `survival = 1/pi`.
- The gate acts on live `Li7` and `Be7` source terms.
- The correct AlterBBN explicit eta command is `alter_eta.x 5.9980718347440000E-10 1`.
- The canonical AlterBBN row is `correct_physical_eta_cptg_bbn_failsafe1`.
- The v10.668 failsafe=0 rows are diagnostic only and not canonical.
- v10.641 remains retained as the integrated PRIMAT-compatible current-chain frontier.

## Recommended next action

Freeze this state into any public status/manuscript/README that needs updating. Any further work should be an explicitly new extension, not another re-audit of the now-closed PRyMordial/PDF/AlterBBN lanes.
