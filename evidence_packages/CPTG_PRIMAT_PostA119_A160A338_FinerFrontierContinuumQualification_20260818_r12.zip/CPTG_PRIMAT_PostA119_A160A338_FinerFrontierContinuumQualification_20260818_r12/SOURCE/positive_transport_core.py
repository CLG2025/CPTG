from __future__ import annotations
import math
import numpy as np
from numba import njit

@njit(cache=True)
def _lerp(a,b,f):
    return a + f*(b-a)

@njit(cache=True)
def solve_backward_euler(t,source,loss,inc_src,inc_start,inc_coeff,substeps):
    ns=source.shape[0]; nt=t.shape[0]
    y=np.zeros(ns,np.float64)
    min_seen=0.0
    for k in range(nt-1):
        dt=(t[k+1]-t[k])/substeps
        for ss in range(substeps):
            f1=(ss+1.0)/substeps
            old=y.copy(); new=np.empty_like(y)
            for i in range(ns):
                s1=_lerp(source[i,k],source[i,k+1],f1)
                l1=_lerp(loss[i,k],loss[i,k+1],f1)
                rhs=old[i]+dt*s1
                for e in range(inc_start[i],inc_start[i+1]):
                    c1=_lerp(inc_coeff[e,k],inc_coeff[e,k+1],f1)
                    rhs += dt*c1*new[inc_src[e]]
                den=1.0+dt*l1
                new[i]=rhs/den
                if new[i]<min_seen:min_seen=new[i]
            y=new
    return y,min_seen

@njit(cache=True)
def solve_positive_exponential_inflow(t,source,loss,inc_src,inc_start,inc_coeff,substeps):
    """
    Positivity-preserving exponential-inflow step on an acyclic triangular network.

    Coefficients are sampled at the substep midpoint. For node i, upstream nodes have
    already been advanced because all incoming graph edges are forward in (A,Z).
    The incoming abundance is approximated by the trapezoidal average of old/new
    upstream states, then the scalar sink term is integrated analytically.
    """
    ns=source.shape[0]; nt=t.shape[0]
    y=np.zeros(ns,np.float64)
    min_seen=0.0
    for k in range(nt-1):
        dt=(t[k+1]-t[k])/substeps
        for ss in range(substeps):
            fm=(ss+0.5)/substeps
            old=y.copy(); new=np.empty_like(y)
            for i in range(ns):
                q=_lerp(source[i,k],source[i,k+1],fm)
                l=_lerp(loss[i,k],loss[i,k+1],fm)
                for e in range(inc_start[i],inc_start[i+1]):
                    c=_lerp(inc_coeff[e,k],inc_coeff[e,k+1],fm)
                    j=inc_src[e]
                    q += c*0.5*(old[j]+new[j])
                z=l*dt
                if l>0.0:
                    decay=math.exp(-z) if z<745.0 else 0.0
                    gain=(-math.expm1(-z))/l
                    new[i]=decay*old[i]+gain*q
                else:
                    new[i]=old[i]+dt*q
                if new[i]<min_seen:min_seen=new[i]
            y=new
    return y,min_seen
