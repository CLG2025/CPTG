from __future__ import annotations
import hashlib,json,math,os,re
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
CONFIG=ROOT/"CONFIG"; EVIDENCE=ROOT/"EVIDENCE"; OUTPUT=ROOT/"OUTPUT"; RESULTS=ROOT/"RESULTS"
ETA=[6.044,6.080,6.094,6.106,6.128,6.134]
LIGHT={(1,0):"n",(1,1):"p",(2,1):"H2",(3,1):"H3",(3,2):"He3",(4,2):"He4"}
ELEMENTS=["n","H","He","Li","Be","B","C","N","O","F","Ne","Na","Mg","Al","Si","P","S","Cl","Ar","K","Ca","Sc","Ti","V","Cr","Mn","Fe","Co","Ni","Cu","Zn","Ga","Ge","As","Se","Br","Kr","Rb","Sr","Y","Zr","Nb","Mo","Tc","Ru","Rh","Pd","Ag","Cd","In","Sn","Sb","Te","I","Xe","Cs","Ba","La","Ce","Pr","Nd","Pm","Sm","Eu","Gd","Tb","Dy","Ho","Er","Tm","Yb","Lu","Hf","Ta","W","Re","Os","Ir","Pt","Au","Hg","Tl","Pb","Bi","Po","At","Rn","Fr","Ra","Ac","Th","Pa","U","Np","Pu","Am","Cm","Bk","Cf","Es","Fm","Md","No","Lr","Rf","Db","Sg","Bh","Hs","Mt","Ds","Rg","Cn","Nh","Fl","Mc","Lv","Ts","Og"]
ZMAP={s:z for z,s in enumerate(ELEMENTS) if z>0}; SYMB={z:s for s,z in ZMAP.items()}
def load_json(p:Path):return json.loads(p.read_text(encoding="utf-8"))
def atomic_json(p:Path,obj):
    p.parent.mkdir(parents=True,exist_ok=True);q=p.with_suffix(p.suffix+".tmp")
    with q.open("w",encoding="utf-8",newline="\n") as f:
        f.write(json.dumps(obj,indent=2,sort_keys=True,allow_nan=False)+"\n");f.flush();os.fsync(f.fileno())
    os.replace(q,p)
def sha_file(p:Path):
    h=hashlib.sha256()
    with p.open("rb") as f:
        for b in iter(lambda:f.read(1048576),b""):h.update(b)
    return h.hexdigest()
def eta_tag(x:float):return f"{x:.3f}".replace(".","p")
def parse_primat_name(name:str):
    if name=="n":return 1,0
    if name=="p":return 1,1
    m=re.fullmatch(r"([A-Z][a-z]?)(\d+)",name)
    if not m or m.group(1) not in ZMAP:raise ValueError("cannot parse PRIMAT nuclide "+name)
    return int(m.group(2)),ZMAP[m.group(1)]
def az_name(A:int,Z:int):
    if A==1 and Z==0:return "n"
    if A==1 and Z==1:return "p"
    return f"{SYMB.get(Z,'Z'+str(Z))}{A}"
def symmetric_rel(a,b,floor=1e-300):return abs(float(a)-float(b))/max(abs(float(a)),abs(float(b)),floor)
def vector_max_rel(a,b,floor=1e-300):return max((symmetric_rel(x,y,floor) for x,y in zip(a,b)),default=0.0)
