from __future__ import annotations
import json,hashlib,shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
R06=Path(r"D:\Downloads\CPTG_PRIMAT_NativeBoundaryFlux_A1A119_FinalEvidenceValidation_20260818_r06")
R09=Path(r"D:\Downloads\CPTG_PRIMAT_PostA119_A120A160_FinerContinuumQualification_20260818_r09_HOTFIX_r01")
R10=Path(r"D:\Downloads\CPTG_PRIMAT_PostA119_A338A339_StructuralFrontierForensic_20260818_r10")
R11=Path(r"D:\Downloads\CPTG_PRIMAT_PostA119_A160A338_FrontierApproachContinuumQualification_20260818_r11")
EXPECT="97fd7b4f4f4e7466be9e45be264e62faade5b55e80d415201ed4390405080f9a"
ALLOWED={"A339_DISCONNECTED_RATE_ISLAND__ALL_INCOMING_SOURCES_UNREACHABLE","A339_ELIGIBLE_NODES_WITH_NO_ALLOWED_INCOMING_EDGE"}
def sha(p):
    h=hashlib.sha256()
    with p.open("rb") as f:
        for b in iter(lambda:f.read(1048576),b""):h.update(b)
    return h.hexdigest()
def main():
    for d in (ROOT/"EVIDENCE",ROOT/"OUTPUT"):d.mkdir(parents=True,exist_ok=True)
    fs=R06/"EVIDENCE/FINAL_VALIDATION_SUMMARY.json";fp=R06/"OUTPUT/NATIVE_TRAJECTORY_FREEZE.json"
    if not fs.is_file() or json.loads(fs.read_text(encoding="utf-8"))["decision"]!="PASS":raise RuntimeError("r06 PASS required")
    if not fp.is_file() or sha(fp)!=EXPECT:raise RuntimeError("r06 native freeze mismatch")
    fr=json.loads(fp.read_text(encoding="utf-8"))
    for rec in fr["files"]:
        s=R06/rec["path"]
        if not s.is_file() or sha(s)!=rec["sha256"]:raise RuntimeError("native member mismatch "+rec["path"])
        d=ROOT/rec["path"];d.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(s,d)
        if sha(d)!=rec["sha256"]:raise RuntimeError("copy mismatch "+rec["path"])
    shutil.copy2(fp,ROOT/"OUTPUT/NATIVE_TRAJECTORY_FREEZE.json")
    r09p=R09/"EVIDENCE/R09_A120_A160_FINER_CONTINUUM_QUALIFICATION.json"
    if not r09p.is_file() or json.loads(r09p.read_text(encoding="utf-8")).get("decision")!="PASS":raise RuntimeError("r09 PASS required")
    r10p=R10/"EVIDENCE/A338_A339_STRUCTURAL_FRONTIER_FORENSIC.json"
    if not r10p.is_file():raise RuntimeError("r10 forensic evidence missing")
    r10=json.loads(r10p.read_text(encoding="utf-8"))
    if r10.get("decision")!="PASS" or r10.get("classification") not in ALLOWED:raise RuntimeError("r10 accepted frontier classification required")
    if r10.get("reachable_max_A")!=338 or r10.get("incoming_edges_to_A339_from_reachable_sources")!=0 or r10.get("A338_outgoing_edges_to_unreachable_nodes")!=0:raise RuntimeError("r10 frontier invariants mismatch")
    r11p=R11/"EVIDENCE/R11_A160_A338_FRONTIER_APPROACH_CONTINUUM_QUALIFICATION.json"
    if not r11p.is_file():raise RuntimeError("r11 production evidence missing; run r11 first")
    r11=json.loads(r11p.read_text(encoding="utf-8"))
    if r11.get("decision")!="NOT_QUALIFIED":raise RuntimeError("r11 NOT_QUALIFIED decision required")
    expected={"global_P256_512_checkpoint_max":0.023876113853663776,"global_BE256_512_checkpoint_max":0.11507297949811768,"global_continuum_cross_checkpoint_max":0.023242328805058166,"global_P512_Richardson_checkpoint_max":0.008795345760896621}
    for k,v in expected.items():
        x=float(r11.get(k,float('nan')))
        if abs(x-v)>max(1e-15,1e-12*abs(v)):raise RuntimeError("r11 frozen metric mismatch "+k)
    if any(a.get("pass") is not False for a in r11.get("anchors",[])) or len(r11.get("anchors",[]))!=6:raise RuntimeError("r11 six-anchor NOT_QUALIFIED structure mismatch")
    shutil.copy2(r09p,ROOT/"EVIDENCE/UPSTREAM_R09_PASS_SUMMARY.json")
    shutil.copy2(r10p,ROOT/"EVIDENCE/UPSTREAM_R10_FRONTIER_FORENSIC.json")
    # r11 copied only as decision/metric evidence; solver never reads it
    shutil.copy2(r11p,ROOT/"EVIDENCE/UPSTREAM_R11_NOT_QUALIFIED_SUMMARY.json")
    out={"schema":"cptg-r12-upstream-adoption-v1","pass":True,"native_freeze_sha256":EXPECT,"r09_decision":"PASS","r10_decision":"PASS","r10_classification":r10["classification"],"r10_reachable_max_A":338,"r11_decision":"NOT_QUALIFIED","r11_metrics_verified":True,"postsilicon_endpoint_vectors_imported":False,"upstream_decision_summaries_imported":True,"historical_postsilicon_numerical_inputs":0}
    (ROOT/"EVIDENCE/UPSTREAM_ADOPTION.json").write_text(json.dumps(out,indent=2,sort_keys=True)+"\n",encoding="utf-8")
    print("R12_UPSTREAM_ADOPTION PASS")
    print("FREEZE_SHA256",EXPECT)
    print("R09_DECISION PASS")
    print("R10_FRONTIER_CLASSIFICATION",r10["classification"])
    print("R11_DECISION NOT_QUALIFIED")
    print("R11_METRICS_VERIFIED True")
    print("POSTSILICON_ENDPOINT_VECTORS_IMPORTED False")
    print("HISTORICAL_POSTSILICON_NUMERICAL_INPUTS 0")
if __name__=="__main__":main()
