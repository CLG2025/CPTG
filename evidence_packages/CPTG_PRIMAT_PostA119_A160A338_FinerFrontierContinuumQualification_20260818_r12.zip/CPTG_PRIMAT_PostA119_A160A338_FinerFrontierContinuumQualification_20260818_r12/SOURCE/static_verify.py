from __future__ import annotations
import json,hashlib,py_compile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def ck(n,c):
    if not c:raise RuntimeError(n+" FAIL")
    print(n,"PASS")
def main():
    p=json.loads((ROOT/"CONFIG/FROZEN_R12_FINER_FRONTIER_PREREGISTRATION.json").read_text(encoding="utf-8"))
    ck("R12_NATURAL_FRONTIER_338",p["graph"]["expected_natural_reachable_max_A"]==338)
    ck("NO_ARTIFICIAL_AMAX",p["graph"]["artificial_Amax"] is None)
    ck("NO_SEED_FLOOR",p["graph"]["artificial_seed_or_floor"] is False)
    ck("NO_ENDPOINT_VECTOR_IMPORT",p["authority"]["no_postsilicon_endpoint_vector_import"] is True)
    ck("R11_NOT_QUALIFIED_REQUIRED",p["hard_gates"]["r11_not_qualified_required"] is True and p["upstream_locked_observations"]["r11_decision"]=="NOT_QUALIFIED")
    ck("LEVELS_512_1024_2048",p["numerics"]["fresh_refinement_levels"]==[512,1024,2048])
    ck("PRODUCTION_2048",p["numerics"]["candidate_production_refinement"]==2048)
    ck("FRONTIER_CHECKPOINTS",p["numerics"]["frontier_checkpoint_masses"]==[160,180,200,220,240,260,280,300,320,330,334,336,337,338])
    ck("FULL_POSITIVE_REGION",p["numerics"]["full_positive_support_region"]==[160,338])
    ck("STRICT_PRIMARY_GATE_UNCHANGED",p["hard_gates"]["primary_1024_2048_checkpoint_max_relative"]==0.005)
    ck("STRICT_RESIDUAL_GATE_UNCHANGED",p["hard_gates"]["primary_2048_to_Richardson_checkpoint_max_relative"]==0.0025)
    ck("STRICT_BE_GATE_UNCHANGED",p["hard_gates"]["BE_1024_2048_checkpoint_max_relative"]==0.04)
    ck("STRICT_CROSS_GATE_UNCHANGED",p["hard_gates"]["continuum_cross_scheme_checkpoint_max_relative"]==0.005)
    ck("R10_FORENSIC_STILL_REQUIRED",p["hard_gates"]["r10_forensic_pass_required"] is True)
    ck("SOURCE_TAIL_QUEUED","tail truncation" in p["future_required_diagnostic"].lower() and "leave-one-out" in p["future_required_diagnostic"].lower())
    s=(ROOT/"SOURCE/run_finer_frontier.py").read_text(encoding="utf-8")
    ck("UNCAPPED_BFS","def build_uncapped_graph" in s and "expected_natural_reachable_max_A" not in s)
    ck("RUNTIME_FRONTIER_ASSERT","maxA==g[\"natural_reachable_max_A_exact\"]" in s)
    ck("STRUCTURAL_ALL_A24_A338","STRUCTURAL_REGION=list(range(24,339))" in s)
    ck("POSITIVE_ALL_A160_A338","POSITIVE_REGION=list(range(160,339))" in s)
    ck("FRESH_2048","solve_positive_exponential_inflow(t,S,L,ii,st,C,2048)" in s)
    ck("TWO_SCHEMES","solve_positive_exponential_inflow" in s and "solve_backward_euler" in s)
    ck("NO_OLD_CONTINUUM_LEVELS","LEVELS=[128,256,512]" not in s and "P[128]" not in s and "P[256]" not in s and "B[128]" not in s and "B[256]" not in s)
    ck("NO_UPSTREAM_ENDPOINT_READ_IN_SOLVER","UPSTREAM_R11_NOT_QUALIFIED_SUMMARY" not in s and "UPSTREAM_R09_PASS_SUMMARY" not in s and "UPSTREAM_R10_FRONTIER_FORENSIC" not in s)
    pys=sorted((ROOT/"SOURCE").glob("*.py"))
    for q in pys:py_compile.compile(str(q),doraise=True)
    print("PYTHON_COMPILE",f"{len(pys)}/{len(pys)}","PASS")
    bad=[];n=0
    for line in (ROOT/"MANIFEST.sha256").read_text(encoding="utf-8").splitlines():
        if line.strip():
            h,rel=line.split("  ",1);n+=1;q=ROOT/rel
            if not q.is_file() or sha(q)!=h:bad.append(rel)
    ck(f"PACKAGE_MANIFEST {n-len(bad)}/{n}",not bad)
    print("R12_FINER_FRONTIER_STATIC_VERIFY PASS")
if __name__=="__main__":main()
