# Prior frontier-approach decision retained

The immediately preceding 128→256→512 frontier-approach campaign ended `NOT_QUALIFIED` at all six anchors. The result is retained, not overwritten.

Frozen user-executed global metrics:

- primary 256→512 max: `0.023876113853663776`
- backward-Euler 256→512 max: `0.11507297949811768`
- continuum cross-scheme max: `0.023242328805058166`
- primary 512→Richardson max: `0.008795345760896621`
- worst checkpoint at every anchor: `A=338`

Observed orders remained coherent: primary approximately `1.91878–1.91939`; backward Euler approximately `0.90311–0.90392`. This motivates a higher-resolution test without changing scientific gates.
