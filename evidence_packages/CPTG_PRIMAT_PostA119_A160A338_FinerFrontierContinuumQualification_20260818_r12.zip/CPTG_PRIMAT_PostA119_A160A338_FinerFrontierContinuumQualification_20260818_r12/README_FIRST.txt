# CPTG PRIMAT A=160–338 Finer Frontier Continuum Qualification — r12

The previous frontier-approach campaign is scientifically retained as **NOT_QUALIFIED at the 512-step production ceiling**. It did not show a structural failure: all six anchors retained coherent convergence orders (primary about 1.919, backward Euler about 0.903), and every anchor identified A=338 as the worst checkpoint. The failure was quantitative resolution: the 256→512, backward-Euler, continuum-cross, and 512→Richardson gates were all above their frozen tolerances.

This campaign asks one narrow question: **does the same frozen PRIMAT-anchored transport become qualified when the continuum ladder is moved to fresh 512 → 1024 → 2048 solutions, without changing any scientific tolerance or reaction rule?**

No post-silicon endpoint vector is imported. The solver begins again from the frozen native PRIMAT trajectories and a fresh ReacLib 2.11.0 graph. The graph remains uncapped and must independently rediscover the natural reachable maximum A=338 established by the structural forensic.

## Why 2048 is preregistered

Using the worst observed convergence orders from the previous campaign only as a resolution-design diagnostic, persistence of those orders projects approximately:

- primary 512→1024: 0.631% (still above the 0.5% gate),
- primary 1024→2048: 0.167% (below gate),
- backward Euler 512→1024: 6.15% (still above the 4% gate),
- backward Euler 1024→2048: 3.29% (below gate),
- primary 2048→Richardson residual: 0.0615% (below the 0.25% gate).

These projections are **not acceptance criteria** and no projection is made for the independent continuum-cross-scheme metric. They only justify choosing 2048 before exposing any 1024/2048 endpoint result.

## Frozen gates

The tolerances are unchanged in value from the prior qualification:

- primary final-step max relative difference <= 0.5%,
- primary observed order in [1.5, 2.5],
- primary production-to-Richardson residual <= 0.25%,
- backward-Euler final-step max relative difference <= 4%,
- backward-Euler observed order in [0.5, 1.5],
- independently extrapolated continuum cross-scheme difference <= 0.5%,
- full-vector source linearity <= 1e-10,
- absolute/normalized reconstruction <= 1e-10,
- zero-source exact zero,
- finite/nonnegative raw states,
- structural reachability A=24…338,
- strict positive primary support A=160…338 at 2048 for all six anchors,
- natural reachable maximum exactly A=338 with no artificial Amax.

The convergence claim remains restricted to the preregistered checkpoints:

160, 180, 200, 220, 240, 260, 280, 300, 320, 330, 334, 336, 337, 338.

## Windows sequence

```cmd
cd /d D:\Downloads\CPTG_PRIMAT_PostA119_A160A338_FinerFrontierContinuumQualification_20260818_r12
RUN_STATIC_VERIFY_WINDOWS.cmd
RUN_ADOPT_UPSTREAM_AUTHORITY_WINDOWS.cmd
RUN_TRANSPORT_SELFTEST_WINDOWS.cmd
RUN_FINER_FRONTIER_WINDOWS.cmd
```

The adoption step requires the existing r11 evidence to remain `NOT_QUALIFIED`; this campaign does not overwrite that result.

The decisive ending is either:

```text
R12_A160_A338_FINER_FRONTIER_CONTINUUM_QUALIFICATION PASS
```

or fail-closed:

```text
R12_A160_A338_FINER_FRONTIER_CONTINUUM_QUALIFICATION NOT_QUALIFIED
```

A PASS qualifies the higher-resolution checkpoint continuum behavior approaching A=338 and full 2048-step positive support over A=160…338. It does not convert the reduced graph into native PRIMAT heavy-network evolution, an all-sector convergence proof, or a primordial heavy-element yield prediction.

After PASS, the already-queued source-tail truncation and all-14 native-boundary-edge leave-one-out ablations remain mandatory before deep-tail amplitudes are described as source-robust.
