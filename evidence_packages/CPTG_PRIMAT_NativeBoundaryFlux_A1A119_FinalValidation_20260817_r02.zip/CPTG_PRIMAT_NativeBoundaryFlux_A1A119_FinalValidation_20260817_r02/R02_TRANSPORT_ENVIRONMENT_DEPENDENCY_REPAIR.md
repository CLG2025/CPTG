# r02 Transport Environment Dependency Repair

## Trigger

The r01 transport environment setup installed `pynucastro==2.11.0` and NumPy 2.5.2, then
failed its own import check:

```text
ModuleNotFoundError: No module named 'numba'
```

No PRIMAT native trajectory run and no external transport calculation had started.

## Classification

`PRE_EXECUTION_DEPENDENCY_CONTRACT_DEFECT`

This is not a PRIMAT result, not an external-network result, and not a CPTG scientific failure.

## Cause

The r01 setup created the transport venv with `--system-site-packages` and assumed Numba would
be inherited from the parent Python environment. It was not.

In addition, the newly installed NumPy was 2.5.2. The stable Numba line used for this package
is pinned to 0.66.0, so r02 pins NumPy to the latest 2.4.x maintenance release used here,
2.4.6, rather than relying on the NumPy 2.5 line.

## r02 repair

A brand-new isolated venv is used:

```text
D:\Downloads\CPTG_PRIMAT_A1A119_TRANSPORT_ENV_r02
```

No `--system-site-packages` is used.

Explicit pins:

```text
numpy==2.4.6
numba==0.66.0
pynucastro==2.11.0
```

`pip check` and exact import/version checks are mandatory before PASS.

## Scientific scope

Unchanged:

- PRIMAT v0.3.2 native trajectory test;
- six eta10 anchors;
- native boundary-flux construction;
- fresh ReacLib graph selection;
- allowed light bath;
- beta-minus transport;
- zero historical numerical inputs;
- all numerical and falsification gates;
- A=1–119 final register;
- paper-data policy.

No scientific result from r01 exists to inherit.
