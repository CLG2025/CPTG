@echo off
setlocal
cd /d "%~dp0"

if exist "D:\Downloads\CPTG_PRIMAT_A1A119_TRANSPORT_ENV_r02" (
  if not exist "D:\Downloads\CPTG_PRIMAT_A1A119_TRANSPORT_ENV_r02\Scripts\python.exe" (
    echo TRANSPORT_ENV_EXISTING_INVALID D:\Downloads\CPTG_PRIMAT_A1A119_TRANSPORT_ENV_r02
    exit /b 2
  )
) else (
  "D:\Downloads\ChatGPT\cptg-cmb-like\Scripts\python.exe" -m venv "D:\Downloads\CPTG_PRIMAT_A1A119_TRANSPORT_ENV_r02"
  if errorlevel 1 exit /b 1
)

"D:\Downloads\CPTG_PRIMAT_A1A119_TRANSPORT_ENV_r02\Scripts\python.exe" -m pip install --disable-pip-version-check --upgrade pip
if errorlevel 1 exit /b 1

"D:\Downloads\CPTG_PRIMAT_A1A119_TRANSPORT_ENV_r02\Scripts\python.exe" -m pip install --disable-pip-version-check --upgrade --force-reinstall "numpy==2.4.6" "numba==0.66.0"
if errorlevel 1 exit /b 1

"D:\Downloads\CPTG_PRIMAT_A1A119_TRANSPORT_ENV_r02\Scripts\python.exe" -m pip install --disable-pip-version-check --upgrade "pynucastro==2.11.0"
if errorlevel 1 exit /b 1

"D:\Downloads\CPTG_PRIMAT_A1A119_TRANSPORT_ENV_r02\Scripts\python.exe" -m pip check
if errorlevel 1 exit /b 1

"D:\Downloads\CPTG_PRIMAT_A1A119_TRANSPORT_ENV_r02\Scripts\python.exe" -c "import importlib.metadata as m, numpy, numba, pynucastro, scipy; assert m.version('numpy')=='2.4.6'; assert m.version('numba')=='0.66.0'; assert m.version('pynucastro')=='2.11.0'; print('TRANSPORT_ENV_NUMPY',m.version('numpy')); print('TRANSPORT_ENV_NUMBA',m.version('numba')); print('TRANSPORT_ENV_PYNUCASTRO',m.version('pynucastro')); print('TRANSPORT_ENV_SETUP PASS')"
exit /b %ERRORLEVEL%
