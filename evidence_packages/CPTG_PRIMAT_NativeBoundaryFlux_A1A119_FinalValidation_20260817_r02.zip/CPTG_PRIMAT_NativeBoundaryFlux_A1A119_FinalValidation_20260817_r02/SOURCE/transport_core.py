from __future__ import annotations
import numpy as np
from numba import njit

@njit(cache=True)
def _interp(a0,a1,f):
    return a0+f*(a1-a0)

@njit(cache=True)
def solve_triangular(t,source,loss,inc_src,inc_start,inc_coeff,substeps,scheme):
    # t: nt; source/loss: ns x nt; inc_coeff: ne x nt, incoming edges grouped by destination
    ns=source.shape[0]; nt=t.shape[0]
    y=np.zeros(ns,np.float64)
    for k in range(nt-1):
        dt0=(t[k+1]-t[k])/substeps
        for ss in range(substeps):
            f0=ss/substeps; f1=(ss+1.0)/substeps
            old=y.copy(); new=np.empty_like(y)
            for i in range(ns):
                if scheme==0: # backward Euler
                    s1=_interp(source[i,k],source[i,k+1],f1)
                    l1=_interp(loss[i,k],loss[i,k+1],f1)
                    rhs=old[i]+dt0*s1
                    for e in range(inc_start[i],inc_start[i+1]):
                        c1=_interp(inc_coeff[e,k],inc_coeff[e,k+1],f1)
                        rhs += dt0*c1*new[inc_src[e]]
                    new[i]=rhs/(1.0+dt0*l1)
                else: # Crank-Nicolson
                    s0=_interp(source[i,k],source[i,k+1],f0)
                    s1=_interp(source[i,k],source[i,k+1],f1)
                    l0=_interp(loss[i,k],loss[i,k+1],f0)
                    l1=_interp(loss[i,k],loss[i,k+1],f1)
                    rhs=old[i]+0.5*dt0*(s0+s1-l0*old[i])
                    for e in range(inc_start[i],inc_start[i+1]):
                        c0=_interp(inc_coeff[e,k],inc_coeff[e,k+1],f0)
                        c1=_interp(inc_coeff[e,k],inc_coeff[e,k+1],f1)
                        rhs += 0.5*dt0*(c0*old[inc_src[e]]+c1*new[inc_src[e]])
                    new[i]=rhs/(1.0+0.5*dt0*l1)
            y=new
    return y
