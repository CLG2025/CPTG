from __future__ import annotations
import csv,json,math,importlib.metadata,time
from collections import defaultdict,deque
from pathlib import Path
import numpy as np
import pynucastro as pyna
from common import *
from transport_core import solve_triangular

LIGHT_TUPLES=set(LIGHT)
SELECTED=[24,28,32,40,56,80,100,119]

def nuc_tuple(n): return int(n.A),int(n.Z)

def rate_key(r):
    return (tuple(sorted(nuc_tuple(x) for x in r.reactants)),
            tuple(sorted(nuc_tuple(x) for x in r.products)),
            str(getattr(r,"weak_type","")),str(r))

def select_rates():
    rl=pyna.ReacLibLibrary()
    captures=[];betas=[]
    for r in rl.get_rates():
        rea=[nuc_tuple(x) for x in r.reactants];pro=[nuc_tuple(x) for x in r.products]
        if not r.weak and len(rea)==2 and len(pro)==1:
            light=[x for x in rea if x in LIGHT_TUPLES]
            if len(light)==1:
                heavy=rea[1] if rea[0]==light[0] else rea[0]
                l=light[0];dst=pro[0]
                if heavy[0]>=6 and dst==(heavy[0]+l[0],heavy[1]+l[1]):
                    captures.append((heavy,l,dst,r))
        if r.weak and getattr(r,"weak_type",None)=="beta_neg" and len(rea)==1 and len(pro)==1:
            if rea[0][0]>=6 and pro[0][0]==rea[0][0] and pro[0][1]==rea[0][1]+1:
                betas.append((rea[0],pro[0],r))
    captures.sort(key=lambda x:(x[0],x[1],x[2],str(x[3])))
    betas.sort(key=lambda x:(x[0],x[1],str(x[2])))
    return captures,betas

def build_graph(native,maxA,captures,betas):
    # Boundary source edges can cross from any native heavy nucleus into A>23.
    source=[]
    for h,l,d,r in captures:
        if h in native and d not in native and d[0]>=24 and d[0]<=maxA:
            source.append((h,l,d,r))
    seeds={d for h,l,d,r in source}
    if not seeds: raise RuntimeError("no native-to-external boundary capture edges")
    cap_by=defaultdict(list);beta_by=defaultdict(list)
    for h,l,d,r in captures:
        if h[0]>=24: cap_by[h].append((d,l,r))
    for s,d,r in betas:
        if s[0]>=24: beta_by[s].append((d,r))
    seen=set(seeds);q=deque(sorted(seeds))
    while q:
        s=q.popleft()
        for d,l,r in cap_by.get(s,[]):
            if d[0]<=maxA and d not in seen:
                seen.add(d);q.append(d)
        for d,r in beta_by.get(s,[]):
            if d[0]<=maxA and d not in seen:
                seen.add(d);q.append(d)
    species=sorted(seen,key=lambda x:(x[0],x[1]))
    idx={s:i for i,s in enumerate(species)}
    incoming=[];outgoing=defaultdict(list)
    # internal transitions; edges beyond maxA are retained as sinks in outgoing only.
    for s in species:
        for d,l,r in cap_by.get(s,[]):
            outgoing[s].append(("capture",d,l,r))
            if d in idx:
                if idx[d]<=idx[s]: raise RuntimeError("non-forward capture ordering")
                incoming.append((idx[s],idx[d],"capture",l,r))
        for d,r in beta_by.get(s,[]):
            outgoing[s].append(("beta",d,None,r))
            if d in idx:
                if idx[d]<=idx[s]: raise RuntimeError("non-forward beta ordering")
                incoming.append((idx[s],idx[d],"beta",None,r))
    incoming.sort(key=lambda e:(e[1],e[0],str(e[4])))
    return source,species,idx,incoming,outgoing

def graph_register(source,species,incoming,outgoing,maxA):
    rows=[]
    for h,l,d,r in source:
        rows.append({"role":"BOUNDARY_SOURCE","src":az_name(*h),"light":az_name(*l),"dst":az_name(*d),
                     "src_A":h[0],"src_Z":h[1],"dst_A":d[0],"dst_Z":d[1],"kind":"capture","rate":str(r)})
    for s in species:
        for kind,d,l,r in outgoing.get(s,[]):
            rows.append({"role":"INTERNAL" if d in set(species) else "OUTER_SINK","src":az_name(*s),
                         "light":az_name(*l) if l else "","dst":az_name(*d),"src_A":s[0],"src_Z":s[1],
                         "dst_A":d[0],"dst_Z":d[1],"kind":kind,"rate":str(r)})
    return rows

def load_traj(eta):
    tag=eta_tag(eta)
    meta=load_json(OUTPUT/f"NATIVE_TRAJECTORIES/PRIMAT_NATIVE_META_ETA{tag}.json")
    z=np.load(OUTPUT/f"NATIVE_TRAJECTORIES/PRIMAT_NATIVE_TRAJECTORY_ETA{tag}.npz")
    names=[str(x) for x in z["species"]]
    az=[parse_primat_name(n) for n in names]
    Y=np.asarray(z["Y"],float)
    return meta,np.asarray(z["t_s"],float),np.asarray(z["T_K"],float),np.asarray(z["rho_b_g_cm3"],float),az,Y

def precompute(eta,maxA,captures,betas,rate_cache):
    meta,t,T,rho,naz,Y=load_traj(eta)
    native=set(naz);name_ix={a:i for i,a in enumerate(naz)}
    for l in LIGHT_TUPLES:
        if l not in name_ix: raise RuntimeError("missing light bath species "+repr(l))
    source_edges,species,idx,incoming,outgoing=build_graph(native,maxA,captures,betas)
    ns=len(species);nt=len(t);ne=len(incoming)
    source=np.zeros((ns,nt));loss=np.zeros((ns,nt));inc_coeff=np.zeros((ne,nt))
    def rv_for(r):
        key=id(r)
        if key not in rate_cache:
            rate_cache[key]=np.array([float(r.eval(float(Tv))) for Tv in T])
        return rate_cache[key]
    # source
    for h,l,d,r in source_edges:
        hi=name_ix[h];li=name_ix[l];di=idx[d]
        rv=rv_for(r)
        coeff=np.maximum(rv,0.0)*rho*Y[li,:]
        source[di,:]+=coeff*Y[hi,:]
    # incoming coefficients
    for e,(si,di,kind,l,r) in enumerate(incoming):
        rv=rv_for(r)
        if kind=="capture":
            li=name_ix[l]; coeff=np.maximum(rv,0.0)*rho*Y[li,:]
        else:
            coeff=np.maximum(rv,0.0)
        inc_coeff[e,:]=coeff
    # outgoing loss includes internal and beyond-max sinks.
    for s in species:
        si=idx[s]
        for kind,d,l,r in outgoing.get(s,[]):
            rv=rv_for(r)
            if kind=="capture":
                li=name_ix[l];coeff=np.maximum(rv,0.0)*rho*Y[li,:]
            else: coeff=np.maximum(rv,0.0)
            loss[si,:]+=coeff
    # incoming offsets by dest
    counts=np.zeros(ns,dtype=np.int64)
    for si,di,kind,l,r in incoming: counts[di]+=1
    starts=np.zeros(ns+1,dtype=np.int64);starts[1:]=np.cumsum(counts)
    inc_src=np.array([x[0] for x in incoming],dtype=np.int64)
    return meta,t,source,loss,inc_src,starts,inc_coeff,species,source_edges,incoming,outgoing

def mass_sums(species,y,maxmass=119):
    out={A:0.0 for A in range(24,maxmass+1)}
    for s,v in zip(species,y):
        if 24<=s[0]<=maxmass: out[s[0]]+=float(v)
    return out

def rel_mass(a,b,masses):
    return max((symmetric_rel(a[m],b[m]) for m in masses),default=0.0)

def graph_reachability(species):
    present={a for a,z in species if 24<=a<=119}
    missing=[a for a in range(24,120) if a not in present]
    return missing

def run_anchor(eta,captures,betas,gates):
    # primary graph A=160
    rate_cache={}
    meta,t,source,loss,inc_src,starts,inc_coeff,species,source_edges,incoming,outgoing=precompute(eta,160,captures,betas,rate_cache)
    integral=float(np.trapezoid(np.sum(source,axis=0),t))
    if not math.isfinite(integral) or integral<=0: raise RuntimeError(f"nonpositive boundary source integral eta={eta}")
    sn=source/integral

    cn={}
    for sub in (1,2,4,8):
        y=solve_triangular(t,sn,loss,inc_src,starts,inc_coeff,sub,1)
        cn[sub]=mass_sums(species,y)
    ycn=solve_triangular(t,sn,loss,inc_src,starts,inc_coeff,8,1)
    ybe=solve_triangular(t,sn,loss,inc_src,starts,inc_coeff,8,0)
    yabs=solve_triangular(t,source,loss,inc_src,starts,inc_coeff,8,1)

    mcn=mass_sums(species,ycn);mbe=mass_sums(species,ybe);mabs=mass_sums(species,yabs)
    conv=rel_mass(cn[4],cn[8],SELECTED)
    cross=rel_mass(mbe,mcn,SELECTED)
    recon=rel_mass(mabs,{A:mcn[A]*integral for A in mcn},SELECTED)

    # exact source controls, at a cheaper but still deterministic refinement.
    yzero=solve_triangular(t,source*0.0,loss,inc_src,starts,inc_coeff,2,1)
    yhalf=solve_triangular(t,source*0.5,loss,inc_src,starts,inc_coeff,2,1)
    ydouble=solve_triangular(t,source*2.0,loss,inc_src,starts,inc_coeff,2,1)
    ybase2=solve_triangular(t,source,loss,inc_src,starts,inc_coeff,2,1)
    zero_exact=bool(np.array_equal(yzero,np.zeros_like(yzero)))
    lin=max(vector_max_rel(yhalf*2.0,ybase2),vector_max_rel(ydouble/2.0,ybase2))

    # outer-boundary controls
    outer={}
    for mx in (128,140,160):
        mm,tt,ss,ll,ii,st,ic,sp,se,ine,out=precompute(eta,mx,captures,betas,rate_cache)
        integ=float(np.trapezoid(np.sum(ss,axis=0),tt))
        yn=solve_triangular(tt,ss/integ,ll,ii,st,ic,8,1)
        outer[mx]=mass_sums(sp,yn)
    outer_rel=max(rel_mass(outer[128],outer[160],range(24,120)),
                  rel_mass(outer[140],outer[160],range(24,120)))

    missing=graph_reachability(species)
    positive_missing=[A for A in range(24,120) if not (mcn[A]>0 and math.isfinite(mcn[A]))]
    passed=(not missing and not positive_missing and zero_exact and
            lin<=float(gates["half_double_source_linearity_max_relative"]) and
            recon<=float(gates["normalized_vs_absolute_reconstruction_max_relative"]) and
            conv<=float(gates["CN4_vs_CN8_selected_mass_max_relative"]) and
            cross<=float(gates["BE8_vs_CN8_selected_mass_max_relative"]) and
            outer_rel<=float(gates["outer_A128_A140_A160_max_relative_through_A119"]))

    d=RESULTS/f"ETA{eta_tag(eta)}";d.mkdir(parents=True,exist_ok=True)
    with (d/"MASS_SECTORS.csv").open("w",newline="",encoding="utf-8") as f:
        w=csv.DictWriter(f,fieldnames=["A","normalized_CN8","absolute_CN8","BE8_normalized"])
        w.writeheader()
        for A in range(24,120):
            w.writerow({"A":A,"normalized_CN8":mcn[A],"absolute_CN8":mabs[A],"BE8_normalized":mbe[A]})
    with (d/"NUCLIDE_ENDPOINT.csv").open("w",newline="",encoding="utf-8") as f:
        w=csv.DictWriter(f,fieldnames=["nuclide","A","Z","normalized_CN8","absolute_CN8"])
        w.writeheader()
        for s,nv,av in zip(species,ycn,yabs):
            if s[0]<=119:
                w.writerow({"nuclide":az_name(*s),"A":s[0],"Z":s[1],"normalized_CN8":float(nv),"absolute_CN8":float(av)})
    diag={
      "schema":"cptg-primat-boundary-flux-anchor-result-v1","eta10":eta,"pass":passed,
      "native_max_A":meta["native_max_A"],"external_species_A160":len(species),
      "boundary_source_edges":len(source_edges),"internal_edges":len(incoming),
      "boundary_source_integral":integral,"structural_missing_A24_A119":missing,
      "positive_support_missing_A24_A119":positive_missing,"zero_source_exact_zero":zero_exact,
      "half_double_source_linearity_max_relative":lin,
      "normalized_vs_absolute_reconstruction_max_relative":recon,
      "CN4_vs_CN8_selected_mass_max_relative":conv,
      "BE8_vs_CN8_selected_mass_max_relative":cross,
      "outer_A128_A140_A160_max_relative_through_A119":outer_rel,
      "selected_masses":SELECTED,
      "path":"fresh PRIMAT prescribed light-bath radiative-capture + beta-minus transport"
    }
    atomic_json(d/"DIAGNOSTICS.json",diag)
    return diag,source_edges,species,incoming,outgoing

def main():
    if importlib.metadata.version("pynucastro")!="2.11.0": raise RuntimeError("pynucastro 2.11.0 required")
    verify_native_freeze()
    gates=load_json(CONFIG/"FROZEN_PREREGISTRATION.json")["hard_gates"]
    captures,betas=select_rates()
    print("FRESH_REACLIB_SELECTED",len(captures),"RADIATIVE_LIGHT_CAPTURES",len(betas),"BETA_MINUS",flush=True)
    allres=[];graph_written=False
    for eta in ETA:
        print("PRIMAT_BOUNDARY_FLUX_START",eta,flush=True)
        diag,se,sp,inc,out=run_anchor(eta,captures,betas,gates)
        allres.append(diag)
        print("PRIMAT_BOUNDARY_FLUX",eta,"PASS" if diag["pass"] else "FAIL",
              "SOURCE_EDGES",diag["boundary_source_edges"],"SPECIES",diag["external_species_A160"],
              "CN_CONV",diag["CN4_vs_CN8_selected_mass_max_relative"],flush=True)
        if not graph_written:
            rows=graph_register(se,sp,inc,out,160)
            with (EVIDENCE/"FRESH_EXTERNAL_GRAPH_REGISTER.csv").open("w",newline="",encoding="utf-8") as f:
                w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
            atomic_json(EVIDENCE/"FRESH_RATE_LIBRARY_IDENTITY.json",{
                "schema":"cptg-fresh-pynucastro-rate-identity-v1",
                "pynucastro_version":"2.11.0",
                "selected_capture_rates":len(captures),"selected_beta_minus_rates":len(betas),
                "graph_register_sha256":sha_file(EVIDENCE/"FRESH_EXTERNAL_GRAPH_REGISTER.csv"),
                "historical_rate_register_used":False})
            graph_written=True

    overall=all(r["pass"] for r in allres)
    summary={"schema":"cptg-primat-native-boundary-flux-sixanchor-validation-v1",
             "pass":overall,"anchors":allres,
             "historical_numerical_inputs_used":False,
             "old_Si30_seed_used":False,
             "artificial_seed_or_floor_used":False}
    atomic_json(EVIDENCE/"SIXANCHOR_TRANSPORT_VALIDATION.json",summary)
    print("PRIMAT_NATIVE_BOUNDARY_FLUX_SIXANCHOR", "PASS" if overall else "FAIL")
    if not overall: raise SystemExit(5)

if __name__=="__main__":main()
