from __future__ import annotations
import json,hashlib,py_compile,re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def sha(p):
    h=hashlib.sha256();h.update(p.read_bytes());return h.hexdigest()
def ck(n,c):
    if not c:raise RuntimeError(n+" FAIL")
    print(n,"PASS")
def main():
    pre=json.loads((ROOT/"CONFIG/FROZEN_PREREGISTRATION.json").read_text())
    hist=json.loads((ROOT/"CONFIG/HISTORICAL_EXCLUSION.json").read_text())
    ck("NEW_TEST_SCHEMA",pre["schema"]=="cptg-primat-native-boundary-flux-a1a119-final-validation-v1")
    ck("PRIMAT_PRIMARY",pre["authority_hierarchy"]["primary"]=="PRIMAT v0.3.2")
    ck("SIX_ETA_ANCHORS",pre["primat"]["eta10_anchors"]==[6.044,6.08,6.094,6.106,6.128,6.134])
    ck("NO_HISTORICAL_NUMERICAL_INPUT",hist["numerical_inputs_imported"]==0 and hist["seed_values_imported"]==0 and hist["rate_records_imported"]==0 and hist["thresholds_imported"]==0 and hist["result_targets_imported"]==0)
    prod="\n".join(p.read_text(errors="ignore") for p in (ROOT/"SOURCE").glob("*.py") if p.name not in ("static_verify.py",))
    ck("NO_HISTORICAL_SI30_VARIABLE","Y_Si30" not in prod and "accepted_A120" not in prod and "flux_trace.csv" not in prod)
    ck("LIGHT_BATH_SIX",len(pre["external_graph"]["light_bath"])==6)
    ck("NO_ARTIFICIAL_SEED",pre["external_graph"]["artificial_seed_or_floor"] is False)
    src=(ROOT/"SOURCE/build_and_run_transport.py").read_text()
    ck("FRESH_REACLIB_CONSTRUCTION","pyna.ReacLibLibrary()" in src and "original_A120_rate_register.csv" not in src and "accepted_A120" not in src and "flux_trace.csv" not in src)
    ck("ALL_NATIVE_BOUNDARY_CAPTURE_RULE","if h in native and d not in native and d[0]>=24" in src)
    ck("BETA_MINUS_TRANSPORT",'weak_type",None)=="beta_neg"' in src)
    ck("DUAL_INTEGRATORS","scheme==0" in (ROOT/"SOURCE/transport_core.py").read_text() and "Crank-Nicolson" in (ROOT/"SOURCE/transport_core.py").read_text())
    ck("OUTER_BOUNDARY_CONTROLS","for mx in (128,140,160)" in src)
    ck("SIXANCHOR_RUN","for eta in ETA:" in src)
    ck("FINAL_REGISTER_1_119","for A in range(1,120)" in (ROOT/"SOURCE/finalize.py").read_text())
    setup=(ROOT/"SETUP_TRANSPORT_ENV_WINDOWS.cmd").read_text()
    envlock=pre["transport_environment"]
    ck("TRANSPORT_ENV_ISOLATED",envlock["inherit_system_site_packages"] is False and "--system-site-packages" not in setup)
    ck("NUMPY_PIN",envlock["numpy_version"]=="2.4.6" and "numpy==2.4.6" in setup)
    ck("NUMBA_PIN",envlock["numba_version"]=="0.66.0" and "numba==0.66.0" in setup)
    ck("PYNUCASTRO_PIN",envlock["pynucastro_version"]=="2.11.0" and "pynucastro==2.11.0" in setup)
    ck("PIP_CHECK_REQUIRED",'-m pip check' in setup)
    ck("R02_REPAIR_SCOPE",(ROOT/"R02_TRANSPORT_ENVIRONMENT_DEPENDENCY_REPAIR.md").is_file())
    pys=sorted((ROOT/"SOURCE").glob("*.py"))
    for p in pys:py_compile.compile(str(p),doraise=True)
    print("PYTHON_COMPILE",f"{len(pys)}/{len(pys)}","PASS")
    bad=[];n=0
    for line in (ROOT/"MANIFEST.sha256").read_text().splitlines():
        if not line.strip():continue
        h,rel=line.split("  ",1);n+=1;p=ROOT/rel
        if not p.is_file() or sha(p)!=h:bad.append(rel)
    ck(f"PACKAGE_MANIFEST {n-len(bad)}/{n}",not bad)
    print("PRIMAT_NATIVE_BOUNDARY_FLUX_STATIC_VERIFY PASS")
if __name__=="__main__":main()
