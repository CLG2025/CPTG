from __future__ import annotations
import importlib.metadata,os,time,json
from pathlib import Path
import numpy as np
from common import *

CACHE=Path(os.environ.get("CPTG_PRIMAT_CACHE",r"D:\Downloads\PRIMAT_v0.3.2\cache"))
STD=("DoH","He3oH","Li7oH","YPBBN")

def params_for(eta):
    from primat.config import PRIMATConfig
    probe=PRIMATConfig({"Omegabh2":0.02242})
    omega=(eta*1e-10)/float(probe.Omegabh2_to_eta0b)
    return omega,{
      "Omegabh2":omega,"network":"large","amax":None,"strict_params":True,
      "numerical_precision":1e-10,"atol_large_LT":1e-26,
      "rate_grid_npts":4000,"rate_grid_T9_min":1e-3,"rate_grid_T9_max":10.0,
      "radiative_corrections":True,"finite_mass_corrections":True,"thermal_corrections":True,
      "spectral_distortions":True,"tau_n_normalization":True,"tau_n":878.4,"nuclear_qed_corrections":True,
      "mc_rate_rescale_cap":None,"cache_dir":str(CACHE),
      "output_time_evolution":False,"output_rates_time_evolution":False,"output_file":None,
      "verbose":False,"show_progress":False,"rescale_nuclear_rates":False}

def std_dict(r): return {k:float(r[k]) for k in STD}

def main():
    if importlib.metadata.version("primat")!="0.3.2": raise RuntimeError("PRIMAT 0.3.2 required")
    from primat.backend import run_bbn
    from primat.main import PRIMAT
    import primat.nuclear_network as nnmod

    refs=load_authority_baselines()
    gates=load_json(CONFIG/"FROZEN_PREREGISTRATION.json")["hard_gates"]
    outdir=OUTPUT/"NATIVE_TRAJECTORIES";outdir.mkdir(parents=True,exist_ok=True)
    summaries=[]

    for eta in ETA:
        omega,params=params_for(eta)
        print("PRIMAT_NATIVE_BOUNDARY_START",eta,flush=True)

        t0=time.perf_counter()
        c=run_bbn(params,force_backend="c")
        csec=time.perf_counter()-t0
        if len(c.get("Y_final",{}))<59: raise RuntimeError("C backend returned fewer than 59 final nuclides")

        captured=[]
        original=nnmod.solve_ivp
        def capture(fun,t_span,y0,*args,**kwargs):
            kw=dict(kwargs);kw["dense_output"]=True
            sol=original(fun,t_span,y0,*args,**kw)
            captured.append({"method":kw.get("method","RK45"),"rtol":kw.get("rtol"),"atol":kw.get("atol"),"sol":sol})
            return sol
        nnmod.solve_ivp=capture
        t1=time.perf_counter()
        try:
            P=PRIMAT(params=params);py=P.solve(progress=False)
        finally:
            nnmod.solve_ivp=original
        pysec=time.perf_counter()-t1

        if len(captured)!=3 or [x["method"] for x in captured]!=["LSODA","BDF","BDF"]:
            raise RuntimeError("unexpected PRIMAT Python solver sequence")
        lt=captured[-1]["sol"]
        if not lt.success or lt.sol is None: raise RuntimeError("PRIMAT LT dense solution failed")

        names=list(P.nucl._lt_net.species)
        az=[parse_primat_name(n) for n in names]
        maxA=max(a for a,z in az)
        if maxA!=int(gates["native_max_A_exact"]): raise RuntimeError(f"native max A {maxA} != 23")
        _,t_weak,t_nucl,t_end=P.nuclear._era_boundaries()
        npts=int(load_json(CONFIG/"FROZEN_PREREGISTRATION.json")["primat"]["trajectory_samples"])
        ts=np.geomspace(float(t_nucl),float(t_end),npts)
        Y=np.asarray(lt.sol(ts),float)
        if Y.shape!=(len(names),len(ts)): raise RuntimeError("trajectory shape mismatch")
        if not np.all(np.isfinite(Y)) or np.min(Y)<-1e-25: raise RuntimeError("invalid native trajectory")
        Y=np.maximum(Y,0.0)
        bg=P.background;cfg=P.cfg
        T_K=np.array([float(bg.T_of_t(float(t)))*cfg.MeV_to_Kelvin for t in ts])
        rho=np.array([float(bg.rhoB_BBN(float(t))) for t in ts])
        if not (np.all(np.isfinite(T_K)) and np.all(np.isfinite(rho)) and np.all(rho>0)): raise RuntimeError("invalid background trajectory")

        cstd=std_dict(c);pystd=std_dict(py);ref=refs[eta]
        c_ref={k:symmetric_rel(cstd[k],float(ref[k])) for k in STD}
        py_c={k:symmetric_rel(pystd[k],cstd[k]) for k in STD}
        if max(c_ref.values())>float(gates["primat_c_vs_authority_standard_max_relative"]):
            raise RuntimeError(f"C backend authority mismatch eta={eta}: {c_ref}")
        if max(py_c.values())>float(gates["primat_python_vs_c_standard_max_relative"]):
            raise RuntimeError(f"Python/C backend mismatch eta={eta}: {py_c}")

        npz=outdir/f"PRIMAT_NATIVE_TRAJECTORY_ETA{eta_tag(eta)}.npz"
        np.savez_compressed(npz,t_s=ts,T_K=T_K,rho_b_g_cm3=rho,
                            species=np.array(names,dtype="U16"),Y=Y)
        pyfinal={str(n):float(Y[i,-1]) for i,n in enumerate(names)}
        cfinal={str(k):float(v) for k,v in c.get("Y_final",{}).items()}
        meta={
          "schema":"cptg-primat-native-boundary-trajectory-v1","eta10":eta,"Omegabh2":omega,
          "primat_version":"0.3.2","network":"large","native_species_count":len(names),
          "native_species":names,"native_max_A":maxA,"t_nucl_s":float(t_nucl),"t_end_s":float(t_end),
          "trajectory_samples":len(ts),"c_backend_seconds":csec,"python_backend_seconds":pysec,
          "standard_C":cstd,"standard_python":pystd,
          "C_vs_authority_relative":c_ref,"Python_vs_C_relative":py_c,
          "Y_final_C":cfinal,"Y_final_python":pyfinal,
          "npz_path":npz.relative_to(ROOT).as_posix()
        }
        mp=outdir/f"PRIMAT_NATIVE_META_ETA{eta_tag(eta)}.json";atomic_json(mp,meta)
        summaries.append(meta)
        print("PRIMAT_NATIVE_BOUNDARY_PASS",eta,"MAX_A",maxA,
              "C_AUTH_MAXREL",max(c_ref.values()),"PY_C_MAXREL",max(py_c.values()),flush=True)

    files=[]
    for p in sorted(outdir.glob("*")):
        if p.is_file():
            files.append({"path":p.relative_to(ROOT).as_posix(),"sha256":sha_file(p),"size_bytes":p.stat().st_size})
    freeze={"schema":"cptg-primat-native-trajectory-freeze-v1","eta_count":6,"files":files}
    atomic_json(OUTPUT/"NATIVE_TRAJECTORY_FREEZE.json",freeze)
    qual={
      "schema":"cptg-primat-native-trajectory-qualification-v1","pass":True,"eta_count":6,
      "native_max_A":23,
      "max_C_vs_authority_relative":max(max(x["C_vs_authority_relative"].values()) for x in summaries),
      "max_python_vs_C_relative":max(max(x["Python_vs_C_relative"].values()) for x in summaries),
      "trajectory_freeze_sha256":sha_file(OUTPUT/"NATIVE_TRAJECTORY_FREEZE.json")
    }
    atomic_json(EVIDENCE/"NATIVE_TRAJECTORY_QUALIFICATION.json",qual)
    print("PRIMAT_NATIVE_TRAJECTORIES_FROZEN",qual["trajectory_freeze_sha256"])
    print("PRIMAT_NATIVE_TRAJECTORY_QUALIFICATION PASS")

if __name__=="__main__":main()
