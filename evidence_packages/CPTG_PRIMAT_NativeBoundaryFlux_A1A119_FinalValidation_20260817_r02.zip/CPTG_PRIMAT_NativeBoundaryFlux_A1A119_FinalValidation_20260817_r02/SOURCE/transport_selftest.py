from __future__ import annotations
import numpy as np
from transport_core import solve_triangular

def main():
    # 0 -> 1 -> 2 with constant rates, source into 0.
    t=np.linspace(0.0,1.0,65)
    ns=3;nt=len(t)
    source=np.zeros((ns,nt));source[0,:]=1.0
    loss=np.zeros((ns,nt));loss[0,:]=0.8;loss[1,:]=0.5
    inc_src=np.array([0,1],dtype=np.int64)
    inc_start=np.array([0,0,1,2],dtype=np.int64)
    inc_coeff=np.zeros((2,nt));inc_coeff[0,:]=0.8;inc_coeff[1,:]=0.5
    be=solve_triangular(t,source,loss,inc_src,inc_start,inc_coeff,8,0)
    cn=solve_triangular(t,source,loss,inc_src,inc_start,inc_coeff,8,1)
    if not (np.all(np.isfinite(be)) and np.all(np.isfinite(cn)) and np.all(be>=0) and np.all(cn>=0)):
        raise RuntimeError("transport core nonfinite/negative")
    if np.max(np.abs(be-cn))/max(np.max(np.abs(cn)),1e-300)>0.01:
        raise RuntimeError("transport core BE/CN disagreement")
    zero=solve_triangular(t,source*0,loss,inc_src,inc_start,inc_coeff,8,1)
    if not np.array_equal(zero,np.zeros_like(zero)): raise RuntimeError("zero-source selftest")
    half=solve_triangular(t,source*0.5,loss,inc_src,inc_start,inc_coeff,8,1)
    double=solve_triangular(t,source*2,loss,inc_src,inc_start,inc_coeff,8,1)
    if np.max(np.abs(half*2-cn))>1e-12 or np.max(np.abs(double/2-cn))>1e-12:
        raise RuntimeError("linearity selftest")
    print("TRANSPORT_CORE_SELFTEST PASS")
if __name__=="__main__":main()
