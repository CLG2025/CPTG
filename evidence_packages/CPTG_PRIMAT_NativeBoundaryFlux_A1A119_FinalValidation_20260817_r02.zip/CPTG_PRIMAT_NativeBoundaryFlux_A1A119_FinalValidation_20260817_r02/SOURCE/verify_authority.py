from __future__ import annotations
import csv,json
from common import *
def main():
    b=load_json(CONFIG/"PRIMAT_AUTHORITY_BINDING.json")
    if b["authority_archive_sha256"]!="b41c8ee49477d8330deb56c85a230d8dcc1d4bba80a1405251a4d6ea7f9b3205":
        raise RuntimeError("authority archive SHA mismatch")
    for name,h in b["reference_files"].items():
        p=REF/"PRIMAT_AUTHORITY"/name
        if not p.is_file() or sha_file(p)!=h: raise RuntimeError("authority reference mismatch "+name)
    s=load_json(REF/"PRIMAT_AUTHORITY/FULL_NETWORK_AUTHORITY_SUMMARY.json")
    if s.get("decision")!="PASS" or s.get("rows_committed")!=20550 or s.get("reactions")!=428:
        raise RuntimeError("PRIMAT authority summary not PASS")
    h=load_json(CONFIG/"HISTORICAL_EXCLUSION.json")
    if h.get("status")!="EXCLUDED_FROM_NEW_SCIENTIFIC_TEST" or any(h[k] for k in
       ["opened_by_production_scripts","numerical_inputs_imported","seed_values_imported","rate_records_imported","thresholds_imported","result_targets_imported"]):
        raise RuntimeError("historical exclusion invalid")
    print("PRIMAT_AUTHORITY_BINDING PASS")
    print("PRIMAT_ROWS 20550 /20550")
    print("PRIMAT_REACTIONS 428 /428")
    print("HISTORICAL_POSTSILICON_NUMERICAL_INPUTS 0")
if __name__=="__main__":main()
