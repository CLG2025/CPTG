from __future__ import annotations
import datetime,zipfile,json
from pathlib import Path
from common import *

def main():
    fin=EVIDENCE/"FINAL_VALIDATION_SUMMARY.json"
    if not fin.is_file() or load_json(fin).get("decision")!="PASS":
        raise RuntimeError("final PASS summary required before export")
    stamp=datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    out=ROOT.parent/f"CPTG_PRIMAT_NativeBoundaryFlux_A1A119_FINAL_EVIDENCE_{stamp}.zip"
    include=[]
    for rel in ("CONFIG","REFERENCE","SOURCE","EVIDENCE","OUTPUT","RESULTS","PAPER_DATA"):
        include.extend(p for p in (ROOT/rel).rglob("*") if p.is_file())
    include += [ROOT/"README_FIRST.txt",ROOT/"SCIENTIFIC_PROTOCOL.md",ROOT/"MANIFEST.sha256"]
    include=sorted(set(p for p in include if p.is_file()),key=lambda p:p.relative_to(ROOT).as_posix())
    entries={}
    with zipfile.ZipFile(out,"w",zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in include:
            rel=p.relative_to(ROOT).as_posix();data=p.read_bytes()
            z.writestr(rel,data);entries[rel]=__import__("hashlib").sha256(data).hexdigest()
        man="".join(f"{h}  {rel}\n" for rel,h in sorted(entries.items()))
        z.writestr("FINAL_EVIDENCE_MANIFEST.sha256",man.encode())
    with zipfile.ZipFile(out) as z:
        if z.testzip() is not None: raise RuntimeError("ZIP CRC fail")
        for line in z.read("FINAL_EVIDENCE_MANIFEST.sha256").decode().splitlines():
            h,rel=line.split("  ",1)
            if __import__("hashlib").sha256(z.read(rel)).hexdigest()!=h: raise RuntimeError("manifest fail "+rel)
    h=sha_file(out);side=out.with_suffix(out.suffix+".sha256.txt");side.write_text(f"{h}  {out.name}\n",encoding="utf-8")
    print("PRIMAT_A1A119_FINAL_EVIDENCE_EXPORT PASS")
    print("ZIP",out)
    print("SHA256",h)

if __name__=="__main__":main()
