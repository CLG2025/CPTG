# Scientific Protocol — PRIMAT Native Boundary-Flux A=1–119 Final Validation

## Scientific question

Starting from fresh PRIMAT v0.3.2 large-network native trajectories, does a separately
preregistered prescribed-bath external transport graph provide a structurally gap-free,
numerically stable continuation through mass sector A=119 without importing any historical
post-silicon trajectory, seed abundance, rate register, output value, fitted threshold, or
PASS/FAIL decision?

## What makes this a new test

This is not a network-name substitution and not a replay of the previous Si-30 calculation.

The native source is the full PRIMAT time-dependent state at six eta10 anchors. The external
source is constructed from every allowed fresh ReacLib radiative capture that crosses from a
PRIMAT-native heavy nucleus into A>23. The prescribed light bath contains n, p, D, T, He-3,
and He-4. External heavy nuclides then evolve through the same radiative light-particle
captures and beta-minus transport.

There is no selected Si-30 source, no fixed 1e-46 abundance floor, and no inherited A=31–119
target vector.

## Native authority layer

PRIMAT v0.3.2 large network is run fresh at eta10:
6.044, 6.080, 6.094, 6.106, 6.128, 6.134.

The Python-native solver is used only because it exposes the dense native LT state and
background trajectory required by the boundary-flux calculation. The C backend is run at
the same configuration and must agree with the accepted PRIMAT authority observables.

## External graph

Allowed transport classes:

1. radiative capture of one prescribed light-bath nucleus on one heavy nucleus, with a
   single heavier nuclear product and exact A/Z addition;
2. one-body beta-minus transport at fixed A and Z+1.

The graph is acyclic under ordering by (A,Z). The light bath is prescribed from PRIMAT and
is not depleted by the external calculation. This is a controlled linear extension, not
a claim of native PRIMAT heavy-network coverage.

## Falsification gates

The exact hard gates are frozen in CONFIG/FROZEN_PREREGISTRATION.json. They include native
PRIMAT authority consistency, six-anchor source positivity, structural A=24–119 reachability,
zero-source behavior, source linearity, absolute/normalized reconstruction, temporal
convergence, independent-integrator agreement, outer-boundary invariance, and positive
source-normalized support through A=119.

No gate may be changed after production results exist.
