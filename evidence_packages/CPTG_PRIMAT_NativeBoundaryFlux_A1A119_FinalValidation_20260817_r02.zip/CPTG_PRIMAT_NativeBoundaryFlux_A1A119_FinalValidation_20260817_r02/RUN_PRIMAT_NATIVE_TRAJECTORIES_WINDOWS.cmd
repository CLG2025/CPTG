@echo off
setlocal
cd /d "%~dp0"
set "CPTG_PRIMAT_CACHE=D:\Downloads\PRIMAT_v0.3.2\cache"
set "OMP_NUM_THREADS=1"
set "OPENBLAS_NUM_THREADS=1"
set "MKL_NUM_THREADS=1"
"D:\Downloads\PRIMAT_v0.3.2\venv\Scripts\python.exe" -u SOURCE\extract_primat_native_trajectories.py
exit /b %ERRORLEVEL%
