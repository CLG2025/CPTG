@echo off
setlocal
cd /d "%~dp0"
call RUN_STATIC_VERIFY_WINDOWS.cmd
if errorlevel 1 exit /b 1
call RUN_VERIFY_PRIMAT_AUTHORITY_WINDOWS.cmd
if errorlevel 1 exit /b 1
call RUN_PRIMAT_NATIVE_TRAJECTORIES_WINDOWS.cmd
if errorlevel 1 exit /b 1
call RUN_TRANSPORT_VALIDATION_WINDOWS.cmd
if errorlevel 1 exit /b 1
call RUN_FINALIZE_WINDOWS.cmd
if errorlevel 1 exit /b 1
call EXPORT_FINAL_EVIDENCE_WINDOWS.cmd
exit /b %ERRORLEVEL%
