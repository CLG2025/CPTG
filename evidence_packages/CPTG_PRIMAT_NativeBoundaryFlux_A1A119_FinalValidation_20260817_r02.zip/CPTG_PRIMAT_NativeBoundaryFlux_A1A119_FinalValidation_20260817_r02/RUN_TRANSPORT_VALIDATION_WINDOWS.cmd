@echo off
setlocal
cd /d "%~dp0"
set "NUMBA_CACHE_DIR=D:\Downloads\CPTG_PRIMAT_A1A119_NUMBA_CACHE_r02"
set "PYTHONDONTWRITEBYTECODE=1"
"D:\Downloads\CPTG_PRIMAT_A1A119_TRANSPORT_ENV_r02\Scripts\python.exe" -u SOURCE\transport_selftest.py
if errorlevel 1 exit /b 1
"D:\Downloads\CPTG_PRIMAT_A1A119_TRANSPORT_ENV_r02\Scripts\python.exe" -u SOURCE\build_and_run_transport.py
exit /b %ERRORLEVEL%
