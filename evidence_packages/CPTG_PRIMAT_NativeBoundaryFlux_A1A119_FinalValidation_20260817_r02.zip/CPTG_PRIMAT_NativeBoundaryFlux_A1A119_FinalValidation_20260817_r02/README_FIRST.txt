# CPTG PRIMAT Native Boundary-Flux A=1–119 Final Validation

This package is a **brand-new test**. It is not a one-for-one replacement of any historical
post-silicon campaign.

## Historical numerical exclusion

The uploaded historical archive is recorded only by identity:

```text
Complete-Processed-Nuclear-Chain_A1-A119_ComputationalCompanion_20260721_r02_PACKAGE(1).zip
SHA-256: 0247c32e7abfb5e4446eb7ba2c5a1ecc6424493c93757f2fee3dee8a9be37d7e
```

Production scripts do not open it. They import zero historical trajectories, seeds, rate tables,
A=31–119 values, thresholds, or decisions.

## New test object

Fresh PRIMAT v0.3.2 large-network trajectories are generated at all six accepted eta10 anchors.
The complete native time-dependent light bath and heavy-state trajectory are then used to construct
a new external source from every fresh ReacLib radiative capture that crosses from a PRIMAT-native
heavy nuclide into A>23.

Prescribed light bath:

```text
n
p
D
T
He-3
He-4
```

External propagation uses those radiative captures plus beta-minus transport.

There is no Si-30 seed and no artificial abundance floor.

## Authority binding

The accepted PRIMAT primary authority is bound to:

```text
CPTG_PRIMAT_PaperReadyValidationEvidence_20260817_r02.zip
SHA-256: b41c8ee49477d8330deb56c85a230d8dcc1d4bba80a1405251a4d6ea7f9b3205
```

Small authority summaries and the six accepted baseline vectors are included under
`REFERENCE/PRIMAT_AUTHORITY/`.

## Windows environment

Existing PRIMAT:

```text
D:\Downloads\PRIMAT_v0.3.2
D:\Downloads\PRIMAT_v0.3.2\venv\Scripts\python.exe
D:\Downloads\PRIMAT_v0.3.2\cache
```

General CPTG Python:

```text
D:\Downloads\ChatGPT\cptg-cmb-like\Scripts\python.exe
```

A separate transport environment is created at:

```text
D:\Downloads\CPTG_PRIMAT_A1A119_TRANSPORT_ENV_r02
```

so the accepted PRIMAT environment is not modified. The transport venv is fully isolated and does not inherit system site packages.

## Execution order

### 1. Static verification

```cmd
RUN_STATIC_VERIFY_WINDOWS.cmd
```

Expected:

```text
PRIMAT_NATIVE_BOUNDARY_FLUX_STATIC_VERIFY PASS
```

### 2. Verify accepted PRIMAT authority binding

```cmd
RUN_VERIFY_PRIMAT_AUTHORITY_WINDOWS.cmd
```

Expected:

```text
PRIMAT_AUTHORITY_BINDING PASS
PRIMAT_ROWS 20550 /20550
PRIMAT_REACTIONS 428 /428
HISTORICAL_POSTSILICON_NUMERICAL_INPUTS 0
```

### 3. Create isolated transport environment

```cmd
SETUP_TRANSPORT_ENV_WINDOWS.cmd
```

This creates a clean isolated transport environment and pins:

```text
numpy==2.4.6
numba==0.66.0
pynucastro==2.11.0
```

The setup runs `pip check` and exact version/import checks.

Expected ending:

```text
TRANSPORT_ENV_NUMPY 2.4.6
TRANSPORT_ENV_NUMBA 0.66.0
TRANSPORT_ENV_PYNUCASTRO 2.11.0
TRANSPORT_ENV_SETUP PASS
```

### 4. Run fresh PRIMAT native trajectory campaign

```cmd
RUN_PRIMAT_NATIVE_TRAJECTORIES_WINDOWS.cmd
```

This performs six fresh PRIMAT trajectory calculations plus C/Python endpoint consistency checks.

Expected final lines:

```text
PRIMAT_NATIVE_TRAJECTORIES_FROZEN <sha256>
PRIMAT_NATIVE_TRAJECTORY_QUALIFICATION PASS
```

### 5. Run new external transport validation

```cmd
RUN_TRANSPORT_VALIDATION_WINDOWS.cmd
```

Expected ending on success:

```text
PRIMAT_NATIVE_BOUNDARY_FLUX_SIXANCHOR PASS
```

### 6. Finalize the A=1–119 evidence/register

```cmd
RUN_FINALIZE_WINDOWS.cmd
```

Required:

```text
PRIMAT_A1A119_FINAL_VALIDATION PASS
HISTORICAL_NUMERICAL_INPUTS_USED False
```

### 7. Export the final evidence archive

```cmd
EXPORT_FINAL_EVIDENCE_WINDOWS.cmd
```

Expected:

```text
PRIMAT_A1A119_FINAL_EVIDENCE_EXPORT PASS
ZIP D:\Downloads\CPTG_PRIMAT_NativeBoundaryFlux_A1A119_FINAL_EVIDENCE_<timestamp>.zip
SHA256 <sha256>
```

## Paper update

Do not update the manuscript with historical post-silicon numbers.

After final PASS, the newly generated `PAPER_DATA/PRIMAT_A1A119_RESULTS.tex` and
`RESULTS/A1_A119_CENTRAL_AND_ENVELOPE.csv` are the controlling numerical objects for the
new paper revision.


## r02 environment repair

See `R02_TRANSPORT_ENVIRONMENT_DEPENDENCY_REPAIR.md`. No scientific execution from r01 is inherited; the repair is pre-execution dependency plumbing only.
