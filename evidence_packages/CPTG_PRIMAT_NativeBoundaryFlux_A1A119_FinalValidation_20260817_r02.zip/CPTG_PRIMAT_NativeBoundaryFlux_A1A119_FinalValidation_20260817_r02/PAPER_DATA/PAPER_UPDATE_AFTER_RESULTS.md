# Paper update after new results

The historical companion manuscript is not copied into the scientific execution package because
its numerical post-silicon values are explicitly excluded from the new test.

After `RUN_FINALIZE_WINDOWS.cmd` returns `PRIMAT_A1A119_FINAL_VALIDATION PASS`, this package
creates:

- `PAPER_DATA/PRIMAT_A1A119_RESULTS.tex`
- `PAPER_DATA/PRIMAT_A1A119_RESULTS.md`
- `RESULTS/A1_A119_SIXANCHOR_REGISTER.csv`
- `RESULTS/A1_A119_CENTRAL_AND_ENVELOPE.csv`

Those files are the controlling numerical inputs for the next manuscript revision.

The manuscript revision must remove the old AlterBBN trajectory description and old Si-30-seeded
A=31–119 numerical table rather than relabeling them. The new methods section should describe the
six-anchor PRIMAT native trajectory qualification and all-native-boundary prescribed-light-bath
transport object. The limitation statement must continue to distinguish native PRIMAT authority
from reduced-graph heavy-sector continuation.
