# PRIMAT Paper-Ready Validation Evidence

## Validation status

**PRIMAT v0.3.2 is validated as the primary native numerical authority for the completed CPTG primordial reaction campaign within the scope defined in `VALIDATION_PROTOCOL.md`.**

## Full-network numerical authority

The frozen large-network campaign contains:

- **20,550 / 20,550 committed rows**
- **428 / 428 native reactions**
- **6 eta10 anchors**
- **8 nonzero perturbation branches**
- **10,272 / 10,272 matched plus/minus pairs**
- **2,568 / 2,568 complete eight-branch ladders**
- **856 direct rate-proof records covering 428 / 428 reactions**

Independent reconstruction from the registered authority checkpoint gives:

- **0 ledger/commit/request/result identity discrepancies**
- **0 request/result field mismatches**
- **0 row hash-integrity discrepancies**
- **0 nonempty stderr rows**
- **20,550 / 20,550 attempt-1 completions**
- backend identity: **C**
- PRIMAT identity: **0.3.2**
- all standard outputs finite
- all **59 final nuclide abundances finite and positive on every row**

The preproduction C/Python qualification passes. The largest recorded relative difference among the exact stored observables `DoH`, `He3oH`, `Li7oH`, and `YPBBN` is `2.5951186e-06`.

## Six-anchor native source/Jacobian validation

The mechanism validation contains:

- **14 mapped light-sector reactions**
- **6 eta10 anchors**
- **84 / 84 variational endpoint predictions**
- **48 / 48 primary resolved reaction-anchor tests**
- **66 / 84 cases at or above the 1e-4 reference-norm reporting floor**
- **6,283 active native source samples**

All 84 predictions were SHA-256 frozen before the perturbed-endpoint reference coefficients were opened.

Prediction freeze SHA-256:

`679e3e6fc7432c0592004b9bf0985b0756323ceb327050f3303ca6c816f31bff`

Independent reconstruction gives:

- maximum source-direction residual: `3.1737572e-16`
- maximum source baryon residual: `4.4368175e-16`
- worst primary endpoint-vector discrepancy: `0.00036762871` = **0.036763%**
- minimum primary endpoint cosine: `0.999999992094`
- worst BDF/Radau cross-relative difference: `5.8248229e-07`
- minimum BDF/Radau cross-cosine: `0.999999999999974`
- maximum six-anchor baseline Python/C relative difference: `2.6317348e-06`

Every frozen qualification gate passes.

For `d_p__He3_g`, the largest six-anchor endpoint-vector discrepancy across either variational solver is `0.00016221511` (**0.01622%**).

## Method chronology

The exact prediction and evaluation source used for the six-anchor validation is included under `02_NATIVE_MECHANISM_VALIDATION/METHOD_SOURCE/`.

The prediction source contains no access to the authoritative endpoint-coefficient file. The evaluation source checks the completed 84-row prediction freeze and its SHA-256 before opening the endpoint-coefficient reference. The prediction path uses PRIMAT's native reaction RHS contribution and analytic Jacobian and requires both BDF and Radau propagation. No endpoint-fit routine is present in the prediction or evaluation source.

## Paper-safe conclusion

Within the tested primordial domain, the accepted evidence supports the following statement:

> A complete 428-reaction PRIMAT v0.3.2 campaign establishes native numerical authority over 20,550 frozen reaction-response rows. A separate six-anchor source/Jacobian validation then propagates fixed reaction-source geometry through PRIMAT's native analytic Jacobian and reproduces the full-network first-order endpoint susceptibilities across 48 primary resolved reaction-anchor cases with worst vector discrepancy below 3.68e-4 and minimum direction cosine above 0.999999992, without fitting the perturbed endpoint coefficients.

## Scope boundary

This evidence supports PRIMAT-native first-order primordial/light-sector validation over the six tested eta10 anchors and the mapped 14-reaction mechanism set. It does not, by itself, establish second-order variational closure, a network-independent static endpoint map, or native heavy-nucleus validation.
